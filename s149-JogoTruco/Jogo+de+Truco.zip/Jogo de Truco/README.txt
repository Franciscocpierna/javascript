JOGO DE TRUCO PAULISTA - HTML, CSS E JAVASCRIPT
================================================

COMO ABRIR
----------
1. Extraia a pasta do arquivo ZIP.
2. Abra o arquivo index.html em um navegador moderno (Chrome, Edge ou Firefox).
3. Não é necessário instalar Python, Node.js ou qualquer biblioteca.

MODOS
-----
- Mano a Mano: Jogador x IA.
- 4 Jogadores: modo tradicional em duplas, com Você + IA Parceira contra IA 2 + IA 3.

RECURSOS
--------
- Interface profissional e responsiva.
- Truco Paulista com baralho de 40 cartas.
- Vira e manilha variável.
- Partida até 12 pontos.
- Truco, Seis, Nove e Doze.
- Mão de 11 valendo 3 pontos, sem aumento.
- Carta fechada da segunda vaza em diante.
- Três níveis de IA: Fácil, Normal e Difícil.
- IAs jogam, avaliam cartas, blefam, pedem aumento, aceitam, aumentam ou correm.
- Modo 4 jogadores com 3 IAs e ordem de jogada em sentido horário.
- Sons WAV reaproveitados do projeto original.
- Ranking persistente no navegador usando localStorage.
- Vitória no ranking: +10 pontos.
- Derrota no ranking: até -10 pontos, sem ficar negativo.
- Ajuda completa dentro do jogo.

ATALHOS
-------
T = pedir Truco / próximo aumento.
C = ativar/desativar carta fechada (a partir da 2ª vaza).
S = ligar/desligar som.
ESC = solicitar retorno ao menu.

ARQUIVOS PRINCIPAIS
-------------------
index.html
css/estilo.css
js/regras.js
js/ia.js
js/app.js
sons/*.wav

OBSERVAÇÃO SOBRE O RANKING
--------------------------
O ranking utiliza localStorage, recurso nativo do navegador que permite manter
os dados das partidas localmente, sem servidor e sem bibliotecas externas.

ESTRUTURA DO LAYOUT
------------------------
- A tela do jogo utiliza três áreas: status/histórico, mesa/cartas e ações/atalhos.
- O layout funciona adequadamente em 100% de zoom em notebooks e monitores comuns.
- A mesa ocupa o espaço disponível da janela e evita corte vertical.
- Cartas, textos, botões e informações possuem dimensões adequadas para facilitar a leitura.
- Em telas menores, o layout utiliza automaticamente uma organização vertical responsiva.

RECURSOS DE JOGABILIDADE
------------------------------
- A Mão de 11 mostra claramente as cartas do jogador antes da decisão.
- Pedidos de Truco, Seis, Nove e Doze feitos pela IA exibem as cartas do jogador na janela de resposta.
- Os modais de decisão preservam a visualização da mão do jogador e não escondem as cartas.
- Quando a IA aceita um pedido, aparece um aviso grande e rápido sem bloquear a mesa.
- Quando a IA corre de um pedido, aparece um aviso grande e rápido antes do encerramento da mão.
- A indicação de MANILHA possui destaque visual para facilitar a leitura.

DECISÕES NO MODO 4 JOGADORES
-----------------------------
No modo 4 Jogadores (Duplas), quando a dupla adversária pedir Truco, Seis,
Nove ou Doze, a janela de decisão mostra separadamente:
- Suas cartas;
- As cartas restantes da IA Parceira;
- A Vira e a Manilha.

As cartas das IAs adversárias permanecem ocultas. As cartas da IA Parceira
são reveladas somente nas janelas em que sua dupla precisa tomar uma decisão.
O mesmo painel de equipe também é utilizado na decisão da Mão de 11.

- Indicador permanente na tela mostrando PARTIDA VALENDO 1, 3, 6, 9 ou 12 pontos conforme a aposta atual.

MODOS DE JOGO
-------------
- A seleção Mano a Mano é lida diretamente do botão marcado no menu.
- Mano a Mano cria exatamente 2 participantes: Jogador + 1 IA Rival.
- 4 Jogadores cria exatamente 4 participantes: Jogador + IA Parceira + 2 IAs adversárias.
- A seleção do menu e o estado interno permanecem sincronizados ao abrir o jogo.
