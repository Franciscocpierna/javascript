// Cria uma função encapsulada para organizar e isolar a lógica deste módulo.
// `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
// `function` = define uma nova função.
// `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
// `{` = abre um bloco de código ou objeto.
(function () {

  // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
  // `'use strict'` = texto literal utilizado nesta instrução.
  'use strict';

  // Declara `C` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `=>` = define uma função de seta.
  // `window` = representa o objeto global da janela do navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `TrucoCore` = objeto que reúne regras e funções centrais do Jogo de Truco.
  const C = () => window.TrucoCore;

  // Declara `IA` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `=>` = define uma função de seta.
  // `window` = representa o objeto global da janela do navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `TrucoIA` = objeto que reúne a lógica de decisão da inteligência artificial.
  const IA = () => window.TrucoIA;

  // Declara `$` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
  // `=>` = define uma função de seta.
  // `document` = representa o documento HTML carregado no navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `getElementById` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a get element by id.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `getElementById` = localiza um elemento pelo atributo id.
  const $ = id => document.getElementById(id);

  // Cria o catálogo de efeitos sonoros utilizados durante a partida.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `sons` = objeto que associa nomes de eventos aos arquivos de áudio correspondentes.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de código ou objeto.
  const sons = {

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `carta` = representa uma carta do baralho.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'sons/carta.wav'` = caminho do arquivo de som `carta.wav` utilizado neste evento do jogo.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
    // `'sons/carta_fechada.wav'` = caminho do arquivo de som `carta_fechada.wav` utilizado neste evento do jogo.
    // `novaMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nova mao.
    // `'sons/nova_mao.wav'` = caminho do arquivo de som `nova_mao.wav` utilizado neste evento do jogo.
    carta: 'sons/carta.wav', fechada: 'sons/carta_fechada.wav', novaMao: 'sons/nova_mao.wav',

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `chamada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chamada.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'sons/chamada.wav'` = caminho do arquivo de som `chamada.wav` utilizado neste evento do jogo.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `aceitar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aceitar.
    // `'sons/aceitar.wav'` = caminho do arquivo de som `aceitar.wav` utilizado neste evento do jogo.
    // `correr` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a correr.
    // `'sons/correr.wav'` = caminho do arquivo de som `correr.wav` utilizado neste evento do jogo.
    // `aumentar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aumentar.
    // `'sons/aumentar.wav'` = caminho do arquivo de som `aumentar.wav` utilizado neste evento do jogo.
    chamada: 'sons/chamada.wav', aceitar: 'sons/aceitar.wav', correr: 'sons/correr.wav', aumentar: 'sons/aumentar.wav',

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `vitoriaVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitoria vaza.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'sons/vaza_vitoria.wav'` = caminho do arquivo de som `vaza_vitoria.wav` utilizado neste evento do jogo.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `derrotaVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a derrota vaza.
    // `'sons/vaza_derrota.wav'` = caminho do arquivo de som `vaza_derrota.wav` utilizado neste evento do jogo.
    // `empate` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a empate.
    // `'sons/empate.wav'` = caminho do arquivo de som `empate.wav` utilizado neste evento do jogo.
    vitoriaVaza: 'sons/vaza_vitoria.wav', derrotaVaza: 'sons/vaza_derrota.wav', empate: 'sons/empate.wav',

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `vitoriaMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitoria mao.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'sons/mao_vitoria.wav'` = caminho do arquivo de som `mao_vitoria.wav` utilizado neste evento do jogo.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `derrotaMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a derrota mao.
    // `'sons/mao_derrota.wav'` = caminho do arquivo de som `mao_derrota.wav` utilizado neste evento do jogo.
    vitoriaMao: 'sons/mao_vitoria.wav', derrotaMao: 'sons/mao_derrota.wav',

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `vitoriaPartida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitoria partida.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'sons/partida_vitoria.wav'` = caminho do arquivo de som `partida_vitoria.wav` utilizado neste evento do jogo.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `derrotaPartida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a derrota partida.
    // `'sons/partida_derrota.wav'` = caminho do arquivo de som `partida_derrota.wav` utilizado neste evento do jogo.
    vitoriaPartida: 'sons/partida_vitoria.wav', derrotaPartida: 'sons/partida_derrota.wav'

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  };

  // Declara `MODOS_VALIDOS` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `MODOS_VALIDOS` = constante utilizada para armazenar ou configurar o valor relacionado a modos validos.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `new` = cria uma nova instância a partir da classe ou construtor informado.
  // `Set` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `[` = abre uma lista, índice ou acesso por chave.
  // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `'quatro'` = identificador do modo de jogo `4 Jogadores`.
  // `]` = fecha uma lista, índice ou acesso por chave.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `Set` = cria uma coleção que não permite valores duplicados.
  const MODOS_VALIDOS = new Set(['duelo', 'quatro']);

  // Inicializa o modo de jogo selecionado pelo usuário.
  // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
  // `modoSelecionado` = armazena o modo de jogo escolhido no menu.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
  let modoSelecionado = 'duelo';

  // Declara `somLigado` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
  // `somLigado` = indica se os efeitos sonoros estão ativados.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `true` = valor lógico verdadeiro.
  let somLigado = true;

  // Inicializa a variável que armazenará todo o estado da partida.
  // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
  // `jogo` = armazena o estado atual da partida.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `null` = representa ausência intencional de valor.
  let jogo = null;

  // Declara `temporizadorToast` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
  // `temporizadorToast` = identificador utilizado para controlar o temporizador relacionado a temporizador toast.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `null` = representa ausência intencional de valor.
  let temporizadorToast = null;

  // Declara `temporizadorAvisoAposta` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
  // `temporizadorAvisoAposta` = identificador utilizado para controlar o temporizador relacionado a temporizador aviso aposta.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `null` = representa ausência intencional de valor.
  let temporizadorAvisoAposta = null;

  // Declara `temporizadores` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
  // `temporizadores` = armazena os identificadores dos temporizadores ativos.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, índice ou acesso por chave.
  // `]` = fecha uma lista, índice ou acesso por chave.
  let temporizadores = [];

  // Define a função `agendar` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `agendar` = nome da função responsável pela operação relacionada a agendar.
  // `funcao` = parâmetro recebido pela função para fornecer o valor relacionado a funcao.
  // `ms` = parâmetro recebido pela função para fornecer o valor relacionado a ms.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function agendar(funcao, ms) {

    // Declara `id` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `setTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set timeout.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `setTimeout` = agenda a execução de uma função após o intervalo informado.
    const id = setTimeout(() => {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `temporizadores` = armazena os identificadores dos temporizadores ativos.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `t` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a t.
      // `=>` = define uma função de seta.
      // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
      // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
      temporizadores = temporizadores.filter(t => t !== id);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `funcao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a funcao.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      funcao();

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `}` = fecha um bloco de código ou objeto.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `ms` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ms.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    }, ms);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `temporizadores` = armazena os identificadores dos temporizadores ativos.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `push` = adiciona um novo elemento ao final da lista.
    temporizadores.push(id);

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
    return id;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `cancelarTemporizadores` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `cancelarTemporizadores` = nome da função responsável pela operação relacionada a cancelar temporizadores.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function cancelarTemporizadores() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `temporizadores` = armazena os identificadores dos temporizadores ativos.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `clearTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a clear timeout.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `forEach` = executa uma função para cada elemento da coleção.
    // `clearTimeout` = cancela um temporizador agendado.
    temporizadores.forEach(clearTimeout);

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `temporizadores` = armazena os identificadores dos temporizadores ativos.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `]` = fecha uma lista, índice ou acesso por chave.
    temporizadores = [];

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a clear timeout.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `temporizadorAvisoAposta` = identificador utilizado para controlar o temporizador relacionado a temporizador aviso aposta.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `clearTimeout` = cancela um temporizador agendado.
    clearTimeout(temporizadorAvisoAposta);

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `temporizadorAvisoAposta` = identificador utilizado para controlar o temporizador relacionado a temporizador aviso aposta.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `null` = representa ausência intencional de valor.
    temporizadorAvisoAposta = null;

    // Declara `aviso` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `aviso` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aviso-aposta'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const aviso = $('aviso-aposta');

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `aviso` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'aviso-aposta'` = texto literal utilizado nesta instrução.
    if (aviso) aviso.className = 'aviso-aposta';

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `tocar` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `tocar` = nome da função responsável pela operação relacionada a tocar.
  // `nome` = parâmetro recebido pela função para fornecer o valor relacionado a nome.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function tocar(nome) {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `somLigado` = indica se os efeitos sonoros estão ativados.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `sons` = objeto que associa nomes de eventos aos arquivos de áudio correspondentes.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    if (!somLigado || !sons[nome]) return;

    // Inicia um bloco protegido para executar uma operação que pode gerar erro.
    // `try` = inicia um bloco protegido para tratamento de possíveis erros.
    // `{` = abre um bloco de código ou objeto.
    try {

      // Declara `audio` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `audio` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a audio.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `new` = cria uma nova instância a partir da classe ou construtor informado.
      // `Audio` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a audio.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `sons` = objeto que associa nomes de eventos aos arquivos de áudio correspondentes.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `Audio` = cria um objeto de áudio para reproduzir um arquivo sonoro.
      const audio = new Audio(sons[nome]);

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `audio` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a audio.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `volume` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a volume.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `.55` = nível de volume do áudio, em uma escala numérica utilizada pelo navegador.
      audio.volume = .55;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `audio` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a audio.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `play` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a play.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `catch` = captura um erro ocorrido no bloco try.
      // `=>` = define uma função de seta.
      // `{` = abre um bloco de código ou objeto.
      // `}` = fecha um bloco de código ou objeto.
      // `play` = inicia a reprodução do áudio.
      audio.play().catch(() => {});

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `}` = fecha um bloco de código ou objeto.
    // `catch` = captura um erro ocorrido no bloco try.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `_` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a  .
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    } catch (_) {}

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `trocarTela` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `trocarTela` = nome da função responsável pela operação relacionada a trocar tela.
  // `nome` = parâmetro recebido pela função para fornecer o valor relacionado a nome.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function trocarTela(nome) {

    // Remove uma classe CSS do elemento para retirar o estado visual correspondente.
    // `document` = representa o documento HTML carregado no navegador.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `querySelectorAll` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a query selector all.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'.tela'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
    // `t` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a t.
    // `=>` = define uma função de seta.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `remove` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a remove.
    // `'ativa'` = texto literal utilizado nesta instrução.
    // `forEach` = executa uma função para cada elemento da coleção.
    // `querySelector` = localiza o primeiro elemento que corresponde ao seletor CSS informado.
    // `querySelectorAll` = localiza todos os elementos que correspondem ao seletor CSS informado.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    document.querySelectorAll('.tela').forEach(t => t.classList.remove('ativa'));

    // Adiciona uma classe CSS ao elemento para alterar seu estado visual.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `add` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add.
    // `'ativa'` = texto literal utilizado nesta instrução.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    $(nome).classList.add('ativa');

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `selecionarModo` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `selecionarModo` = nome da função responsável pela operação relacionada a selecionar modo.
  // `modo` = parâmetro recebido pela função para fornecer o valor relacionado a modo.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function selecionarModo(modo) {

    // Declara `modoSeguro` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `modoSeguro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo seguro.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'quatro'` = identificador do modo de jogo `4 Jogadores`.
    // `?` = participa do operador condicional ternário.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    const modoSeguro = modo === 'quatro' ? 'quatro' : 'duelo';

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `modoSelecionado` = armazena o modo de jogo escolhido no menu.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `modoSeguro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo seguro.
    modoSelecionado = modoSeguro;

    // Declara `grupoModos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `grupoModos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a grupo modos.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `document` = representa o documento HTML carregado no navegador.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `querySelector` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a query selector.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'.opcoes-modo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `querySelector` = localiza o primeiro elemento que corresponde ao seletor CSS informado.
    const grupoModos = document.querySelector('.opcoes-modo');

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `grupoModos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a grupo modos.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `dataset` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a dataset.
    // `modoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo atual.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `modoSeguro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo seguro.
    if (grupoModos) grupoModos.dataset.modoAtual = modoSeguro;

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `document` = representa o documento HTML carregado no navegador.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `querySelectorAll` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a query selector all.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'.opcao-modo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
    // `botao` = referência ao botão relacionado a botao.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `forEach` = executa uma função para cada elemento da coleção.
    // `querySelector` = localiza o primeiro elemento que corresponde ao seletor CSS informado.
    // `querySelectorAll` = localiza todos os elementos que correspondem ao seletor CSS informado.
    document.querySelectorAll('.opcao-modo').forEach(botao => {

      // Declara `selecionado` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `selecionado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a selecionado.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `botao` = referência ao botão relacionado a botao.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `dataset` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a dataset.
      // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `modoSeguro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo seguro.
      const selecionado = botao.dataset.modo === modoSeguro;

      // Ativa ou desativa uma classe CSS do elemento de acordo com a condição informada.
      // `botao` = referência ao botão relacionado a botao.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
      // `toggle` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a toggle.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'selecionada'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `selecionado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a selecionado.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
      botao.classList.toggle('selecionada', selecionado);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `botao` = referência ao botão relacionado a botao.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `setAttribute` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set attribute.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'aria-pressed'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `selecionado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a selecionado.
      // `?` = participa do operador condicional ternário.
      // `'true'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'false'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      botao.setAttribute('aria-pressed', selecionado ? 'true' : 'false');

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    });

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `obterModoSelecionadoNoMenu` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `obterModoSelecionadoNoMenu` = nome da função responsável pela operação relacionada a obter modo selecionado no menu.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function obterModoSelecionadoNoMenu() {

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `modoSelecionado` = armazena o modo de jogo escolhido no menu.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'quatro'` = identificador do modo de jogo `4 Jogadores`.
    // `?` = participa do operador condicional ternário.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    return modoSelecionado === 'quatro' ? 'quatro' : 'duelo';

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `toast` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `toast` = nome da função responsável pela operação relacionada a toast.
  // `texto` = parâmetro recebido pela função para fornecer o valor relacionado a texto.
  // `duracao` = parâmetro recebido pela função para fornecer o valor relacionado a duracao.
  // `1900` = valor padrão usado para `duracao` quando o argumento não é fornecido.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `1900` = intervalo de tempo utilizado pelo temporizador nesta operação.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function toast(texto, duracao = 1900) {

    // Declara `elemento` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `elemento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a elemento.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'toast'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const elemento = $('toast');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a clear timeout.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `temporizadorToast` = identificador utilizado para controlar o temporizador relacionado a temporizador toast.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `clearTimeout` = cancela um temporizador agendado.
    clearTimeout(temporizadorToast);

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `elemento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a elemento.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
    elemento.textContent = texto;

    // Adiciona uma classe CSS ao elemento para alterar seu estado visual.
    // `elemento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a elemento.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `add` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'visivel'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    elemento.classList.add('visivel');

    // Remove uma classe CSS do elemento para retirar o estado visual correspondente.
    // `temporizadorToast` = identificador utilizado para controlar o temporizador relacionado a temporizador toast.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `setTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set timeout.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `elemento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a elemento.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `remove` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a remove.
    // `'visivel'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `duracao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a duracao.
    // `setTimeout` = agenda a execução de uma função após o intervalo informado.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    temporizadorToast = setTimeout(() => elemento.classList.remove('visivel'), duracao);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `abrirModal` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `abrirModal` = nome da função responsável pela operação relacionada a abrir modal.
  // `{ rotulo` = parâmetro recebido pela função para fornecer o valor relacionado a { rotulo.
  // `'TRUCO PAULISTA'` = valor padrão usado para `{ rotulo` quando o argumento não é fornecido.
  // `titulo` = parâmetro recebido pela função para fornecer o valor relacionado a titulo.
  // `html` = parâmetro recebido pela função para fornecer o valor relacionado a html.
  // `icone` = parâmetro recebido pela função para fornecer o valor relacionado a icone.
  // `'♣'` = valor padrão usado para `icone` quando o argumento não é fornecido.
  // `botoes` = parâmetro recebido pela função para fornecer o valor relacionado a botoes.
  // `[]` = valor padrão usado para `botoes` quando o argumento não é fornecido.
  // `podeFechar` = parâmetro recebido pela função para fornecer o valor relacionado a pode fechar.
  // `false` = valor padrão usado para `podeFechar` quando o argumento não é fornecido.
  // `tipo` = parâmetro recebido pela função para fornecer o valor relacionado a tipo.
  // `'padrao' }` = valor padrão usado para `tipo` quando o argumento não é fornecido.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `rotulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rotulo.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `'TRUCO PAULISTA'` = texto literal utilizado nesta instrução.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `'♣'` = texto literal utilizado nesta instrução.
  // `[` = abre uma lista, índice ou acesso por chave.
  // `]` = fecha uma lista, índice ou acesso por chave.
  // `false` = valor lógico falso.
  // `'padrao'` = texto literal utilizado nesta instrução.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  function abrirModal({ rotulo = 'TRUCO PAULISTA', titulo, html, icone = '♣', botoes = [], podeFechar = false, tipo = 'padrao' }) {

    // Declara `modal` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const modal = $('modal');

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'modal'` = texto literal utilizado nesta instrução.
    modal.className = 'modal';

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'decisao'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `add` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add.
    // `'modal-decisao'` = texto literal utilizado nesta instrução.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    if (tipo === 'decisao') modal.classList.add('modal-decisao');

    // Ativa ou desativa uma classe CSS do elemento de acordo com a condição informada.
    // `document` = representa o documento HTML carregado no navegador.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `body` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a body.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `toggle` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a toggle.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'decisao-ativa'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'decisao'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    document.body.classList.toggle('decisao-ativa', tipo === 'decisao');

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-rotulo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `rotulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rotulo.
    $('modal-rotulo').textContent = rotulo;

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-titulo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
    $('modal-titulo').textContent = titulo;

    // Atualiza o conteúdo HTML interno do elemento da interface.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-texto'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
    $('modal-texto').innerHTML = html;

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-icone'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
    $('modal-icone').textContent = icone;

    // Altera diretamente uma propriedade visual do elemento na interface.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-fechar'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `style` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a style.
    // `display` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a display.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `podeFechar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechar.
    // `?` = participa do operador condicional ternário.
    // `''` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'none'` = texto literal utilizado nesta instrução.
    // `play` = inicia a reprodução do áudio.
    $('modal-fechar').style.display = podeFechar ? '' : 'none';

    // Declara `acoes` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `acoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acoes.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-acoes'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const acoes = $('modal-acoes');

    // Atualiza o conteúdo HTML interno do elemento da interface.
    // `acoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acoes.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `''` = texto literal utilizado nesta instrução.
    acoes.innerHTML = '';

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `forEach` = executa uma função para cada elemento da coleção.
    botoes.forEach(b => {

      // Declara `btn` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `btn` = referência ao botão relacionado a btn.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `document` = representa o documento HTML carregado no navegador.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `createElement` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a create element.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'button'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      const btn = document.createElement('button');

      // Atualiza o conteúdo textual do elemento da interface com o valor informado.
      // `btn` = referência ao botão relacionado a btn.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
      // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
      btn.textContent = b.texto;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `btn` = referência ao botão relacionado a btn.
      // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      if (b.classe) btn.className = b.classe;

      // Registra um evento para executar uma função quando a interação indicada ocorrer.
      // `btn` = referência ao botão relacionado a btn.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'click'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `=>` = define uma função de seta.
      // `{` = abre um bloco de código ou objeto.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
      // `fechar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechar.
      // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
      // `false` = valor lógico falso.
      // `fecharModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechar modal.
      // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
      // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
      // `}` = fecha um bloco de código ou objeto.
      btn.addEventListener('click', () => { if (b.fechar !== false) fecharModal(); b.acao?.(); });

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `acoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acoes.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `appendChild` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a append child.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `btn` = referência ao botão relacionado a btn.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      acoes.appendChild(btn);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    });

    // Adiciona uma classe CSS ao elemento para alterar seu estado visual.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `add` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aberto'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    modal.classList.add('aberto');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `setAttribute` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set attribute.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aria-hidden'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'false'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    modal.setAttribute('aria-hidden', 'false');

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `fecharModal` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `fecharModal` = nome da função responsável pela operação relacionada a fechar modal.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function fecharModal() {

    // Declara `modal` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const modal = $('modal');

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'modal'` = texto literal utilizado nesta instrução.
    modal.className = 'modal';

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `modal` = representa a janela modal usada para mensagens e decisões.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `setAttribute` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set attribute.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aria-hidden'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'true'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    modal.setAttribute('aria-hidden', 'true');

    // Remove uma classe CSS do elemento para retirar o estado visual correspondente.
    // `document` = representa o documento HTML carregado no navegador.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `body` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a body.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `remove` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a remove.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'decisao-ativa'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    document.body.classList.remove('decisao-ativa');

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `avisoApostaRapido` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `avisoApostaRapido` = nome da função responsável pela operação relacionada a aviso aposta rapido.
  // `{ titulo` = parâmetro recebido pela função para fornecer o valor relacionado a { titulo.
  // `texto` = parâmetro recebido pela função para fornecer o valor relacionado a texto.
  // `tipo` = parâmetro recebido pela função para fornecer o valor relacionado a tipo.
  // `'aceitou'` = valor padrão usado para `tipo` quando o argumento não é fornecido.
  // `duracao` = parâmetro recebido pela função para fornecer o valor relacionado a duracao.
  // `1050 }` = valor padrão usado para `duracao` quando o argumento não é fornecido.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `'aceitou'` = texto literal utilizado nesta instrução.
  // `1050` = intervalo de tempo utilizado pelo temporizador nesta operação.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  function avisoApostaRapido({ titulo, texto, tipo = 'aceitou', duracao = 1050 }) {

    // Declara `aviso` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `aviso` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aviso-aposta'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const aviso = $('aviso-aposta');

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `aviso` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    if (!aviso) return;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a clear timeout.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `temporizadorAvisoAposta` = identificador utilizado para controlar o temporizador relacionado a temporizador aviso aposta.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `clearTimeout` = cancela um temporizador agendado.
    clearTimeout(temporizadorAvisoAposta);

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aviso-aposta-titulo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
    $('aviso-aposta-titulo').textContent = titulo;

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aviso-aposta-texto'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
    $('aviso-aposta-texto').textContent = texto;

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'aviso-aposta-icone'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'correu'` = texto literal utilizado nesta instrução.
    // `?` = participa do operador condicional ternário.
    // `'✕'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'✓'` = texto literal utilizado nesta instrução.
    $('aviso-aposta-icone').textContent = tipo === 'correu' ? '✕' : '✓';

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `aviso` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `-` = realiza subtração ou representa um valor negativo.
    // `aposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aposta.
    // `{` = abre um bloco de código ou objeto.
    // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
    // `}` = fecha um bloco de código ou objeto.
    // `visivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a visivel.
    aviso.className = `aviso-aposta ${tipo} visivel`;

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `temporizadorAvisoAposta` = identificador utilizado para controlar o temporizador relacionado a temporizador aviso aposta.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `setTimeout` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set timeout.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `setTimeout` = agenda a execução de uma função após o intervalo informado.
    temporizadorAvisoAposta = setTimeout(() => {

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `aviso` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `'aviso-aposta'` = texto literal utilizado nesta instrução.
      aviso.className = 'aviso-aposta';

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `temporizadorAvisoAposta` = identificador utilizado para controlar o temporizador relacionado a temporizador aviso aposta.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      temporizadorAvisoAposta = null;

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `}` = fecha um bloco de código ou objeto.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `duracao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a duracao.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    }, duracao);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `modalAjuda` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `modalAjuda` = nome da função responsável pela operação relacionada a modal ajuda.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function modalAjuda() {

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    abrirModal({

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'Como jogar Truco Paulista'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
      // `'♠'` = texto literal utilizado nesta instrução.
      // `podeFechar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechar.
      // `true` = valor lógico verdadeiro.
      titulo: 'Como jogar Truco Paulista', icone: '♠', podeFechar: true,

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      html: `

        <div class="regras-grid">
          <div class="regras-box"><strong>Objetivo</strong>Vence a partida a equipe que alcançar 12 pontos primeiro.</div>
          <div class="regras-box"><strong>Cartas</strong>A ordem normal é 4, 5, 6, 7, Q, J, K, A, 2 e 3. A manilha é definida pela carta seguinte à vira.</div>
          <div class="regras-box"><strong>Manilhas</strong>Entre manilhas do mesmo valor, a força dos naipes é: Paus ♣, Copas ♥, Espadas ♠ e Ouros ♦.</div>
          <div class="regras-box"><strong>Vazas</strong>Cada mão tem até 3 vazas. A equipe que conquistar duas vazas vence a mão.</div>
          <div class="regras-box"><strong>Truco</strong>A mão começa valendo 1. Pode subir para Truco (3), Seis (6), Nove (9) e Doze (12).</div>
          <div class="regras-box"><strong>Correr</strong>Quem corre entrega à equipe rival o valor que a mão valia antes do último pedido.</div>
          <div class="regras-box"><strong>Carta fechada</strong>Da 2ª vaza em diante você pode jogar uma carta fechada. Ela não disputa força naquela vaza.</div>
          <div class="regras-box"><strong>Mão de 11</strong>Quando uma equipe chega a 11, não existe pedido de Truco. A mão vale 3; a equipe pode jogar ou correr cedendo 1 ponto.</div>
          <div class="regras-box"><strong>Mano a Mano</strong>Você joga diretamente contra uma IA.</div>
          <div class="regras-box"><strong>4 Jogadores</strong>Duplas: Você e IA Parceira contra IA 2 e IA 3. As jogadas seguem no sentido horário.</div>
        </div>`,

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `{` = abre um bloco de código ou objeto.
      // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
      // `'ENTENDI'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
      // `'destaque'` = texto literal utilizado nesta instrução.
      // `}` = fecha um bloco de código ou objeto.
      // `]` = fecha uma lista, índice ou acesso por chave.
      botoes: [{ texto: 'ENTENDI', classe: 'destaque' }]

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    });

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Declara `CHAVE_RANKING` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `CHAVE_RANKING` = define a chave usada para salvar o ranking local no navegador.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `'trucoPaulistaRanking'` = texto literal utilizado nesta instrução.
  const CHAVE_RANKING = 'trucoPaulistaRanking';

  // Define a função `obterRanking` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `obterRanking` = nome da função responsável pela operação relacionada a obter ranking.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function obterRanking() {

    // Inicia um bloco protegido para executar uma operação que pode gerar erro.
    // `try` = inicia um bloco protegido para tratamento de possíveis erros.
    // `{` = abre um bloco de código ou objeto.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `JSON` = constante utilizada para armazenar ou configurar o valor relacionado a json.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `parse` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a parse.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `localStorage` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a local storage.
    // `getItem` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a get item.
    // `CHAVE_RANKING` = define a chave usada para salvar o ranking local no navegador.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `'[]'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `catch` = captura um erro ocorrido no bloco try.
    // `_` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a  .
    // `[` = abre uma lista, índice ou acesso por chave.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `localStorage` = fornece armazenamento persistente local no navegador.
    // `JSON.parse` = converte um texto JSON de volta para um valor JavaScript.
    try { return JSON.parse(localStorage.getItem(CHAVE_RANKING) || '[]'); } catch (_) { return []; }

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `salvarRanking` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `salvarRanking` = nome da função responsável pela operação relacionada a salvar ranking.
  // `r` = parâmetro recebido pela função para fornecer o valor relacionado a r.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `localStorage` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a local storage.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `setItem` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set item.
  // `CHAVE_RANKING` = define a chave usada para salvar o ranking local no navegador.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `JSON` = constante utilizada para armazenar ou configurar o valor relacionado a json.
  // `stringify` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a stringify.
  // `}` = fecha um bloco de código ou objeto.
  // `localStorage` = fornece armazenamento persistente local no navegador.
  // `JSON.stringify` = converte um valor JavaScript para texto JSON.
  function salvarRanking(r) { localStorage.setItem(CHAVE_RANKING, JSON.stringify(r)); }

  // Define a função `registrarRanking` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `registrarRanking` = nome da função responsável pela operação relacionada a registrar ranking.
  // `nome` = parâmetro recebido pela função para fornecer o valor relacionado a nome.
  // `venceu` = parâmetro recebido pela função para fornecer o valor relacionado a venceu.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function registrarRanking(nome, venceu) {

    // Declara `ranking` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `obterRanking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a obter ranking.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const ranking = obterRanking();

    // Declara `chave` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `chave` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chave.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `trim` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a trim.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `toLocaleLowerCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to locale lower case.
    // `'pt-BR'` = texto literal utilizado nesta instrução.
    const chave = nome.trim().toLocaleLowerCase('pt-BR');

    // Declara `item` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `item` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a item.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `find` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a find.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r.
    // `=>` = define uma função de seta.
    // `chave` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chave.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    let item = ranking.find(r => r.chave === chave);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `item` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a item.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `chave` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chave.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `trim` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a trim.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `'Jogador'` = texto literal utilizado nesta instrução.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `vitorias` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitorias.
    // `derrotas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a derrotas.
    // `partidas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partidas.
    // `}` = fecha um bloco de código ou objeto.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
    // `push` = adiciona um novo elemento ao final da lista.
    if (!item) { item = { chave, nome: nome.trim() || 'Jogador', pontos: 0, vitorias: 0, derrotas: 0, partidas: 0 }; ranking.push(item); }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `item` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a item.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `partidas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partidas.
    // `++` = incrementa o valor em uma unidade.
    item.partidas++;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `venceu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `item` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a item.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `vitorias` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitorias.
    // `++` = incrementa o valor em uma unidade.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `10` = valor numérico 10 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    if (venceu) { item.vitorias++; item.pontos += 10; }

    // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `{` = abre um bloco de código ou objeto.
    // `item` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a item.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `derrotas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a derrotas.
    // `++` = incrementa o valor em uma unidade.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `max` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a max.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `-` = realiza subtração ou representa um valor negativo.
    // `10` = valor numérico 10 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `}` = fecha um bloco de código ou objeto.
    else { item.derrotas++; item.pontos = Math.max(0, item.pontos - 10); }

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `salvarRanking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a salvar ranking.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    salvarRanking(ranking);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `atualizarRankingMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a atualizar ranking menu.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    atualizarRankingMenu();

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `atualizarRankingMenu` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `atualizarRankingMenu` = nome da função responsável pela operação relacionada a atualizar ranking menu.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function atualizarRankingMenu() {

    // Declara `lista` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `lista` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a lista.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'ranking-lista'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const lista = $('ranking-lista');

    // Declara `ranking` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `obterRanking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a obter ranking.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `sort` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sort.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
    // `=>` = define uma função de seta.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `-` = realiza subtração ou representa um valor negativo.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `vitorias` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitorias.
    // `partidas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partidas.
    // `slice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a slice.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `5` = valor numérico 5 utilizado nesta instrução.
    const ranking = obterRanking().sort((a,b) => b.pontos-a.pontos || b.vitorias-a.vitorias || a.partidas-b.partidas).slice(0,5);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `lista` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a lista.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'<div class="ranking-vazio">Nenhuma partida concluída neste navegador.</div>'` = texto literal utilizado nesta instrução.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `}` = fecha um bloco de código ou objeto.
    if (!ranking.length) { lista.innerHTML = '<div class="ranking-vazio">Nenhuma partida concluída neste navegador.</div>'; return; }

    // Atualiza o conteúdo HTML interno do elemento da interface.
    // `lista` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a lista.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
    // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
    // `class` = define uma nova classe.
    // `"ranking-item"` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `span` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a span.
    // `{` = abre um bloco de código ou objeto.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `}` = fecha um bloco de código ou objeto.
    // `/` = realiza divisão.
    // `escapar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escapar.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `pts` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pts.
    // `join` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a join.
    // `''` = texto literal utilizado nesta instrução.
    // `map` = transforma cada elemento da lista e produz uma nova lista.
    lista.innerHTML = ranking.map((r,i) => `<div class="ranking-item"><span>${i+1}º</span><span>${escapar(r.nome)}</span><strong>${r.pontos} pts</strong></div>`).join('');

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `escapar` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `escapar` = nome da função responsável pela operação relacionada a escapar.
  // `texto` = parâmetro recebido pela função para fornecer o valor relacionado a texto.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `d` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a d.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `document` = representa o documento HTML carregado no navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `createElement` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a create element.
  // `'div'` = texto literal utilizado nesta instrução.
  // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
  // `return` = encerra a função atual e devolve o valor especificado.
  // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
  // `}` = fecha um bloco de código ou objeto.
  function escapar(texto) { const d = document.createElement('div'); d.textContent = texto; return d.innerHTML; }

  // Define a função `htmlCartasDaDecisao` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `htmlCartasDaDecisao` = nome da função responsável pela operação relacionada a html cartas da decisao.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function htmlCartasDaDecisao() {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `''` = texto literal utilizado nesta instrução.
    if (!jogo || !jogo.jogadores?.[0]) return '';

    // Declara `cartasHumano` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `cartasHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas humano.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `mao` = representa uma mão completa de Truco.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    const cartasHumano = jogo.jogadores[0].mao || [];

    // Declara `cartasHumanoHtml` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `cartasHumanoHtml` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas humano html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `cartasHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas humano.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    const cartasHumanoHtml = cartasHumano.length

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `?` = participa do operador condicional ternário.
      // `cartasHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas humano.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `carta` = representa uma carta do baralho.
      // `=>` = define uma função de seta.
      // `criarCartaHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a criar carta html.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `false` = valor lógico falso.
      // `'carta carta-decisao'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `join` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a join.
      // `''` = texto literal utilizado nesta instrução.
      // `map` = transforma cada elemento da lista e produz uma nova lista.
      ? cartasHumano.map(carta => criarCartaHTML(carta, false, 'carta carta-decisao')).join('')

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'<span class="sem-cartas-decisao">Você não possui mais cartas nesta mão.</span>'` = texto literal utilizado nesta instrução.
      : '<span class="sem-cartas-decisao">Você não possui mais cartas nesta mão.</span>';

    // Declara `manilha` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `manilha` = representa o valor de carta que se torna o mais forte na mão atual.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `?` = participa do operador condicional ternário.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `valorManilha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor manilha.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'—'` = texto literal utilizado nesta instrução.
    const manilha = jogo.vira ? C().valorManilha(jogo.vira) : '—';

    // Declara `vira` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `?` = participa do operador condicional ternário.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nomeCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome carta.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'—'` = texto literal utilizado nesta instrução.
    const vira = jogo.vira ? C().nomeCarta(jogo.vira) : '—';

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if (jogo.modo !== 'duelo') {

      // Declara `parceira` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `parceira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a parceira.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `jogo` = armazena o estado atual da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `find` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a find.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=>` = define uma função de seta.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `!` = nega o valor lógico da expressão seguinte.
      // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      const parceira = jogo.jogadores.find(j => j.equipe === 0 && !j.humano);

      // Declara `cartasParceira` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `cartasParceira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas parceira.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `parceira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a parceira.
      // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
      // `mao` = representa uma mão completa de Truco.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `]` = fecha uma lista, índice ou acesso por chave.
      const cartasParceira = parceira?.mao || [];

      // Declara `cartasParceiraHtml` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `cartasParceiraHtml` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas parceira html.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `cartasParceira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas parceira.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      const cartasParceiraHtml = cartasParceira.length

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `?` = participa do operador condicional ternário.
        // `cartasParceira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas parceira.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `carta` = representa uma carta do baralho.
        // `=>` = define uma função de seta.
        // `criarCartaHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a criar carta html.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `false` = valor lógico falso.
        // `'carta carta-decisao'` = texto literal utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `join` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a join.
        // `''` = texto literal utilizado nesta instrução.
        // `map` = transforma cada elemento da lista e produz uma nova lista.
        ? cartasParceira.map(carta => criarCartaHTML(carta, false, 'carta carta-decisao')).join('')

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `'<span class="sem-cartas-decisao">Sua parceira não possui mais cartas nesta mão.</span>'` = texto literal utilizado nesta instrução.
        : '<span class="sem-cartas-decisao">Sua parceira não possui mais cartas nesta mão.</span>';

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      return `

        <div class="painel-cartas-decisao painel-cartas-dupla">
          <div class="cabecalho-cartas-decisao">
            <strong>CARTAS DA SUA DUPLA</strong>
            <span>Vira: ${vira} • Manilha: ${manilha}</span>
          </div>
          <div class="grupos-cartas-decisao">
            <div class="grupo-cartas-decisao grupo-humano-decisao">
              <div class="titulo-grupo-cartas">SUAS CARTAS</div>
              <div class="cartas-decisao">${cartasHumanoHtml}</div>
            </div>
            <div class="separador-dupla-decisao"><span>+</span></div>
            <div class="grupo-cartas-decisao grupo-parceiro-decisao">
              <div class="titulo-grupo-cartas">CARTAS DA IA PARCEIRA</div>
              <div class="cartas-decisao">${cartasParceiraHtml}</div>
            </div>
          </div>
          <div class="legenda-parceiro-decisao">As cartas da IA parceira aparecem somente para ajudar nas decisões da sua dupla.</div>
        </div>`;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    return `

      <div class="painel-cartas-decisao">
        <div class="cabecalho-cartas-decisao">
          <strong>SUAS CARTAS</strong>
          <span>Vira: ${vira} • Manilha: ${manilha}</span>
        </div>
        <div class="cartas-decisao">${cartasHumanoHtml}</div>
      </div>`;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
  // `class` = define uma nova classe.
  // `PartidaTrucoWeb` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida truco web.
  // `{` = abre um bloco de código ou objeto.
  class PartidaTrucoWeb {

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `constructor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a constructor.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    constructor({ nome, modo, nivel }) {

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `nomeHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome humano.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `'Jogador'` = texto literal utilizado nesta instrução.
      this.nomeHumano = nome || 'Jogador';

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'quatro'` = identificador do modo de jogo `4 Jogadores`.
      // `?` = participa do operador condicional ternário.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
      this.modo = modo === 'quatro' ? 'quatro' : 'duelo';

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      this.nivel = nivel;

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
      this.jogadores = this.modo === 'duelo'

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `?` = participa do operador condicional ternário.
        // `[` = abre uma lista, índice ou acesso por chave.
        ? [

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
            // `this` = representa o objeto atual dentro do método ou função em execução.
            // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
            // `nomeHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome humano.
            // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
            // `true` = valor lógico verdadeiro.
            // `equipe` = representa uma das equipes da partida.
            // `mao` = representa uma mão completa de Truco.
            // `[` = abre uma lista, índice ou acesso por chave.
            // `]` = fecha uma lista, índice ou acesso por chave.
            // `}` = fecha um bloco de código ou objeto.
            { id:0, nome:this.nomeHumano, humano:true, equipe:0, mao:[] },

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
            // `'IA Rival'` = texto literal utilizado nesta instrução.
            // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
            // `false` = valor lógico falso.
            // `equipe` = representa uma das equipes da partida.
            // `mao` = representa uma mão completa de Truco.
            // `[` = abre uma lista, índice ou acesso por chave.
            // `]` = fecha uma lista, índice ou acesso por chave.
            // `}` = fecha um bloco de código ou objeto.
            { id:1, nome:'IA Rival', humano:false, equipe:1, mao:[] }

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `]` = fecha uma lista, índice ou acesso por chave.
          ]

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `[` = abre uma lista, índice ou acesso por chave.
        : [

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
            // `this` = representa o objeto atual dentro do método ou função em execução.
            // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
            // `nomeHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome humano.
            // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
            // `true` = valor lógico verdadeiro.
            // `equipe` = representa uma das equipes da partida.
            // `mao` = representa uma mão completa de Truco.
            // `[` = abre uma lista, índice ou acesso por chave.
            // `]` = fecha uma lista, índice ou acesso por chave.
            // `}` = fecha um bloco de código ou objeto.
            { id:0, nome:this.nomeHumano, humano:true, equipe:0, mao:[] },

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
            // `'IA 2'` = texto literal utilizado nesta instrução.
            // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
            // `false` = valor lógico falso.
            // `equipe` = representa uma das equipes da partida.
            // `mao` = representa uma mão completa de Truco.
            // `[` = abre uma lista, índice ou acesso por chave.
            // `]` = fecha uma lista, índice ou acesso por chave.
            // `}` = fecha um bloco de código ou objeto.
            { id:1, nome:'IA 2', humano:false, equipe:1, mao:[] },

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `2` = valor numérico 2 utilizado nesta instrução.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
            // `'IA Parceira'` = texto literal utilizado nesta instrução.
            // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
            // `false` = valor lógico falso.
            // `equipe` = representa uma das equipes da partida.
            // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
            // `mao` = representa uma mão completa de Truco.
            // `[` = abre uma lista, índice ou acesso por chave.
            // `]` = fecha uma lista, índice ou acesso por chave.
            // `}` = fecha um bloco de código ou objeto.
            { id:2, nome:'IA Parceira', humano:false, equipe:0, mao:[] },

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `3` = valor numérico 3 utilizado nesta instrução.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
            // `'IA 3'` = texto literal utilizado nesta instrução.
            // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
            // `false` = valor lógico falso.
            // `equipe` = representa uma das equipes da partida.
            // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
            // `mao` = representa uma mão completa de Truco.
            // `[` = abre uma lista, índice ou acesso por chave.
            // `]` = fecha uma lista, índice ou acesso por chave.
            // `}` = fecha um bloco de código ou objeto.
            { id:3, nome:'IA 3', humano:false, equipe:1, mao:[] }

          // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
          // `]` = fecha uma lista, índice ou acesso por chave.
          ];

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `]` = fecha uma lista, índice ou acesso por chave.
      this.pontos = [0,0];

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `indiceMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      this.indiceMao = 0;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `numeroMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a numero mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      this.numeroMao = 0;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      this.valorMao = 1;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      this.vira = null;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `]` = fecha uma lista, índice ou acesso por chave.
      this.vazas = [];

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `]` = fecha uma lista, índice ou acesso por chave.
      this.jogadasVaza = [];

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      this.turno = 0;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `primeiroVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a primeiro vaza.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      this.primeiroVaza = 0;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      this.maoAtiva = false;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `partidaEncerrada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida encerrada.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      this.partidaEncerrada = false;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      this.bloqueado = false;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      this.fechadaAtiva = false;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      this.ultimoPedidoEquipe = null;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      this.pedidoPendente = null;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoIAFeitoTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido iafeito turno.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      this.pedidoIAFeitoTurno = null;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `iniciar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciar.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    iniciar() {

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `indiceMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice mao.
      // `numeroMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a numero mao.
      // `partidaEncerrada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida encerrada.
      // `false` = valor lógico falso.
      this.pontos = [0,0]; this.indiceMao = 0; this.numeroMao = 0; this.partidaEncerrada = false;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `novaMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nova mao.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      this.novaMao();

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `equipeMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe mao.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `this` = representa o objeto atual dentro do método ou função em execução.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `indiceMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice mao.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `equipe` = representa uma das equipes da partida.
    // `}` = fecha um bloco de código ou objeto.
    equipeMao() { return this.jogadores[this.indiceMao].equipe; }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `maoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao de onze.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `this` = representa o objeto atual dentro do método ou função em execução.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `11` = valor numérico 11 utilizado nesta instrução.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `}` = fecha um bloco de código ou objeto.
    maoDeOnze() { return this.pontos[0] === 11 || this.pontos[1] === 11; }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `novaMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nova mao.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    novaMao() {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `partidaEncerrada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida encerrada.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (this.partidaEncerrada) return;

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `numeroMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a numero mao.
      // `++` = incrementa o valor em uma unidade.
      this.numeroMao++;

      // Declara `baralho` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `baralho` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a baralho.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `criarBaralho` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a criar baralho.
      const baralho = C().criarBaralho();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=>` = define uma função de seta.
      // `mao` = representa uma mão completa de Truco.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forEach` = executa uma função para cada elemento da coleção.
      this.jogadores.forEach(j => j.mao = []);

      // Percorre os elementos ou repetições definidos nesta estrutura de laço.
      // `for` = inicia uma estrutura de repetição.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
      // `rodada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rodada.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `3` = valor numérico 3 utilizado nesta instrução.
      // `++` = incrementa o valor em uma unidade.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      for (let rodada = 0; rodada < 3; rodada++) {

        // Percorre os elementos ou repetições definidos nesta estrutura de laço.
        // `for` = inicia uma estrutura de repetição.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
        // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
        // `<` = verifica se o valor da esquerda é menor que o da direita.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
        // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
        // `++` = incrementa o valor em uma unidade.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `[` = abre uma lista, índice ou acesso por chave.
        // `]` = fecha uma lista, índice ou acesso por chave.
        // `mao` = representa uma mão completa de Truco.
        // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
        // `baralho` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a baralho.
        // `pop` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pop.
        // `push` = adiciona um novo elemento ao final da lista.
        for (let i = 0; i < this.jogadores.length; i++) this.jogadores[i].mao.push(baralho.pop());

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `baralho` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a baralho.
      // `pop` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pop.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      this.vira = baralho.pop();

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `maoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao de onze.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `?` = participa do operador condicional ternário.
      // `3` = valor numérico 3 utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      this.valorMao = this.maoDeOnze() ? 3 : 1;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
      this.vazas = []; this.jogadasVaza = [];

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `primeiroVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a primeiro vaza.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `indiceMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice mao.
      this.primeiroVaza = this.indiceMao;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `primeiroVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a primeiro vaza.
      this.turno = this.primeiroVaza;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `true` = valor lógico verdadeiro.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `false` = valor lógico falso.
      // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
      this.maoAtiva = true; this.bloqueado = false; this.fechadaAtiva = false;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `pedidoIAFeitoTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido iafeito turno.
      this.ultimoPedidoEquipe = null; this.pedidoPendente = null; this.pedidoIAFeitoTurno = null;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'novaMao'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      tocar('novaMao');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarTudo();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `Nova` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nova.
      // `mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
      // `Vira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vira.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `{` = abre um bloco de código ou objeto.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `nomeCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome carta.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `}` = fecha um bloco de código ou objeto.
      // `Manilha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a manilha.
      // `valorManilha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor manilha.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `2400` = valor numérico 2400 utilizado nesta instrução.
      toast(`Nova mão • Vira: ${C().nomeCarta(this.vira)} • Manilha: ${C().valorManilha(this.vira)}`, 2400);

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao de onze.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `tratarMaoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tratar mao de onze.
      if (this.maoDeOnze()) this.tratarMaoDeOnze();

      // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      else this.processarTurno();

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `tratarMaoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tratar mao de onze.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    tratarMaoDeOnze() {

      // Declara `humano11` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `humano11` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano11.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `11` = valor numérico 11 utilizado nesta instrução.
      const humano11 = this.pontos[0] === 11;

      // Declara `rival11` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `rival11` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rival11.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `11` = valor numérico 11 utilizado nesta instrução.
      const rival11 = this.pontos[1] === 11;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `humano11` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano11.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if (humano11) {

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `true` = valor lógico verdadeiro.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        this.bloqueado = true; renderizarTudo();

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        abrirModal({

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `rotulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rotulo.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `'MÃO DE 11'` = texto literal utilizado nesta instrução.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
          // `'Sua equipe chegou a 11 pontos'` = texto literal utilizado nesta instrução.
          // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
          // `'11'` = texto literal utilizado nesta instrução.
          // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
          // `'decisao'` = texto literal utilizado nesta instrução.
          rotulo:'MÃO DE 11', titulo:'Sua equipe chegou a 11 pontos', icone:'11', tipo:'decisao',

          // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
          // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `{` = abre um bloco de código ou objeto.
          // `htmlCartasDaDecisao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html cartas da decisao.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `}` = fecha um bloco de código ou objeto.
          // `<` = verifica se o valor da esquerda é menor que o da direita.
          // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
          // `class` = define uma nova classe.
          // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
          // `"texto-decisao"` = texto literal utilizado nesta instrução.
          // `>` = verifica se o valor da esquerda é maior que o da direita.
          // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
          // `Esta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a esta.
          // `mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
          // `vale` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vale.
          // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
          // `3` = valor numérico 3 utilizado nesta instrução.
          // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
          // `/` = realiza divisão.
          // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
          // `não` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a não.
          // `pode` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode.
          // `haver` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a haver.
          // `Truco` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a truco.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `Seis` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a seis.
          // `Nove` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nove.
          // `ou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ou.
          // `Doze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a doze.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `Confira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a confira.
          // `as` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a as.
          // `cartas` = representa uma coleção de cartas.
          // `da` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a da.
          // `sua` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sua.
          // `equipe` = representa uma das equipes da partida.
          // `acima` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acima.
          // `escolha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escolha.
          // `se` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a se.
          // `deseja` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a deseja.
          // `jogar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar.
          // `correr` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a correr.
          // `entregando` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a entregando.
          // `somente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a somente.
          // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
          // `ponto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ponto.
          // `aos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aos.
          // `adversários` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a adversários.
          html:`${htmlCartasDaDecisao()}<div class="texto-decisao"><p>Esta mão vale <strong>3 pontos</strong> e não pode haver Truco, Seis, Nove ou Doze.</p><p>Confira as cartas da sua equipe acima e escolha se deseja jogar ou correr, entregando somente <strong>1 ponto</strong> aos adversários.</p></div>`,

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `[` = abre uma lista, índice ou acesso por chave.
          botoes:[

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `'CORRER • PERDER 1'` = texto literal utilizado nesta instrução.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
            // `'perigo'` = texto literal utilizado nesta instrução.
            // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
            // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `=>` = define uma função de seta.
            // `this` = representa o objeto atual dentro do método ou função em execução.
            // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
            // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
            // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
            // `'Mão de 11: sua equipe correu'` = texto literal utilizado nesta instrução.
            // `}` = fecha um bloco de código ou objeto.
            {texto:'CORRER • PERDER 1', classe:'perigo', acao:()=>this.encerrarMao(1,1,'Mão de 11: sua equipe correu')},

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `'JOGAR VALENDO 3'` = texto literal utilizado nesta instrução.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
            // `'destaque'` = texto literal utilizado nesta instrução.
            // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
            // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `=>` = define uma função de seta.
            // `this` = representa o objeto atual dentro do método ou função em execução.
            // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
            // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
            // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
            // `false` = valor lógico falso.
            // `if` = inicia uma condição executada quando a expressão é verdadeira.
            // `rival11` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rival11.
            // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
            // `iaCorreMaoOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ia corre mao onze.
            // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
            // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
            // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
            // `'Adversários correram na mão de 11'` = texto literal utilizado nesta instrução.
            // `}` = fecha um bloco de código ou objeto.
            // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
            // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
            // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
            {texto:'JOGAR VALENDO 3', classe:'destaque', acao:()=>{this.bloqueado=false; if(rival11 && this.iaCorreMaoOnze(1)){this.encerrarMao(0,1,'Adversários correram na mão de 11');} else {renderizarTudo();this.processarTurno();}}}

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `]` = fecha uma lista, índice ou acesso por chave.
          ]

        // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
        // `}` = fecha um bloco de código ou objeto.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        });

        // Encerra imediatamente a execução da função atual sem devolver um valor específico.
        // `return` = encerra a função atual e devolve o valor especificado.
        return;

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `rival11` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rival11.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `iaCorreMaoOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ia corre mao onze.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `'Adversários correram na mão de 11'` = texto literal utilizado nesta instrução.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `}` = fecha um bloco de código ou objeto.
      if (rival11 && this.iaCorreMaoOnze(1)) { this.encerrarMao(0,1,'Adversários correram na mão de 11'); return; }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      this.processarTurno();

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `iaCorreMaoOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ia corre mao onze.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipe` = representa uma das equipes da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    iaCorreMaoOnze(equipe) {

      // Declara `cartas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `cartas` = representa uma coleção de cartas.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=>` = define uma função de seta.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `flatMap` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a flat map.
      // `mao` = representa uma mão completa de Truco.
      // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
      const cartas = this.jogadores.filter(j=>j.equipe===equipe).flatMap(j=>j.mao);

      // Declara `nota` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `avaliarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a avaliar mao.
      // `cartas` = representa uma coleção de cartas.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
      // `/` = realiza divisão.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `max` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a max.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=>` = define uma função de seta.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
      const nota = IA().avaliarMao(cartas, this.vira, this.nivel) / Math.max(1, this.jogadores.filter(j=>j.equipe===equipe).length);

      // Declara `limite` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `limite` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a limite.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de código ou objeto.
      // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `5.5` = valor numérico 5.5 utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
      // `5.0` = valor numérico 5.0 utilizado nesta instrução.
      // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
      // `4.5` = valor numérico 4.5 utilizado nesta instrução.
      // `}` = fecha um bloco de código ou objeto.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
      // `]` = fecha uma lista, índice ou acesso por chave.
      const limite = { 'Fácil':5.5, 'Normal':5.0, 'Difícil':4.5 }[this.nivel];

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `limite` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a limite.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `.2` = valor numérico .2 utilizado nesta instrução.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      return nota < limite && Math.random() > .2;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `podeJogarHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode jogar humano.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `this` = representa o objeto atual dentro do método ou função em execução.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `!` = nega o valor lógico da expressão seguinte.
    // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
    // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
    // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `}` = fecha um bloco de código ou objeto.
    podeJogarHumano() { return this.maoAtiva && !this.bloqueado && !this.pedidoPendente && this.turno === 0; }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `podeFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechada.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `this` = representa o objeto atual dentro do método ou função em execução.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `podeJogarHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode jogar humano.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `}` = fecha um bloco de código ou objeto.
    podeFechada() { return this.podeJogarHumano() && this.vazas.length >= 1; }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `podePedir` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode pedir.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipe` = representa uma das equipes da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    podePedir(equipe) {

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `!` = nega o valor lógico da expressão seguinte.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `maoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao de onze.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
      // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
      // `equipe` = representa uma das equipes da partida.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `null` = representa ausência intencional de valor.
      return this.maoAtiva && !this.bloqueado && !this.maoDeOnze() && !this.pedidoPendente && this.ultimoPedidoEquipe !== equipe && C().proximoValorAposta(this.valorMao) !== null;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `jogarHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar humano.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    jogarHumano(indice) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `podeJogarHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode jogar humano.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (!this.podeJogarHumano()) return;

      // Declara `fechada` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `podeFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechada.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      const fechada = this.fechadaAtiva && this.podeFechada();

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      this.fechadaAtiva = false;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogarCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar carta.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      this.jogarCarta(0, indice, fechada);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `jogarCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar carta.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `false` = valor lógico falso.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    jogarCarta(jogadorId, indice, fechada=false) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
      // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
      // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `false` = valor lógico falso.
      if (!this.maoAtiva || this.bloqueado || this.turno !== jogadorId) return false;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      if (fechada && this.vazas.length < 1) fechada = false;

      // Declara `jogador` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `jogador` = representa um participante da partida.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
      // `]` = fecha uma lista, índice ou acesso por chave.
      const jogador = this.jogadores[jogadorId];

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `jogador` = representa um participante da partida.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `mao` = representa uma mão completa de Truco.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `false` = valor lógico falso.
      if (!jogador || indice < 0 || indice >= jogador.mao.length) return false;

      // Declara `variável` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `carta` = representa uma carta do baralho.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `jogador` = representa um participante da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `mao` = representa uma mão completa de Truco.
      // `splice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a splice.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      const [carta] = jogador.mao.splice(indice,1);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
      // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `jogador` = representa um participante da partida.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `equipe` = representa uma das equipes da partida.
      // `carta` = representa uma carta do baralho.
      // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
      // `}` = fecha um bloco de código ou objeto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `push` = adiciona um novo elemento ao final da lista.
      this.jogadasVaza.push({ jogador:jogadorId, equipe:jogador.equipe, carta, fechada });

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoIAFeitoTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido iafeito turno.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `null` = representa ausência intencional de valor.
      this.pedidoIAFeitoTurno = null;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
      // `?` = participa do operador condicional ternário.
      // `'fechada'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'carta'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      tocar(fechada ? 'fechada' : 'carta');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarTudo();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if (this.jogadasVaza.length === this.jogadores.length) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `resolverVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resolver vaza.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        this.resolverVaza();

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `}` = fecha um bloco de código ou objeto.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `{` = abre um bloco de código ou objeto.
      } else {

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `+` = realiza soma ou concatenação conforme os valores envolvidos.
        // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `%` = calcula o resto da divisão e também pode ser usado para circular índices.
        // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
        // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
        this.turno = (this.turno + 1) % this.jogadores.length;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        renderizarTudo();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        this.processarTurno();

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `true` = valor lógico verdadeiro.
      return true;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `resolverVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resolver vaza.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    resolverVaza() {

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `true` = valor lógico verdadeiro.
      this.bloqueado = true;

      // Declara `resultado` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vencedorVaza` = identificador relacionado ao vencedor de vaza.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      const resultado = C().vencedorVaza(this.jogadasVaza, this.vira);

      // Declara `registro` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `registro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a registro.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de código ou objeto.
      // `numero` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a numero.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `vencedorJogador` = identificador relacionado ao vencedor de jogador.
      // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
      // `jogador` = representa um participante da partida.
      // `vencedorEquipe` = identificador relacionado ao vencedor de equipe.
      // `equipe` = representa uma das equipes da partida.
      // `}` = fecha um bloco de código ou objeto.
      const registro = { numero:this.vazas.length+1, jogadas:[...this.jogadasVaza], vencedorJogador:resultado.jogador, vencedorEquipe:resultado.equipe };

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `registro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a registro.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `push` = adiciona um novo elemento ao final da lista.
      this.vazas.push(registro);

      // Declara `n` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `n` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a n.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      const n = this.vazas.length;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `null` = representa ausência intencional de valor.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `n` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a n.
      // `}` = fecha um bloco de código ou objeto.
      // `vaza` = representa uma rodada em que cada jogador joga uma carta.
      // `empatou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a empatou.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1800` = valor numérico 1800 utilizado nesta instrução.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `'empate'` = texto literal utilizado nesta instrução.
      if (resultado.equipe === null) { toast(`${n}ª vaza empatou.`, 1800); tocar('empate'); }

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
      // `}` = fecha um bloco de código ou objeto.
      // `venceu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu.
      // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
      // `n` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a n.
      // `vaza` = representa uma rodada em que cada jogador joga uma carta.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1800` = valor numérico 1800 utilizado nesta instrução.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `'vitoriaVaza'` = texto literal utilizado nesta instrução.
      else if (resultado.equipe === 0) { toast(`${nomeEquipe(0)} venceu a ${n}ª vaza.`, 1800); tocar('vitoriaVaza'); }

      // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `{` = abre um bloco de código ou objeto.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `}` = fecha um bloco de código ou objeto.
      // `venceu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu.
      // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
      // `n` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a n.
      // `vaza` = representa uma rodada em que cada jogador joga uma carta.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1800` = valor numérico 1800 utilizado nesta instrução.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `'derrotaVaza'` = texto literal utilizado nesta instrução.
      else { toast(`${nomeEquipe(1)} venceu a ${n}ª vaza.`, 1800); tocar('derrotaVaza'); }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarTudo();

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `=>` = define uma função de seta.
      // `{` = abre um bloco de código ou objeto.
      agendar(() => {

        // Declara `vencedores` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `vencedores` = identificador relacionado ao vencedor de es.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
        // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `v` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a v.
        // `=>` = define uma função de seta.
        // `vencedorEquipe` = identificador relacionado ao vencedor de equipe.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `map` = transforma cada elemento da lista e produz uma nova lista.
        const vencedores = this.vazas.map(v=>v.vencedorEquipe);

        // Declara `vencedorMao` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `vencedorMao` = identificador relacionado ao vencedor de mao.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `vencedores` = identificador relacionado ao vencedor de es.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `equipeMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe mao.
        const vencedorMao = C().vencedorMao(vencedores, this.equipeMao());

        // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `vencedorMao` = identificador relacionado ao vencedor de mao.
        // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
        // `null` = representa ausência intencional de valor.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
        // `'Vazas'` = texto literal utilizado nesta instrução.
        // `return` = encerra a função atual e devolve o valor especificado.
        // `}` = fecha um bloco de código ou objeto.
        if (vencedorMao !== null) { this.encerrarMao(vencedorMao, this.valorMao, 'Vazas'); return; }

        // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
        // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
        // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
        // `3` = valor numérico 3 utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
        // `equipeMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe mao.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
        // `'Desempate pela equipe da mão'` = texto literal utilizado nesta instrução.
        // `return` = encerra a função atual e devolve o valor especificado.
        // `}` = fecha um bloco de código ou objeto.
        if (this.vazas.length >= 3) { this.encerrarMao(this.equipeMao(), this.valorMao, 'Desempate pela equipe da mão'); return; }

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, índice ou acesso por chave.
        // `]` = fecha uma lista, índice ou acesso por chave.
        this.jogadasVaza = [];

        // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `jogador` = representa um participante da partida.
        // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
        // `null` = representa ausência intencional de valor.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `primeiroVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a primeiro vaza.
        if (resultado.jogador === null) this.turno = this.primeiroVaza;

        // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
        // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
        // `jogador` = representa um participante da partida.
        else this.turno = resultado.jogador;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `primeiroVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a primeiro vaza.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
        this.primeiroVaza = this.turno;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `false` = valor lógico falso.
        this.bloqueado = false;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        renderizarTudo();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        this.processarTurno();

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `}` = fecha um bloco de código ou objeto.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1850` = valor numérico 1850 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      }, 1850);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipe` = representa uma das equipes da partida.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `motivo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a motivo.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    encerrarMao(equipe, pontos, motivo) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (!this.maoAtiva) return;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `false` = valor lógico falso.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `true` = valor lógico verdadeiro.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `null` = representa ausência intencional de valor.
      this.maoAtiva = false; this.bloqueado = true; this.pedidoPendente = null;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `equipe` = representa uma das equipes da partida.
      // `]` = fecha uma lista, índice ou acesso por chave.
      this.pontos[equipe] += pontos;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarTudo();

      // Declara `ganhouHumano` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ganhouHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ganhou humano.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      const ganhouHumano = equipe === 0;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `ganhouHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ganhou humano.
      // `?` = participa do operador condicional ternário.
      // `'vitoriaMao'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'derrotaMao'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      tocar(ganhouHumano ? 'vitoriaMao' : 'derrotaMao');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
      // `equipe` = representa uma das equipes da partida.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `}` = fecha um bloco de código ou objeto.
      // `venceu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu.
      // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
      // `mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `marcou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a marcou.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `ponto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ponto.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `?` = participa do operador condicional ternário.
      // `''` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'s'` = texto literal utilizado nesta instrução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `2200` = valor numérico 2200 utilizado nesta instrução.
      toast(`${nomeEquipe(equipe)} venceu a mão e marcou ${pontos} ponto${pontos===1?'':'s'}.`, 2200);

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `equipe` = representa uma das equipes da partida.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `PONTOS_PARA_VENCER` = define a pontuação necessária para vencer a partida.
      // `{` = abre um bloco de código ou objeto.
      if (this.pontos[equipe] >= C().PONTOS_PARA_VENCER) {

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `partidaEncerrada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida encerrada.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `true` = valor lógico verdadeiro.
        this.partidaEncerrada = true;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `ganhouHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ganhou humano.
        // `?` = participa do operador condicional ternário.
        // `'vitoriaPartida'` = texto literal utilizado nesta instrução.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `'derrotaPartida'` = texto literal utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        tocar(ganhouHumano ? 'vitoriaPartida' : 'derrotaPartida');

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `registrarRanking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a registrar ranking.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `nomeHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome humano.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `ganhouHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ganhou humano.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        registrarRanking(this.nomeHumano, ganhouHumano);

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `=>` = define uma função de seta.
        // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
        // `{` = abre um bloco de código ou objeto.
        agendar(() => abrirModal({

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `rotulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rotulo.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `'FIM DE PARTIDA'` = texto literal utilizado nesta instrução.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
          // `ganhouHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ganhou humano.
          // `?` = participa do operador condicional ternário.
          // `'Você venceu!'` = texto literal utilizado nesta instrução.
          // `'Os adversários venceram'` = texto literal utilizado nesta instrução.
          // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
          // `'🏆'` = texto literal utilizado nesta instrução.
          // `'♦'` = texto literal utilizado nesta instrução.
          rotulo:'FIM DE PARTIDA', titulo:ganhouHumano?'Você venceu!':'Os adversários venceram', icone:ganhouHumano?'🏆':'♦',

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `<` = verifica se o valor da esquerda é menor que o da direita.
          // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
          // `>` = verifica se o valor da esquerda é maior que o da direita.
          // `{` = abre um bloco de código ou objeto.
          // `ganhouHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ganhou humano.
          // `?` = participa do operador condicional ternário.
          // `'Excelente partida!'` = texto literal utilizado nesta instrução.
          // `'A revanche já pode começar.'` = texto literal utilizado nesta instrução.
          // `}` = fecha um bloco de código ou objeto.
          // `/` = realiza divisão.
          // `Placar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a placar.
          // `final` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a final.
          // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
          // `[` = abre uma lista, índice ou acesso por chave.
          // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
          // `]` = fecha uma lista, índice ou acesso por chave.
          // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
          // `No` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a no.
          // `ranking` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ranking.
          // `local` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a local.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `vitória` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vitória.
          // `vale` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vale.
          // `+` = realiza soma ou concatenação conforme os valores envolvidos.
          // `10` = valor numérico 10 utilizado nesta instrução.
          // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
          // `derrota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a derrota.
          // `pode` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode.
          // `retirar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a retirar.
          // `até` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a até.
          // `sem` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sem.
          // `deixar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a deixar.
          // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
          // `pontuação` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontuação.
          // `negativa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a negativa.
          html:`<p>${ganhouHumano?'Excelente partida!':'A revanche já pode começar.'}</p><p>Placar final: <strong>${this.pontos[0]} × ${this.pontos[1]}</strong>.</p><p>No ranking local, vitória vale +10 pontos e derrota pode retirar até 10, sem deixar a pontuação negativa.</p>`,

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `[` = abre uma lista, índice ou acesso por chave.
          botoes:[

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `'VOLTAR AO MENU'` = texto literal utilizado nesta instrução.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
            // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `=>` = define uma função de seta.
            // `voltarMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a voltar menu.
            // `}` = fecha um bloco de código ou objeto.
            {texto:'VOLTAR AO MENU', acao:()=>voltarMenu()},

            // Inicia a estrutura de dados declarada nesta linha.
            // `{` = abre um bloco de código ou objeto.
            // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
            // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
            // `'JOGAR NOVAMENTE'` = texto literal utilizado nesta instrução.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
            // `'destaque'` = texto literal utilizado nesta instrução.
            // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
            // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `=>` = define uma função de seta.
            // `iniciarPartidaComConfiguracaoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciar partida com configuracao atual.
            // `}` = fecha um bloco de código ou objeto.
            {texto:'JOGAR NOVAMENTE', classe:'destaque', acao:()=>iniciarPartidaComConfiguracaoAtual()}

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `]` = fecha uma lista, índice ou acesso por chave.
          ]

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `}` = fecha um bloco de código ou objeto.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `800` = valor numérico 800 utilizado nesta instrução.
        }), 800);

        // Encerra imediatamente a execução da função atual sem devolver um valor específico.
        // `return` = encerra a função atual e devolve o valor especificado.
        return;

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `indiceMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `%` = calcula o resto da divisão e também pode ser usado para circular índices.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      this.indiceMao = (this.indiceMao + 1) % this.jogadores.length;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `=>` = define uma função de seta.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `novaMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nova mao.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `2350` = intervalo de tempo utilizado pelo temporizador nesta operação.
      agendar(() => this.novaMao(), 2350);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    processarTurno() {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (!this.maoAtiva || this.bloqueado || this.pedidoPendente) return;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarTudo();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (this.turno === 0) return;

      // Declara `jogador` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `jogador` = representa um participante da partida.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
      // `]` = fecha uma lista, índice ou acesso por chave.
      const jogador = this.jogadores[this.turno];

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `jogador` = representa um participante da partida.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (!jogador || jogador.humano) return;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `true` = valor lógico verdadeiro.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      this.bloqueado = true; renderizarTudo();

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `=>` = define uma função de seta.
      // `{` = abre um bloco de código ou objeto.
      agendar(() => {

        // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `!` = nega o valor lógico da expressão seguinte.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
        // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
        // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
        // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
        // `jogador` = representa um participante da partida.
        // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
        // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `false` = valor lógico falso.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `return` = encerra a função atual e devolve o valor especificado.
        // `}` = fecha um bloco de código ou objeto.
        if (!this.maoAtiva || this.turno !== jogador.id || this.pedidoPendente) { this.bloqueado=false; renderizarTudo(); return; }

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `false` = valor lógico falso.
        this.bloqueado = false;

        // Declara `chaveTurno` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `chaveTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chave turno.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `{` = abre um bloco de código ou objeto.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
        // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
        // `}` = fecha um bloco de código ou objeto.
        // `-` = realiza subtração ou representa um valor negativo.
        // `jogador` = representa um participante da partida.
        // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
        // `mao` = representa uma mão completa de Truco.
        // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
        const chaveTurno = `${this.vazas.length}-${jogador.id}-${jogador.mao.length}-${this.valorMao}`;

        // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `pedidoIAFeitoTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido iafeito turno.
        // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
        // `chaveTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chave turno.
        // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
        // `podePedir` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode pedir.
        // `jogador` = representa um participante da partida.
        // `equipe` = representa uma das equipes da partida.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        if (this.pedidoIAFeitoTurno !== chaveTurno && this.podePedir(jogador.equipe)) {

          // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `pedidoIAFeitoTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido iafeito turno.
          // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
          // `chaveTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chave turno.
          this.pedidoIAFeitoTurno = chaveTurno;

          // Declara `cartasEquipe` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `cartasEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas equipe.
          // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
          // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
          // `=>` = define uma função de seta.
          // `equipe` = representa uma das equipes da partida.
          // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
          // `jogador` = representa um participante da partida.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `flatMap` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a flat map.
          // `mao` = representa uma mão completa de Truco.
          // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
          const cartasEquipe = this.jogadores.filter(j=>j.equipe===jogador.equipe).flatMap(j=>j.mao);

          // Declara `venceuPrimeira` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `venceuPrimeira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu primeira.
          // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
          // `[` = abre uma lista, índice ou acesso por chave.
          // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
          // `]` = fecha uma lista, índice ou acesso por chave.
          // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
          // `vencedorEquipe` = identificador relacionado ao vencedor de equipe.
          // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
          // `jogador` = representa um participante da partida.
          // `equipe` = representa uma das equipes da partida.
          const venceuPrimeira = this.vazas[0]?.vencedorEquipe === jogador.equipe;

          // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
          // `if` = inicia uma condição executada quando a expressão é verdadeira.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `devePedirAumento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a deve pedir aumento.
          // `{` = abre um bloco de código ou objeto.
          // `cartas` = representa uma coleção de cartas.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `cartasEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas equipe.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `vira` = representa a carta virada que determina qual valor será a manilha.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `valorAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor atual.
          // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
          // `pontosEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos equipe.
          // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
          // `[` = abre uma lista, índice ou acesso por chave.
          // `jogador` = representa um participante da partida.
          // `equipe` = representa uma das equipes da partida.
          // `]` = fecha uma lista, índice ou acesso por chave.
          // `pontosRival` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos rival.
          // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
          // `-` = realiza subtração ou representa um valor negativo.
          // `venceuPrimeira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu primeira.
          // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
          // `}` = fecha um bloco de código ou objeto.
          if (IA().devePedirAumento({cartas:cartasEquipe, vira:this.vira, valorAtual:this.valorMao, pontosEquipe:this.pontos[jogador.equipe], pontosRival:this.pontos[1-jogador.equipe], venceuPrimeira, nivel:this.nivel})) {

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `this` = representa o objeto atual dentro do método ou função em execução.
            // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
            // `pedirAumento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedir aumento.
            // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
            // `jogador` = representa um participante da partida.
            // `equipe` = representa uma das equipes da partida.
            // `,` = separa argumentos, parâmetros ou elementos da estrutura.
            // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
            // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
            this.pedirAumento(jogador.equipe, jogador.id);

            // Encerra imediatamente a execução da função atual sem devolver um valor específico.
            // `return` = encerra a função atual e devolve o valor especificado.
            return;

          // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
          // `}` = fecha um bloco de código ou objeto.
          }

        // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
        // `}` = fecha um bloco de código ou objeto.
        }

        // Declara `fechada` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
        // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
        // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
        // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
        // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
        // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `deveJogarFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a deve jogar fechada.
        // `{` = abre um bloco de código ou objeto.
        // `mao` = representa uma mão completa de Truco.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `jogador` = representa um participante da partida.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `vira` = representa a carta virada que determina qual valor será a manilha.
        // `rodada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rodada.
        // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
        // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
        // `equipe` = representa uma das equipes da partida.
        // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
        // `}` = fecha um bloco de código ou objeto.
        const fechada = this.vazas.length >= 1 && IA().deveJogarFechada({mao:jogador.mao,vira:this.vira,rodada:this.vazas.length,jogadas:this.jogadasVaza,equipe:jogador.equipe,nivel:this.nivel});

        // Declara `indice` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
        const indice = fechada

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `?` = participa do operador condicional ternário.
          // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `escolherDescarteFechado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escolher descarte fechado.
          // `jogador` = representa um participante da partida.
          // `mao` = representa uma mão completa de Truco.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `vira` = representa a carta virada que determina qual valor será a manilha.
          ? IA().escolherDescarteFechado(jogador.mao,this.vira)

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `escolherCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escolher carta.
          // `{` = abre um bloco de código ou objeto.
          // `mao` = representa uma mão completa de Truco.
          // `jogador` = representa um participante da partida.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `vira` = representa a carta virada que determina qual valor será a manilha.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
          // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
          // `equipe` = representa uma das equipes da partida.
          // `rodada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rodada.
          // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
          // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
          // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
          // `pontosEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos equipe.
          // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
          // `[` = abre uma lista, índice ou acesso por chave.
          // `]` = fecha uma lista, índice ou acesso por chave.
          // `pontosRival` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos rival.
          // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
          // `-` = realiza subtração ou representa um valor negativo.
          // `}` = fecha um bloco de código ou objeto.
          : IA().escolherCarta({mao:jogador.mao,vira:this.vira,jogadas:this.jogadasVaza,equipe:jogador.equipe,rodada:this.vazas.length,nivel:this.nivel,pontosEquipe:this.pontos[jogador.equipe],pontosRival:this.pontos[1-jogador.equipe]});

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `jogarCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar carta.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `jogador` = representa um participante da partida.
        // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
        // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        this.jogarCarta(jogador.id, indice, fechada);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `}` = fecha um bloco de código ou objeto.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `820` = valor numérico 820 utilizado nesta instrução.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `floor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a floor.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `*` = realiza multiplicação.
      // `500` = valor numérico 500 utilizado nesta instrução.
      // `Math.floor` = arredonda um número para o inteiro imediatamente inferior.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      }, 820 + Math.floor(Math.random()*500));

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `pedidoHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido humano.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `this` = representa o objeto atual dentro do método ou função em execução.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `podePedir` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode pedir.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `pedirAumento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedir aumento.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `}` = fecha um bloco de código ou objeto.
    pedidoHumano() { if (this.podePedir(0)) this.pedirAumento(0,0); }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `pedirAumento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedir aumento.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipe` = representa uma das equipes da partida.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    pedirAumento(equipe, jogadorId) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `podePedir` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode pedir.
      // `equipe` = representa uma das equipes da partida.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `false` = valor lógico falso.
      if (!this.podePedir(equipe)) return false;

      // Declara `pedido` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      const pedido = C().proximoValorAposta(this.valorMao);

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de código ou objeto.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `equipe` = representa uma das equipes da partida.
      // `jogadorSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador solicitante.
      // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
      // `valorAnterior` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor anterior.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `}` = fecha um bloco de código ou objeto.
      this.pedidoPendente = { pedido, equipeSolicitante:equipe, jogadorSolicitante:jogadorId, valorAnterior:this.valorMao };

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `true` = valor lógico verdadeiro.
      this.bloqueado = true;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'chamada'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      tocar('chamada');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `jogadorId` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador id.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
      // `}` = fecha um bloco de código ou objeto.
      // `pediu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pediu.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `!` = nega o valor lógico da expressão seguinte.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1700` = valor numérico 1700 utilizado nesta instrução.
      toast(`${this.jogadores[jogadorId].nome} pediu ${C().nomePedido(pedido)}!`, 1700);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarTudo();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if (equipe === 1) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `=>` = define uma função de seta.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `modalResponderPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modal responder pedido.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `650` = intervalo de tempo utilizado pelo temporizador nesta operação.
        agendar(() => this.modalResponderPedido(), 650);

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `}` = fecha um bloco de código ou objeto.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `{` = abre um bloco de código ou objeto.
      } else {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `=>` = define uma função de seta.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `respostaAutomatica` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta automatica.
        // `1` = intervalo de tempo utilizado pelo temporizador nesta operação.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `700` = intervalo de tempo utilizado pelo temporizador nesta operação.
        agendar(() => this.respostaAutomatica(1), 700);

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `true` = valor lógico verdadeiro.
      return true;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `cartasEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas equipe.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipe` = representa uma das equipes da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `this` = representa o objeto atual dentro do método ou função em execução.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
    // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
    // `=>` = define uma função de seta.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `flatMap` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a flat map.
    // `mao` = representa uma mão completa de Truco.
    // `}` = fecha um bloco de código ou objeto.
    // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
    cartasEquipe(equipe) { return this.jogadores.filter(j=>j.equipe===equipe).flatMap(j=>j.mao); }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `respostaAutomatica` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta automatica.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    respostaAutomatica(equipeRespondente) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (!this.pedidoPendente) return;

      // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      const p = this.pedidoPendente;

      // Declara `venceuPrimeira` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `venceuPrimeira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu primeira.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
      // `vencedorEquipe` = identificador relacionado ao vencedor de equipe.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
      const venceuPrimeira = this.vazas[0]?.vencedorEquipe === equipeRespondente;

      // Declara `resposta` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `resposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `responderPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder pedido.
      // `{` = abre um bloco de código ou objeto.
      // `cartas` = representa uma coleção de cartas.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `cartasEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cartas equipe.
      // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `valorPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor pedido.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `pontosEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos equipe.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `venceuPrimeira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu primeira.
      // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
      // `}` = fecha um bloco de código ou objeto.
      const resposta = IA().responderPedido({cartas:this.cartasEquipe(equipeRespondente),vira:this.vira,valorPedido:p.pedido,pontosEquipe:this.pontos[equipeRespondente],venceuPrimeira,nivel:this.nivel});

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `resposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'correr'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if (resposta === 'correr') {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `'correr'` = texto literal utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        tocar('correr');

        // Declara `valorGanhar` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `valorGanhar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor ganhar.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `valorAnterior` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor anterior.
        const valorGanhar = p.valorAnterior;

        // Declara `vencedor` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `vencedor` = identificador relacionado ao vencedor de uma etapa da partida.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
        const vencedor = p.equipeSolicitante;

        // Declara `nomePedido` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        const nomePedido = C().nomePedido(p.pedido);

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `null` = representa ausência intencional de valor.
        this.pedidoPendente = null;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `true` = valor lógico verdadeiro.
        this.bloqueado = true;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        renderizarTudo();

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `avisoApostaRapido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso aposta rapido.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        avisoApostaRapido({

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `{` = abre um bloco de código ou objeto.
          // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `toUpperCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to upper case.
          // `}` = fecha um bloco de código ou objeto.
          // `CORREU` = constante utilizada para armazenar ou configurar o valor relacionado a correu.
          // `!` = nega o valor lógico da expressão seguinte.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          titulo: `${nomeEquipe(equipeRespondente).toUpperCase()} CORREU!`,

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `A` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
          // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
          // `correu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a correu.
          // `do` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a do.
          // `{` = abre um bloco de código ou objeto.
          // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
          // `}` = fecha um bloco de código ou objeto.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `Sua` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sua.
          // `equipe` = representa uma das equipes da partida.
          // `recebe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a recebe.
          // `valorGanhar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor ganhar.
          // `ponto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ponto.
          // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
          // `1` = valor normal da mão, equivalente a 1 ponto.
          // `?` = participa do operador condicional ternário.
          // `''` = texto literal utilizado nesta instrução.
          // `'s'` = texto literal utilizado nesta instrução.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          texto: `A IA correu do ${nomePedido}. Sua equipe recebe ${valorGanhar} ponto${valorGanhar===1?'':'s'}.`,

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `'correu'` = texto literal utilizado nesta instrução.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          tipo: 'correu',

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `duracao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a duracao.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `1150` = intervalo de tempo utilizado pelo temporizador nesta operação.
          duracao: 1150

        // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
        // `}` = fecha um bloco de código ou objeto.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        });

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `=>` = define uma função de seta.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
        // `vencedor` = identificador relacionado ao vencedor de uma etapa da partida.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `valorGanhar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor ganhar.
        // `'Equipe rival correu do pedido'` = texto literal utilizado nesta instrução.
        // `1180` = intervalo de tempo utilizado pelo temporizador nesta operação.
        agendar(() => this.encerrarMao(vencedor, valorGanhar, 'Equipe rival correu do pedido'), 1180);

        // Encerra imediatamente a execução da função atual sem devolver um valor específico.
        // `return` = encerra a função atual e devolve o valor especificado.
        return;

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `resposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'aceitar'` = texto literal utilizado nesta instrução.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `!` = nega o valor lógico da expressão seguinte.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `{` = abre um bloco de código ou objeto.
      if (resposta === 'aceitar' || !C().proximoValorAposta(p.pedido)) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `'aceitar'` = texto literal utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        tocar('aceitar');

        // Declara `nomePedido` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        const nomePedido = C().nomePedido(p.pedido);

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        this.valorMao = p.pedido;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
        this.ultimoPedidoEquipe = p.equipeSolicitante;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `null` = representa ausência intencional de valor.
        this.pedidoPendente = null;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `true` = valor lógico verdadeiro.
        this.bloqueado = true;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        renderizarTudo();

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `avisoApostaRapido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aviso aposta rapido.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        avisoApostaRapido({

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `{` = abre um bloco de código ou objeto.
          // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `toUpperCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to upper case.
          // `}` = fecha um bloco de código ou objeto.
          // `ACEITOU` = constante utilizada para armazenar ou configurar o valor relacionado a aceitou.
          // `!` = nega o valor lógico da expressão seguinte.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          titulo: `${nomeEquipe(equipeRespondente).toUpperCase()} ACEITOU!`,

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `A` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
          // `IA` = constante utilizada para armazenar ou configurar o valor relacionado a ia.
          // `aceitou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aceitou.
          // `o` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a o.
          // `{` = abre um bloco de código ou objeto.
          // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
          // `}` = fecha um bloco de código ou objeto.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
          // `agora` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agora.
          // `vale` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vale.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
          // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          texto: `A IA aceitou o ${nomePedido}. A mão agora vale ${this.valorMao} pontos.`,

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `'aceitou'` = texto literal utilizado nesta instrução.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          tipo: 'aceitou',

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `duracao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a duracao.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `1000` = intervalo de tempo utilizado pelo temporizador nesta operação.
          duracao: 1000

        // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
        // `}` = fecha um bloco de código ou objeto.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        });

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `=>` = define uma função de seta.
        // `{` = abre um bloco de código ou objeto.
        agendar(() => {

          // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
          // `if` = inicia uma condição executada quando a expressão é verdadeira.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `!` = nega o valor lógico da expressão seguinte.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
          // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
          // `partidaEncerrada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida encerrada.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `return` = encerra a função atual e devolve o valor especificado.
          if (!this.maoAtiva || this.partidaEncerrada) return;

          // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
          // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
          // `false` = valor lógico falso.
          this.bloqueado = false;

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          renderizarTudo();

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          this.processarTurno();

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `}` = fecha um bloco de código ou objeto.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `1030` = valor numérico 1030 utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        }, 1030);

        // Encerra imediatamente a execução da função atual sem devolver um valor específico.
        // `return` = encerra a função atual e devolve o valor especificado.
        return;

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Declara `novo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `novo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a novo.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      const novo = C().proximoValorAposta(p.pedido);

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      this.valorMao = p.pedido;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de código ou objeto.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `novo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a novo.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
      // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
      // `jogadorSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador solicitante.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `find` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a find.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=>` = define uma função de seta.
      // `equipe` = representa uma das equipes da partida.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `!` = nega o valor lógico da expressão seguinte.
      // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
      // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
      // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
      // `1` = valor normal da mão, equivalente a 1 ponto.
      // `valorAnterior` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor anterior.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `}` = fecha um bloco de código ou objeto.
      this.pedidoPendente = {pedido:novo,equipeSolicitante:equipeRespondente,jogadorSolicitante:this.jogadores.find(j=>j.equipe===equipeRespondente && !j.humano)?.id ?? 1,valorAnterior:p.pedido};

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
      this.ultimoPedidoEquipe = equipeRespondente;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'aumentar'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `{` = abre um bloco de código ou objeto.
      // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
      // `equipeRespondente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe respondente.
      // `}` = fecha um bloco de código ou objeto.
      // `aumentou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aumentou.
      // `para` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a para.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
      // `novo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a novo.
      // `!` = nega o valor lógico da expressão seguinte.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `1800` = valor numérico 1800 utilizado nesta instrução.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      tocar('aumentar'); toast(`${nomeEquipe(equipeRespondente)} aumentou para ${C().nomePedido(novo)}!`,1800); renderizarTudo();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `0` = intervalo de tempo utilizado pelo temporizador nesta operação.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
      // `=>` = define uma função de seta.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `modalResponderPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modal responder pedido.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `600` = intervalo de tempo utilizado pelo temporizador nesta operação.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `respostaAutomatica` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta automatica.
      if (p.equipeSolicitante === 0) agendar(()=>this.modalResponderPedido(),600); else agendar(()=>this.respostaAutomatica(0),600);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `modalResponderPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modal responder pedido.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    modalResponderPedido() {

      // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      const p = this.pedidoPendente; if (!p) return;

      // Declara `proximo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `proximo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      const proximo = C().proximoValorAposta(p.pedido);

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      abrirModal({

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `rotulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rotulo.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `'PEDIDO DE APOSTA'` = texto literal utilizado nesta instrução.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
        // `{` = abre um bloco de código ou objeto.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        // `}` = fecha um bloco de código ou objeto.
        // `!` = nega o valor lógico da expressão seguinte.
        // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
        // `'♣'` = texto literal utilizado nesta instrução.
        // `tipo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tipo.
        // `'decisao'` = texto literal utilizado nesta instrução.
        rotulo:'PEDIDO DE APOSTA', titulo:`${C().nomePedido(p.pedido)}!`, icone:'♣', tipo:'decisao',

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `{` = abre um bloco de código ou objeto.
        // `htmlCartasDaDecisao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html cartas da decisao.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `}` = fecha um bloco de código ou objeto.
        // `<` = verifica se o valor da esquerda é menor que o da direita.
        // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
        // `class` = define uma nova classe.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `"texto-decisao"` = texto literal utilizado nesta instrução.
        // `>` = verifica se o valor da esquerda é maior que o da direita.
        // `"chamada-gigante"` = texto literal utilizado nesta instrução.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        // `/` = realiza divisão.
        // `Os` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a os.
        // `adversários` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a adversários.
        // `aumentaram` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aumentaram.
        // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
        // `mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
        // `para` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a para.
        // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
        // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
        // `Confira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a confira.
        // `as` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a as.
        // `cartas` = representa uma coleção de cartas.
        // `disponíveis` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a disponíveis.
        // `da` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a da.
        // `sua` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sua.
        // `equipe` = representa uma das equipes da partida.
        // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
        // `decida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a decida.
        // `o` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a o.
        // `que` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a que.
        // `ela` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ela.
        // `fará` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fará.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        html:`${htmlCartasDaDecisao()}<div class="texto-decisao"><div class="chamada-gigante">${C().nomePedido(p.pedido)}</div><p>Os adversários aumentaram a mão para <strong>${p.pedido} pontos</strong>. Confira as cartas disponíveis da sua equipe e decida o que ela fará.</p></div>`,

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `[` = abre uma lista, índice ou acesso por chave.
        botoes:[

          // Inicia a estrutura de dados declarada nesta linha.
          // `{` = abre um bloco de código ou objeto.
          // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `CORRER` = constante utilizada para armazenar ou configurar o valor relacionado a correr.
          // `CEDE` = constante utilizada para armazenar ou configurar o valor relacionado a cede.
          // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `valorAnterior` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor anterior.
          // `}` = fecha um bloco de código ou objeto.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
          // `'perigo'` = texto literal utilizado nesta instrução.
          // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `=>` = define uma função de seta.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `responderHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder humano.
          // `'correr'` = texto literal utilizado nesta instrução.
          {texto:`CORRER • CEDE ${p.valorAnterior}`,classe:'perigo',acao:()=>this.responderHumano('correr')},

          // Inicia a estrutura de dados declarada nesta linha.
          // `{` = abre um bloco de código ou objeto.
          // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `ACEITAR` = constante utilizada para armazenar ou configurar o valor relacionado a aceitar.
          // `VALE` = constante utilizada para armazenar ou configurar o valor relacionado a vale.
          // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
          // `}` = fecha um bloco de código ou objeto.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `=>` = define uma função de seta.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `responderHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder humano.
          // `'aceitar'` = texto literal utilizado nesta instrução.
          {texto:`ACEITAR • VALE ${p.pedido}`,acao:()=>this.responderHumano('aceitar')},

          // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
          // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
          // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `proximo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo.
          // `?` = participa do operador condicional ternário.
          // `[` = abre uma lista, índice ou acesso por chave.
          // `{` = abre um bloco de código ou objeto.
          // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
          // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
          // `AUMENTAR` = constante utilizada para armazenar ou configurar o valor relacionado a aumentar.
          // `PARA` = constante utilizada para armazenar ou configurar o valor relacionado a para.
          // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
          // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
          // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
          // `}` = fecha um bloco de código ou objeto.
          // `,` = separa argumentos, parâmetros ou elementos da estrutura.
          // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
          // `'destaque'` = texto literal utilizado nesta instrução.
          // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
          // `=>` = define uma função de seta.
          // `this` = representa o objeto atual dentro do método ou função em execução.
          // `responderHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder humano.
          // `'aumentar'` = texto literal utilizado nesta instrução.
          // `]` = fecha uma lista, índice ou acesso por chave.
          ...(proximo?[{texto:`AUMENTAR PARA ${C().nomePedido(proximo)}`,classe:'destaque',acao:()=>this.responderHumano('aumentar')}]:[])

        // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
        // `]` = fecha uma lista, índice ou acesso por chave.
        ]

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      });

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `responderHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder humano.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    responderHumano(acao) {

      // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      const p=this.pedidoPendente; if(!p)return;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'correr'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `vencedor` = identificador relacionado ao vencedor de uma etapa da partida.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
      // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
      // `valorAnterior` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor anterior.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `null` = representa ausência intencional de valor.
      // `encerrarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a encerrar mao.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `'Sua equipe correu'` = texto literal utilizado nesta instrução.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `}` = fecha um bloco de código ou objeto.
      if(acao==='correr'){tocar('correr');const vencedor=p.equipeSolicitante;const pontos=p.valorAnterior;this.pedidoPendente=null;this.encerrarMao(vencedor,pontos,'Sua equipe correu');return;}

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'aceitar'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
      // `this` = representa o objeto atual dentro do método ou função em execução.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
      // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
      // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
      // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
      // `null` = representa ausência intencional de valor.
      // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
      // `false` = valor lógico falso.
      // `toast` = representa a mensagem temporária exibida na interface.
      // `Sua` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sua.
      // `equipe` = representa uma das equipes da partida.
      // `aceitou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aceitou.
      // `A` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
      // `mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
      // `vale` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vale.
      // `}` = fecha um bloco de código ou objeto.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `processarTurno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a processar turno.
      // `return` = encerra a função atual e devolve o valor especificado.
      if(acao==='aceitar'){tocar('aceitar');this.valorMao=p.pedido;this.ultimoPedidoEquipe=p.equipeSolicitante;this.pedidoPendente=null;this.bloqueado=false;toast(`Sua equipe aceitou. A mão vale ${this.valorMao}.`);renderizarTudo();this.processarTurno();return;}

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'aumentar'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if(acao==='aumentar'){

        // Declara `novo` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `novo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a novo.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `!` = nega o valor lógico da expressão seguinte.
        // `{` = abre um bloco de código ou objeto.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `responderHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder humano.
        // `'aceitar'` = texto literal utilizado nesta instrução.
        // `return` = encerra a função atual e devolve o valor especificado.
        // `}` = fecha um bloco de código ou objeto.
        const novo=C().proximoValorAposta(p.pedido);if(!novo){this.responderHumano('aceitar');return;}

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa o objeto atual dentro do método ou função em execução.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
        // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
        // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
        // `{` = abre um bloco de código ou objeto.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `novo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a novo.
        // `,` = separa argumentos, parâmetros ou elementos da estrutura.
        // `equipeSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe solicitante.
        // `0` = intervalo de tempo utilizado pelo temporizador nesta operação.
        // `jogadorSolicitante` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogador solicitante.
        // `valorAnterior` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor anterior.
        // `}` = fecha um bloco de código ou objeto.
        // `ultimoPedidoEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ultimo pedido equipe.
        // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
        // `true` = valor lógico verdadeiro.
        // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `'aumentar'` = texto literal utilizado nesta instrução.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `toast` = representa a mensagem temporária exibida na interface.
        // `Você` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a você.
        // `aumentou` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aumentou.
        // `para` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a para.
        // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
        // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
        // `!` = nega o valor lógico da expressão seguinte.
        // `1700` = intervalo de tempo utilizado pelo temporizador nesta operação.
        // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
        // `agendar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a agendar.
        // `=>` = define uma função de seta.
        // `respostaAutomatica` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resposta automatica.
        // `1` = valor normal da mão, equivalente a 1 ponto.
        // `650` = intervalo de tempo utilizado pelo temporizador nesta operação.
        this.valorMao=p.pedido;this.pedidoPendente={pedido:novo,equipeSolicitante:0,jogadorSolicitante:0,valorAnterior:p.pedido};this.ultimoPedidoEquipe=0;this.bloqueado=true;tocar('aumentar');toast(`Você aumentou para ${C().nomePedido(novo)}!`,1700);renderizarTudo();agendar(()=>this.respostaAutomatica(1),650);

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `nomeEquipe` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `nomeEquipe` = nome da função responsável pela operação relacionada a nome equipe.
  // `equipe` = parâmetro recebido pela função para fornecer o valor relacionado a equipe.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function nomeEquipe(equipe) {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `equipe` = representa uma das equipes da partida.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `?` = participa do operador condicional ternário.
    // `'Você'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'IA'` = texto literal utilizado nesta instrução.
    if (!jogo) return equipe===0?'Você':'IA';

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `equipe` = representa uma das equipes da partida.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `?` = participa do operador condicional ternário.
    // `nomeHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome humano.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'IA Rival'` = texto literal utilizado nesta instrução.
    if (jogo.modo === 'duelo') return equipe===0 ? jogo.nomeHumano : 'IA Rival';

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `equipe` = representa uma das equipes da partida.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `?` = participa do operador condicional ternário.
    // `'Sua dupla'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'Dupla adversária'` = texto literal utilizado nesta instrução.
    return equipe===0 ? 'Sua dupla' : 'Dupla adversária';

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `criarCartaHTML` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `criarCartaHTML` = nome da função responsável pela operação relacionada a criar carta html.
  // `carta` = parâmetro recebido pela função para fornecer o valor relacionado a carta.
  // `fechada` = parâmetro recebido pela função para fornecer o valor relacionado a fechada.
  // `false` = valor padrão usado para `fechada` quando o argumento não é fornecido.
  // `classe` = parâmetro recebido pela função para fornecer o valor relacionado a classe.
  // `'carta'` = valor padrão usado para `classe` quando o argumento não é fornecido.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `false` = valor lógico falso.
  // `'carta'` = texto literal utilizado nesta instrução.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function criarCartaHTML(carta, fechada=false, classe='carta') {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
    // `class` = define uma nova classe.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `"${classe} fechada"` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `/` = realiza divisão.
    if (fechada) return `<div class="${classe} fechada"></div>`;

    // Declara `vermelha` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `vermelha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vermelha.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `'♦'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'♥'` = texto literal utilizado nesta instrução.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `includes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a includes.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `carta` = representa uma carta do baralho.
    // `naipe` = representa o naipe de uma carta.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `?` = participa do operador condicional ternário.
    // `' vermelha'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `''` = texto literal utilizado nesta instrução.
    const vermelha = ['♦','♥'].includes(carta.naipe) ? ' vermelha' : '';

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
    // `class` = define uma nova classe.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `"${classe}${vermelha}"` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `"canto"` = texto literal utilizado nesta instrução.
    // `{` = abre um bloco de código ou objeto.
    // `carta` = representa uma carta do baralho.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `valor` = representa o valor ou figura de uma carta.
    // `}` = fecha um bloco de código ou objeto.
    // `br` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a br.
    // `naipe` = representa o naipe de uma carta.
    // `/` = realiza divisão.
    // `"naipe-centro"` = texto literal utilizado nesta instrução.
    // `"canto baixo"` = texto literal utilizado nesta instrução.
    return `<div class="${classe}${vermelha}"><div class="canto">${carta.valor}<br>${carta.naipe}</div><div class="naipe-centro">${carta.naipe}</div><div class="canto baixo">${carta.valor}<br>${carta.naipe}</div></div>`;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarAssento` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarAssento` = nome da função responsável pela operação relacionada a renderizar assento.
  // `idElemento` = parâmetro recebido pela função para fornecer o valor relacionado a id elemento.
  // `jogador` = parâmetro recebido pela função para fornecer o valor relacionado a jogador.
  // `posicao` = parâmetro recebido pela função para fornecer o valor relacionado a posicao.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function renderizarAssento(idElemento, jogador, posicao) {

    // Declara `el` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `idElemento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id elemento.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const el=$(idElemento);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogador` = representa um participante da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `assento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a assento.
    // `-` = realiza subtração ou representa um valor negativo.
    // `posicao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a posicao.
    // `}` = fecha um bloco de código ou objeto.
    // `oculto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a oculto.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `''` = texto literal utilizado nesta instrução.
    // `return` = encerra a função atual e devolve o valor especificado.
    if(!jogador){el.className=`assento assento-${posicao} oculto`;el.innerHTML='';return;}

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `assento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a assento.
    // `-` = realiza subtração ou representa um valor negativo.
    // `{` = abre um bloco de código ou objeto.
    // `posicao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a posicao.
    // `}` = fecha um bloco de código ou objeto.
    // `jogo` = armazena o estado atual da partida.
    // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `jogador` = representa um participante da partida.
    // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
    // `?` = participa do operador condicional ternário.
    // `' turno'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `''` = texto literal utilizado nesta instrução.
    el.className=`assento assento-${posicao}${jogo.turno===jogador.id&&jogo.maoAtiva?' turno':''}`;

    // Declara `iniciais` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `iniciais` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciais.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogador` = representa um participante da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
    // `?` = participa do operador condicional ternário.
    // `'EU'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'IA'` = texto literal utilizado nesta instrução.
    const iniciais=jogador.humano?'EU':'IA';

    // Declara `cartas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `cartas` = representa uma coleção de cartas.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogador` = representa um participante da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
    // `?` = participa do operador condicional ternário.
    // `''` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
    // `class` = define uma nova classe.
    // `"cartas-costas"` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `{` = abre um bloco de código ou objeto.
    // `mao` = representa uma mão completa de Truco.
    // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `'<div class="carta-costas-mini"></div>'` = texto literal utilizado nesta instrução.
    // `join` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a join.
    // `}` = fecha um bloco de código ou objeto.
    // `/` = realiza divisão.
    // `map` = transforma cada elemento da lista e produz uma nova lista.
    const cartas=jogador.humano?'':`<div class="cartas-costas">${jogador.mao.map(()=>'<div class="carta-costas-mini"></div>').join('')}</div>`;

    // Atualiza o conteúdo HTML interno do elemento da interface.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
    // `class` = define uma nova classe.
    // `"info-jogador"` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `span` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a span.
    // `"avatar"` = texto literal utilizado nesta instrução.
    // `{` = abre um bloco de código ou objeto.
    // `iniciais` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciais.
    // `}` = fecha um bloco de código ou objeto.
    // `/` = realiza divisão.
    // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
    // `escapar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escapar.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogador` = representa um participante da partida.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `small` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a small.
    // `equipe` = representa uma das equipes da partida.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `?` = participa do operador condicional ternário.
    // `'Sua equipe'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'Adversário'` = texto literal utilizado nesta instrução.
    // `mao` = representa uma mão completa de Truco.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `carta` = representa uma carta do baralho.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `''` = texto literal utilizado nesta instrução.
    // `'s'` = texto literal utilizado nesta instrução.
    // `cartas` = representa uma coleção de cartas.
    el.innerHTML=`<div class="info-jogador"><span class="avatar">${iniciais}</span><div><strong>${escapar(jogador.nome)}</strong><small>${jogador.equipe===0?'Sua equipe':'Adversário'} • ${jogador.mao.length} carta${jogador.mao.length===1?'':'s'}</small></div></div>${cartas}`;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarMesa` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarMesa` = nome da função responsável pela operação relacionada a renderizar mesa.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function renderizarMesa() {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    if(!jogo)return;

    // Ativa ou desativa uma classe CSS do elemento de acordo com a condição informada.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'mesa'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `toggle` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a toggle.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `jogo` = armazena o estado atual da partida.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    $('mesa').classList.toggle('duelo',jogo.modo==='duelo');

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if(jogo.modo==='duelo'){

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'jogador-topo'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `jogo` = armazena o estado atual da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `'topo'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarAssento('jogador-topo',jogo.jogadores[1],'topo');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'jogador-esquerda'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `null` = representa ausência intencional de valor.
      // `'esquerda'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarAssento('jogador-esquerda',null,'esquerda');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'jogador-direita'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `null` = representa ausência intencional de valor.
      // `'direita'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarAssento('jogador-direita',null,'direita');

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `}` = fecha um bloco de código ou objeto.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `{` = abre um bloco de código ou objeto.
    }else{

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'jogador-topo'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `jogo` = armazena o estado atual da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `2` = valor numérico 2 utilizado nesta instrução.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `'topo'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarAssento('jogador-topo',jogo.jogadores[2],'topo');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'jogador-esquerda'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `jogo` = armazena o estado atual da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `'esquerda'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarAssento('jogador-esquerda',jogo.jogadores[1],'esquerda');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'jogador-direita'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `jogo` = armazena o estado atual da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `3` = valor numérico 3 utilizado nesta instrução.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `'direita'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      renderizarAssento('jogador-direita',jogo.jogadores[3],'direita');

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `renderizarAssento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar assento.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'jogador-humano'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `'baixo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    renderizarAssento('jogador-humano',jogo.jogadores[0],'baixo');

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'carta-vira'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `outerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a outer html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
    // `id` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a id.
    // `"carta-vira"` = texto literal utilizado nesta instrução.
    // `class` = define uma nova classe.
    // `"mini-carta${['♦','♥'].includes(jogo.vira.naipe)?' vermelha':''}"` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `"canto"` = texto literal utilizado nesta instrução.
    // `{` = abre um bloco de código ou objeto.
    // `jogo` = armazena o estado atual da partida.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `valor` = representa o valor ou figura de uma carta.
    // `}` = fecha um bloco de código ou objeto.
    // `br` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a br.
    // `naipe` = representa o naipe de uma carta.
    // `/` = realiza divisão.
    // `"naipe-centro"` = texto literal utilizado nesta instrução.
    // `"canto baixo"` = texto literal utilizado nesta instrução.
    $('carta-vira').outerHTML = `<div id="carta-vira" class="mini-carta${['♦','♥'].includes(jogo.vira.naipe)?' vermelha':''}"><div class="canto">${jogo.vira.valor}<br>${jogo.vira.naipe}</div><div class="naipe-centro">${jogo.vira.naipe}</div><div class="canto baixo">${jogo.vira.valor}<br>${jogo.vira.naipe}</div></div>`;

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'texto-manilha'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `MANILHA` = constante utilizada para armazenar ou configurar o valor relacionado a manilha.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `{` = abre um bloco de código ou objeto.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `valorManilha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor manilha.
    // `jogo` = armazena o estado atual da partida.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `}` = fecha um bloco de código ou objeto.
    $('texto-manilha').textContent=`MANILHA: ${C().valorManilha(jogo.vira)}`;

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'valor-mao'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
    // `'nome-aposta'` = texto literal utilizado nesta instrução.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
    $('valor-mao').textContent=jogo.valorMao;$('nome-aposta').textContent=C().nomePedido(jogo.valorMao);

    // Declara `area` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `area` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a area.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'area-jogadas'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `''` = texto literal utilizado nesta instrução.
    const area=$('area-jogadas');area.innerHTML='';

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadasVaza` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas vaza.
    // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `forEach` = executa uma função para cada elemento da coleção.
    jogo.jogadasVaza.forEach(j=>{

      // Declara `div` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `document` = representa o documento HTML carregado no navegador.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `createElement` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a create element.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'div'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
      // `jogada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogada.
      // `-` = realiza subtração ou representa um valor negativo.
      // `centro` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a centro.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `{` = abre um bloco de código ou objeto.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `jogador` = representa um participante da partida.
      // `}` = fecha um bloco de código ou objeto.
      // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
      // `criarCartaHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a criar carta html.
      // `carta` = representa uma carta do baralho.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
      // `'carta'` = texto literal utilizado nesta instrução.
      // `area` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a area.
      // `appendChild` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a append child.
      const div=document.createElement('div');div.className=`jogada-centro p${j.jogador}`;div.innerHTML=criarCartaHTML(j.carta,j.fechada,'carta');area.appendChild(div);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    });

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarMao` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarMao` = nome da função responsável pela operação relacionada a renderizar mao.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function renderizarMao() {

    // Declara `el` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'mao-humana'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `{` = abre um bloco de código ou objeto.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `''` = texto literal utilizado nesta instrução.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `}` = fecha um bloco de código ou objeto.
    const el=$('mao-humana'); if(!jogo){el.innerHTML='';return;}

    // Declara `humano` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    const humano=jogo.jogadores[0];

    // Atualiza o conteúdo HTML interno do elemento da interface.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `''` = texto literal utilizado nesta instrução.
    el.innerHTML='';

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `humano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humano.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `mao` = representa uma mão completa de Truco.
    // `forEach` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a for each.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `carta` = representa uma carta do baralho.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `forEach` = executa uma função para cada elemento da coleção.
    humano.mao.forEach((carta,indice)=>{

      // Declara `btn` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `btn` = referência ao botão relacionado a btn.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `document` = representa o documento HTML carregado no navegador.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `createElement` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a create element.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'button'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
      // `carta` = representa uma carta do baralho.
      // `-` = realiza subtração ou representa um valor negativo.
      // `humana` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a humana.
      // `{` = abre um bloco de código ou objeto.
      // `jogo` = armazena o estado atual da partida.
      // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
      // `?` = participa do operador condicional ternário.
      // `' selecionada-fechada'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `''` = texto literal utilizado nesta instrução.
      // `}` = fecha um bloco de código ou objeto.
      // `disabled` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a disabled.
      // `!` = nega o valor lógico da expressão seguinte.
      // `podeJogarHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode jogar humano.
      // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
      // `criarCartaHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a criar carta html.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `false` = valor lógico falso.
      // `'carta'` = texto literal utilizado nesta instrução.
      // `title` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a title.
      // `'Jogar esta carta fechada'` = texto literal utilizado nesta instrução.
      // `Jogar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `nomeCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome carta.
      // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
      // `'click'` = texto literal utilizado nesta instrução.
      // `=>` = define uma função de seta.
      // `jogarHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogar humano.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `'contextmenu'` = texto literal utilizado nesta instrução.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `preventDefault` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a prevent default.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
      // `podeFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechada.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `true` = valor lógico verdadeiro.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
      // `appendChild` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a append child.
      const btn=document.createElement('button');btn.className=`carta-humana${jogo.fechadaAtiva?' selecionada-fechada':''}`;btn.disabled=!jogo.podeJogarHumano();btn.innerHTML=criarCartaHTML(carta,false,'carta');btn.title=jogo.fechadaAtiva?'Jogar esta carta fechada':`Jogar ${C().nomeCarta(carta)}`;btn.addEventListener('click',()=>jogo.jogarHumano(indice));btn.addEventListener('contextmenu',e=>{e.preventDefault();if(!jogo?.podeFechada())return;jogo.fechadaAtiva=true;renderizarTudo();jogo.jogarHumano(indice);});el.appendChild(btn);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    });

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarPlacar` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarPlacar` = nome da função responsável pela operação relacionada a renderizar placar.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function renderizarPlacar() {

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'pontos-time-a'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `'pontos-time-b'` = texto literal utilizado nesta instrução.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    $('pontos-time-a').textContent=jogo.pontos[0];$('pontos-time-b').textContent=jogo.pontos[1];

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'placar-nome-time-a'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `?` = participa do operador condicional ternário.
    // `nomeHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome humano.
    // `toUpperCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to upper case.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'SUA DUPLA'` = texto literal utilizado nesta instrução.
    $('placar-nome-time-a').textContent=jogo.modo==='duelo'?jogo.nomeHumano.toUpperCase():'SUA DUPLA';

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'placar-nome-time-b'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `?` = participa do operador condicional ternário.
    // `'IA RIVAL'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'DUPLA ADVERSÁRIA'` = texto literal utilizado nesta instrução.
    $('placar-nome-time-b').textContent=jogo.modo==='duelo'?'IA RIVAL':'DUPLA ADVERSÁRIA';

    // Declara `marc` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `marc` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a marc.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'marcadores-pontos'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `''` = texto literal utilizado nesta instrução.
    // `for` = inicia uma estrutura de repetição.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `12` = valor numérico 12 utilizado nesta instrução.
    // `++` = incrementa o valor em uma unidade.
    // `{` = abre um bloco de código ou objeto.
    // `s` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a s.
    // `document` = representa o documento HTML carregado no navegador.
    // `createElement` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a create element.
    // `'span'` = texto literal utilizado nesta instrução.
    // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
    // `'marcador'` = texto literal utilizado nesta instrução.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `jogo` = armazena o estado atual da partida.
    // `pontos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `?` = participa do operador condicional ternário.
    // `' a'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `' b'` = texto literal utilizado nesta instrução.
    // `appendChild` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a append child.
    // `}` = fecha um bloco de código ou objeto.
    const marc=$('marcadores-pontos');marc.innerHTML='';for(let i=1;i<=12;i++){const s=document.createElement('span');s.className='marcador'+(i<=jogo.pontos[0]?' a':i<=jogo.pontos[1]?' b':'');marc.appendChild(s);}

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarAcoesStatus` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarAcoesStatus` = nome da função responsável pela operação relacionada a renderizar acoes status.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function renderizarAcoesStatus() {

    // Declara `turno` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `]` = fecha uma lista, índice ou acesso por chave.
    const turno=jogo.jogadores[jogo.turno];

    // Declara `status` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'Mão em andamento'` = texto literal utilizado nesta instrução.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `''` = texto literal utilizado nesta instrução.
    let status='Mão em andamento';let detalhe='';

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `partidaEncerrada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida encerrada.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'Partida encerrada'` = texto literal utilizado nesta instrução.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `'Confira o resultado final.'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    if(jogo.partidaEncerrada){status='Partida encerrada';detalhe='Confira o resultado final.';}

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'Mão encerrada'` = texto literal utilizado nesta instrução.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `'Preparando a próxima mão...'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    else if(!jogo.maoAtiva){status='Mão encerrada';detalhe='Preparando a próxima mão...';}

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `pedidoPendente` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido pendente.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `Pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
    // `de` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a de.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
    // `pedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido.
    // `}` = fecha um bloco de código ou objeto.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `'Aguardando decisão da aposta.'` = texto literal utilizado nesta instrução.
    else if(jogo.pedidoPendente){status=`Pedido de ${C().nomePedido(jogo.pedidoPendente.pedido)}`;detalhe='Aguardando decisão da aposta.';}

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `bloqueado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a bloqueado.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'Aguarde'` = texto literal utilizado nesta instrução.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `'A mesa está concluindo a jogada.'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    else if(jogo.bloqueado){status='Aguarde';detalhe='A mesa está concluindo a jogada.';}

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `'Sua vez'` = texto literal utilizado nesta instrução.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `'Escolha uma carta para jogar.'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    else if(jogo.turno===0){status='Sua vez';detalhe='Escolha uma carta para jogar.';}

    // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `{` = abre um bloco de código ou objeto.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `Vez` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vez.
    // `de` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a de.
    // `turno` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a turno.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `}` = fecha um bloco de código ou objeto.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    // `'A Inteligência Artificial está pensando.'` = texto literal utilizado nesta instrução.
    else{status=`Vez de ${turno.nome}`;detalhe='A Inteligência Artificial está pensando.';}

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'mensagem-status'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `status` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a status.
    // `'texto-turno'` = texto literal utilizado nesta instrução.
    // `detalhe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a detalhe.
    $('mensagem-status').textContent=status;$('texto-turno').textContent=detalhe;

    // Declara `indicadorValor` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `indicadorValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indicador valor.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'partida-valendo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const indicadorValor=$('partida-valendo');

    // Declara `textoValor` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `textoValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto valor.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'partida-valendo-valor'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const textoValor=$('partida-valendo-valor');

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `indicadorValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indicador valor.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `textoValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto valor.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if(indicadorValor && textoValor){

      // Atualiza o conteúdo textual do elemento da interface com o valor informado.
      // `textoValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto valor.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de código ou objeto.
      // `jogo` = armazena o estado atual da partida.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `}` = fecha um bloco de código ou objeto.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `?` = participa do operador condicional ternário.
      // `'PONTO'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'PONTOS'` = texto literal utilizado nesta instrução.
      textoValor.textContent=`${jogo.valorMao} ${jogo.valorMao===1?'PONTO':'PONTOS'}`;

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `indicadorValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indicador valor.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `partida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida.
      // `-` = realiza subtração ou representa um valor negativo.
      // `valendo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valendo.
      // `valor` = representa o valor ou figura de uma carta.
      // `{` = abre um bloco de código ou objeto.
      // `jogo` = armazena o estado atual da partida.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `}` = fecha um bloco de código ou objeto.
      indicadorValor.className=`partida-valendo valor-${jogo.valorMao}`;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `indicadorValor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indicador valor.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `setAttribute` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set attribute.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'aria-label'` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `Partida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida.
      // `valendo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valendo.
      // `{` = abre um bloco de código ou objeto.
      // `jogo` = armazena o estado atual da partida.
      // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
      // `}` = fecha um bloco de código ou objeto.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `?` = participa do operador condicional ternário.
      // `'ponto'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'pontos'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      indicadorValor.setAttribute('aria-label',`Partida valendo ${jogo.valorMao} ${jogo.valorMao===1?'ponto':'pontos'}`);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Declara `btnT` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `btnT` = referência ao botão relacionado a btn t.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-truco'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `proximo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
    // `jogo` = armazena o estado atual da partida.
    // `valorMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor mao.
    // `disabled` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a disabled.
    // `!` = nega o valor lógico da expressão seguinte.
    // `podePedir` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode pedir.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `maoDeOnze` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao de onze.
    // `?` = participa do operador condicional ternário.
    // `'SEM TRUCO (11)'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
    // `'MÁXIMO'` = texto literal utilizado nesta instrução.
    const btnT=$('btn-truco');const proximo=C().proximoValorAposta(jogo.valorMao);btnT.disabled=!jogo.podePedir(0);btnT.textContent=jogo.maoDeOnze()?'SEM TRUCO (11)':proximo?C().nomePedido(proximo):'MÁXIMO';

    // Declara `btnF` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `btnF` = referência ao botão relacionado a btn f.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-fechada'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `disabled` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a disabled.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `podeFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechada.
    // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
    // `toggle` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a toggle.
    // `'ativo'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `?` = participa do operador condicional ternário.
    // `'✓ JOGAR FECHADA'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'🂠 Carta fechada'` = texto literal utilizado nesta instrução.
    // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
    const btnF=$('btn-fechada');btnF.disabled=!jogo.podeFechada();btnF.classList.toggle('ativo',jogo.fechadaAtiva);btnF.textContent=jogo.fechadaAtiva?'✓ JOGAR FECHADA':'🂠 Carta fechada';

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'indicador-mao'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `Mão` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mão.
    // `{` = abre um bloco de código ou objeto.
    // `jogo` = armazena o estado atual da partida.
    // `numeroMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a numero mao.
    // `}` = fecha um bloco de código ou objeto.
    $('indicador-mao').textContent=`Mão ${jogo.numeroMao}`;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarVazas` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarVazas` = nome da função responsável pela operação relacionada a renderizar vazas.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function renderizarVazas() {

    // Declara `el` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'vazas-lista'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
    // `''` = texto literal utilizado nesta instrução.
    const el=$('vazas-lista');el.innerHTML='';

    // Percorre os elementos ou repetições definidos nesta estrutura de laço.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `3` = valor numérico 3 utilizado nesta instrução.
    // `++` = incrementa o valor em uma unidade.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    for(let i=0;i<3;i++){

      // Declara `v` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `v` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a v.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `jogo` = armazena o estado atual da partida.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
      // `document` = representa o documento HTML carregado no navegador.
      // `createElement` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a create element.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `'div'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `className` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class name.
      // `'vaza-item'` = texto literal utilizado nesta instrução.
      const v=jogo.vazas[i];const div=document.createElement('div');div.className='vaza-item';

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `v` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a v.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `}` = fecha um bloco de código ou objeto.
      // `VAZA` = constante utilizada para armazenar ou configurar o valor relacionado a vaza.
      // `/` = realiza divisão.
      // `span` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a span.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `jogo` = armazena o estado atual da partida.
      // `vazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a vazas.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `maoAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a mao ativa.
      // `?` = participa do operador condicional ternário.
      // `'Em andamento'` = texto literal utilizado nesta instrução.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `'Aguardando'` = texto literal utilizado nesta instrução.
      if(!v){div.innerHTML=`<strong>${i+1}ª VAZA</strong><span>${i===jogo.vazas.length&&jogo.maoAtiva?'Em andamento':'Aguardando'}</span>`;}

      // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `{` = abre um bloco de código ou objeto.
      else{

        // Declara `resultado` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
        // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `'Empate'` = texto literal utilizado nesta instrução.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `v` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a v.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `vencedorEquipe` = identificador relacionado ao vencedor de equipe.
        // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
        // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `{` = abre um bloco de código ou objeto.
        // `nomeEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome equipe.
        // `}` = fecha um bloco de código ou objeto.
        // `venceu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu.
        // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
        // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
        // `add` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add.
        // `'vencida-a'` = texto literal utilizado nesta instrução.
        // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
        // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
        // `'vencida-b'` = texto literal utilizado nesta instrução.
        // `'empate'` = texto literal utilizado nesta instrução.
        // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
        let resultado='Empate';if(v.vencedorEquipe===0){resultado=`${nomeEquipe(0)} venceu`;div.classList.add('vencida-a');}else if(v.vencedorEquipe===1){resultado=`${nomeEquipe(1)} venceu`;div.classList.add('vencida-b');}else div.classList.add('empate');

        // Declara `cartas` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `cartas` = representa uma coleção de cartas.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `v` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a v.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
        // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
        // `=>` = define uma função de seta.
        // `{` = abre um bloco de código ou objeto.
        // `jogo` = armazena o estado atual da partida.
        // `jogadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadores.
        // `[` = abre uma lista, índice ou acesso por chave.
        // `jogador` = representa um participante da partida.
        // `]` = fecha uma lista, índice ou acesso por chave.
        // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
        // `}` = fecha um bloco de código ou objeto.
        // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
        // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
        // `?` = participa do operador condicional ternário.
        // `'Fechada'` = texto literal utilizado nesta instrução.
        // `carta` = representa uma carta do baralho.
        // `valor` = representa o valor ou figura de uma carta.
        // `naipe` = representa o naipe de uma carta.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `join` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a join.
        // `' • '` = texto literal utilizado nesta instrução.
        // `map` = transforma cada elemento da lista e produz uma nova lista.
        const cartas=v.jogadas.map(j=>`${jogo.jogadores[j.jogador].nome}: ${j.fechada?'Fechada':`${j.carta.valor}${j.carta.naipe}`}`).join(' • ');

        // Atualiza o conteúdo HTML interno do elemento da interface.
        // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `innerHTML` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a inner html.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `<` = verifica se o valor da esquerda é menor que o da direita.
        // `strong` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a strong.
        // `>` = verifica se o valor da esquerda é maior que o da direita.
        // `{` = abre um bloco de código ou objeto.
        // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
        // `+` = realiza soma ou concatenação conforme os valores envolvidos.
        // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
        // `}` = fecha um bloco de código ou objeto.
        // `VAZA` = constante utilizada para armazenar ou configurar o valor relacionado a vaza.
        // `resultado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a resultado.
        // `/` = realiza divisão.
        // `span` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a span.
        // `escapar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escapar.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `cartas` = representa uma coleção de cartas.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        div.innerHTML=`<strong>${i+1}ª VAZA — ${resultado}</strong><span>${escapar(cartas)}</span>`;

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `el` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a el.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `appendChild` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a append child.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `div` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a div.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      el.appendChild(div);

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `renderizarTudo` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `renderizarTudo` = nome da função responsável pela operação relacionada a renderizar tudo.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `if` = inicia uma condição executada quando a expressão é verdadeira.
  // `!` = nega o valor lógico da expressão seguinte.
  // `jogo` = armazena o estado atual da partida.
  // `return` = encerra a função atual e devolve o valor especificado.
  // `renderizarPlacar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar placar.
  // `renderizarMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar mesa.
  // `renderizarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar mao.
  // `renderizarAcoesStatus` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar acoes status.
  // `renderizarVazas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar vazas.
  // `}` = fecha um bloco de código ou objeto.
  function renderizarTudo() { if(!jogo)return;renderizarPlacar();renderizarMesa();renderizarMao();renderizarAcoesStatus();renderizarVazas(); }

  // Define a função `iniciarPartidaComConfiguracaoAtual` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `iniciarPartidaComConfiguracaoAtual` = nome da função responsável pela operação relacionada a iniciar partida com configuracao atual.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function iniciarPartidaComConfiguracaoAtual() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `cancelarTemporizadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cancelar temporizadores.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `fecharModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechar modal.
    cancelarTemporizadores();fecharModal();

    // Declara `nome` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'nome-jogador'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `value` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a value.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `'Jogador'` = texto literal utilizado nesta instrução.
    // `trim` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a trim.
    // `slice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a slice.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `24` = valor numérico 24 utilizado nesta instrução.
    const nome=($('nome-jogador').value||'Jogador').trim().slice(0,24)||'Jogador';

    // Declara `modoAtual` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `modoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo atual.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `obterModoSelecionadoNoMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a obter modo selecionado no menu.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const modoAtual = obterModoSelecionadoNoMenu();

    // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
    // `jogo` = armazena o estado atual da partida.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `new` = cria uma nova instância a partir da classe ou construtor informado.
    // `PartidaTrucoWeb` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a partida truco web.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `nome` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `modo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `modoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo atual.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `'nivel-ia'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `value` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a value.
    // `}` = fecha um bloco de código ou objeto.
    jogo=new PartidaTrucoWeb({nome,modo:modoAtual,nivel:$('nivel-ia').value});

    // Atualiza o conteúdo textual do elemento da interface com o valor informado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'texto-modo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `modoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modo atual.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `?` = participa do operador condicional ternário.
    // `'Mano a Mano • Você x IA'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'4 Jogadores • Duplas'` = texto literal utilizado nesta instrução.
    $('texto-modo').textContent=modoAtual==='duelo'?'Mano a Mano • Você x IA':'4 Jogadores • Duplas';

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `trocarTela` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a trocar tela.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'tela-jogo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogo` = armazena o estado atual da partida.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `iniciar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciar.
    trocarTela('tela-jogo');jogo.iniciar();

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `voltarMenu` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `voltarMenu` = nome da função responsável pela operação relacionada a voltar menu.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `cancelarTemporizadores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a cancelar temporizadores.
  // `fecharModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechar modal.
  // `jogo` = armazena o estado atual da partida.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `null` = representa ausência intencional de valor.
  // `trocarTela` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a trocar tela.
  // `'tela-menu'` = texto literal utilizado nesta instrução.
  // `atualizarRankingMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a atualizar ranking menu.
  // `}` = fecha um bloco de código ou objeto.
  function voltarMenu() { cancelarTemporizadores();fecharModal();jogo=null;trocarTela('tela-menu');atualizarRankingMenu(); }

  // Define a função `confirmarNovaPartida` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `confirmarNovaPartida` = nome da função responsável pela operação relacionada a confirmar nova partida.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function confirmarNovaPartida() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'Começar outra partida?'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
    // `'↻'` = texto literal utilizado nesta instrução.
    // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
    // `'<p>O placar atual será descartado. Partidas abandonadas não alteram o ranking.</p>'` = texto literal utilizado nesta instrução.
    // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
    // `'CANCELAR'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `'NOVA PARTIDA'` = texto literal utilizado nesta instrução.
    // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
    // `'destaque'` = texto literal utilizado nesta instrução.
    // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `iniciarPartidaComConfiguracaoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciar partida com configuracao atual.
    // `]` = fecha uma lista, índice ou acesso por chave.
    abrirModal({titulo:'Começar outra partida?',icone:'↻',html:'<p>O placar atual será descartado. Partidas abandonadas não alteram o ranking.</p>',botoes:[{texto:'CANCELAR'},{texto:'NOVA PARTIDA',classe:'destaque',acao:()=>iniciarPartidaComConfiguracaoAtual()}]});

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `configurarEventos` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `configurarEventos` = nome da função responsável pela operação relacionada a configurar eventos.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function configurarEventos() {

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modo-duelo'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `selecionarModo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a selecionar modo.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    $('modo-duelo').addEventListener('click',()=>selecionarModo('duelo'));

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modo-quatro'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `selecionarModo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a selecionar modo.
    // `'quatro'` = identificador do modo de jogo `4 Jogadores`.
    $('modo-quatro').addEventListener('click',()=>selecionarModo('quatro'));

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-iniciar'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `iniciarPartidaComConfiguracaoAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a iniciar partida com configuracao atual.
    $('btn-iniciar').addEventListener('click',iniciarPartidaComConfiguracaoAtual);

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-menu'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
    // `{` = abre um bloco de código ou objeto.
    // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'Voltar ao menu?'` = texto literal utilizado nesta instrução.
    // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
    // `'←'` = texto literal utilizado nesta instrução.
    // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
    // `'<p>A partida atual será abandonada e não alterará o ranking.</p>'` = texto literal utilizado nesta instrução.
    // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
    // `'CONTINUAR JOGANDO'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `'VOLTAR AO MENU'` = texto literal utilizado nesta instrução.
    // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
    // `'destaque'` = texto literal utilizado nesta instrução.
    // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
    // `voltarMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a voltar menu.
    // `]` = fecha uma lista, índice ou acesso por chave.
    $('btn-menu').addEventListener('click',()=>abrirModal({titulo:'Voltar ao menu?',icone:'←',html:'<p>A partida atual será abandonada e não alterará o ranking.</p>',botoes:[{texto:'CONTINUAR JOGANDO'},{texto:'VOLTAR AO MENU',classe:'destaque',acao:voltarMenu}]}));

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-nova-partida'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `confirmarNovaPartida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a confirmar nova partida.
    $('btn-nova-partida').addEventListener('click',confirmarNovaPartida);

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-ajuda-menu'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `modalAjuda` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modal ajuda.
    // `'btn-ajuda-jogo'` = texto literal utilizado nesta instrução.
    $('btn-ajuda-menu').addEventListener('click',modalAjuda);$('btn-ajuda-jogo').addEventListener('click',modalAjuda);

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'modal-fechar'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `fecharModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechar modal.
    $('modal-fechar').addEventListener('click',fecharModal);

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-som'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `somLigado` = indica se os efeitos sonoros estão ativados.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `!` = nega o valor lógico da expressão seguinte.
    // `textContent` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a text content.
    // `?` = participa do operador condicional ternário.
    // `'🔊 Som'` = texto literal utilizado nesta instrução.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'🔇 Som'` = texto literal utilizado nesta instrução.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `tocar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a tocar.
    // `'aceitar'` = texto literal utilizado nesta instrução.
    // `toast` = representa a mensagem temporária exibida na interface.
    // `'Som ativado.'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
    // `'Som desativado.'` = texto literal utilizado nesta instrução.
    $('btn-som').addEventListener('click',()=>{somLigado=!somLigado;$('btn-som').textContent=somLigado?'🔊 Som':'🔇 Som';if(somLigado){tocar('aceitar');toast('Som ativado.');}else toast('Som desativado.');});

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-truco'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `jogo` = armazena o estado atual da partida.
    // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
    // `pedidoHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido humano.
    $('btn-truco').addEventListener('click',()=>jogo?.pedidoHumano());

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-fechada'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `!` = nega o valor lógico da expressão seguinte.
    // `jogo` = armazena o estado atual da partida.
    // `?.` = acessa uma propriedade ou método somente quando o valor anterior não é nulo.
    // `podeFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechada.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
    // `}` = fecha um bloco de código ou objeto.
    $('btn-fechada').addEventListener('click',()=>{if(!jogo?.podeFechada())return;jogo.fechadaAtiva=!jogo.fechadaAtiva;renderizarTudo();});

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'btn-limpar-ranking'` = texto literal utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `'click'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `=>` = define uma função de seta.
    // `abrirModal` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abrir modal.
    // `{` = abre um bloco de código ou objeto.
    // `titulo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a titulo.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'Limpar ranking?'` = texto literal utilizado nesta instrução.
    // `icone` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a icone.
    // `'🏆'` = texto literal utilizado nesta instrução.
    // `html` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a html.
    // `'<p>Todos os resultados armazenados neste navegador serão apagados.</p>'` = texto literal utilizado nesta instrução.
    // `botoes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a botoes.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `texto` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a texto.
    // `'CANCELAR'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `'LIMPAR'` = texto literal utilizado nesta instrução.
    // `classe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a classe.
    // `'perigo'` = texto literal utilizado nesta instrução.
    // `acao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a acao.
    // `localStorage` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a local storage.
    // `removeItem` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a remove item.
    // `CHAVE_RANKING` = define a chave usada para salvar o ranking local no navegador.
    // `atualizarRankingMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a atualizar ranking menu.
    // `toast` = representa a mensagem temporária exibida na interface.
    // `'Ranking apagado.'` = texto literal utilizado nesta instrução.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `localStorage` = fornece armazenamento persistente local no navegador.
    $('btn-limpar-ranking').addEventListener('click',()=>abrirModal({titulo:'Limpar ranking?',icone:'🏆',html:'<p>Todos os resultados armazenados neste navegador serão apagados.</p>',botoes:[{texto:'CANCELAR'},{texto:'LIMPAR',classe:'perigo',acao:()=>{localStorage.removeItem(CHAVE_RANKING);atualizarRankingMenu();toast('Ranking apagado.');}}]}));

    // Registra um evento para executar uma função quando a interação indicada ocorrer.
    // `document` = representa o documento HTML carregado no navegador.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'keydown'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    document.addEventListener('keydown',e=>{

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `'tela-jogo'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
      // `contains` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a contains.
      // `'ativa'` = texto literal utilizado nesta instrução.
      // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
      // `jogo` = armazena o estado atual da partida.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
      if(!$('tela-jogo').classList.contains('ativa')||!jogo)return;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `key` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a key.
      // `toLowerCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to lower case.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'t'` = texto literal utilizado nesta instrução.
      // `jogo` = armazena o estado atual da partida.
      // `pedidoHumano` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pedido humano.
      if(e.key.toLowerCase()==='t')jogo.pedidoHumano();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `key` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a key.
      // `toLowerCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to lower case.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'c'` = texto literal utilizado nesta instrução.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `jogo` = armazena o estado atual da partida.
      // `podeFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pode fechada.
      // `{` = abre um bloco de código ou objeto.
      // `fechadaAtiva` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada ativa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `!` = nega o valor lógico da expressão seguinte.
      // `renderizarTudo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a renderizar tudo.
      // `}` = fecha um bloco de código ou objeto.
      if(e.key.toLowerCase()==='c'&&jogo.podeFechada()){jogo.fechadaAtiva=!jogo.fechadaAtiva;renderizarTudo();}

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `key` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a key.
      // `toLowerCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to lower case.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'s'` = texto literal utilizado nesta instrução.
      // `'btn-som'` = texto literal utilizado nesta instrução.
      // `click` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a click.
      if(e.key.toLowerCase()==='s')$('btn-som').click();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `key` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a key.
      // `toLowerCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to lower case.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'h'` = texto literal utilizado nesta instrução.
      // `modalAjuda` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a modal ajuda.
      if(e.key.toLowerCase()==='h')modalAjuda();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `key` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a key.
      // `toLowerCase` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a to lower case.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'r'` = texto literal utilizado nesta instrução.
      // `confirmarNovaPartida` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a confirmar nova partida.
      if(e.key.toLowerCase()==='r')confirmarNovaPartida();

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `e` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a e.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `key` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a key.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'Escape'` = texto literal utilizado nesta instrução.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `!` = nega o valor lógico da expressão seguinte.
      // `'modal'` = texto literal utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `classList` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a class list.
      // `contains` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a contains.
      // `'aberto'` = texto literal utilizado nesta instrução.
      // `'btn-menu'` = texto literal utilizado nesta instrução.
      // `click` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a click.
      // `classList` = fornece acesso às classes CSS aplicadas ao elemento.
      if(e.key==='Escape'&&!$('modal').classList.contains('aberto'))$('btn-menu').click();

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    });

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Expõe ou configura no objeto global do navegador o recurso definido nesta linha.
  // `window` = representa o objeto global da janela do navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `addEventListener` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a add event listener.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `'DOMContentLoaded'` = texto literal utilizado nesta instrução.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `=>` = define uma função de seta.
  // `{` = abre um bloco de código ou objeto.
  window.addEventListener('DOMContentLoaded',()=>{

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `configurarEventos` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a configurar eventos.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    configurarEventos();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `selecionarModo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a selecionar modo.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `'duelo'` = identificador do modo de jogo `Mano a Mano`.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    selecionarModo('duelo');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `atualizarRankingMenu` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a atualizar ranking menu.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    atualizarRankingMenu();

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  });

// Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
// `}` = fecha um bloco de código ou objeto.
// `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
// `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
})();
