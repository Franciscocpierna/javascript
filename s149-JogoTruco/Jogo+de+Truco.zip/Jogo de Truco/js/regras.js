// Cria uma função encapsulada para organizar e isolar a lógica deste módulo.
// `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
// `function` = define uma nova função.
// `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
// `{` = abre um bloco de código ou objeto.
(function () {

  // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
  // `'use strict'` = texto literal utilizado nesta instrução.
  'use strict';

  // Define a ordem de força dos valores das cartas usada pelas regras do Truco.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `ORDEM_VALORES` = define a ordem de força dos valores das cartas fora das manilhas.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, índice ou acesso por chave.
  // `'4'` = texto literal utilizado nesta instrução.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `'5'` = texto literal utilizado nesta instrução.
  // `'6'` = texto literal utilizado nesta instrução.
  // `'7'` = texto literal utilizado nesta instrução.
  // `'Q'` = texto literal utilizado nesta instrução.
  // `'J'` = texto literal utilizado nesta instrução.
  // `'K'` = texto literal utilizado nesta instrução.
  // `'A'` = texto literal utilizado nesta instrução.
  // `'2'` = texto literal utilizado nesta instrução.
  // `'3'` = texto literal utilizado nesta instrução.
  // `]` = fecha uma lista, índice ou acesso por chave.
  const ORDEM_VALORES = ['4', '5', '6', '7', 'Q', 'J', 'K', 'A', '2', '3'];

  // Define os quatro naipes utilizados na criação do baralho.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `NAIPES` = lista os quatro naipes usados no baralho de Truco.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, índice ou acesso por chave.
  // `'♦'` = texto literal utilizado nesta instrução.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `'♠'` = texto literal utilizado nesta instrução.
  // `'♥'` = texto literal utilizado nesta instrução.
  // `'♣'` = texto literal utilizado nesta instrução.
  // `]` = fecha uma lista, índice ou acesso por chave.
  const NAIPES = ['♦', '♠', '♥', '♣'];

  // Declara `NOMES_NAIPES` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `NOMES_NAIPES` = associa cada símbolo de naipe ao seu nome por extenso.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de código ou objeto.
  // `'♦'` = texto literal utilizado nesta instrução.
  // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
  // `'Ouros'` = texto literal utilizado nesta instrução.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `'♠'` = texto literal utilizado nesta instrução.
  // `'Espadas'` = texto literal utilizado nesta instrução.
  // `'♥'` = texto literal utilizado nesta instrução.
  // `'Copas'` = texto literal utilizado nesta instrução.
  // `'♣'` = texto literal utilizado nesta instrução.
  // `'Paus'` = texto literal utilizado nesta instrução.
  // `}` = fecha um bloco de código ou objeto.
  const NOMES_NAIPES = { '♦': 'Ouros', '♠': 'Espadas', '♥': 'Copas', '♣': 'Paus' };

  // Define os valores possíveis da mão, começando em 1 ponto e podendo chegar a 12 pontos.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `VALORES_APOSTA` = lista os valores possíveis da mão: normal, Truco, Seis, Nove e Doze.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, índice ou acesso por chave.
  // `1` = valor normal da mão, equivalente a 1 ponto.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `3` = valor do pedido de Truco, equivalente a 3 pontos.
  // `6` = valor do pedido de Seis, equivalente a 6 pontos.
  // `9` = valor do pedido de Nove, equivalente a 9 pontos.
  // `12` = valor máximo do pedido de Doze, equivalente a 12 pontos.
  // `]` = fecha uma lista, índice ou acesso por chave.
  const VALORES_APOSTA = [1, 3, 6, 9, 12];

  // Define em 12 pontos a pontuação necessária para vencer a partida.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `PONTOS_PARA_VENCER` = define a pontuação necessária para vencer a partida.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `12` = quantidade de pontos necessária para vencer uma partida de Truco.
  const PONTOS_PARA_VENCER = 12;

  // Define a função `criarBaralho` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `criarBaralho` = nome da função responsável pela operação relacionada a criar baralho.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function criarBaralho() {

    // Declara `cartas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `cartas` = representa uma coleção de cartas.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `]` = fecha uma lista, índice ou acesso por chave.
    const cartas = [];

    // Percorre os elementos ou repetições definidos nesta estrutura de laço.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `valor` = representa o valor ou figura de uma carta.
    // `of` = percorre os valores produzidos por uma coleção iterável.
    // `ORDEM_VALORES` = define a ordem de força dos valores das cartas fora das manilhas.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    for (const valor of ORDEM_VALORES) {

      // Percorre os elementos ou repetições definidos nesta estrutura de laço.
      // `for` = inicia uma estrutura de repetição.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `naipe` = representa o naipe de uma carta.
      // `of` = percorre os valores produzidos por uma coleção iterável.
      // `NAIPES` = lista os quatro naipes usados no baralho de Truco.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `cartas` = representa uma coleção de cartas.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
      // `{` = abre um bloco de código ou objeto.
      // `valor` = representa o valor ou figura de uma carta.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `}` = fecha um bloco de código ou objeto.
      // `push` = adiciona um novo elemento ao final da lista.
      for (const naipe of NAIPES) cartas.push({ valor, naipe });

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `embaralhar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a embaralhar.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `cartas` = representa uma coleção de cartas.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    return embaralhar(cartas);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `embaralhar` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `embaralhar` = nome da função responsável pela operação relacionada a embaralhar.
  // `array` = parâmetro recebido pela função para fornecer o valor relacionado a array.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function embaralhar(array) {

    // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `copia` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a copia.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `array` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a array.
    // `]` = fecha uma lista, índice ou acesso por chave.
    const copia = [...array];

    // Percorre os elementos ou repetições definidos nesta estrutura de laço.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `copia` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a copia.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `-` = realiza subtração ou representa um valor negativo.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `--` = decrementa o valor em uma unidade.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    for (let i = copia.length - 1; i > 0; i--) {

      // Declara `j` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `floor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a floor.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `*` = realiza multiplicação.
      // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `Math.floor` = arredonda um número para o inteiro imediatamente inferior.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      const j = Math.floor(Math.random() * (i + 1));

      // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `copia` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a copia.
      // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      [copia[i], copia[j]] = [copia[j], copia[i]];

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `copia` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a copia.
    return copia;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `nomeCarta` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `nomeCarta` = nome da função responsável pela operação relacionada a nome carta.
  // `carta` = parâmetro recebido pela função para fornecer o valor relacionado a carta.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function nomeCarta(carta) {

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `{` = abre um bloco de código ou objeto.
    // `carta` = representa uma carta do baralho.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `valor` = representa o valor ou figura de uma carta.
    // `}` = fecha um bloco de código ou objeto.
    // `de` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a de.
    // `NOMES_NAIPES` = associa cada símbolo de naipe ao seu nome por extenso.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `naipe` = representa o naipe de uma carta.
    // `]` = fecha uma lista, índice ou acesso por chave.
    return `${carta.valor} de ${NOMES_NAIPES[carta.naipe]}`;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `valorManilha` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `valorManilha` = nome da função responsável pela operação relacionada a valor manilha.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function valorManilha(vira) {

    // Declara `indice` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `ORDEM_VALORES` = define a ordem de força dos valores das cartas fora das manilhas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `indexOf` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a index of.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `valor` = representa o valor ou figura de uma carta.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `indexOf` = procura um valor na coleção e retorna sua posição.
    const indice = ORDEM_VALORES.indexOf(vira.valor);

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `ORDEM_VALORES` = define a ordem de força dos valores das cartas fora das manilhas.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `%` = calcula o resto da divisão e também pode ser usado para circular índices.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `]` = fecha uma lista, índice ou acesso por chave.
    return ORDEM_VALORES[(indice + 1) % ORDEM_VALORES.length];

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `forcaCarta` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `forcaCarta` = nome da função responsável pela operação relacionada a forca carta.
  // `carta` = parâmetro recebido pela função para fornecer o valor relacionado a carta.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function forcaCarta(carta, vira) {

    // Declara `manilha` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `manilha` = representa o valor de carta que se torna o mais forte na mão atual.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `valorManilha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor manilha.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const manilha = valorManilha(vira);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `carta` = representa uma carta do baralho.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `valor` = representa o valor ou figura de uma carta.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `manilha` = representa o valor de carta que se torna o mais forte na mão atual.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `100` = valor numérico 100 utilizado nesta instrução.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `NAIPES` = lista os quatro naipes usados no baralho de Truco.
    // `indexOf` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a index of.
    // `naipe` = representa o naipe de uma carta.
    // `indexOf` = procura um valor na coleção e retorna sua posição.
    if (carta.valor === manilha) return 100 + NAIPES.indexOf(carta.naipe);

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `ORDEM_VALORES` = define a ordem de força dos valores das cartas fora das manilhas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `indexOf` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a index of.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `carta` = representa uma carta do baralho.
    // `valor` = representa o valor ou figura de uma carta.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `indexOf` = procura um valor na coleção e retorna sua posição.
    return ORDEM_VALORES.indexOf(carta.valor);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `compararCartas` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `compararCartas` = nome da função responsável pela operação relacionada a comparar cartas.
  // `a` = parâmetro recebido pela função para fornecer o valor relacionado a a.
  // `b` = parâmetro recebido pela função para fornecer o valor relacionado a b.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function compararCartas(a, b, vira) {

    // Declara `fa` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `fa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fa.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const fa = forcaCarta(a, vira);

    // Declara `fb` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `fb` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fb.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const fb = forcaCarta(b, vira);

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `fa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fa.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `fb` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fb.
    // `?` = participa do operador condicional ternário.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `-` = realiza subtração ou representa um valor negativo.
    return fa === fb ? 0 : fa > fb ? 1 : -1;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `proximoValorAposta` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `proximoValorAposta` = nome da função responsável pela operação relacionada a proximo valor aposta.
  // `valorAtual` = parâmetro recebido pela função para fornecer o valor relacionado a valor atual.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function proximoValorAposta(valorAtual) {

    // Declara `i` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `VALORES_APOSTA` = lista os valores possíveis da mão: normal, Truco, Seis, Nove e Doze.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `indexOf` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a index of.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `valorAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor atual.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `indexOf` = procura um valor na coleção e retorna sua posição.
    const i = VALORES_APOSTA.indexOf(valorAtual);

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `VALORES_APOSTA` = lista os valores possíveis da mão: normal, Truco, Seis, Nove e Doze.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `-` = realiza subtração ou representa um valor negativo.
    // `1` = valor normal da mão, equivalente a 1 ponto.
    // `?` = participa do operador condicional ternário.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `null` = representa ausência intencional de valor.
    return i >= 0 && i < VALORES_APOSTA.length - 1 ? VALORES_APOSTA[i + 1] : null;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `nomePedido` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `nomePedido` = nome da função responsável pela operação relacionada a nome pedido.
  // `valor` = parâmetro recebido pela função para fornecer o valor relacionado a valor.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function nomePedido(valor) {

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `'NORMAL'` = texto literal utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `3` = valor numérico 3 utilizado nesta instrução.
    // `'TRUCO'` = texto literal utilizado nesta instrução.
    // `6` = valor numérico 6 utilizado nesta instrução.
    // `'SEIS'` = texto literal utilizado nesta instrução.
    // `9` = valor numérico 9 utilizado nesta instrução.
    // `'NOVE'` = texto literal utilizado nesta instrução.
    // `12` = valor numérico 12 utilizado nesta instrução.
    // `'DOZE'` = texto literal utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `valor` = representa o valor ou figura de uma carta.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `String` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a string.
    return ({ 1: 'NORMAL', 3: 'TRUCO', 6: 'SEIS', 9: 'NOVE', 12: 'DOZE' })[valor] || String(valor);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `vencedorMao` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `vencedorMao` = nome da função responsável pela operação relacionada a vencedor mao.
  // `vencedoresVazas` = parâmetro recebido pela função para fornecer o valor relacionado a vencedores vazas.
  // `equipeMao` = parâmetro recebido pela função para fornecer o valor relacionado a equipe mao.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function vencedorMao(vencedoresVazas, equipeMao) {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `vencedoresVazas` = identificador relacionado ao vencedor de es vazas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `2` = valor numérico 2 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `null` = representa ausência intencional de valor.
    if (vencedoresVazas.length < 2) return null;

    // Declara `variável` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `r1` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r1.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `r2` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r2.
    // `r3` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r3.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `vencedoresVazas` = identificador relacionado ao vencedor de es vazas.
    const [r1, r2, r3] = vencedoresVazas;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r1` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r1.
    // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
    // `null` = representa ausência intencional de valor.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `r2` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r2.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    if (r1 !== null && r2 === r1) return r1;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r1` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r1.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `null` = representa ausência intencional de valor.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `r2` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r2.
    // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    if (r1 === null && r2 !== null) return r2;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r1` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r1.
    // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
    // `null` = representa ausência intencional de valor.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `r2` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r2.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    if (r1 !== null && r2 === null) return r1;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `vencedoresVazas` = identificador relacionado ao vencedor de es vazas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `3` = valor numérico 3 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `null` = representa ausência intencional de valor.
    if (vencedoresVazas.length < 3) return null;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r1` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r1.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `null` = representa ausência intencional de valor.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `r2` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r2.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `r3` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r3.
    // `?` = participa do operador condicional ternário.
    // `equipeMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe mao.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    if (r1 === null && r2 === null) return r3 === null ? equipeMao : r3;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `r3` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r3.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `null` = representa ausência intencional de valor.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if (r3 === null) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `r1` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r1.
      // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
      // `null` = representa ausência intencional de valor.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (r1 !== null) return r1;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `r2` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r2.
      // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
      // `null` = representa ausência intencional de valor.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      if (r2 !== null) return r2;

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `equipeMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipe mao.
      return equipeMao;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `r3` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a r3.
    return r3;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `vencedorVaza` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `vencedorVaza` = nome da função responsável pela operação relacionada a vencedor vaza.
  // `jogadas` = parâmetro recebido pela função para fornecer o valor relacionado a jogadas.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function vencedorVaza(jogadas, vira) {

    // Declara `abertas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `abertas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abertas.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
    // `=>` = define uma função de seta.
    // `!` = nega o valor lógico da expressão seguinte.
    // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
    const abertas = jogadas.filter(j => !j.fechada);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `abertas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abertas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `{` = abre um bloco de código ou objeto.
    // `jogador` = representa um participante da partida.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `null` = representa ausência intencional de valor.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `equipe` = representa uma das equipes da partida.
    // `empate` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a empate.
    // `true` = valor lógico verdadeiro.
    // `}` = fecha um bloco de código ou objeto.
    if (!abertas.length) return { jogador: null, equipe: null, empate: true };

    // Declara `melhorForca` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `melhorForca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor forca.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `-` = realiza subtração ou representa um valor negativo.
    // `Infinity` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a infinity.
    let melhorForca = -Infinity;

    // Declara `melhores` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `melhores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhores.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `]` = fecha uma lista, índice ou acesso por chave.
    let melhores = [];

    // Percorre os elementos ou repetições definidos nesta estrutura de laço.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `jogada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogada.
    // `of` = percorre os valores produzidos por uma coleção iterável.
    // `abertas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abertas.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    for (const jogada of abertas) {

      // Declara `forca` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `jogada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogada.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `carta` = representa uma carta do baralho.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      const forca = forcaCarta(jogada.carta, vira);

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `melhorForca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor forca.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if (forca > melhorForca) {

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `melhorForca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor forca.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
        melhorForca = forca;

        // Calcula ou obtém o valor da direita e o armazena no elemento indicado à esquerda.
        // `melhores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhores.
        // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, índice ou acesso por chave.
        // `jogada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogada.
        // `]` = fecha uma lista, índice ou acesso por chave.
        melhores = [jogada];

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `}` = fecha um bloco de código ou objeto.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `melhorForca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor forca.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      } else if (forca === melhorForca) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `melhores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhores.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `push` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a push.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `jogada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogada.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `push` = adiciona um novo elemento ao final da lista.
        melhores.push(jogada);

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Declara `equipes` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `equipes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipes.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `new` = cria uma nova instância a partir da classe ou construtor informado.
    // `Set` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a set.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `melhores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhores.
    // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
    // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
    // `=>` = define uma função de seta.
    // `equipe` = representa uma das equipes da partida.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `map` = transforma cada elemento da lista e produz uma nova lista.
    // `Set` = cria uma coleção que não permite valores duplicados.
    const equipes = [...new Set(melhores.map(j => j.equipe))];

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `equipes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipes.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `!==` = compara valor e tipo e retorna verdadeiro quando existe diferença.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `{` = abre um bloco de código ou objeto.
    // `jogador` = representa um participante da partida.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `null` = representa ausência intencional de valor.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `equipe` = representa uma das equipes da partida.
    // `empate` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a empate.
    // `true` = valor lógico verdadeiro.
    // `}` = fecha um bloco de código ou objeto.
    if (equipes.length !== 1) return { jogador: null, equipe: null, empate: true };

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `{` = abre um bloco de código ou objeto.
    // `jogador` = representa um participante da partida.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `melhores` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhores.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `equipe` = representa uma das equipes da partida.
    // `equipes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a equipes.
    // `empate` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a empate.
    // `false` = valor lógico falso.
    // `}` = fecha um bloco de código ou objeto.
    return { jogador: melhores[0].jogador, equipe: equipes[0], empate: false };

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Expõe ou configura no objeto global do navegador o recurso definido nesta linha.
  // `window` = representa o objeto global da janela do navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `TrucoCore` = objeto que reúne regras e funções centrais do Jogo de Truco.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de código ou objeto.
  window.TrucoCore = {

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `ORDEM_VALORES` = define a ordem de força dos valores das cartas fora das manilhas.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `NAIPES` = lista os quatro naipes usados no baralho de Truco.
    // `NOMES_NAIPES` = associa cada símbolo de naipe ao seu nome por extenso.
    // `VALORES_APOSTA` = lista os valores possíveis da mão: normal, Truco, Seis, Nove e Doze.
    // `PONTOS_PARA_VENCER` = define a pontuação necessária para vencer a partida.
    ORDEM_VALORES, NAIPES, NOMES_NAIPES, VALORES_APOSTA, PONTOS_PARA_VENCER,

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `criarBaralho` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a criar baralho.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `embaralhar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a embaralhar.
    // `nomeCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome carta.
    // `valorManilha` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor manilha.
    // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
    // `compararCartas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a comparar cartas.
    criarBaralho, embaralhar, nomeCarta, valorManilha, forcaCarta, compararCartas,

    // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
    // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `nomePedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nome pedido.
    // `vencedorMao` = identificador relacionado ao vencedor de mao.
    // `vencedorVaza` = identificador relacionado ao vencedor de vaza.
    proximoValorAposta, nomePedido, vencedorMao, vencedorVaza

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  };

// Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
// `}` = fecha um bloco de código ou objeto.
// `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
// `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
})();
