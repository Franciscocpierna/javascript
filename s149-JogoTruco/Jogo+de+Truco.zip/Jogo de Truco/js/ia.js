// Cria uma função encapsulada para organizar e isolar a lógica deste módulo.
// `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
// `function` = define uma nova função.
// `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
// `{` = abre um bloco de código ou objeto.
(function () {

  // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
  // `'use strict'` = texto literal utilizado nesta instrução.
  'use strict';

  // Declara `C` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `=>` = define uma função de seta.
  // `window` = representa o objeto global da janela do navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `TrucoCore` = objeto que reúne regras e funções centrais do Jogo de Truco.
  const C = () => window.TrucoCore;

  // Define a função `ruido` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `ruido` = nome da função responsável pela operação relacionada a ruido.
  // `nivel` = parâmetro recebido pela função para fornecer o valor relacionado a nivel.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function ruido(nivel) {

    // Declara `amplitudes` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `amplitudes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a amplitudes.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de código ou objeto.
    // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `1.8` = valor numérico 1.8 utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `0.8` = valor numérico 0.8 utilizado nesta instrução.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `0.25` = valor numérico 0.25 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    const amplitudes = { 'Fácil': 1.8, 'Normal': 0.8, 'Difícil': 0.25 };

    // Declara `a` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `amplitudes` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a amplitudes.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    // `0.8` = valor numérico 0.8 utilizado nesta instrução.
    const a = amplitudes[nivel] ?? 0.8;

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `*` = realiza multiplicação.
    // `2` = valor numérico 2 utilizado nesta instrução.
    // `-` = realiza subtração ou representa um valor negativo.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    return (Math.random() * 2 - 1) * a;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `avaliarMao` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `avaliarMao` = nome da função responsável pela operação relacionada a avaliar mao.
  // `cartas` = parâmetro recebido pela função para fornecer o valor relacionado a cartas.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `nivel` = parâmetro recebido pela função para fornecer o valor relacionado a nivel.
  // `'Normal'` = valor padrão usado para `nivel` quando o argumento não é fornecido.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function avaliarMao(cartas, vira, nivel = 'Normal') {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `cartas` = representa uma coleção de cartas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    if (!cartas.length) return 0;

    // Declara `forcas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `forcas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forcas.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `cartas` = representa uma coleção de cartas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `c` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `=>` = define uma função de seta.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `sort` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sort.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
    // `-` = realiza subtração ou representa um valor negativo.
    // `map` = transforma cada elemento da lista e produz uma nova lista.
    const forcas = cartas.map(c => C().forcaCarta(c, vira)).sort((a, b) => b - a);

    // Declara `nota` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    let nota = 0;

    // Percorre os elementos ou repetições definidos nesta estrutura de laço.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
    // `of` = percorre os valores produzidos por uma coleção iterável.
    // `forcas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forcas.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    for (const forca of forcas) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `100` = valor numérico 100 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `4.4` = valor numérico 4.4 utilizado nesta instrução.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo.
      // `*` = realiza multiplicação.
      // `0.25` = valor numérico 0.25 utilizado nesta instrução.
      if (forca >= 100) nota += 4.4 + (forca - 100) * 0.25;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `9` = valor numérico 9 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `3.2` = valor numérico 3.2 utilizado nesta instrução.
      else if (forca >= 9) nota += 3.2;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `8` = valor numérico 8 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `2.5` = valor numérico 2.5 utilizado nesta instrução.
      else if (forca >= 8) nota += 2.5;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `7` = valor numérico 7 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `2.0` = valor numérico 2.0 utilizado nesta instrução.
      else if (forca >= 7) nota += 2.0;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `6` = valor numérico 6 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `1.5` = valor numérico 1.5 utilizado nesta instrução.
      else if (forca >= 6) nota += 1.5;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `5` = valor numérico 5 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `1.0` = valor numérico 1.0 utilizado nesta instrução.
      else if (forca >= 5) nota += 1.0;

      // Inicia o bloco alternativo executado quando a condição anterior não for atendida.
      // `else` = define o caminho alternativo executado quando a condição anterior é falsa.
      // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
      // `0.45` = valor numérico 0.45 utilizado nesta instrução.
      else nota += 0.45;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `ruido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a ruido.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    return nota + ruido(nivel);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `melhorJogadaAtual` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `melhorJogadaAtual` = nome da função responsável pela operação relacionada a melhor jogada atual.
  // `jogadas` = parâmetro recebido pela função para fornecer o valor relacionado a jogadas.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function melhorJogadaAtual(jogadas, vira) {

    // Declara `abertas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `abertas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abertas.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `j` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a j.
    // `=>` = define uma função de seta.
    // `!` = nega o valor lógico da expressão seguinte.
    // `fechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a fechada.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
    const abertas = jogadas.filter(j => !j.fechada);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `abertas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abertas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `null` = representa ausência intencional de valor.
    if (!abertas.length) return null;

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `abertas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a abertas.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `reduce` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a reduce.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `melhor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `atual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a atual.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    return abertas.reduce((melhor, atual) =>

      // Executa a instrução desta linha como parte da lógica do Jogo de Truco.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
      // `atual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a atual.
      // `carta` = representa uma carta do baralho.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `melhor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor.
      // `?` = participa do operador condicional ternário.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      C().forcaCarta(atual.carta, vira) > C().forcaCarta(melhor.carta, vira) ? atual : melhor

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    );

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `escolherCarta` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `escolherCarta` = nome da função responsável pela operação relacionada a escolher carta.
  // `{ mao` = parâmetro recebido pela função para fornecer o valor relacionado a { mao.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `jogadas` = parâmetro recebido pela função para fornecer o valor relacionado a jogadas.
  // `equipe` = parâmetro recebido pela função para fornecer o valor relacionado a equipe.
  // `rodada` = parâmetro recebido pela função para fornecer o valor relacionado a rodada.
  // `nivel` = parâmetro recebido pela função para fornecer o valor relacionado a nivel.
  // `pontosEquipe` = parâmetro recebido pela função para fornecer o valor relacionado a pontos equipe.
  // `pontosRival }` = parâmetro recebido pela função para fornecer o valor relacionado a pontos rival }.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `mao` = representa uma mão completa de Truco.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `pontosRival` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos rival.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  function escolherCarta({ mao, vira, jogadas, equipe, rodada, nivel, pontosEquipe, pontosRival }) {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `mao` = representa uma mão completa de Truco.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    if (mao.length <= 1) return 0;

    // Declara `pares` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `mao` = representa uma mão completa de Truco.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `carta` = representa uma carta do baralho.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `=>` = define uma função de seta.
    // `{` = abre um bloco de código ou objeto.
    // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `}` = fecha um bloco de código ou objeto.
    // `sort` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sort.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
    // `-` = realiza subtração ou representa um valor negativo.
    // `map` = transforma cada elemento da lista e produz uma nova lista.
    const pares = mao.map((carta, indice) => ({ indice, forca: C().forcaCarta(carta, vira) })).sort((a,b) => a.forca - b.forca);

    // Declara `melhorMesa` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `melhorJogadaAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor jogada atual.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const melhorMesa = melhorJogadaAtual(jogadas, vira);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `equipe` = representa uma das equipes da partida.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if (melhorMesa && melhorMesa.equipe === equipe) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `.25` = valor numérico .25 utilizado nesta instrução.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `floor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a floor.
      // `*` = realiza multiplicação.
      // `mao` = representa uma mão completa de Truco.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `Math.floor` = arredonda um número para o inteiro imediatamente inferior.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      if (nivel === 'Fácil' && Math.random() < .25) return Math.floor(Math.random() * mao.length);

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      return pares[0].indice;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if (melhorMesa) {

      // Declara `forcaMesa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `forcaMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca mesa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
      // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
      // `carta` = representa uma carta do baralho.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      const forcaMesa = C().forcaCarta(melhorMesa.carta, vira);

      // Declara `vencedoras` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `vencedoras` = identificador relacionado ao vencedor de as.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `filter` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a filter.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `p` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a p.
      // `=>` = define uma função de seta.
      // `forca` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `forcaMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca mesa.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `filter` = cria uma nova lista mantendo apenas os elementos que atendem à condição.
      const vencedoras = pares.filter(p => p.forca > forcaMesa);

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `vencedoras` = identificador relacionado ao vencedor de as.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `{` = abre um bloco de código ou objeto.
      if (vencedoras.length) {

        // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão é verdadeira.
        // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
        // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
        // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
        // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
        // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
        // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
        // `<` = verifica se o valor da esquerda é menor que o da direita.
        // `.30` = valor numérico .30 utilizado nesta instrução.
        // `return` = encerra a função atual e devolve o valor especificado.
        // `floor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a floor.
        // `*` = realiza multiplicação.
        // `mao` = representa uma mão completa de Truco.
        // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
        // `Math.floor` = arredonda um número para o inteiro imediatamente inferior.
        // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
        if (nivel === 'Fácil' && Math.random() < .30) return Math.floor(Math.random() * mao.length);

        // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
        // `return` = encerra a função atual e devolve o valor especificado.
        // `vencedoras` = identificador relacionado ao vencedor de as.
        // `[` = abre uma lista, índice ou acesso por chave.
        // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
        // `]` = fecha uma lista, índice ou acesso por chave.
        // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
        // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
        return vencedoras[0].indice;

      // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
      // `}` = fecha um bloco de código ou objeto.
      }

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `.35` = valor numérico .35 utilizado nesta instrução.
      // `?` = participa do operador condicional ternário.
      // `floor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a floor.
      // `*` = realiza multiplicação.
      // `mao` = representa uma mão completa de Truco.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `Math.floor` = arredonda um número para o inteiro imediatamente inferior.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      return nivel === 'Fácil' && Math.random() < .35 ? Math.floor(Math.random() * mao.length) : pares[0].indice;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if (nivel === 'Difícil') {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `rodada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rodada.
      // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `3` = valor numérico 3 utilizado nesta instrução.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      if (rodada === 0 && pares.length >= 3) return pares[1].indice;

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `pontosEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos equipe.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `10` = valor numérico 10 utilizado nesta instrução.
      // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
      // `pontosRival` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos rival.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `.46` = valor numérico .46 utilizado nesta instrução.
      // `?` = participa do operador condicional ternário.
      // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
      // `at` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a at.
      // `-` = realiza subtração ou representa um valor negativo.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      if (pontosEquipe >= 10 && pontosRival >= 10) return Math.random() < .46 ? pares.at(-1).indice : pares[0].indice;

      // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `.60` = valor numérico .60 utilizado nesta instrução.
      // `?` = participa do operador condicional ternário.
      // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
      // `min` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a min.
      // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
      // `-` = realiza subtração ou representa um valor negativo.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      return Math.random() < .60 ? pares[0].indice : pares[Math.min(1, pares.length - 1)].indice;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `.72` = valor numérico .72 utilizado nesta instrução.
    // `?` = participa do operador condicional ternário.
    // `pares` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pares.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `min` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a min.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `-` = realiza subtração ou representa um valor negativo.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    if (nivel === 'Normal') return Math.random() < .72 ? pares[0].indice : pares[Math.min(1, pares.length - 1)].indice;

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `floor` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a floor.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `*` = realiza multiplicação.
    // `mao` = representa uma mão completa de Truco.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `Math.floor` = arredonda um número para o inteiro imediatamente inferior.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    return Math.floor(Math.random() * mao.length);

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `deveJogarFechada` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `deveJogarFechada` = nome da função responsável pela operação relacionada a deve jogar fechada.
  // `{ mao` = parâmetro recebido pela função para fornecer o valor relacionado a { mao.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `rodada` = parâmetro recebido pela função para fornecer o valor relacionado a rodada.
  // `jogadas` = parâmetro recebido pela função para fornecer o valor relacionado a jogadas.
  // `equipe` = parâmetro recebido pela função para fornecer o valor relacionado a equipe.
  // `nivel }` = parâmetro recebido pela função para fornecer o valor relacionado a nivel }.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `mao` = representa uma mão completa de Truco.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  function deveJogarFechada({ mao, vira, rodada, jogadas, equipe, nivel }) {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `rodada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a rodada.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `!` = nega o valor lógico da expressão seguinte.
    // `mao` = representa uma mão completa de Truco.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `false` = valor lógico falso.
    if (rodada < 1 || !mao.length) return false;

    // Declara `melhorMesa` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `melhorJogadaAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor jogada atual.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `jogadas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a jogadas.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    const melhorMesa = melhorJogadaAtual(jogadas, vira);

    // Declara `chance` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `chance` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chance.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de código ou objeto.
    // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `.06` = valor numérico .06 utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `.16` = valor numérico .16 utilizado nesta instrução.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `.25` = valor numérico .25 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    const chance = { 'Fácil': .06, 'Normal': .16, 'Difícil': .25 }[nivel] ?? .16;

    // Declara `forcas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `forcas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forcas.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `mao` = representa uma mão completa de Truco.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `map` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a map.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `c` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `=>` = define uma função de seta.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `sort` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a sort.
    // `a` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a a.
    // `b` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a b.
    // `-` = realiza subtração ou representa um valor negativo.
    // `map` = transforma cada elemento da lista e produz uma nova lista.
    const forcas = mao.map(c => C().forcaCarta(c, vira)).sort((a,b)=>a-b);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `equipe` = representa uma das equipes da partida.
    // `===` = compara valor e tipo e retorna verdadeiro somente quando ambos são iguais.
    // `forcas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forcas.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `5` = valor numérico 5 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `chance` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chance.
    // `+` = realiza soma ou concatenação conforme os valores envolvidos.
    // `.20` = valor numérico .20 utilizado nesta instrução.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    if (melhorMesa && melhorMesa.equipe === equipe && forcas[0] <= 5) return Math.random() < chance + .20;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    if (melhorMesa) {

      // Declara `forcaMesa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `forcaMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca mesa.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
      // `melhorMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a melhor mesa.
      // `carta` = representa uma carta do baralho.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      const forcaMesa = C().forcaCarta(melhorMesa.carta, vira);

      // Declara `consegue` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `consegue` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a consegue.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      // `forcas` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forcas.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `some` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a some.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `f` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a f.
      // `=>` = define uma função de seta.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `forcaMesa` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca mesa.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      const consegue = forcas.some(f => f > forcaMesa);

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `!` = nega o valor lógico da expressão seguinte.
      // `consegue` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a consegue.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `return` = encerra a função atual e devolve o valor especificado.
      // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `chance` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a chance.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `.25` = valor numérico .25 utilizado nesta instrução.
      // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
      if (!consegue) return Math.random() < chance + .25;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `false` = valor lógico falso.
    return false;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `escolherDescarteFechado` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `escolherDescarteFechado` = nome da função responsável pela operação relacionada a escolher descarte fechado.
  // `mao` = parâmetro recebido pela função para fornecer o valor relacionado a mao.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  function escolherDescarteFechado(mao, vira) {

    // Declara `indice` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `0` = valor zero utilizado como estado inicial, índice inicial, ausência quantitativa ou limite inferior conforme o contexto desta linha.
    let indice = 0;

    // Percorre os elementos ou repetições definidos nesta estrutura de laço.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `1` = valor um utilizado como primeiro índice lógico, incremento unitário, multiplicador neutro ou pontuação básica conforme o contexto.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `mao` = representa uma mão completa de Truco.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `length` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a length.
    // `++` = incrementa o valor em uma unidade.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `{` = abre um bloco de código ou objeto.
    for (let i = 1; i < mao.length; i++) {

      // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão é verdadeira.
      // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
      // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
      // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
      // `forcaCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a forca carta.
      // `mao` = representa uma mão completa de Truco.
      // `[` = abre uma lista, índice ou acesso por chave.
      // `i` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a i.
      // `]` = fecha uma lista, índice ou acesso por chave.
      // `,` = separa argumentos, parâmetros ou elementos da estrutura.
      // `vira` = representa a carta virada que determina qual valor será a manilha.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
      // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
      if (C().forcaCarta(mao[i], vira) < C().forcaCarta(mao[indice], vira)) indice = i;

    // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
    // `}` = fecha um bloco de código ou objeto.
    }

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `indice` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a indice.
    return indice;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `devePedirAumento` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `devePedirAumento` = nome da função responsável pela operação relacionada a deve pedir aumento.
  // `{ cartas` = parâmetro recebido pela função para fornecer o valor relacionado a { cartas.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `valorAtual` = parâmetro recebido pela função para fornecer o valor relacionado a valor atual.
  // `pontosEquipe` = parâmetro recebido pela função para fornecer o valor relacionado a pontos equipe.
  // `pontosRival` = parâmetro recebido pela função para fornecer o valor relacionado a pontos rival.
  // `venceuPrimeira` = parâmetro recebido pela função para fornecer o valor relacionado a venceu primeira.
  // `nivel }` = parâmetro recebido pela função para fornecer o valor relacionado a nivel }.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `cartas` = representa uma coleção de cartas.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  function devePedirAumento({ cartas, vira, valorAtual, pontosEquipe, pontosRival, venceuPrimeira, nivel }) {

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `!` = nega o valor lógico da expressão seguinte.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
    // `valorAtual` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `false` = valor lógico falso.
    if (!C().proximoValorAposta(valorAtual)) return false;

    // Declara `nota` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `avaliarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a avaliar mao.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `cartas` = representa uma coleção de cartas.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    let nota = avaliarMao(cartas, vira, nivel);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `venceuPrimeira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu primeira.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `1.25` = valor numérico 1.25 utilizado nesta instrução.
    if (venceuPrimeira) nota += 1.25;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `pontosEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos equipe.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `10` = valor numérico 10 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `.6` = valor numérico .6 utilizado nesta instrução.
    if (pontosEquipe >= 10) nota += .6;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `pontosRival` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos rival.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `10` = valor numérico 10 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `.4` = valor numérico .4 utilizado nesta instrução.
    if (pontosRival >= 10) nota += .4;

    // Declara `limiar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `limiar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a limiar.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de código ou objeto.
    // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `8.6` = valor numérico 8.6 utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `7.0` = valor numérico 7.0 utilizado nesta instrução.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `6.25` = valor numérico 6.25 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    // `7` = valor numérico 7 utilizado nesta instrução.
    const limiar = { 'Fácil': 8.6, 'Normal': 7.0, 'Difícil': 6.25 }[nivel] ?? 7;

    // Declara `blefe` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `blefe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a blefe.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de código ou objeto.
    // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `.025` = valor numérico .025 utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `.07` = valor numérico .07 utilizado nesta instrução.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `.12` = valor numérico .12 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    const blefe = { 'Fácil': .025, 'Normal': .07, 'Difícil': .12 }[nivel] ?? .07;

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `limiar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a limiar.
    // `||` = operador lógico OU que aceita pelo menos uma condição verdadeira.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `blefe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a blefe.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    return nota >= limiar || Math.random() < blefe;

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Define a função `responderPedido` responsável pela rotina correspondente.
  // `function` = define uma nova função.
  // `responderPedido` = nome da função responsável pela operação relacionada a responder pedido.
  // `{ cartas` = parâmetro recebido pela função para fornecer o valor relacionado a { cartas.
  // `vira` = parâmetro recebido pela função para fornecer o valor relacionado a vira.
  // `valorPedido` = parâmetro recebido pela função para fornecer o valor relacionado a valor pedido.
  // `pontosEquipe` = parâmetro recebido pela função para fornecer o valor relacionado a pontos equipe.
  // `venceuPrimeira` = parâmetro recebido pela função para fornecer o valor relacionado a venceu primeira.
  // `nivel }` = parâmetro recebido pela função para fornecer o valor relacionado a nivel }.
  // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
  // `{` = abre um bloco de código ou objeto.
  // `cartas` = representa uma coleção de cartas.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
  // `}` = fecha um bloco de código ou objeto.
  // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
  function responderPedido({ cartas, vira, valorPedido, pontosEquipe, venceuPrimeira, nivel }) {

    // Declara `nota` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco e permite alterar seu valor posteriormente.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `avaliarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a avaliar mao.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `cartas` = representa uma coleção de cartas.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `vira` = representa a carta virada que determina qual valor será a manilha.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    let nota = avaliarMao(cartas, vira, nivel);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `venceuPrimeira` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a venceu primeira.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `1.1` = valor numérico 1.1 utilizado nesta instrução.
    if (venceuPrimeira) nota += 1.1;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `pontosEquipe` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a pontos equipe.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `10` = valor numérico 10 utilizado nesta instrução.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `.5` = valor numérico .5 utilizado nesta instrução.
    if (pontosEquipe >= 10) nota += .5;

    // Declara `aceitar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `aceitar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aceitar.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de código ou objeto.
    // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `6.1` = valor numérico 6.1 utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `5.3` = valor numérico 5.3 utilizado nesta instrução.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `4.7` = valor numérico 4.7 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    const aceitar = { 'Fácil': 6.1, 'Normal': 5.3, 'Difícil': 4.7 }[nivel] ?? 5.3;

    // Declara `proximo` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `proximo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `C` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a c.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `proximoValorAposta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo valor aposta.
    // `valorPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a valor pedido.
    const proximo = C().proximoValorAposta(valorPedido);

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `aceitar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aceitar.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `.12` = valor numérico .12 utilizado nesta instrução.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `'correr'` = texto literal utilizado nesta instrução.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    if (nota < aceitar && Math.random() > .12) return 'correr';

    // Declara `aumentar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `aumentar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aumentar.
    // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de código ou objeto.
    // `'Fácil'` = nome do nível de dificuldade da inteligência artificial.
    // `:` = separa chave e valor em objetos ou marca uma alternativa do operador ternário.
    // `9.4` = valor numérico 9.4 utilizado nesta instrução.
    // `,` = separa argumentos, parâmetros ou elementos da estrutura.
    // `'Normal'` = nome do nível de dificuldade da inteligência artificial.
    // `8.2` = valor numérico 8.2 utilizado nesta instrução.
    // `'Difícil'` = nome do nível de dificuldade da inteligência artificial.
    // `7.4` = valor numérico 7.4 utilizado nesta instrução.
    // `}` = fecha um bloco de código ou objeto.
    // `[` = abre uma lista, índice ou acesso por chave.
    // `nivel` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nivel.
    // `]` = fecha uma lista, índice ou acesso por chave.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    const aumentar = { 'Fácil': 9.4, 'Normal': 8.2, 'Difícil': 7.4 }[nivel] ?? 8.2;

    // Verifica a condição informada e executa o bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão é verdadeira.
    // `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `proximo` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a proximo.
    // `&&` = operador lógico E que exige que as duas condições sejam verdadeiras.
    // `nota` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a nota.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `aumentar` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a aumentar.
    // `Math` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a math.
    // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
    // `random` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a random.
    // `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `.66` = valor numérico .66 utilizado nesta instrução.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `'aumentar'` = texto literal utilizado nesta instrução.
    // `Math.random` = gera um número pseudoaleatório entre 0 inclusive e 1 exclusivo.
    if (proximo && nota >= aumentar && Math.random() < .66) return 'aumentar';

    // Retorna o valor ou resultado calculado nesta linha para o ponto que chamou a função atual.
    // `return` = encerra a função atual e devolve o valor especificado.
    // `'aceitar'` = texto literal utilizado nesta instrução.
    return 'aceitar';

  // Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
  // `}` = fecha um bloco de código ou objeto.
  }

  // Expõe ou configura no objeto global do navegador o recurso definido nesta linha.
  // `window` = representa o objeto global da janela do navegador.
  // `.` = acessa uma propriedade ou método pertencente ao objeto anterior.
  // `TrucoIA` = objeto que reúne a lógica de decisão da inteligência artificial.
  // `=` = operador de atribuição que associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de código ou objeto.
  // `avaliarMao` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a avaliar mao.
  // `,` = separa argumentos, parâmetros ou elementos da estrutura.
  // `escolherCarta` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escolher carta.
  // `deveJogarFechada` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a deve jogar fechada.
  // `escolherDescarteFechado` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a escolher descarte fechado.
  // `devePedirAumento` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a deve pedir aumento.
  // `responderPedido` = identificador utilizado para armazenar, acessar ou representar o valor relacionado a responder pedido.
  // `}` = fecha um bloco de código ou objeto.
  window.TrucoIA = { avaliarMao, escolherCarta, deveJogarFechada, escolherDescarteFechado, devePedirAumento, responderPedido };

// Encerra a estrutura, bloco, objeto, lista ou chamada que foi iniciada nas linhas anteriores.
// `}` = fecha um bloco de código ou objeto.
// `)` = fecha uma lista de argumentos, parâmetros ou agrupamento lógico.
// `(` = abre uma lista de argumentos, parâmetros ou agrupamento lógico.
})();
