// Cria uma função imediatamente executada para isolar o código do jogo e inicia seu bloco de execução.
// `=>` = define uma função de seta e separa seus parâmetros do corpo.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou um objeto.
(() => {

  // Ativa o modo estrito do JavaScript para aplicar regras mais rigorosas durante a execução do arquivo.
  // `'use strict'` = texto literal utilizado nesta instrução.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  'use strict';

  // Declara `DB_STORAGE_KEY` e armazena o valor necessário para representar chave utilizada para identificar os dados persistidos do banco do jogo.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `'sinuca3d_sqlite'` = texto literal utilizado nesta instrução.
  // `DB_STORAGE_KEY` = chave utilizada para identificar os dados persistidos do banco do jogo.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const DB_STORAGE_KEY = 'sinuca3d_sqlite';

  // Declara `IDB_NAME` e armazena o valor necessário para representar nome do banco IndexedDB utilizado para persistência no navegador.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `'sinuca3d_storage'` = texto literal utilizado nesta instrução.
  // `IDB_NAME` = nome do banco IndexedDB utilizado para persistência no navegador.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const IDB_NAME = 'sinuca3d_storage';

  // Declara `IDB_STORE` e armazena o valor necessário para representar nome do armazenamento interno utilizado no IndexedDB.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `'database'` = texto literal utilizado nesta instrução.
  // `IDB_STORE` = nome do armazenamento interno utilizado no IndexedDB.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const IDB_STORE = 'database';

  // Declara `bytesToBase64` e armazena o valor necessário para representar valor, objeto ou referência relacionada a bytes to base64.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `bytesToBase64` = valor, objeto ou referência relacionada a bytes to base64.
  // `bytes` = valor, objeto ou referência relacionada a bytes.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções ou um objeto.
  const bytesToBase64 = bytes => {

    // Declara `binary` e armazena o valor necessário para representar valor, objeto ou referência relacionada a binary.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `''` = texto vazio, utilizado para representar ausência de conteúdo textual.
    // `binary` = valor, objeto ou referência relacionada a binary.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let binary = '';

    // Declara `chunk` e armazena o valor necessário para representar valor, objeto ou referência relacionada a chunk.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `0x8000` = valor hexadecimal equivalente ao número decimal 32768, utilizado nesta operação.
    // `chunk` = valor, objeto ou referência relacionada a chunk.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const chunk = 0x8000;

    // Inicia uma repetição para percorrer valores, elementos ou índices necessários nesta rotina.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `for` = inicia uma estrutura de repetição controlada por contador, coleção ou condição.
    // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
    // `i` = contador ou índice utilizado durante a repetição.
    // `bytes.length` = valor, objeto ou referência relacionada a bytes.length.
    // `chunk` = valor, objeto ou referência relacionada a chunk.
    // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    for (let i = 0; i < bytes.length; i += chunk) {

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `String.fromCharCode` = chama o método `fromCharCode` pertencente ao objeto indicado antes do ponto.
      // `bytes.subarray` = chama o método `subarray` pertencente ao objeto indicado antes do ponto.
      // `binary` = valor, objeto ou referência relacionada a binary.
      // `i` = contador ou índice utilizado durante a repetição.
      // `chunk` = valor, objeto ou referência relacionada a chunk.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `btoa` = valor, objeto ou referência relacionada a btoa.
    // `binary` = valor, objeto ou referência relacionada a binary.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return btoa(binary);

  // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou um objeto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  };

  // Declara `base64ToBytes` e armazena o valor necessário para representar valor, objeto ou referência relacionada a base64 to bytes.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `base64ToBytes` = valor, objeto ou referência relacionada a base64 to bytes.
  // `text` = valor, objeto ou referência relacionada a text.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções ou um objeto.
  const base64ToBytes = text => {

    // Declara `binary` e armazena o valor necessário para representar valor, objeto ou referência relacionada a binary.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `binary` = valor, objeto ou referência relacionada a binary.
    // `atob` = valor, objeto ou referência relacionada a atob.
    // `text` = valor, objeto ou referência relacionada a text.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const binary = atob(text);

    // Declara `bytes` e armazena o valor necessário para representar valor, objeto ou referência relacionada a bytes.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `new` = cria uma nova instância a partir da classe ou função construtora informada.
    // `bytes` = valor, objeto ou referência relacionada a bytes.
    // `Uint8Array` = valor, objeto ou referência relacionada a uint8 array.
    // `binary.length` = valor, objeto ou referência relacionada a binary.length.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const bytes = new Uint8Array(binary.length);

    // Inicia uma repetição para percorrer valores, elementos ou índices necessários nesta rotina.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `for` = inicia uma estrutura de repetição controlada por contador, coleção ou condição.
    // `binary.charCodeAt` = chama o método `charCodeAt` pertencente ao objeto indicado antes do ponto.
    // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
    // `i` = contador ou índice utilizado durante a repetição.
    // `binary.length` = valor, objeto ou referência relacionada a binary.length.
    // `bytes` = valor, objeto ou referência relacionada a bytes.
    // `++` = incrementa o valor numérico em uma unidade.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, índice ou acesso a uma posição.
    // `]` = fecha uma lista, índice ou acesso a uma posição.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `bytes` = valor, objeto ou referência relacionada a bytes.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return bytes;

  // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou um objeto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  };

  // Define a classe `SinucaDatabase` que organiza dados e comportamentos relacionados ao jogo.
  // `class` = define uma classe utilizada como modelo para criar objetos.
  // `SinucaDatabase` = valor, objeto ou referência relacionada a sinuca database.
  // `{` = abre um bloco de instruções ou um objeto.
  class SinucaDatabase {

    // Define o método construtor responsável por inicializar os atributos e recursos de uma nova instância da classe.
    // `constructor` = valor, objeto ou referência relacionada a constructor.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    constructor() {

      // Armazena em `this.SQL` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `this.SQL` = atributo `SQL` pertencente à instância atual do jogo.
      // `null` = indica ausência intencional de um objeto ou valor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.SQL = null;

      // Armazena em `this.db` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `this.db` = atributo `db` pertencente à instância atual do jogo.
      // `null` = indica ausência intencional de um objeto ou valor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.db = null;

      // Armazena em `this.ready` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `this.ready` = atributo `ready` pertencente à instância atual do jogo.
      // `false` = valor lógico falso, utilizado para desativar ou negar uma condição.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.ready = false;

      // Armazena em `this.storageMode` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `'memória'` = texto literal utilizado nesta instrução.
      // `this.storageMode` = atributo `storageMode` pertencente à instância atual do jogo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.storageMode = 'memória';

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `init` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `init` = valor, objeto ou referência relacionada a init.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async init() {

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `this.ready` = atributo `ready` pertencente à instância atual do jogo.
      // `this` = valor, objeto ou referência relacionada a this.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (this.ready) return this;

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `new` = cria uma nova instância a partir da classe ou função construtora informada.
      // `throw` = interrompe o fluxo normal lançando explicitamente um erro.
      // `typeof` = obtém o tipo do valor informado.
      // `'function'` = texto literal utilizado nesta instrução.
      // `'Biblioteca SQLite (sql.js) não carregada.'` = texto literal utilizado nesta instrução.
      // `initSqlJs` = valor, objeto ou referência relacionada a init sql js.
      // `!==` = compara dois valores exigindo que sejam diferentes em valor ou tipo.
      // `==` = compara dois valores verificando igualdade.
      // `!=` = compara dois valores verificando diferença.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (typeof initSqlJs !== 'function') throw new Error('Biblioteca SQLite (sql.js) não carregada.');

      // Armazena em `this.SQL` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `this.SQL` = atributo `SQL` pertencente à instância atual do jogo.
      // `initSqlJs` = valor, objeto ou referência relacionada a init sql js.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.SQL = await initSqlJs();

      // Declara `saved` e armazena o valor necessário para representar valor, objeto ou referência relacionada a saved.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `this.loadBinary` = chama o método `loadBinary` pertencente ao objeto indicado antes do ponto.
      // `saved` = valor, objeto ou referência relacionada a saved.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const saved = await this.loadBinary();

      // Armazena em `this.db` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `new` = cria uma nova instância a partir da classe ou função construtora informada.
      // `this.SQL.Database` = chama o método `Database` pertencente ao objeto indicado antes do ponto.
      // `this.db` = atributo `db` pertencente à instância atual do jogo.
      // `saved` = valor, objeto ou referência relacionada a saved.
      // `saved.length` = valor, objeto ou referência relacionada a saved.length.
      // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `?` = inicia a parte condicional de uma expressão ternária.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.db = saved && saved.length ? new this.SQL.Database(saved) : new this.SQL.Database();

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `this.createSchema` = chama o método `createSchema` pertencente ao objeto indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.createSchema();

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `this.persist` = persiste o estado atual do banco de dados.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      await this.persist();

      // Armazena em `this.ready` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `this.ready` = atributo `ready` pertencente à instância atual do jogo.
      // `true` = valor lógico verdadeiro, utilizado para ativar ou confirmar uma condição.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.ready = true;

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `this` = valor, objeto ou referência relacionada a this.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return this;

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `createSchema` responsável por executar a rotina correspondente dentro da classe.
    // `createSchema` = valor, objeto ou referência relacionada a create schema.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    createSchema() {

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O texto multilinha iniciado nesta linha contém comandos SQL enviados ao banco de dados.
      // `PRAGMA` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `CREATE TABLE` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `IF NOT EXISTS` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `PRIMARY KEY` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `AUTOINCREMENT` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `NOT NULL` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `DEFAULT` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `FOREIGN KEY` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `REFERENCES` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `0` = representa o índice zero, que corresponde à primeira posição da coleção dentro do conteúdo multilinha iniciado nesta instrução.
      this.db.run(`
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS jogadores (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome TEXT NOT NULL COLLATE NOCASE UNIQUE,
          criado_em TEXT NOT NULL,
          total_partidas INTEGER NOT NULL DEFAULT 0,
          vitorias INTEGER NOT NULL DEFAULT 0,
          derrotas INTEGER NOT NULL DEFAULT 0,
          pontos_ranking INTEGER NOT NULL DEFAULT 0,
          sequencia_atual INTEGER NOT NULL DEFAULT 0,
          melhor_sequencia INTEGER NOT NULL DEFAULT 0,
          bolas_embocadas INTEGER NOT NULL DEFAULT 0,
          faltas INTEGER NOT NULL DEFAULT 0,
          tacadas INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS partidas (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          jogador_id INTEGER NOT NULL,
          iniciada_em TEXT NOT NULL,
          encerrada_em TEXT,
          dificuldade TEXT NOT NULL,
          resultado TEXT,
          vencedor TEXT,
          duracao_segundos INTEGER NOT NULL DEFAULT 0,
          grupo_jogador TEXT,
          grupo_ia TEXT,
          tacadas_jogador INTEGER NOT NULL DEFAULT 0,
          tacadas_ia INTEGER NOT NULL DEFAULT 0,
          bolas_jogador INTEGER NOT NULL DEFAULT 0,
          bolas_ia INTEGER NOT NULL DEFAULT 0,
          faltas_jogador INTEGER NOT NULL DEFAULT 0,
          faltas_ia INTEGER NOT NULL DEFAULT 0,
          pontos_variacao INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY (jogador_id) REFERENCES jogadores(id)
        );
        CREATE TABLE IF NOT EXISTS tacadas (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          partida_id INTEGER NOT NULL,
          numero INTEGER NOT NULL,
          jogador TEXT NOT NULL,
          bola_declarada INTEGER,
          cacapa_declarada INTEGER,
          potencia REAL NOT NULL,
          angulo REAL NOT NULL,
          primeiro_contato INTEGER,
          bolas_embocadas TEXT,
          falta INTEGER NOT NULL DEFAULT 0,
          motivos_falta TEXT,
          branca_embocada INTEGER NOT NULL DEFAULT 0,
          seguranca INTEGER NOT NULL DEFAULT 0,
          duracao_ms INTEGER NOT NULL DEFAULT 0,
          criada_em TEXT NOT NULL,
          FOREIGN KEY (partida_id) REFERENCES partidas(id)
        );
        CREATE TABLE IF NOT EXISTS configuracoes (
          chave TEXT PRIMARY KEY,
          valor TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_partidas_jogador ON partidas(jogador_id, encerrada_em DESC);
        CREATE INDEX IF NOT EXISTS idx_tacadas_partida ON tacadas(partida_id, numero);
      `);
    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `openIDB` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `openIDB` = valor, objeto ou referência relacionada a open idb.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async openIDB() {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `new` = cria uma nova instância a partir da classe ou função construtora informada.
      // `resolve` = valor, objeto ou referência relacionada a resolve.
      // `reject` = valor, objeto ou referência relacionada a reject.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      return new Promise((resolve, reject) => {

        // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor especificado.
        // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `'IndexedDB indisponível'` = texto literal utilizado nesta instrução.
        // `window.indexedDB` = valor, objeto ou referência relacionada a window.indexed db.
        // `reject` = valor, objeto ou referência relacionada a reject.
        // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        if (!window.indexedDB) return reject(new Error('IndexedDB indisponível'));

        // Declara `req` e armazena o valor necessário para representar valor, objeto ou referência relacionada a req.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `indexedDB.open` = chama o método `open` pertencente ao objeto indicado antes do ponto.
        // `1` = valor numérico 1 atribuído a `req`, utilizado como valor, objeto ou referência relacionada a req.
        // `req` = valor, objeto ou referência relacionada a req.
        // `IDB_NAME` = nome do banco IndexedDB utilizado para persistência no navegador.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        const req = indexedDB.open(IDB_NAME, 1);

        // Armazena em `req.onupgradeneeded` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `req.onupgradeneeded` = valor, objeto ou referência relacionada a req.onupgradeneeded.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções ou um objeto.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        req.onupgradeneeded = () => {

          // Declara `db` e armazena o valor necessário para representar valor, objeto ou referência relacionada a db.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `db` = valor, objeto ou referência relacionada a db.
          // `req.result` = valor, objeto ou referência relacionada a req.result.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          const db = req.result;

          // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
          // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
          // `db.objectStoreNames.contains` = chama o método `contains` pertencente ao objeto indicado antes do ponto.
          // `db.createObjectStore` = chama o método `createObjectStore` pertencente ao objeto indicado antes do ponto.
          // `IDB_STORE` = nome do armazenamento interno utilizado no IndexedDB.
          // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções ou um objeto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        };

        // Armazena em `req.onsuccess` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `req.onsuccess` = valor, objeto ou referência relacionada a req.onsuccess.
        // `resolve` = valor, objeto ou referência relacionada a resolve.
        // `req.result` = valor, objeto ou referência relacionada a req.result.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        req.onsuccess = () => resolve(req.result);

        // Armazena em `req.onerror` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `'Falha no IndexedDB'` = texto literal utilizado nesta instrução.
        // `req.onerror` = valor, objeto ou referência relacionada a req.onerror.
        // `reject` = valor, objeto ou referência relacionada a reject.
        // `req.error` = valor, objeto ou referência relacionada a req.error.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo.
        // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        req.onerror = () => reject(req.error || new Error('Falha no IndexedDB'));

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções ou um objeto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      });

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `loadBinary` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `loadBinary` = valor, objeto ou referência relacionada a load binary.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async loadBinary() {

      // Inicia um bloco protegido para executar as instruções e permitir o tratamento de possíveis erros.
      // `try` = inicia um bloco protegido para capturar possíveis erros.
      // `{` = abre um bloco de instruções ou um objeto.
      try {

        // Declara `idb` e armazena o valor necessário para representar valor, objeto ou referência relacionada a idb.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
        // `this.openIDB` = chama o método `openIDB` pertencente ao objeto indicado antes do ponto.
        // `idb` = valor, objeto ou referência relacionada a idb.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        const idb = await this.openIDB();

        // Declara `value` e armazena o valor necessário para representar valor, objeto ou referência relacionada a value.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
        // `value` = valor, objeto ou referência relacionada a value.
        // `resolve` = valor, objeto ou referência relacionada a resolve.
        // `reject` = valor, objeto ou referência relacionada a reject.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções ou um objeto.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        const value = await new Promise((resolve, reject) => {

          // Declara `tx` e armazena o valor necessário para representar valor, objeto ou referência relacionada a tx.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `idb.transaction` = chama o método `transaction` pertencente ao objeto indicado antes do ponto.
          // `'readonly'` = texto literal utilizado nesta instrução.
          // `tx` = valor, objeto ou referência relacionada a tx.
          // `IDB_STORE` = nome do armazenamento interno utilizado no IndexedDB.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          const tx = idb.transaction(IDB_STORE, 'readonly');

          // Declara `req` e armazena o valor necessário para representar valor, objeto ou referência relacionada a req.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `tx.objectStore` = chama o método `objectStore` pertencente ao objeto indicado antes do ponto.
          // `req` = valor, objeto ou referência relacionada a req.
          // `IDB_STORE` = nome do armazenamento interno utilizado no IndexedDB.
          // `get` = valor, objeto ou referência relacionada a get.
          // `DB_STORAGE_KEY` = chave utilizada para identificar os dados persistidos do banco do jogo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          const req = tx.objectStore(IDB_STORE).get(DB_STORAGE_KEY);

          // Armazena em `req.onsuccess` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
          // `req.onsuccess` = valor, objeto ou referência relacionada a req.onsuccess.
          // `resolve` = valor, objeto ou referência relacionada a resolve.
          // `req.result` = valor, objeto ou referência relacionada a req.result.
          // `null` = indica ausência intencional de um objeto ou valor.
          // `=>` = define uma função de seta e separa seus parâmetros do corpo.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          req.onsuccess = () => resolve(req.result || null);

          // Armazena em `req.onerror` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
          // `req.onerror` = valor, objeto ou referência relacionada a req.onerror.
          // `reject` = valor, objeto ou referência relacionada a reject.
          // `req.error` = valor, objeto ou referência relacionada a req.error.
          // `=>` = define uma função de seta e separa seus parâmetros do corpo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          req.onerror = () => reject(req.error);

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `}` = fecha um bloco de instruções ou um objeto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        });

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `idb.close` = chama o método `close` pertencente ao objeto indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        idb.close();

        // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
        // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
        // `value` = valor, objeto ou referência relacionada a value.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções ou um objeto.
        if (value) {

          // Armazena em `this.storageMode` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
          // `'IndexedDB + SQLite'` = texto literal utilizado nesta instrução.
          // `this.storageMode` = atributo `storageMode` pertencente à instância atual do jogo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          this.storageMode = 'IndexedDB + SQLite';

          // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
          // `return` = encerra a rotina atual e devolve o valor especificado.
          // `new` = cria uma nova instância a partir da classe ou função construtora informada.
          // `Uint8Array` = valor, objeto ou referência relacionada a uint8 array.
          // `value` = valor, objeto ou referência relacionada a value.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          return new Uint8Array(value);

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções ou um objeto.
        }

      // Captura e trata um erro produzido durante a execução do bloco protegido anterior.
      // `catch` = captura um erro ocorrido no bloco try.
      // `_` = valor utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      } catch (_) {}

      // Inicia um bloco protegido para executar as instruções e permitir o tratamento de possíveis erros.
      // `try` = inicia um bloco protegido para capturar possíveis erros.
      // `{` = abre um bloco de instruções ou um objeto.
      try {

        // Declara `raw` e armazena o valor necessário para representar valor, objeto ou referência relacionada a raw.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `localStorage.getItem` = chama o método `getItem` pertencente ao objeto indicado antes do ponto.
        // `raw` = valor, objeto ou referência relacionada a raw.
        // `DB_STORAGE_KEY` = chave utilizada para identificar os dados persistidos do banco do jogo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        const raw = localStorage.getItem(DB_STORAGE_KEY);

        // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
        // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
        // `raw` = valor, objeto ou referência relacionada a raw.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções ou um objeto.
        if (raw) {

          // Armazena em `this.storageMode` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
          // `'localStorage + SQLite'` = texto literal utilizado nesta instrução.
          // `this.storageMode` = atributo `storageMode` pertencente à instância atual do jogo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          this.storageMode = 'localStorage + SQLite';

          // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
          // `return` = encerra a rotina atual e devolve o valor especificado.
          // `base64ToBytes` = valor, objeto ou referência relacionada a base64 to bytes.
          // `raw` = valor, objeto ou referência relacionada a raw.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          return base64ToBytes(raw);

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções ou um objeto.
        }

      // Captura e trata um erro produzido durante a execução do bloco protegido anterior.
      // `catch` = captura um erro ocorrido no bloco try.
      // `_` = valor utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      } catch (_) {}

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `null` = indica ausência intencional de um objeto ou valor.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return null;

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `persist` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `persist` = valor, objeto ou referência relacionada a persist.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async persist() {

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `this.db` = atributo `db` pertencente à instância atual do jogo.
      // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!this.db) return;

      // Declara `bytes` e armazena o valor necessário para representar valor, objeto ou referência relacionada a bytes.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.db.export` = chama o método `export` pertencente ao objeto indicado antes do ponto.
      // `bytes` = valor, objeto ou referência relacionada a bytes.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const bytes = this.db.export();

      // Inicia um bloco protegido para executar as instruções e permitir o tratamento de possíveis erros.
      // `try` = inicia um bloco protegido para capturar possíveis erros.
      // `{` = abre um bloco de instruções ou um objeto.
      try {

        // Declara `idb` e armazena o valor necessário para representar valor, objeto ou referência relacionada a idb.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
        // `this.openIDB` = chama o método `openIDB` pertencente ao objeto indicado antes do ponto.
        // `idb` = valor, objeto ou referência relacionada a idb.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        const idb = await this.openIDB();

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
        // `resolve` = valor, objeto ou referência relacionada a resolve.
        // `reject` = valor, objeto ou referência relacionada a reject.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções ou um objeto.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        await new Promise((resolve, reject) => {

          // Declara `tx` e armazena o valor necessário para representar valor, objeto ou referência relacionada a tx.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `idb.transaction` = chama o método `transaction` pertencente ao objeto indicado antes do ponto.
          // `'readwrite'` = texto literal utilizado nesta instrução.
          // `tx` = valor, objeto ou referência relacionada a tx.
          // `IDB_STORE` = nome do armazenamento interno utilizado no IndexedDB.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          const tx = idb.transaction(IDB_STORE, 'readwrite');

          // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
          // `tx.objectStore` = chama o método `objectStore` pertencente ao objeto indicado antes do ponto.
          // `IDB_STORE` = nome do armazenamento interno utilizado no IndexedDB.
          // `put` = valor, objeto ou referência relacionada a put.
          // `bytes` = valor, objeto ou referência relacionada a bytes.
          // `DB_STORAGE_KEY` = chave utilizada para identificar os dados persistidos do banco do jogo.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          tx.objectStore(IDB_STORE).put(bytes, DB_STORAGE_KEY);

          // Armazena em `tx.oncomplete` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
          // `tx.oncomplete` = valor, objeto ou referência relacionada a tx.oncomplete.
          // `resolve` = valor, objeto ou referência relacionada a resolve.
          // `=>` = define uma função de seta e separa seus parâmetros do corpo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          tx.oncomplete = () => resolve();

          // Armazena em `tx.onerror` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
          // `tx.onerror` = valor, objeto ou referência relacionada a tx.onerror.
          // `reject` = valor, objeto ou referência relacionada a reject.
          // `tx.error` = valor, objeto ou referência relacionada a tx.error.
          // `=>` = define uma função de seta e separa seus parâmetros do corpo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          // O ponto e vírgula = encerra a instrução JavaScript atual.
          tx.onerror = () => reject(tx.error);

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `}` = fecha um bloco de instruções ou um objeto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        });

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `idb.close` = chama o método `close` pertencente ao objeto indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        idb.close();

        // Armazena em `this.storageMode` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `'IndexedDB + SQLite'` = texto literal utilizado nesta instrução.
        // `this.storageMode` = atributo `storageMode` pertencente à instância atual do jogo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.storageMode = 'IndexedDB + SQLite';

        // Encerra imediatamente a rotina atual sem devolver um valor específico.
        // `return` = encerra a rotina atual e devolve o valor especificado.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        return;

      // Captura e trata um erro produzido durante a execução do bloco protegido anterior.
      // `catch` = captura um erro ocorrido no bloco try.
      // `_` = valor utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      } catch (_) {}

      // Inicia um bloco protegido para executar as instruções e permitir o tratamento de possíveis erros.
      // `try` = inicia um bloco protegido para capturar possíveis erros.
      // `{` = abre um bloco de instruções ou um objeto.
      try {

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `localStorage.setItem` = chama o método `setItem` pertencente ao objeto indicado antes do ponto.
        // `DB_STORAGE_KEY` = chave utilizada para identificar os dados persistidos do banco do jogo.
        // `bytesToBase64` = valor, objeto ou referência relacionada a bytes to base64.
        // `bytes` = valor, objeto ou referência relacionada a bytes.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        localStorage.setItem(DB_STORAGE_KEY, bytesToBase64(bytes));

        // Armazena em `this.storageMode` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `'localStorage + SQLite'` = texto literal utilizado nesta instrução.
        // `this.storageMode` = atributo `storageMode` pertencente à instância atual do jogo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.storageMode = 'localStorage + SQLite';

      // Captura e trata um erro produzido durante a execução do bloco protegido anterior.
      // `catch` = captura um erro ocorrido no bloco try.
      // `_` = valor utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      } catch (_) {

        // Armazena em `this.storageMode` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `'SQLite em memória'` = texto literal utilizado nesta instrução.
        // `this.storageMode` = atributo `storageMode` pertencente à instância atual do jogo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.storageMode = 'SQLite em memória';

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou um objeto.
      }

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `all` responsável por executar a rotina correspondente dentro da classe.
    // `all` = valor, objeto ou referência relacionada a all.
    // `sql` = valor, objeto ou referência relacionada a sql.
    // `params` = valor, objeto ou referência relacionada a params.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, índice ou acesso a uma posição.
    // `]` = fecha uma lista, índice ou acesso a uma posição.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    all(sql, params = []) {

      // Declara `stmt` e armazena o valor necessário para representar valor, objeto ou referência relacionada a stmt.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.db.prepare` = chama o método `prepare` pertencente ao objeto indicado antes do ponto.
      // `stmt` = valor, objeto ou referência relacionada a stmt.
      // `sql` = valor, objeto ou referência relacionada a sql.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const stmt = this.db.prepare(sql);

      // Inicia um bloco protegido para executar as instruções e permitir o tratamento de possíveis erros.
      // `try` = inicia um bloco protegido para capturar possíveis erros.
      // `{` = abre um bloco de instruções ou um objeto.
      try {

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `stmt.bind` = chama o método `bind` pertencente ao objeto indicado antes do ponto.
        // `params` = valor, objeto ou referência relacionada a params.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        stmt.bind(params);

        // Declara `rows` e armazena o valor necessário para representar conjunto de registros retornados por uma consulta.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `rows` = conjunto de registros retornados por uma consulta.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, índice ou acesso a uma posição.
        // `]` = fecha uma lista, índice ou acesso a uma posição.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        const rows = [];

        // Repete o bloco de instruções enquanto a condição informada permanecer verdadeira.
        // `while` = repete o bloco enquanto a condição informada permanecer verdadeira.
        // `stmt.step` = chama o método `step` pertencente ao objeto indicado antes do ponto.
        // `rows.push` = chama o método `push` pertencente ao objeto indicado antes do ponto.
        // `stmt.getAsObject` = chama o método `getAsObject` pertencente ao objeto indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        while (stmt.step()) rows.push(stmt.getAsObject());

        // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor especificado.
        // `rows` = conjunto de registros retornados por uma consulta.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        return rows;

      // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
      // `finally` = define um bloco executado independentemente de ocorrer erro.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      } finally {

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `stmt.free` = chama o método `free` pertencente ao objeto indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        stmt.free();

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou um objeto.
      }

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `one` responsável por executar a rotina correspondente dentro da classe.
    // `one` = valor, objeto ou referência relacionada a one.
    // `sql` = valor, objeto ou referência relacionada a sql.
    // `params` = valor, objeto ou referência relacionada a params.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, índice ou acesso a uma posição.
    // `]` = fecha uma lista, índice ou acesso a uma posição.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    one(sql, params = []) {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `this.all` = obtém todos os registros correspondentes à consulta.
      // `0` = representa o índice zero, que corresponde à primeira posição da coleção.
      // `sql` = valor, objeto ou referência relacionada a sql.
      // `params` = valor, objeto ou referência relacionada a params.
      // `null` = indica ausência intencional de um objeto ou valor.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, índice ou acesso a uma posição.
      // `]` = fecha uma lista, índice ou acesso a uma posição.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return this.all(sql, params)[0] || null;

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `run` responsável por executar a rotina correspondente dentro da classe.
    // `run` = valor, objeto ou referência relacionada a run.
    // `sql` = valor, objeto ou referência relacionada a sql.
    // `params` = valor, objeto ou referência relacionada a params.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, índice ou acesso a uma posição.
    // `]` = fecha uma lista, índice ou acesso a uma posição.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    run(sql, params = []) {

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
      // `sql` = valor, objeto ou referência relacionada a sql.
      // `params` = valor, objeto ou referência relacionada a params.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.db.run(sql, params);

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `this.one` = chama o método `one` pertencente ao objeto indicado antes do ponto.
      // `'SELECT last_insert_rowid() AS id'` = texto literal utilizado nesta instrução.
      // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
      // `id` = identificador numérico ou textual do elemento tratado nesta linha.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `?.` = acesso opcional que evita erro quando o valor anterior é nulo ou indefinido.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return Number(this.one('SELECT last_insert_rowid() AS id')?.id || 0);

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `ensurePlayer` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `ensurePlayer` = valor, objeto ou referência relacionada a ensure player.
    // `name` = nome textual utilizado para identificar o jogador ou recurso.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async ensurePlayer(name) {

      // Declara `clean` e armazena o valor necessário para representar valor, objeto ou referência relacionada a clean.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `'Jogador'` = texto literal utilizado nesta instrução.
      // `0` = valor numérico 0 atribuído a `clean`, utilizado como valor, objeto ou referência relacionada a clean.
      // `24` = valor numérico 24 atribuído a `clean`, utilizado como valor, objeto ou referência relacionada a clean.
      // `clean` = valor, objeto ou referência relacionada a clean.
      // `name` = nome textual utilizado para identificar o jogador ou recurso.
      // `trim` = valor, objeto ou referência relacionada a trim.
      // `slice` = valor, objeto ou referência relacionada a slice.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const clean = (name || 'Jogador').trim().slice(0, 24) || 'Jogador';

      // Declara `row` e armazena o valor necessário para representar registro individual obtido de uma consulta.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `this.one` = chama o método `one` pertencente ao objeto indicado antes do ponto.
      // `'SELECT * FROM jogadores WHERE nome = ? COLLATE NOCASE'` = texto literal utilizado nesta instrução.
      // `row` = registro individual obtido de uma consulta.
      // `clean` = valor, objeto ou referência relacionada a clean.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, índice ou acesso a uma posição.
      // `]` = fecha uma lista, índice ou acesso a uma posição.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      let row = this.one('SELECT * FROM jogadores WHERE nome = ? COLLATE NOCASE', [clean]);

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `row` = registro individual obtido de uma consulta.
      // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      if (!row) {

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `this.run` = executa um comando SQL ou operação associada ao objeto.
        // `'INSERT INTO jogadores (nome, criado_em) VALUES (?, ?)'` = texto literal utilizado nesta instrução.
        // `clean` = valor, objeto ou referência relacionada a clean.
        // `toISOString` = valor, objeto ou referência relacionada a to isostring.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, índice ou acesso a uma posição.
        // `]` = fecha uma lista, índice ou acesso a uma posição.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.run('INSERT INTO jogadores (nome, criado_em) VALUES (?, ?)', [clean, new Date().toISOString()]);

        // Armazena em `row` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
        // `this.one` = chama o método `one` pertencente ao objeto indicado antes do ponto.
        // `'SELECT * FROM jogadores WHERE id = last_insert_rowid()'` = texto literal utilizado nesta instrução.
        // `row` = registro individual obtido de uma consulta.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        row = this.one('SELECT * FROM jogadores WHERE id = last_insert_rowid()');

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
        // `this.persist` = persiste o estado atual do banco de dados.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        await this.persist();

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou um objeto.
      }

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `row` = registro individual obtido de uma consulta.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return row;

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `listPlayers` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `listPlayers` = valor, objeto ou referência relacionada a list players.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async listPlayers() {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `this.all` = obtém todos os registros correspondentes à consulta.
      // `'SELECT id, nome, vitorias, derrotas, pontos_ranking FROM jogadores ORDER BY nome COLLATE NOCASE'` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return this.all('SELECT id, nome, vitorias, derrotas, pontos_ranking FROM jogadores ORDER BY nome COLLATE NOCASE');

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `getPlayerSummary` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `getPlayerSummary` = valor, objeto ou referência relacionada a get player summary.
    // `name` = nome textual utilizado para identificar o jogador ou recurso.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async getPlayerSummary(name) {

      // Declara `player` e armazena o valor necessário para representar objeto ou identificador relacionado ao jogador humano.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.one` = chama o método `one` pertencente ao objeto indicado antes do ponto.
      // `'SELECT * FROM jogadores WHERE nome = ? COLLATE NOCASE'` = texto literal utilizado nesta instrução.
      // `player` = objeto ou identificador relacionado ao jogador humano.
      // `name` = nome textual utilizado para identificar o jogador ou recurso.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, índice ou acesso a uma posição.
      // `]` = fecha uma lista, índice ou acesso a uma posição.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const player = this.one('SELECT * FROM jogadores WHERE nome = ? COLLATE NOCASE', [name]);

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `player` = objeto ou identificador relacionado ao jogador humano.
      // `null` = indica ausência intencional de um objeto ou valor.
      // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!player) return null;

      // Declara `total` e armazena o valor necessário para representar valor, objeto ou referência relacionada a total.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `0` = valor numérico 0 atribuído a `total`, utilizado como valor, objeto ou referência relacionada a total.
      // `total` = valor, objeto ou referência relacionada a total.
      // `player.total_partidas` = valor, objeto ou referência relacionada a player.total partidas.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const total = Number(player.total_partidas || 0);

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `{` = abre um bloco de instruções ou um objeto.
      return {

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `player` = objeto ou identificador relacionado ao jogador humano.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        ...player,

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
        // `100` = valor numérico 100 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
        // `aproveitamento` = valor, objeto ou referência relacionada a aproveitamento.
        // `total` = valor, objeto ou referência relacionada a total.
        // `player.vitorias` = valor, objeto ou referência relacionada a player.vitorias.
        // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
        // `*` = realiza multiplicação.
        // `/` = realiza divisão.
        // `?` = inicia a parte condicional de uma expressão ternária.
        // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        aproveitamento: total ? Number(player.vitorias || 0) * 100 / total : 0

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou um objeto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      };

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `startMatch` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `startMatch` = valor, objeto ou referência relacionada a start match.
    // `playerId` = valor, objeto ou referência relacionada a player id.
    // `difficulty` = valor, objeto ou referência relacionada a difficulty.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    async startMatch(playerId, difficulty) {

      // Declara `id` e armazena o valor necessário para representar identificador numérico ou textual do elemento tratado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.run` = executa um comando SQL ou operação associada ao objeto.
      // `id` = identificador numérico ou textual do elemento tratado nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      const id = this.run(

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `'INSERT INTO partidas (jogador_id, iniciada_em, dificuldade) VALUES (?, ?, ?)'` = texto literal utilizado nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        'INSERT INTO partidas (jogador_id, iniciada_em, dificuldade) VALUES (?, ?, ?)',

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `playerId` = valor, objeto ou referência relacionada a player id.
        // `toISOString` = valor, objeto ou referência relacionada a to isostring.
        // `difficulty` = valor, objeto ou referência relacionada a difficulty.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, índice ou acesso a uma posição.
        // `]` = fecha uma lista, índice ou acesso a uma posição.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        [playerId, new Date().toISOString(), difficulty]

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      );

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `this.persist` = persiste o estado atual do banco de dados.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      await this.persist();

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `id` = identificador numérico ou textual do elemento tratado nesta linha.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return id;

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `logShot` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `logShot` = valor, objeto ou referência relacionada a log shot.
    // `matchId` = valor, objeto ou referência relacionada a match id.
    // `shot` = valor, objeto ou referência relacionada a shot.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    async logShot(matchId, shot) {

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `matchId` = valor, objeto ou referência relacionada a match id.
      // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!matchId) return;

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `this.run` = executa um comando SQL ou operação associada ao objeto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O texto multilinha iniciado nesta linha contém comandos SQL enviados ao banco de dados.
      // `INSERT INTO` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `VALUES` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      this.run(`
        INSERT INTO tacadas (
          partida_id, numero, jogador, bola_declarada, cacapa_declarada, potencia, angulo,
          primeiro_contato, bolas_embocadas, falta, motivos_falta, branca_embocada,
          seguranca, duracao_ms, criada_em
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `matchId` = valor, objeto ou referência relacionada a match id.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        matchId,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.numero` = valor, objeto ou referência relacionada a shot.numero.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.numero,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.jogador` = valor, objeto ou referência relacionada a shot.jogador.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.jogador,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.bolaDeclarada` = valor, objeto ou referência relacionada a shot.bola declarada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.bolaDeclarada,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.cacapaDeclarada` = valor, objeto ou referência relacionada a shot.cacapa declarada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.cacapaDeclarada,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.potencia` = valor, objeto ou referência relacionada a shot.potencia.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.potencia,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.angulo` = valor, objeto ou referência relacionada a shot.angulo.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.angulo,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.primeiroContato` = valor, objeto ou referência relacionada a shot.primeiro contato.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.primeiroContato,

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `shot.bolasEmbocadas.join` = chama o método `join` pertencente ao objeto indicado antes do ponto.
        // `','` = texto literal utilizado nesta instrução.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.bolasEmbocadas.join(','),

        // Define uma propriedade, alternativa ou associação de chave e valor dentro da estrutura atual.
        // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha.
        // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
        // `shot.falta` = valor, objeto ou referência relacionada a shot.falta.
        // `?` = inicia a parte condicional de uma expressão ternária.
        // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.falta ? 1 : 0,

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `shot.motivosFalta.join` = chama o método `join` pertencente ao objeto indicado antes do ponto.
        // `'; '` = texto literal utilizado nesta instrução.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.motivosFalta.join('; '),

        // Define uma propriedade, alternativa ou associação de chave e valor dentro da estrutura atual.
        // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha.
        // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
        // `shot.brancaEmbocada` = valor, objeto ou referência relacionada a shot.branca embocada.
        // `?` = inicia a parte condicional de uma expressão ternária.
        // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.brancaEmbocada ? 1 : 0,

        // Define uma propriedade, alternativa ou associação de chave e valor dentro da estrutura atual.
        // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha.
        // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
        // `shot.seguranca` = valor, objeto ou referência relacionada a shot.seguranca.
        // `?` = inicia a parte condicional de uma expressão ternária.
        // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.seguranca ? 1 : 0,

        // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
        // `shot.duracaoMs` = valor, objeto ou referência relacionada a shot.duracao ms.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        shot.duracaoMs,

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `new` = cria uma nova instância a partir da classe ou função construtora informada.
        // `toISOString` = valor, objeto ou referência relacionada a to isostring.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        new Date().toISOString()

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha uma lista, índice ou acesso a uma posição.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      ]);

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `this.persist` = persiste o estado atual do banco de dados.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      await this.persist();

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `pointsForResult` responsável por executar a rotina correspondente dentro da classe.
    // `pointsForResult` = valor, objeto ou referência relacionada a points for result.
    // `result` = resultado produzido pela operação executada.
    // `difficulty` = valor, objeto ou referência relacionada a difficulty.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    pointsForResult(result, difficulty) {

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `'vitoria'` = texto literal utilizado nesta instrução.
      // `'facil'` = texto literal utilizado nesta instrução.
      // `'avancado'` = texto literal utilizado nesta instrução.
      // `10` = valor numérico 10 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
      // `35` = valor numérico 35 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
      // `20` = valor numérico 20 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
      // `result` = resultado produzido pela operação executada.
      // `difficulty` = valor, objeto ou referência relacionada a difficulty.
      // `===` = compara dois valores exigindo igualdade de valor e de tipo.
      // `==` = compara dois valores verificando igualdade.
      // `?` = inicia a parte condicional de uma expressão ternária.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (result === 'vitoria') return difficulty === 'facil' ? 10 : difficulty === 'avancado' ? 35 : 20;

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `'facil'` = texto literal utilizado nesta instrução.
      // `'avancado'` = texto literal utilizado nesta instrução.
      // `5` = valor numérico 5 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
      // `10` = valor numérico 10 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
      // `8` = valor numérico 8 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
      // `difficulty` = valor, objeto ou referência relacionada a difficulty.
      // `===` = compara dois valores exigindo igualdade de valor e de tipo.
      // `==` = compara dois valores verificando igualdade.
      // `-` = realiza subtração ou representa um valor negativo.
      // `?` = inicia a parte condicional de uma expressão ternária.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return difficulty === 'facil' ? -5 : difficulty === 'avancado' ? -10 : -8;

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `finishMatch` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `finishMatch` = valor, objeto ou referência relacionada a finish match.
    // `matchId` = valor, objeto ou referência relacionada a match id.
    // `playerId` = valor, objeto ou referência relacionada a player id.
    // `payload` = valor, objeto ou referência relacionada a payload.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    async finishMatch(matchId, playerId, payload) {

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `matchId` = valor, objeto ou referência relacionada a match id.
      // `playerId` = valor, objeto ou referência relacionada a player id.
      // `null` = indica ausência intencional de um objeto ou valor.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!matchId || !playerId) return null;

      // Declara `result` e armazena o valor necessário para representar resultado produzido pela operação executada.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `'human'` = texto literal utilizado nesta instrução.
      // `'vitoria'` = texto literal utilizado nesta instrução.
      // `'derrota'` = texto literal utilizado nesta instrução.
      // `result` = resultado produzido pela operação executada.
      // `payload.winner` = valor, objeto ou referência relacionada a payload.winner.
      // `===` = compara dois valores exigindo igualdade de valor e de tipo.
      // `==` = compara dois valores verificando igualdade.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `?` = inicia a parte condicional de uma expressão ternária.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const result = payload.winner === 'human' ? 'vitoria' : 'derrota';

      // Declara `deltaRaw` e armazena o valor necessário para representar valor, objeto ou referência relacionada a delta raw.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.pointsForResult` = chama o método `pointsForResult` pertencente ao objeto indicado antes do ponto.
      // `deltaRaw` = valor, objeto ou referência relacionada a delta raw.
      // `result` = resultado produzido pela operação executada.
      // `payload.difficulty` = valor, objeto ou referência relacionada a payload.difficulty.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const deltaRaw = this.pointsForResult(result, payload.difficulty);

      // Declara `player` e armazena o valor necessário para representar objeto ou identificador relacionado ao jogador humano.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.one` = chama o método `one` pertencente ao objeto indicado antes do ponto.
      // `'SELECT * FROM jogadores WHERE id = ?'` = texto literal utilizado nesta instrução.
      // `player` = objeto ou identificador relacionado ao jogador humano.
      // `playerId` = valor, objeto ou referência relacionada a player id.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, índice ou acesso a uma posição.
      // `]` = fecha uma lista, índice ou acesso a uma posição.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const player = this.one('SELECT * FROM jogadores WHERE id = ?', [playerId]);

      // Verifica a condição informada e executa o bloco associado somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada somente quando a expressão avaliada for verdadeira.
      // `player` = objeto ou identificador relacionado ao jogador humano.
      // `null` = indica ausência intencional de um objeto ou valor.
      // `!` = operador lógico de negação, invertendo o valor lógico da expressão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!player) return null;

      // Declara `oldPoints` e armazena o valor necessário para representar valor, objeto ou referência relacionada a old points.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `0` = valor numérico 0 atribuído a `oldPoints`, utilizado como valor, objeto ou referência relacionada a old points.
      // `oldPoints` = valor, objeto ou referência relacionada a old points.
      // `player.pontos_ranking` = valor, objeto ou referência relacionada a player.pontos ranking.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const oldPoints = Number(player.pontos_ranking || 0);

      // Declara `newPoints` e armazena o valor necessário para representar valor, objeto ou referência relacionada a new points.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `Math.max` = retorna o maior entre os valores informados.
      // `0` = valor numérico 0 atribuído a `newPoints`, utilizado como valor, objeto ou referência relacionada a new points.
      // `newPoints` = valor, objeto ou referência relacionada a new points.
      // `oldPoints` = valor, objeto ou referência relacionada a old points.
      // `deltaRaw` = valor, objeto ou referência relacionada a delta raw.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const newPoints = Math.max(0, oldPoints + deltaRaw);

      // Declara `actualDelta` e armazena o valor necessário para representar valor, objeto ou referência relacionada a actual delta.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `actualDelta` = valor, objeto ou referência relacionada a actual delta.
      // `newPoints` = valor, objeto ou referência relacionada a new points.
      // `oldPoints` = valor, objeto ou referência relacionada a old points.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const actualDelta = newPoints - oldPoints;

      // Declara `currentStreak` e armazena o valor necessário para representar valor, objeto ou referência relacionada a current streak.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `'vitoria'` = texto literal utilizado nesta instrução.
      // `0` = valor numérico 0 atribuído a `currentStreak`, utilizado como valor, objeto ou referência relacionada a current streak.
      // `1` = valor numérico 1 atribuído a `currentStreak`, utilizado como valor, objeto ou referência relacionada a current streak.
      // `currentStreak` = valor, objeto ou referência relacionada a current streak.
      // `result` = resultado produzido pela operação executada.
      // `player.sequencia_atual` = valor, objeto ou referência relacionada a player.sequencia atual.
      // `===` = compara dois valores exigindo igualdade de valor e de tipo.
      // `==` = compara dois valores verificando igualdade.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma ou concatenação conforme os valores envolvidos.
      // `?` = inicia a parte condicional de uma expressão ternária.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const currentStreak = result === 'vitoria' ? Number(player.sequencia_atual || 0) + 1 : 0;

      // Declara `bestStreak` e armazena o valor necessário para representar valor, objeto ou referência relacionada a best streak.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `Math.max` = retorna o maior entre os valores informados.
      // `0` = valor numérico 0 atribuído a `bestStreak`, utilizado como valor, objeto ou referência relacionada a best streak.
      // `bestStreak` = valor, objeto ou referência relacionada a best streak.
      // `player.melhor_sequencia` = valor, objeto ou referência relacionada a player.melhor sequencia.
      // `currentStreak` = valor, objeto ou referência relacionada a current streak.
      // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const bestStreak = Math.max(Number(player.melhor_sequencia || 0), currentStreak);

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
      // `'BEGIN TRANSACTION'` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.db.run('BEGIN TRANSACTION');

      // Inicia um bloco protegido para executar as instruções e permitir o tratamento de possíveis erros.
      // `try` = inicia um bloco protegido para capturar possíveis erros.
      // `{` = abre um bloco de instruções ou um objeto.
      try {

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O texto multilinha iniciado nesta linha contém comandos SQL enviados ao banco de dados.
        // `WHERE` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
        // `UPDATE` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
        this.db.run(`
          UPDATE partidas SET
            encerrada_em = ?, resultado = ?, vencedor = ?, duracao_segundos = ?,
            grupo_jogador = ?, grupo_ia = ?, tacadas_jogador = ?, tacadas_ia = ?,
            bolas_jogador = ?, bolas_ia = ?, faltas_jogador = ?, faltas_ia = ?,
            pontos_variacao = ?
          WHERE id = ?
        `, [
          // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
          // `new` = cria uma nova instância a partir da classe ou função construtora informada.
          // `toISOString` = valor, objeto ou referência relacionada a to isostring.
          // `result` = resultado produzido pela operação executada.
          // `payload.winner` = valor, objeto ou referência relacionada a payload.winner.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          new Date().toISOString(), result, payload.winner,

          // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
          // `Math.max` = retorna o maior entre os valores informados.
          // `Math.round` = chama o método `round` pertencente ao objeto indicado antes do ponto.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.durationSeconds` = valor, objeto ou referência relacionada a payload.duration seconds.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          Math.max(0, Math.round(payload.durationSeconds || 0)),

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `payload.playerGroup` = valor, objeto ou referência relacionada a payload.player group.
          // `payload.aiGroup` = valor, objeto ou referência relacionada a payload.ai group.
          // `null` = indica ausência intencional de um objeto ou valor.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerGroup || null, payload.aiGroup || null,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.playerShots` = valor, objeto ou referência relacionada a payload.player shots.
          // `payload.aiShots` = valor, objeto ou referência relacionada a payload.ai shots.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerShots || 0, payload.aiShots || 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.playerPocketed` = valor, objeto ou referência relacionada a payload.player pocketed.
          // `payload.aiPocketed` = valor, objeto ou referência relacionada a payload.ai pocketed.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerPocketed || 0, payload.aiPocketed || 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.playerFouls` = valor, objeto ou referência relacionada a payload.player fouls.
          // `payload.aiFouls` = valor, objeto ou referência relacionada a payload.ai fouls.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerFouls || 0, payload.aiFouls || 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `actualDelta` = valor, objeto ou referência relacionada a actual delta.
          // `matchId` = valor, objeto ou referência relacionada a match id.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          actualDelta, matchId

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `]` = fecha uma lista, índice ou acesso a uma posição.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        ]);

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O texto multilinha iniciado nesta linha contém comandos SQL enviados ao banco de dados.
        // `WHERE` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
        // `UPDATE` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
        // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha dentro do conteúdo multilinha iniciado nesta instrução.
        this.db.run(`
          UPDATE jogadores SET
            total_partidas = total_partidas + 1,
            vitorias = vitorias + ?,
            derrotas = derrotas + ?,
            pontos_ranking = ?,
            sequencia_atual = ?,
            melhor_sequencia = ?,
            bolas_embocadas = bolas_embocadas + ?,
            faltas = faltas + ?,
            tacadas = tacadas + ?
          WHERE id = ?
        `, [
          // Define uma propriedade, alternativa ou associação de chave e valor dentro da estrutura atual.
          // `'vitoria'` = texto literal utilizado nesta instrução.
          // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `result` = resultado produzido pela operação executada.
          // `===` = compara dois valores exigindo igualdade de valor e de tipo.
          // `==` = compara dois valores verificando igualdade.
          // `?` = inicia a parte condicional de uma expressão ternária.
          // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          result === 'vitoria' ? 1 : 0,

          // Define uma propriedade, alternativa ou associação de chave e valor dentro da estrutura atual.
          // `'derrota'` = texto literal utilizado nesta instrução.
          // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `result` = resultado produzido pela operação executada.
          // `===` = compara dois valores exigindo igualdade de valor e de tipo.
          // `==` = compara dois valores verificando igualdade.
          // `?` = inicia a parte condicional de uma expressão ternária.
          // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          result === 'derrota' ? 1 : 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `newPoints` = valor, objeto ou referência relacionada a new points.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          newPoints,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `currentStreak` = valor, objeto ou referência relacionada a current streak.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          currentStreak,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `bestStreak` = valor, objeto ou referência relacionada a best streak.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          bestStreak,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.playerPocketed` = valor, objeto ou referência relacionada a payload.player pocketed.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerPocketed || 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.playerFouls` = valor, objeto ou referência relacionada a payload.player fouls.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerFouls || 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
          // `payload.playerShots` = valor, objeto ou referência relacionada a payload.player shots.
          // `||` = operador lógico OU, que aceita pelo menos uma condição verdadeira.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
          payload.playerShots || 0,

          // Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
          // `playerId` = valor, objeto ou referência relacionada a player id.
          playerId

        // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `]` = fecha uma lista, índice ou acesso a uma posição.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        ]);

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
        // `'COMMIT'` = texto literal utilizado nesta instrução.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.db.run('COMMIT');

      // Captura e trata um erro produzido durante a execução do bloco protegido anterior.
      // `catch` = captura um erro ocorrido no bloco try.
      // `err` = objeto que representa o erro capturado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      } catch (err) {

        // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
        // `this.db.run` = executa um comando SQL ou operação associada ao objeto.
        // `'ROLLBACK'` = texto literal utilizado nesta instrução.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.db.run('ROLLBACK');

        // Interrompe o fluxo normal da rotina e lança explicitamente um erro com a informação indicada.
        // `throw` = interrompe o fluxo normal lançando explicitamente um erro.
        // `err` = objeto que representa o erro capturado.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        throw err;

      // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou um objeto.
      }

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `this.persist` = persiste o estado atual do banco de dados.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      await this.persist();

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `result` = resultado produzido pela operação executada.
      // `points` = valor, objeto ou referência relacionada a points.
      // `newPoints` = valor, objeto ou referência relacionada a new points.
      // `delta` = valor, objeto ou referência relacionada a delta.
      // `actualDelta` = valor, objeto ou referência relacionada a actual delta.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return { result, points: newPoints, delta: actualDelta };

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `getRanking` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `30` = valor numérico 30 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
    // `getRanking` = valor, objeto ou referência relacionada a get ranking.
    // `limit` = limite utilizado para restringir a quantidade ou o intervalo da operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    async getRanking(limit = 30) {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `this.all` = obtém todos os registros correspondentes à consulta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O texto multilinha iniciado nesta linha contém comandos SQL enviados ao banco de dados.
      // `SELECT` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `FROM` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `ORDER BY` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `LIMIT` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha dentro do conteúdo multilinha iniciado nesta instrução.
      // `100.0` = valor numérico 100.0 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha dentro do conteúdo multilinha iniciado nesta instrução.
      // `1` = representa o valor um, usado como unidade, incremento, fator integral ou segunda posição conforme o contexto desta linha dentro do conteúdo multilinha iniciado nesta instrução.
      return this.all(`
        SELECT nome, pontos_ranking, vitorias, derrotas, total_partidas,
               CASE WHEN total_partidas = 0 THEN 0 ELSE ROUND(vitorias * 100.0 / total_partidas, 1) END AS aproveitamento,
               melhor_sequencia
        FROM jogadores
        ORDER BY pontos_ranking DESC, vitorias DESC, aproveitamento DESC, nome COLLATE NOCASE
        LIMIT ?
      `, [limit]);
    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `getRecentMatches` responsável por executar a rotina correspondente dentro da classe.
    // `async` = define uma rotina assíncrona que pode utilizar await.
    // `20` = valor numérico 20 utilizado diretamente no cálculo, comparação, configuração ou chamada desta linha.
    // `getRecentMatches` = valor, objeto ou referência relacionada a get recent matches.
    // `name` = nome textual utilizado para identificar o jogador ou recurso.
    // `limit` = limite utilizado para restringir a quantidade ou o intervalo da operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
    async getRecentMatches(name, limit = 20) {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `this.all` = obtém todos os registros correspondentes à consulta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O texto multilinha iniciado nesta linha contém comandos SQL enviados ao banco de dados.
      // `NOT NULL` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `SELECT` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `FROM` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `WHERE` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `ORDER BY` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      // `LIMIT` = elemento SQL utilizado no bloco de banco de dados iniciado nesta linha.
      return this.all(`
        SELECT p.*, j.nome
        FROM partidas p
        JOIN jogadores j ON j.id = p.jogador_id
        WHERE j.nome = ? COLLATE NOCASE AND p.encerrada_em IS NOT NULL
        ORDER BY p.id DESC
        LIMIT ?
      `, [name, limit]);
    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

    // Define o método `exportDatabase` responsável por executar a rotina correspondente dentro da classe.
    // `'sinuca3d.sqlite'` = texto literal utilizado nesta instrução.
    // `exportDatabase` = valor, objeto ou referência relacionada a export database.
    // `filename` = valor, objeto ou referência relacionada a filename.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou um objeto.
    exportDatabase(filename = 'sinuca3d.sqlite') {

      // Declara `bytes` e armazena o valor necessário para representar valor, objeto ou referência relacionada a bytes.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this.db.export` = chama o método `export` pertencente ao objeto indicado antes do ponto.
      // `bytes` = valor, objeto ou referência relacionada a bytes.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const bytes = this.db.export();

      // Declara `blob` e armazena o valor necessário para representar valor, objeto ou referência relacionada a blob.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `new` = cria uma nova instância a partir da classe ou função construtora informada.
      // `'application/x-sqlite3'` = texto literal utilizado nesta instrução.
      // `blob` = valor, objeto ou referência relacionada a blob.
      // `Blob` = valor, objeto ou referência relacionada a blob.
      // `bytes` = valor, objeto ou referência relacionada a bytes.
      // `type` = valor, objeto ou referência relacionada a type.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa partes da instrução, como chave e valor ou alternativas de uma expressão condicional.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, índice ou acesso a uma posição.
      // `]` = fecha uma lista, índice ou acesso a uma posição.
      // `{` = abre um bloco de instruções ou um objeto.
      // `}` = fecha um bloco de instruções ou um objeto.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const blob = new Blob([bytes], { type: 'application/x-sqlite3' });

      // Declara `url` e armazena o valor necessário para representar valor, objeto ou referência relacionada a url.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `URL.createObjectURL` = chama o método `createObjectURL` pertencente ao objeto indicado antes do ponto.
      // `url` = valor, objeto ou referência relacionada a url.
      // `blob` = valor, objeto ou referência relacionada a blob.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const url = URL.createObjectURL(blob);

      // Declara `a` e armazena o valor necessário para representar variável que representa um objeto ou valor utilizado na operação atual.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `document.createElement` = cria um novo elemento HTML.
      // `'a'` = texto literal utilizado nesta instrução.
      // `a` = variável que representa um objeto ou valor utilizado na operação atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const a = document.createElement('a');

      // Armazena em `a.href` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `a.href` = valor, objeto ou referência relacionada a a.href.
      // `url` = valor, objeto ou referência relacionada a url.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      a.href = url;

      // Armazena em `a.download` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
      // `a.download` = valor, objeto ou referência relacionada a a.download.
      // `filename` = valor, objeto ou referência relacionada a filename.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      a.download = filename;

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `document.body.appendChild` = adiciona um elemento filho ao elemento atual.
      // `a` = variável que representa um objeto ou valor utilizado na operação atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      document.body.appendChild(a);

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `a.click` = chama o método `click` pertencente ao objeto indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      a.click();

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `a.remove` = remove o elemento ou recurso.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      a.remove();

      // Executa a função, método ou chamada definida nesta linha com os argumentos informados.
      // `URL.revokeObjectURL` = chama o método `revokeObjectURL` pertencente ao objeto indicado antes do ponto.
      // `1000` = define um intervalo de 1000 milissegundos, equivalente a 1 segundo(s).
      // `setTimeout` = valor, objeto ou referência relacionada a set timeout.
      // `url` = valor, objeto ou referência relacionada a url.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos da estrutura.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      setTimeout(() => URL.revokeObjectURL(url), 1000);

    // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou um objeto.
    }

  // Encerra a estrutura, chamada, coleção ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou um objeto.
  }

  // Armazena em `window.SinucaDatabase` o valor ou resultado calculado nesta linha para uso posterior pelo jogo.
  // `window.SinucaDatabase` = valor, objeto ou referência relacionada a window.sinuca database.
  // `SinucaDatabase` = valor, objeto ou referência relacionada a sinuca database.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao elemento indicado antes do ponto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  window.SinucaDatabase = SinucaDatabase;

// Executa a instrução desta linha para construir, configurar ou controlar o funcionamento do jogo.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `}` = fecha um bloco de instruções ou um objeto.
// O ponto e vírgula = encerra a instrução JavaScript atual.
})();
