-- Configura uma opção interna do SQLite utilizada pelo banco de dados do jogo.
-- `PRAGMA` = configura uma opção interna de funcionamento do SQLite.
-- `ON` = define condição de relacionamento ou ativa uma configuração.
-- O ponto e vírgula = encerra a instrução SQL atual.
PRAGMA foreign_keys = ON;

-- Cria a tabela indicada e inicia a definição de suas colunas, tipos e restrições.
-- `CREATE` = inicia a criação de uma estrutura no banco de dados.
-- `TABLE` = indica que a estrutura criada é uma tabela.
CREATE TABLE jogadores (

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `PRIMARY` = participa da definição da chave primária.
  -- `KEY` = indica uma chave utilizada para identificar ou relacionar registros.
  -- `AUTOINCREMENT` = faz o SQLite gerar automaticamente identificadores numéricos sequenciais.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `id` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `nome` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  nome TEXT NOT NULL COLLATE NOCASE UNIQUE,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `criado_em` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  criado_em TEXT NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `total_partidas` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  total_partidas INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `vitorias` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  vitorias INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `derrotas` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  derrotas INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `pontos_ranking` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  pontos_ranking INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `sequencia_atual` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  sequencia_atual INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `melhor_sequencia` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  melhor_sequencia INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `bolas_embocadas` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  bolas_embocadas INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `faltas` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  faltas INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `tacadas` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  tacadas INTEGER NOT NULL DEFAULT 0

-- Encerra a definição da estrutura SQL iniciada anteriormente.
-- O ponto e vírgula = encerra a instrução SQL atual.
);

-- Cria a tabela indicada e inicia a definição de suas colunas, tipos e restrições.
-- `CREATE` = inicia a criação de uma estrutura no banco de dados.
-- `TABLE` = indica que a estrutura criada é uma tabela.
CREATE TABLE partidas (

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `PRIMARY` = participa da definição da chave primária.
  -- `KEY` = indica uma chave utilizada para identificar ou relacionar registros.
  -- `AUTOINCREMENT` = faz o SQLite gerar automaticamente identificadores numéricos sequenciais.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `id` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `jogador_id` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  jogador_id INTEGER NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `iniciada_em` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  iniciada_em TEXT NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `encerrada_em` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  encerrada_em TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `dificuldade` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  dificuldade TEXT NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `resultado` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  resultado TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `vencedor` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  vencedor TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `duracao_segundos` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  duracao_segundos INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `grupo_jogador` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  grupo_jogador TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `grupo_ia` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  grupo_ia TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `tacadas_jogador` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  tacadas_jogador INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `tacadas_ia` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  tacadas_ia INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `bolas_jogador` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  bolas_jogador INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `bolas_ia` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  bolas_ia INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `faltas_jogador` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  faltas_jogador INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `faltas_ia` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  faltas_ia INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `pontos_variacao` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  pontos_variacao INTEGER NOT NULL DEFAULT 0,

  -- Completa a instrução SQL atual com a cláusula, coluna, restrição ou valor definido nesta linha.
  -- `KEY` = indica uma chave utilizada para identificar ou relacionar registros.
  -- `FOREIGN` = participa da definição de uma chave estrangeira.
  -- `REFERENCES` = define a tabela e coluna referenciadas por uma chave estrangeira.
  FOREIGN KEY (jogador_id) REFERENCES jogadores(id)

-- Encerra a definição da estrutura SQL iniciada anteriormente.
-- O ponto e vírgula = encerra a instrução SQL atual.
);

-- Cria a tabela indicada e inicia a definição de suas colunas, tipos e restrições.
-- `CREATE` = inicia a criação de uma estrutura no banco de dados.
-- `TABLE` = indica que a estrutura criada é uma tabela.
CREATE TABLE tacadas (

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `PRIMARY` = participa da definição da chave primária.
  -- `KEY` = indica uma chave utilizada para identificar ou relacionar registros.
  -- `AUTOINCREMENT` = faz o SQLite gerar automaticamente identificadores numéricos sequenciais.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `id` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `partida_id` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  partida_id INTEGER NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `numero` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  numero INTEGER NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `jogador` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  jogador TEXT NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `bola_declarada` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  bola_declarada INTEGER,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `cacapa_declarada` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  cacapa_declarada INTEGER,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `REAL` = define uma coluna destinada a números com casas decimais.
  -- `NULL` = representa ausência de valor.
  -- `potencia` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  potencia REAL NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `REAL` = define uma coluna destinada a números com casas decimais.
  -- `NULL` = representa ausência de valor.
  -- `angulo` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  angulo REAL NOT NULL,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `primeiro_contato` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  primeiro_contato INTEGER,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `bolas_embocadas` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  bolas_embocadas TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `falta` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  falta INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `motivos_falta` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  motivos_falta TEXT,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `branca_embocada` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  branca_embocada INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `seguranca` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  seguranca INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `INTEGER` = define uma coluna destinada a números inteiros.
  -- `NULL` = representa ausência de valor.
  -- `DEFAULT` = define um valor usado automaticamente quando nenhum outro é informado.
  -- `duracao_ms` = nome da coluna definida nesta linha.
  -- `0` = representa o valor zero, usado como estado inicial, ausência de quantidade, limite mínimo ou índice conforme o contexto desta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  duracao_ms INTEGER NOT NULL DEFAULT 0,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `criada_em` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  criada_em TEXT NOT NULL,

  -- Completa a instrução SQL atual com a cláusula, coluna, restrição ou valor definido nesta linha.
  -- `KEY` = indica uma chave utilizada para identificar ou relacionar registros.
  -- `FOREIGN` = participa da definição de uma chave estrangeira.
  -- `REFERENCES` = define a tabela e coluna referenciadas por uma chave estrangeira.
  FOREIGN KEY (partida_id) REFERENCES partidas(id)

-- Encerra a definição da estrutura SQL iniciada anteriormente.
-- O ponto e vírgula = encerra a instrução SQL atual.
);

-- Cria a tabela indicada e inicia a definição de suas colunas, tipos e restrições.
-- `CREATE` = inicia a criação de uma estrutura no banco de dados.
-- `TABLE` = indica que a estrutura criada é uma tabela.
CREATE TABLE configuracoes (

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `PRIMARY` = participa da definição da chave primária.
  -- `KEY` = indica uma chave utilizada para identificar ou relacionar registros.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `chave` = nome da coluna definida nesta linha.
  -- `,` = separa esta coluna, valor ou expressão da próxima parte da instrução SQL.
  chave TEXT PRIMARY KEY,

  -- Define uma coluna da tabela com o nome, tipo, valor padrão e restrições informados nesta linha.
  -- `NOT` = nega a condição ou restrição seguinte.
  -- `TEXT` = define uma coluna destinada a texto.
  -- `NULL` = representa ausência de valor.
  -- `valor` = nome da coluna definida nesta linha.
  valor TEXT NOT NULL

-- Encerra a definição da estrutura SQL iniciada anteriormente.
-- O ponto e vírgula = encerra a instrução SQL atual.
);
