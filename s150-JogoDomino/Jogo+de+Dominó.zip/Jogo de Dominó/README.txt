JOGO DE DOMINÓ - HTML, CSS E JAVASCRIPT
===================================

Jogo de Dominó desenvolvido com HTML, CSS e JavaScript, com modos Mano a Mano e Duplas.

ARQUIVOS
--------
index.html  - Estrutura da interface.
style.css   - Layout responsivo, mesa, peças e animações.
app.js      - Regras do jogo, IA, turnos, pontuação, drag-and-drop e histórico.
sons/       - Efeitos sonoros WAV utilizados durante a partida.

COMO EXECUTAR
-------------
Basta abrir o arquivo index.html em um navegador moderno.

Para melhor compatibilidade com áudio, também é possível servir a pasta com um servidor local simples.
Exemplo com Python instalado:

python -m http.server 8000

Depois acesse no navegador:
http://localhost:8000

RECURSOS
--------
- Dominó tradicional duplo-seis com 28 peças.
- Mano a Mano: jogador contra IA.
- Duplas com 4 jogadores: jogador + IA parceira contra 2 IAs.
- 7 peças por participante.
- Monte de 14 peças no Mano a Mano.
- Sem monte no modo Duplas.
- Maior dupla inicia a rodada; sem dupla, inicia a maior soma.
- Jogadas pelos extremos esquerdo e direito.
- Compra manual do jogador.
- Compra automática da IA.
- Passe de turno quando não existe jogada nem peças no monte.
- Detecção de rodada bloqueada.
- Pontuação acumulada até 100 pontos.
- IA heurística.
- Sons.
- Arrastar e soltar.
- Histórico de jogadas.
- Estatísticas e ranking.

ARMAZENAMENTO
-------------
O histórico e o ranking são armazenados no localStorage do próprio navegador.
Os dados permanecem disponíveis no mesmo navegador até que o armazenamento do site seja apagado.

LAYOUT E INTERAÇÃO
------------------
- Mesa com acabamento visual de madeira e feltro.
- Interface responsiva.
- Placar centralizado e destacado.
- Jogadores posicionados ao redor da mesa no modo Duplas.
- Mão do jogador maior e legível.
- Peças desenhadas com pontos em CSS/HTML.
- Destaque das peças jogáveis.
- Destaque dos extremos válidos durante a seleção e o arraste.
- Painel lateral com turno, extremos, monte, ações e histórico.
- Modais para regras, estatísticas e resultado final.
- A primeira peça da rodada é posicionada no centro da mesa.
- A corrente cresce para os dois lados e cria novas linhas em serpentina.
- As curvas entre linhas usam peças verticais e mantêm distância entre as fileiras.
- O arraste utiliza Pointer Events para mouse e dispositivos de toque compatíveis.
- Ao segurar e mover uma peça, uma cópia visual acompanha o ponteiro.
- Ao soltar a peça sobre a mesa, o jogo escolhe o extremo válido mais próximo quando ambos são possíveis.
- Peças que não combinam não podem ser encaixadas.
