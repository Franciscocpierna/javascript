// Ativa o modo estrito do JavaScript para aplicar regras mais rigorosas durante a execução do arquivo.
// `use strict` = texto literal utilizado nesta instrução.
// O ponto e vírgula = encerra a instrução JavaScript atual.
"use strict";

// Declara `LADO_ESQUERDO` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `LADO_ESQUERDO` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `esquerda` = texto utilizado para identificar o lado esquerda da corrente de peças.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const LADO_ESQUERDO = "esquerda";

// Declara `LADO_DIREITO` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `LADO_DIREITO` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `direita` = texto utilizado para identificar o lado direita da corrente de peças.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const LADO_DIREITO = "direita";

// Declara `MODO_MANO_A_MANO` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `MODO_MANO_A_MANO` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `mano_a_mano` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const MODO_MANO_A_MANO = "mano_a_mano";

// Declara `MODO_DUPLAS` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `MODO_DUPLAS` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `duplas` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const MODO_DUPLAS = "duplas";

// Declara `JOGADOR` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `JOGADOR` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `jogador` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const JOGADOR = "jogador";

// Declara `IA` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `IA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `ia` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const IA = "ia";

// Declara `PARCEIRA` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `PARCEIRA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `parceira` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const PARCEIRA = "parceira";

// Declara `IA_DIREITA` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `IA_DIREITA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `ia_direita` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const IA_DIREITA = "ia_direita";

// Declara `IA_ESQUERDA` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `IA_ESQUERDA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `ia_esquerda` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const IA_ESQUERDA = "ia_esquerda";

// Declara `EQUIPE_JOGADOR` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `EQUIPE_JOGADOR` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `equipe_jogador` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const EQUIPE_JOGADOR = "equipe_jogador";

// Declara `EQUIPE_ADVERSARIA` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `EQUIPE_ADVERSARIA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `equipe_adversaria` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const EQUIPE_ADVERSARIA = "equipe_adversaria";

// Declara `ORDEM_MANO` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `ORDEM_MANO` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
// `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const ORDEM_MANO = [JOGADOR, IA];

// Declara `ORDEM_DUPLAS` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `ORDEM_DUPLAS` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
// `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const ORDEM_DUPLAS = [JOGADOR, IA_DIREITA, PARCEIRA, IA_ESQUERDA];

// Declara `NOMES` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `NOMES` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
const NOMES = {

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `Você` = texto literal utilizado nesta instrução.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  [JOGADOR]: "Você",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `IA` = texto literal utilizado nesta instrução.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  [IA]: "IA",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `Sua parceira IA` = texto literal utilizado nesta instrução.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  [PARCEIRA]: "Sua parceira IA",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `IA da direita` = texto literal utilizado nesta instrução.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  [IA_DIREITA]: "IA da direita",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `IA da esquerda` = texto literal utilizado nesta instrução.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  [IA_ESQUERDA]: "IA da esquerda",

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
// O ponto e vírgula = encerra a instrução JavaScript atual.
};

// Declara `META_PONTOS` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `META_PONTOS` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `100` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const META_PONTOS = 100;

// Declara `STORAGE_KEY` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `STORAGE_KEY` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `domino_dados` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const STORAGE_KEY = "domino_dados";

// Declara `SOM_KEY` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `SOM_KEY` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `domino_som` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// O ponto e vírgula = encerra a instrução JavaScript atual.
const SOM_KEY = "domino_som";

// Declara `AUDIO` e armazena nele o valor ou resultado definido nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `AUDIO` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
const AUDIO = {

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/abertura.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  abertura: "sons/abertura.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/comprar.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  comprar: "sons/comprar.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/ia_comprar.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  ia_comprar: "sons/ia_comprar.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/pedra.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  pedra: "sons/pedra.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/passar.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  passar: "sons/passar.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/erro.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  erro: "sons/erro.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/rodada_vitoria.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  rodada_vitoria: "sons/rodada_vitoria.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/rodada_derrota.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  rodada_derrota: "sons/rodada_derrota.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/empate.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  empate: "sons/empate.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/partida_vitoria.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  partida_vitoria: "sons/partida_vitoria.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/partida_derrota.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  partida_derrota: "sons/partida_derrota.wav",

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `sons/menu.wav` = caminho do arquivo de áudio WAV utilizado para reproduzir este efeito sonoro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  menu: "sons/menu.wav",

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
// O ponto e vírgula = encerra a instrução JavaScript atual.
};

// Define a classe `PecaDomino`, agrupando os dados e comportamentos relacionados a esta parte do jogo.
// `class` = define uma classe que agrupa estado e comportamentos relacionados.
// `PecaDomino` = nome atribuído à classe definida nesta linha.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
class PecaDomino {

  // Define o método construtor responsável por inicializar os atributos e estados do objeto quando a classe é instanciada.
  // `constructor` = método executado automaticamente quando um objeto da classe é criado.
  // `null` = representa ausência intencional de valor.
  // `constructor` = nome do método ou função executado por esta rotina.
  // `a` = parâmetro recebido pela rotina para fornecer o valor relacionado a `a`.
  // `b` = parâmetro recebido pela rotina para fornecer o valor relacionado a `b`.
  // `id` = parâmetro recebido pela rotina para fornecer o valor relacionado a `id`.
  // `null` = valor padrão utilizado para `id` quando nenhum valor é fornecido.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  constructor(a, b, id = null) {

    // Armazena ou atualiza no atributo `a` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.a = a;

    // Armazena ou atualiza no atributo `b` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.b = b;

    // Armazena ou atualiza no atributo `id` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.id` = acessa o atributo ou método `id` pertencente à instância atual da classe.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.id = id || `p-${a}-${b}`;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `this` = representa a própria instância atual da classe.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `get` = define um acessor de leitura que se comporta como propriedade.
  // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
  // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  get total() { return this.a + this.b; }

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `this` = representa a própria instância atual da classe.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `get` = define um acessor de leitura que se comporta como propriedade.
  // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
  // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
  // `===` = compara valor e tipo para verificar igualdade estrita.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  get dupla() { return this.a === this.b; }

  // Define o método `combinaCom` responsável por executar a rotina correspondente dentro do jogo.
  // `combinaCom` = nome do método ou função executado por esta rotina.
  // `valor` = parâmetro recebido pela rotina para fornecer o valor relacionado a `valor`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  combinaCom(valor) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `true` = valor lógico verdadeiro.
    // `null` = representa ausência intencional de valor.
    // `undefined` = representa um valor ainda não definido.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (valor === null || valor === undefined) return true;

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
    // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return this.a === valor || this.b === valor;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `outroValor` responsável por executar a rotina correspondente dentro do jogo.
  // `outroValor` = nome do método ou função executado por esta rotina.
  // `valor` = parâmetro recebido pela rotina para fornecer o valor relacionado a `valor`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  outroValor(valor) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
    // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.a === valor) return this.b;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
    // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.b === valor) return this.a;

    // Interrompe o fluxo atual e lança um erro com a informação definida nesta linha.
    // `throw` = interrompe o fluxo lançando um erro.
    // `new` = cria uma nova instância da classe informada.
    // `Error` = classe utilizada para representar um erro com uma mensagem explicativa.
    // `A peça não combina com o valor informado.` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    throw new Error("A peça não combina com o valor informado.");

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `texto` responsável por executar a rotina correspondente dentro do jogo.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `texto` = nome do método ou função executado por esta rotina.
  // `this.a` = acessa o atributo ou método `a` pertencente à instância atual da classe.
  // `this.b` = acessa o atributo ou método `b` pertencente à instância atual da classe.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  texto() { return `[${this.a}|${this.b}]`; }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a classe `EstadoRodada`, agrupando os dados e comportamentos relacionados a esta parte do jogo.
// `class` = define uma classe que agrupa estado e comportamentos relacionados.
// `EstadoRodada` = nome atribuído à classe definida nesta linha.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
class EstadoRodada {

  // Define o método construtor responsável por inicializar os atributos e estados do objeto quando a classe é instanciada.
  // `constructor` = método executado automaticamente quando um objeto da classe é criado.
  // `constructor` = nome do método ou função executado por esta rotina.
  // `modo` = parâmetro recebido pela rotina para fornecer o valor relacionado a `modo`.
  // `MODO_MANO_A_MANO` = valor padrão utilizado para `modo` quando nenhum valor é fornecido.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  constructor(modo = MODO_MANO_A_MANO) {

    // Armazena ou atualiza no atributo `modo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.modo = modo;

    // Armazena ou atualiza no atributo `maos` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.maos = {};

    // Armazena ou atualiza no atributo `monte` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.monte = [];

    // Armazena ou atualiza no atributo `mesa` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mesa = [];

    // Armazena ou atualiza no atributo `pecaInicialId` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.pecaInicialId` = acessa o atributo ou método `pecaInicialId` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.pecaInicialId = null;

    // Armazena ou atualiza no atributo `esquerda` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.esquerda = null;

    // Armazena ou atualiza no atributo `direita` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.direita = null;

    // Armazena ou atualiza no atributo `turno` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.turno` = acessa o atributo ou método `turno` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.turno = JOGADOR;

    // Armazena ou atualiza no atributo `passesConsecutivos` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.passesConsecutivos` = acessa o atributo ou método `passesConsecutivos` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.passesConsecutivos = 0;

    // Armazena ou atualiza no atributo `encerrada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `false` = valor lógico falso.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.encerrada = false;

    // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.vencedor = null;

    // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mensagemFinal = "";

    // Armazena ou atualiza no atributo `motivoFim` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.motivoFim` = acessa o atributo ou método `motivoFim` pertencente à instância atual da classe.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.motivoFim = "";

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
  // `this` = representa a própria instância atual da classe.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `get` = define um acessor de leitura que se comporta como propriedade.
  // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
  // `===` = compara valor e tipo para verificar igualdade estrita.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  get ordemTurnos() { return this.modo === MODO_DUPLAS ? ORDEM_DUPLAS : ORDEM_MANO; }

  // Define o método `maoDe` responsável por executar a rotina correspondente dentro do jogo.
  // `maoDe` = nome do método ou função executado por esta rotina.
  // `participante` = parâmetro recebido pela rotina para fornecer o valor relacionado a `participante`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  maoDe(participante) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.maos[participante]) this.maos[participante] = [];

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return this.maos[participante];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `preparar` responsável por executar a rotina correspondente dentro do jogo.
  // `this` = representa a própria instância atual da classe.
  // `preparar` = nome do método ou função executado por esta rotina.
  // `modo` = parâmetro recebido pela rotina para fornecer o valor relacionado a `modo`.
  // `this.modo` = valor padrão utilizado para `modo` quando nenhum valor é fornecido.
  // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  preparar(modo = this.modo) {

    // Armazena ou atualiza no atributo `modo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.modo = modo;

    // Declara `pecas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `pecas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const pecas = criarConjuntoCompleto();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `embaralhar` = nome do método ou função executado por esta rotina.
    // `pecas` = parâmetro recebido pela rotina para fornecer o valor relacionado a `pecas`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    embaralhar(pecas);

    // Armazena ou atualiza no atributo `maos` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.maos = {};

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (modo === MODO_DUPLAS) {

      // Percorre todos os elementos da coleção e executa a função indicada para cada um deles.
      // `ORDEM_DUPLAS.forEach` = chama o método `forEach` pertencente a `ORDEM_DUPLAS`.
      // `=>` = define uma função de seta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      ORDEM_DUPLAS.forEach((p, indice) => {

        // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
        // `this` = representa a própria instância atual da classe.
        // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
        // `pecas.slice` = chama o método `slice` pertencente a `pecas`.
        // `7` = quantidade de peças distribuídas para cada participante no início da rodada.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
        // `*` = operador que realiza multiplicação numérica.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
        // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.maos[p] = pecas.slice(indice * 7, indice * 7 + 7);

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      });

      // Armazena ou atualiza no atributo `monte` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.monte = [];

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
      // `this` = representa a própria instância atual da classe.
      // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
      // `pecas.slice` = chama o método `slice` pertencente a `pecas`.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `7` = quantidade de peças distribuídas para cada participante no início da rodada.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.maos[JOGADOR] = pecas.slice(0, 7);

      // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
      // `this` = representa a própria instância atual da classe.
      // `this.maos` = acessa o atributo ou método `maos` pertencente à instância atual da classe.
      // `pecas.slice` = chama o método `slice` pertencente a `pecas`.
      // `7` = quantidade de peças distribuídas para cada participante no início da rodada.
      // `14` = índice que marca o final das 14 peças distribuídas entre jogador e IA no modo Mano a Mano.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.maos[IA] = pecas.slice(7, 14);

      // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
      // `this` = representa a própria instância atual da classe.
      // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
      // `pecas.slice` = chama o método `slice` pertencente a `pecas`.
      // `14` = índice a partir do qual as peças restantes passam a formar o monte no modo Mano a Mano.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.monte = pecas.slice(14);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Armazena ou atualiza no atributo `mesa` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mesa = [];

    // Armazena ou atualiza no atributo `pecaInicialId` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.pecaInicialId` = acessa o atributo ou método `pecaInicialId` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.pecaInicialId = null;

    // Armazena ou atualiza no atributo `esquerda` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.esquerda = null;

    // Armazena ou atualiza no atributo `direita` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.direita = null;

    // Armazena ou atualiza no atributo `turno` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.turno` = acessa o atributo ou método `turno` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.turno = JOGADOR;

    // Armazena ou atualiza no atributo `passesConsecutivos` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.passesConsecutivos` = acessa o atributo ou método `passesConsecutivos` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.passesConsecutivos = 0;

    // Armazena ou atualiza no atributo `encerrada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `false` = valor lógico falso.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.encerrada = false;

    // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.vencedor = null;

    // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mensagemFinal = "";

    // Armazena ou atualiza no atributo `motivoFim` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.motivoFim` = acessa o atributo ou método `motivoFim` pertencente à instância atual da classe.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.motivoFim = "";

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `ladosValidos` responsável por executar a rotina correspondente dentro do jogo.
  // `ladosValidos` = nome do método ou função executado por esta rotina.
  // `peca` = parâmetro recebido pela rotina para fornecer o valor relacionado a `peca`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  ladosValidos(peca) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.mesa.length) return [LADO_DIREITO];

    // Declara `lados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `lados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lados = [];

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
    // `peca.combinaCom` = chama o método `combinaCom` pertencente a `peca`.
    // `lados.push` = chama o método `push` pertencente a `lados`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (peca.combinaCom(this.esquerda)) lados.push(LADO_ESQUERDO);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
    // `peca.combinaCom` = chama o método `combinaCom` pertencente a `peca`.
    // `lados.push` = chama o método `push` pertencente a `lados`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (peca.combinaCom(this.direita)) lados.push(LADO_DIREITO);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return lados;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `possuiJogada` responsável por executar a rotina correspondente dentro do jogo.
  // `possuiJogada` = nome do método ou função executado por esta rotina.
  // `mao` = parâmetro recebido pela rotina para fornecer o valor relacionado a `mao`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  possuiJogada(mao) {

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.ladosValidos` = acessa o atributo ou método `ladosValidos` pertencente à instância atual da classe.
    // `mao.some` = chama o método `some` pertencente a `mao`.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `=>` = define uma função de seta.
    // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return mao.some((peca) => this.ladosValidos(peca).length > 0);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `podeComprar` responsável por executar a rotina correspondente dentro do jogo.
  // `podeComprar` = nome do método ou função executado por esta rotina.
  // `origem` = parâmetro recebido pela rotina para fornecer o valor relacionado a `origem`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  podeComprar(origem) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `false` = valor lógico falso.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `this.ordemTurnos` = acessa o atributo ou método `ordemTurnos` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.modo !== MODO_MANO_A_MANO || !this.ordemTurnos.includes(origem)) return false;

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
    // `this.possuiJogada` = acessa o atributo ou método `possuiJogada` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return this.monte.length > 0 && !this.possuiJogada(this.maoDe(origem));

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `podePassar` responsável por executar a rotina correspondente dentro do jogo.
  // `podePassar` = nome do método ou função executado por esta rotina.
  // `origem` = parâmetro recebido pela rotina para fornecer o valor relacionado a `origem`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  podePassar(origem) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `false` = valor lógico falso.
    // `this.ordemTurnos` = acessa o atributo ou método `ordemTurnos` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.ordemTurnos.includes(origem)) return false;

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.possuiJogada` = acessa o atributo ou método `possuiJogada` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return !this.possuiJogada(this.maoDe(origem)) && this.monte.length === 0;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `jogar` responsável por executar a rotina correspondente dentro do jogo.
  // `jogar` = nome do método ou função executado por esta rotina.
  // `peca` = parâmetro recebido pela rotina para fornecer o valor relacionado a `peca`.
  // `lado` = parâmetro recebido pela rotina para fornecer o valor relacionado a `lado`.
  // `origem` = parâmetro recebido pela rotina para fornecer o valor relacionado a `origem`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  jogar(peca, lado, origem) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `throw` = interrompe o fluxo lançando um erro.
    // `new` = cria uma nova instância da classe informada.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `Error` = classe utilizada para representar um erro com uma mensagem explicativa.
    // `A rodada já foi encerrada.` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.encerrada) throw new Error("A rodada já foi encerrada.");

    // Declara `mao` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `mao` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const mao = this.maoDe(origem);

    // Procura e retorna o índice do primeiro elemento da coleção que atende à condição informada.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `indicePeca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `mao.findIndex` = chama o método `findIndex` pertencente a `mao`.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const indicePeca = mao.findIndex((p) => p.id === peca.id);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `throw` = interrompe o fluxo lançando um erro.
    // `new` = cria uma nova instância da classe informada.
    // `Error` = classe utilizada para representar um erro com uma mensagem explicativa.
    // `A peça não pertence à mão informada.` = texto literal utilizado nesta instrução.
    // `0` = valor numérico utilizado como índice, posição ou limite nesta operação.
    // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (indicePeca < 0) throw new Error("A peça não pertence à mão informada.");

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `throw` = interrompe o fluxo lançando um erro.
    // `new` = cria uma nova instância da classe informada.
    // `this.ladosValidos` = acessa o atributo ou método `ladosValidos` pertencente à instância atual da classe.
    // `Error` = classe utilizada para representar um erro com uma mensagem explicativa.
    // `A peça não combina com esse lado.` = texto literal utilizado nesta instrução.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.ladosValidos(peca).includes(lado)) throw new Error("A peça não combina com esse lado.");

    // Declara `orientada` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `orientada` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let orientada;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!this.mesa.length) {

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      orientada = { esquerda: peca.a, direita: peca.b, origem, id: peca.id, dupla: peca.dupla };

      // Armazena ou atualiza no atributo `pecaInicialId` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.pecaInicialId` = acessa o atributo ou método `pecaInicialId` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.pecaInicialId = peca.id;

      // Adiciona o valor informado ao final da coleção utilizada nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mesa.push(orientada);

      // Armazena ou atualiza no atributo `esquerda` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.esquerda = orientada.esquerda;

      // Armazena ou atualiza no atributo `direita` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.direita = orientada.direita;

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else if (lado === LADO_ESQUERDO) {

      // Declara `outro` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `outro` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
      // `peca.outroValor` = chama o método `outroValor` pertencente a `peca`.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const outro = peca.outroValor(this.esquerda);

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `this` = representa a própria instância atual da classe.
      // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      orientada = { esquerda: outro, direita: this.esquerda, origem, id: peca.id, dupla: peca.dupla };

      // Adiciona o valor informado ao início da coleção utilizada nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mesa.unshift(orientada);

      // Armazena ou atualiza no atributo `esquerda` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.esquerda` = acessa o atributo ou método `esquerda` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.esquerda = outro;

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Declara `outro` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `outro` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
      // `peca.outroValor` = chama o método `outroValor` pertencente a `peca`.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const outro = peca.outroValor(this.direita);

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `this` = representa a própria instância atual da classe.
      // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      orientada = { esquerda: this.direita, direita: outro, origem, id: peca.id, dupla: peca.dupla };

      // Adiciona o valor informado ao final da coleção utilizada nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mesa` = acessa o atributo ou método `mesa` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mesa.push(orientada);

      // Armazena ou atualiza no atributo `direita` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.direita` = acessa o atributo ou método `direita` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.direita = outro;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Remove, substitui ou insere elementos na coleção a partir da posição informada.
    // `mao.splice` = chama o método `splice` pertencente a `mao`.
    // `1` = valor numérico utilizado como índice, posição ou limite nesta operação.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    mao.splice(indicePeca, 1);

    // Armazena ou atualiza no atributo `passesConsecutivos` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.passesConsecutivos` = acessa o atributo ou método `passesConsecutivos` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.passesConsecutivos = 0;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.verificarMaoVazia` = acessa o atributo ou método `verificarMaoVazia` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.verificarMaoVazia(origem);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return orientada;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `comprar` responsável por executar a rotina correspondente dentro do jogo.
  // `comprar` = nome do método ou função executado por esta rotina.
  // `origem` = parâmetro recebido pela rotina para fornecer o valor relacionado a `origem`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  comprar(origem) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `null` = representa ausência intencional de valor.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.modo !== MODO_MANO_A_MANO || !this.monte.length) return null;

    // Remove e obtém o último elemento da coleção utilizada nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const peca = this.monte.pop();

    // Adiciona o valor informado ao final da coleção utilizada nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.maoDe(origem).push(peca);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return peca;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `registrarPasse` responsável por executar a rotina correspondente dentro do jogo.
  // `registrarPasse` = nome do método ou função executado por esta rotina.
  // `origem` = parâmetro recebido pela rotina para fornecer o valor relacionado a `origem`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  registrarPasse(origem) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.encerrada) return;

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.passesConsecutivos` = acessa o atributo ou método `passesConsecutivos` pertencente à instância atual da classe.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.passesConsecutivos += 1;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.passesConsecutivos` = acessa o atributo ou método `passesConsecutivos` pertencente à instância atual da classe.
    // `this.ordemTurnos` = acessa o atributo ou método `ordemTurnos` pertencente à instância atual da classe.
    // `this.monte` = acessa o atributo ou método `monte` pertencente à instância atual da classe.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.passesConsecutivos >= this.ordemTurnos.length && this.monte.length === 0) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.encerrarBloqueio` = acessa o atributo ou método `encerrarBloqueio` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.encerrarBloqueio();

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `proximoParticipante` responsável por executar a rotina correspondente dentro do jogo.
  // `this` = representa a própria instância atual da classe.
  // `proximoParticipante` = nome do método ou função executado por esta rotina.
  // `atual` = parâmetro recebido pela rotina para fornecer o valor relacionado a `atual`.
  // `this.turno` = valor padrão utilizado para `atual` quando nenhum valor é fornecido.
  // `this.turno` = acessa o atributo ou método `turno` pertencente à instância atual da classe.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  proximoParticipante(atual = this.turno) {

    // Declara `indice` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `indice` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.ordemTurnos` = acessa o atributo ou método `ordemTurnos` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const indice = this.ordemTurnos.indexOf(atual);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.ordemTurnos` = acessa o atributo ou método `ordemTurnos` pertencente à instância atual da classe.
    // `1` = valor numérico utilizado como índice, posição ou limite nesta operação.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `%` = operador que obtém o resto da divisão inteira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return this.ordemTurnos[(indice + 1) % this.ordemTurnos.length];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `primeiroParticipante` responsável por executar a rotina correspondente dentro do jogo.
  // `primeiroParticipante` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  primeiroParticipante() {

    // Percorre a coleção e cria uma nova coleção com os valores transformados pela função indicada.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `candidatos` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.ordemTurnos` = acessa o atributo ou método `ordemTurnos` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    const candidatos = this.ordemTurnos.map((participante, indice) => {

      // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const peca = melhorPecaInicial(this.maoDe(participante));

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return { participante, indice, peca, chave: chavePecaInicial(peca) };

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `candidatos.sort` = chama o método `sort` pertencente a `candidatos`.
    // `=>` = define uma função de seta.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    candidatos.sort((a, b) => compararChaves(b.chave, a.chave) || a.indice - b.indice);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return [candidatos[0].participante, candidatos[0].peca];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `equipeDe` responsável por executar a rotina correspondente dentro do jogo.
  // `equipeDe` = nome do método ou função executado por esta rotina.
  // `participante` = parâmetro recebido pela rotina para fornecer o valor relacionado a `participante`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  equipeDe(participante) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.modo === MODO_MANO_A_MANO) return participante === JOGADOR ? EQUIPE_JOGADOR : EQUIPE_ADVERSARIA;

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return [JOGADOR, PARCEIRA].includes(participante) ? EQUIPE_JOGADOR : EQUIPE_ADVERSARIA;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `totalMao` responsável por executar a rotina correspondente dentro do jogo.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `totalMao` = nome do método ou função executado por esta rotina.
  // `mao` = parâmetro recebido pela rotina para fornecer o valor relacionado a `mao`.
  // `mao.reduce` = chama o método `reduce` pertencente a `mao`.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `=>` = define uma função de seta.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  totalMao(mao) { return mao.reduce((soma, peca) => soma + peca.total, 0); }

  // Define o método `totalEquipe` responsável por executar a rotina correspondente dentro do jogo.
  // `totalEquipe` = nome do método ou função executado por esta rotina.
  // `equipe` = parâmetro recebido pela rotina para fornecer o valor relacionado a `equipe`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  totalEquipe(equipe) {

    // Declara `participantes` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `participantes` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    const participantes = this.modo === MODO_MANO_A_MANO

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      ? (equipe === EQUIPE_JOGADOR ? [JOGADOR] : [IA])

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      : (equipe === EQUIPE_JOGADOR ? [JOGADOR, PARCEIRA] : [IA_DIREITA, IA_ESQUERDA]);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.totalMao` = acessa o atributo ou método `totalMao` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `participantes.reduce` = chama o método `reduce` pertencente a `participantes`.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=>` = define uma função de seta.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return participantes.reduce((soma, p) => soma + this.totalMao(this.maoDe(p)), 0);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `verificarMaoVazia` responsável por executar a rotina correspondente dentro do jogo.
  // `verificarMaoVazia` = nome do método ou função executado por esta rotina.
  // `origem` = parâmetro recebido pela rotina para fornecer o valor relacionado a `origem`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  verificarMaoVazia(origem) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.maoDe(origem).length) return;

    // Armazena ou atualiza no atributo `encerrada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.encerrada = true;

    // Armazena ou atualiza no atributo `motivoFim` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.motivoFim` = acessa o atributo ou método `motivoFim` pertencente à instância atual da classe.
    // `bateu` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.motivoFim = "bateu";

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.modo === MODO_DUPLAS) {

      // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `this.equipeDe` = acessa o atributo ou método `equipeDe` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.vencedor = this.equipeDe(origem);

      // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      this.mensagemFinal = this.vencedor === EQUIPE_JOGADOR

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        ? `${NOMES[origem]} bateu. Sua dupla venceu a rodada.`

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        : `${NOMES[origem]} bateu. A dupla adversária venceu a rodada.`;

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.vencedor = origem;

      // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
      // `Você bateu e venceu a rodada.` = texto literal utilizado nesta instrução.
      // `A IA bateu e venceu a rodada.` = texto literal utilizado nesta instrução.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mensagemFinal = origem === JOGADOR ? "Você bateu e venceu a rodada." : "A IA bateu e venceu a rodada.";

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `encerrarBloqueio` responsável por executar a rotina correspondente dentro do jogo.
  // `encerrarBloqueio` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  encerrarBloqueio() {

    // Armazena ou atualiza no atributo `encerrada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.encerrada = true;

    // Armazena ou atualiza no atributo `motivoFim` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.motivoFim` = acessa o atributo ou método `motivoFim` pertencente à instância atual da classe.
    // `bloqueio` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.motivoFim = "bloqueio";

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.modo === MODO_DUPLAS) {

      // Declara `totalJogador` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `totalJogador` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.totalEquipe` = acessa o atributo ou método `totalEquipe` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const totalJogador = this.totalEquipe(EQUIPE_JOGADOR);

      // Declara `totalAdversario` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `totalAdversario` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.totalEquipe` = acessa o atributo ou método `totalEquipe` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const totalAdversario = this.totalEquipe(EQUIPE_ADVERSARIA);

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      if (totalJogador < totalAdversario) {

        // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.vencedor = EQUIPE_JOGADOR;

        // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
        // `Rodada bloqueada: sua dupla possui menos pontos nas mãos.` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.mensagemFinal = "Rodada bloqueada: sua dupla possui menos pontos nas mãos.";

      // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
      // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      } else if (totalAdversario < totalJogador) {

        // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.vencedor = EQUIPE_ADVERSARIA;

        // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
        // `Rodada bloqueada: a dupla adversária possui menos pontos nas mãos.` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.mensagemFinal = "Rodada bloqueada: a dupla adversária possui menos pontos nas mãos.";

      // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
      // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      } else {

        // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
        // `empate` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.vencedor = "empate";

        // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
        // `Rodada bloqueada e empatada em pontos.` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.mensagemFinal = "Rodada bloqueada e empatada em pontos.";

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Declara `totalJogador` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `totalJogador` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.totalMao` = acessa o atributo ou método `totalMao` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const totalJogador = this.totalMao(this.maoDe(JOGADOR));

    // Declara `totalIA` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `totalIA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.totalMao` = acessa o atributo ou método `totalMao` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const totalIA = this.totalMao(this.maoDe(IA));

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (totalJogador < totalIA) {

      // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.vencedor = JOGADOR;

      // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
      // `Rodada bloqueada: você possui menos pontos na mão.` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mensagemFinal = "Rodada bloqueada: você possui menos pontos na mão.";

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else if (totalIA < totalJogador) {

      // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.vencedor = IA;

      // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
      // `Rodada bloqueada: a IA possui menos pontos na mão.` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mensagemFinal = "Rodada bloqueada: a IA possui menos pontos na mão.";

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Armazena ou atualiza no atributo `vencedor` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `empate` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.vencedor = "empate";

      // Armazena ou atualiza no atributo `mensagemFinal` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mensagemFinal` = acessa o atributo ou método `mensagemFinal` pertencente à instância atual da classe.
      // `Rodada bloqueada e empatada em pontos.` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mensagemFinal = "Rodada bloqueada e empatada em pontos.";

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `pontosDaRodada` responsável por executar a rotina correspondente dentro do jogo.
  // `pontosDaRodada` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  pontosDaRodada() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.encerrada` = acessa o atributo ou método `encerrada` pertencente à instância atual da classe.
    // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
    // `empate` = texto literal utilizado nesta instrução.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.encerrada || !this.vencedor || this.vencedor === "empate") return 0;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.modo === MODO_DUPLAS) {

      // Declara `totalJogador` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `totalJogador` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.totalEquipe` = acessa o atributo ou método `totalEquipe` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const totalJogador = this.totalEquipe(EQUIPE_JOGADOR);

      // Declara `totalAdversario` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `totalAdversario` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.totalEquipe` = acessa o atributo ou método `totalEquipe` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const totalAdversario = this.totalEquipe(EQUIPE_ADVERSARIA);

      // Declara `pontos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `pontos` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      const pontos = this.vencedor === EQUIPE_JOGADOR

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `this` = representa a própria instância atual da classe.
        // `this.motivoFim` = acessa o atributo ou método `motivoFim` pertencente à instância atual da classe.
        // `bateu` = texto literal utilizado nesta instrução.
        // `===` = compara valor e tipo para verificar igualdade estrita.
        // `-` = operador que realiza subtração numérica.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
        ? (this.motivoFim === "bateu" ? totalAdversario : totalAdversario - totalJogador)

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `this` = representa a própria instância atual da classe.
        // `this.motivoFim` = acessa o atributo ou método `motivoFim` pertencente à instância atual da classe.
        // `bateu` = texto literal utilizado nesta instrução.
        // `===` = compara valor e tipo para verificar igualdade estrita.
        // `-` = operador que realiza subtração numérica.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        : (this.motivoFim === "bateu" ? totalJogador : totalJogador - totalAdversario);

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `Math.max` = retorna o maior entre os valores informados.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return Math.max(1, pontos);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Declara `totalJogador` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `totalJogador` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.totalMao` = acessa o atributo ou método `totalMao` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const totalJogador = this.totalMao(this.maoDe(JOGADOR));

    // Declara `totalIA` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `totalIA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.totalMao` = acessa o atributo ou método `totalMao` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const totalIA = this.totalMao(this.maoDe(IA));

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.vencedor` = acessa o atributo ou método `vencedor` pertencente à instância atual da classe.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `Math.max` = retorna o maior entre os valores informados.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.vencedor === JOGADOR) return Math.max(1, this.maoDe(JOGADOR).length === 0 ? totalIA : totalIA - totalJogador);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.maoDe` = acessa o atributo ou método `maoDe` pertencente à instância atual da classe.
    // `Math.max` = retorna o maior entre os valores informados.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return Math.max(1, this.maoDe(IA).length === 0 ? totalJogador : totalJogador - totalIA);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a classe `InteligenciaDomino`, agrupando os dados e comportamentos relacionados a esta parte do jogo.
// `class` = define uma classe que agrupa estado e comportamentos relacionados.
// `InteligenciaDomino` = nome atribuído à classe definida nesta linha.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
class InteligenciaDomino {

  // Define o método `escolherJogada` responsável por executar a rotina correspondente dentro do jogo.
  // `escolherJogada` = nome do método ou função executado por esta rotina.
  // `estado` = parâmetro recebido pela rotina para fornecer o valor relacionado a `estado`.
  // `mao` = parâmetro recebido pela rotina para fornecer o valor relacionado a `mao`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  escolherJogada(estado, mao) {

    // Declara `frequencias` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `new` = cria uma nova instância da classe informada.
    // `frequencias` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const frequencias = new Map();

    // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    for (const peca of mao) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `get` = define um acessor de leitura que se comporta como propriedade.
      // `frequencias.set` = chama o método `set` pertencente a `frequencias`.
      // `frequencias.get` = chama o método `get` pertencente a `frequencias`.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      frequencias.set(peca.a, (frequencias.get(peca.a) || 0) + 1);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `get` = define um acessor de leitura que se comporta como propriedade.
      // `frequencias.set` = chama o método `set` pertencente a `frequencias`.
      // `frequencias.get` = chama o método `get` pertencente a `frequencias`.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      frequencias.set(peca.b, (frequencias.get(peca.b) || 0) + 1);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Declara `jogadas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `jogadas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const jogadas = [];

    // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `for` = inicia uma estrutura de repetição.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    for (const peca of mao) {

      // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição.
      // `estado.ladosValidos` = chama o método `ladosValidos` pertencente a `estado`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      for (const lado of estado.ladosValidos(peca)) {

        // Declara `valorAberto` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
        // `valorAberto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        let valorAberto;

        // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // `!` = operador que nega ou inverte um valor lógico.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        if (!estado.mesa.length) valorAberto = peca.b;

        // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
        // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
        // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
        // `peca.outroValor` = chama o método `outroValor` pertencente a `peca`.
        // `===` = compara valor e tipo para verificar igualdade estrita.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        else if (lado === LADO_ESQUERDO) valorAberto = peca.outroValor(estado.esquerda);

        // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
        // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
        // `peca.outroValor` = chama o método `outroValor` pertencente a `peca`.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        else valorAberto = peca.outroValor(estado.direita);

        // Declara `pontuacao` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
        // `pontuacao` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
        // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // `*` = operador que realiza multiplicação numérica.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        let pontuacao = peca.total * 2;

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `get` = define um acessor de leitura que se comporta como propriedade.
        // `frequencias.get` = chama o método `get` pertencente a `frequencias`.
        // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
        // `3` = valor numérico 3 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
        // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
        // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
        // `*` = operador que realiza multiplicação numérica.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        pontuacao += (frequencias.get(valorAberto) || 0) * 3;

        // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
        // `5` = valor numérico 5 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
        // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        if (peca.dupla) pontuacao += 5;

        // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
        // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
        // `10` = valor numérico 10 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
        // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
        // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
        // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        if (peca.total >= 10) pontuacao += 2;

        // Adiciona o valor informado ao final da coleção utilizada nesta linha.
        // `jogadas.push` = chama o método `push` pertencente a `jogadas`.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
        // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
        // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        jogadas.push({ pontuacao, total: peca.total, peca, lado });

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `null` = representa ausência intencional de valor.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!jogadas.length) return null;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `jogadas.sort` = chama o método `sort` pertencente a `jogadas`.
    // `=>` = define uma função de seta.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    jogadas.sort((a, b) => b.pontuacao - a.pontuacao || b.total - a.total);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return jogadas[0];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `criarConjuntoCompleto` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `criarConjuntoCompleto` = nome atribuído à função definida nesta linha.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
function criarConjuntoCompleto() {

  // Declara `pecas` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `pecas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const pecas = [];

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
  // `for` = inicia uma estrutura de repetição.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `6` = valor numérico 6 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
  // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  for (let a = 0; a <= 6; a += 1) {

    // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `for` = inicia uma estrutura de repetição.
    // `6` = valor numérico 6 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    for (let b = a; b <= 6; b += 1) {

      // Adiciona o valor informado ao final da coleção utilizada nesta linha.
      // `new` = cria uma nova instância da classe informada.
      // `pecas.push` = chama o método `push` pertencente a `pecas`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      pecas.push(new PecaDomino(a, b));

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return pecas;

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `embaralhar` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `embaralhar` = nome atribuído à função definida nesta linha.
// `lista` = parâmetro recebido pela função para fornecer o valor relacionado a `lista`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
function embaralhar(lista) {

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
  // `for` = inicia uma estrutura de repetição.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
  // `-=` = subtrai o valor da direita do valor existente e armazena o resultado.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  for (let i = lista.length - 1; i > 0; i -= 1) {

    // Declara `j` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `j` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `Math.floor` = arredonda o valor numérico para baixo até o inteiro mais próximo.
    // `Math.random` = gera um número pseudoaleatório entre 0 e 1.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `*` = operador que realiza multiplicação numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const j = Math.floor(Math.random() * (i + 1));

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    [lista[i], lista[j]] = [lista[j], lista[i]];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `melhorPecaInicial` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `melhorPecaInicial` = nome atribuído à função definida nesta linha.
// `mao` = parâmetro recebido pela função para fornecer o valor relacionado a `mao`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
function melhorPecaInicial(mao) {

  // Filtra a coleção e cria uma nova coleção apenas com os elementos que atendem à condição.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `duplas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `mao.filter` = chama o método `filter` pertencente a `mao`.
  // `=>` = define uma função de seta.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const duplas = mao.filter((p) => p.dupla);

  // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
  // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
  // `=>` = define uma função de seta.
  // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
  // `-` = operador que realiza subtração numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  if (duplas.length) return [...duplas].sort((a, b) => b.a - a.a || b.total - a.total)[0];

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `Math.max` = retorna o maior entre os valores informados.
  // `Math.min` = retorna o menor entre os valores informados.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `=>` = define uma função de seta.
  // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
  // `-` = operador que realiza subtração numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return [...mao].sort((a, b) => b.total - a.total || Math.max(b.a, b.b) - Math.max(a.a, a.b) || Math.min(b.a, b.b) - Math.min(a.a, a.b))[0];

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `chavePecaInicial` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `chavePecaInicial` = nome atribuído à função definida nesta linha.
// `peca` = parâmetro recebido pela função para fornecer o valor relacionado a `peca`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
function chavePecaInicial(peca) {

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `Math.max` = retorna o maior entre os valores informados.
  // `Math.min` = retorna o menor entre os valores informados.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return [peca.dupla ? 1 : 0, peca.dupla ? peca.a : peca.total, Math.max(peca.a, peca.b), Math.min(peca.a, peca.b)];

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `compararChaves` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `compararChaves` = nome atribuído à função definida nesta linha.
// `a` = parâmetro recebido pela função para fornecer o valor relacionado a `a`.
// `b` = parâmetro recebido pela função para fornecer o valor relacionado a `b`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
function compararChaves(a, b) {

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
  // `for` = inicia uma estrutura de repetição.
  // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  for (let i = 0; i < a.length; i += 1) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (a[i] !== b[i]) return a[i] - b[i];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return 0;

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a classe `ArmazenamentoLocal`, agrupando os dados e comportamentos relacionados a esta parte do jogo.
// `class` = define uma classe que agrupa estado e comportamentos relacionados.
// `ArmazenamentoLocal` = nome atribuído à classe definida nesta linha.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
class ArmazenamentoLocal {

  // Define o método `carregar` responsável por executar a rotina correspondente dentro do jogo.
  // `carregar` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  carregar() {

    // Inicia um bloco protegido para executar uma operação que pode gerar erro.
    // `try` = inicia um bloco protegido para tratamento de possíveis erros.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    try {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `JSON.parse` = converte um texto JSON para uma estrutura JavaScript.
      // `localStorage.getItem` = recupera um valor do armazenamento local do navegador.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || { partidas: [] };

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `catch` = captura um erro ocorrido no bloco try.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } catch {

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return { partidas: [] };

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `salvarPartida` responsável por executar a rotina correspondente dentro do jogo.
  // `salvarPartida` = nome do método ou função executado por esta rotina.
  // `partida` = parâmetro recebido pela rotina para fornecer o valor relacionado a `partida`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  salvarPartida(partida) {

    // Declara `dados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `dados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.carregar` = acessa o atributo ou método `carregar` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const dados = this.carregar();

    // Adiciona o valor informado ao final da coleção utilizada nesta linha.
    // `dados.partidas.push` = chama o método `push` pertencente a `dados.partidas`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    dados.partidas.push(partida);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `dados.partidas.slice` = chama o método `slice` pertencente a `dados.partidas`.
    // `300` = valor numérico 300 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `-300` = valor numérico -300 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (dados.partidas.length > 300) dados.partidas = dados.partidas.slice(-300);

    // Salva os dados informados no armazenamento local do navegador.
    // `localStorage.setItem` = salva um valor associado a uma chave no armazenamento local do navegador.
    // `JSON.stringify` = converte uma estrutura JavaScript para texto JSON.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dados));

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `partidasDoJogador` responsável por executar a rotina correspondente dentro do jogo.
  // `partidasDoJogador` = nome do método ou função executado por esta rotina.
  // `nome` = parâmetro recebido pela rotina para fornecer o valor relacionado a `nome`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  partidasDoJogador(nome) {

    // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `nome.trim` = chama o método `trim` pertencente a `nome`.
    // `pt-BR` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const alvo = nome.trim().toLocaleLowerCase("pt-BR");

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `this.carregar` = acessa o atributo ou método `carregar` pertencente à instância atual da classe.
    // `partidas.filter` = chama o método `filter` pertencente a `partidas`.
    // `p.nome.toLocaleLowerCase` = chama o método `toLocaleLowerCase` pertencente a `p.nome`.
    // `pt-BR` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return this.carregar().partidas.filter((p) => p.nome.toLocaleLowerCase("pt-BR") === alvo);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `ranking` responsável por executar a rotina correspondente dentro do jogo.
  // `ranking` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  ranking() {

    // Declara `mapa` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `new` = cria uma nova instância da classe informada.
    // `mapa` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const mapa = new Map();

    // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `for` = inicia uma estrutura de repetição.
    // `this.carregar` = acessa o atributo ou método `carregar` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    for (const p of this.carregar().partidas) {

      // Declara `chave` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `chave` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `p.nome.toLocaleLowerCase` = chama o método `toLocaleLowerCase` pertencente a `p.nome`.
      // `pt-BR` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const chave = p.nome.toLocaleLowerCase("pt-BR");

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `mapa.has` = chama o método `has` pertencente a `mapa`.
      // `mapa.set` = chama o método `set` pertencente a `mapa`.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `!` = operador que nega ou inverte um valor lógico.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!mapa.has(chave)) mapa.set(chave, { nome: p.nome, partidas: 0, vitorias: 0, pontos: 0 });

      // Declara `item` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `get` = define um acessor de leitura que se comporta como propriedade.
      // `item` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `mapa.get` = chama o método `get` pertencente a `mapa`.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const item = mapa.get(chave);

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      item.partidas += 1;

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `jogador` = texto literal utilizado nesta instrução.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      item.vitorias += p.vencedor === "jogador" ? 1 : 0;

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      item.pontos += p.pontosJogador;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `mapa.values` = chama o método `values` pertencente a `mapa`.
    // `a.nome.localeCompare` = chama o método `localeCompare` pertencente a `a.nome`.
    // `pt-BR` = texto literal utilizado nesta instrução.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `10` = valor numérico 10 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return [...mapa.values()].sort((a, b) => b.vitorias - a.vitorias || b.pontos - a.pontos || a.partidas - b.partidas || a.nome.localeCompare(b.nome, "pt-BR")).slice(0, 10);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a classe `DominoApp`, agrupando os dados e comportamentos relacionados a esta parte do jogo.
// `class` = define uma classe que agrupa estado e comportamentos relacionados.
// `DominoApp` = nome atribuído à classe definida nesta linha.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
class DominoApp {

  // Define o método construtor responsável por inicializar os atributos e estados do objeto quando a classe é instanciada.
  // `constructor` = método executado automaticamente quando um objeto da classe é criado.
  // `constructor` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  constructor() {

    // Armazena ou atualiza no atributo `estado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado = new EstadoRodada();

    // Armazena ou atualiza no atributo `ia` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.ia` = acessa o atributo ou método `ia` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.ia = new InteligenciaDomino();

    // Armazena ou atualiza no atributo `storage` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.storage` = acessa o atributo ou método `storage` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.storage = new ArmazenamentoLocal();

    // Armazena ou atualiza no atributo `modo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.modo = MODO_MANO_A_MANO;

    // Armazena ou atualiza no atributo `nome` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.nome` = acessa o atributo ou método `nome` pertencente à instância atual da classe.
    // `Jogador` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.nome = "Jogador";

    // Armazena ou atualiza no atributo `pontosJogador` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.pontosJogador = 0;

    // Armazena ou atualiza no atributo `pontosIA` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.pontosIA = 0;

    // Armazena ou atualiza no atributo `rodada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.rodada = 0;

    // Armazena ou atualiza no atributo `inicioPartida` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.inicioPartida` = acessa o atributo ou método `inicioPartida` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.inicioPartida = 0;

    // Armazena ou atualiza no atributo `selecionada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.selecionada = null;

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Armazena ou atualiza no atributo `emJogo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `false` = valor lógico falso.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.emJogo = false;

    // Armazena ou atualiza no atributo `timerIds` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.timerIds` = acessa o atributo ou método `timerIds` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.timerIds = new Set();

    // Armazena ou atualiza no atributo `toastTimer` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.toastTimer` = acessa o atributo ou método `toastTimer` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.toastTimer = null;

    // Armazena ou atualiza no atributo `draggedId` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.draggedId` = acessa o atributo ou método `draggedId` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.draggedId = null;

    // Armazena ou atualiza no atributo `dragState` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.dragState = null;

    // Recupera do armazenamento local do navegador os dados associados à chave informada.
    // `this` = representa a própria instância atual da classe.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `localStorage.getItem` = recupera um valor do armazenamento local do navegador.
    // `0` = texto literal utilizado nesta instrução.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.somAtivo = localStorage.getItem(SOM_KEY) !== "0";

    // Armazena ou atualiza no atributo `audioCache` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.audioCache` = acessa o atributo ou método `audioCache` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.audioCache = new Map();

    // Armazena ou atualiza no atributo `logs` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.logs = [];

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.cacheDOM` = acessa o atributo ou método `cacheDOM` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.cacheDOM();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.bindEventos` = acessa o atributo ou método `bindEventos` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bindEventos();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.atualizarBotoesSom` = acessa o atributo ou método `atualizarBotoesSom` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.atualizarBotoesSom();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderMenuModo` = acessa o atributo ou método `renderMenuModo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderMenuModo();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `cacheDOM` responsável por executar a rotina correspondente dentro do jogo.
  // `cacheDOM` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  cacheDOM() {

    // Declara `ids` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `ids` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    const ids = [

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `tela-menu` = texto literal utilizado nesta instrução.
      // `tela-jogo` = texto literal utilizado nesta instrução.
      // `nome-jogador` = texto literal utilizado nesta instrução.
      // `btn-iniciar` = texto literal utilizado nesta instrução.
      // `btn-estatisticas-menu` = texto literal utilizado nesta instrução.
      // `btn-regras-menu` = texto literal utilizado nesta instrução.
      // `btn-som-menu` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "tela-menu", "tela-jogo", "nome-jogador", "btn-iniciar", "btn-estatisticas-menu", "btn-regras-menu", "btn-som-menu",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `header-nome` = texto literal utilizado nesta instrução.
      // `header-modo` = texto literal utilizado nesta instrução.
      // `placar-jogador` = texto literal utilizado nesta instrução.
      // `placar-ia` = texto literal utilizado nesta instrução.
      // `rodada-label` = texto literal utilizado nesta instrução.
      // `label-time-jogador` = texto literal utilizado nesta instrução.
      // `label-time-ia` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "header-nome", "header-modo", "placar-jogador", "placar-ia", "rodada-label", "label-time-jogador", "label-time-ia",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `btn-som-jogo` = texto literal utilizado nesta instrução.
      // `btn-regras-jogo` = texto literal utilizado nesta instrução.
      // `btn-estatisticas-jogo` = texto literal utilizado nesta instrução.
      // `btn-menu` = texto literal utilizado nesta instrução.
      // `mesa` = texto literal utilizado nesta instrução.
      // `board-chain` = texto literal utilizado nesta instrução.
      // `drop-left` = texto literal utilizado nesta instrução.
      // `drop-right` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "btn-som-jogo", "btn-regras-jogo", "btn-estatisticas-jogo", "btn-menu", "mesa", "board-chain", "drop-left", "drop-right",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `drop-left-value` = texto literal utilizado nesta instrução.
      // `drop-right-value` = texto literal utilizado nesta instrução.
      // `jogador-topo` = texto literal utilizado nesta instrução.
      // `jogador-esquerda` = texto literal utilizado nesta instrução.
      // `jogador-direita` = texto literal utilizado nesta instrução.
      // `jogador-ia-mano` = texto literal utilizado nesta instrução.
      // `mao-topo` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "drop-left-value", "drop-right-value", "jogador-topo", "jogador-esquerda", "jogador-direita", "jogador-ia-mano", "mao-topo",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `mao-esquerda` = texto literal utilizado nesta instrução.
      // `mao-direita` = texto literal utilizado nesta instrução.
      // `mao-ia` = texto literal utilizado nesta instrução.
      // `contagem-topo` = texto literal utilizado nesta instrução.
      // `contagem-esquerda` = texto literal utilizado nesta instrução.
      // `contagem-direita` = texto literal utilizado nesta instrução.
      // `contagem-ia` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "mao-esquerda", "mao-direita", "mao-ia", "contagem-topo", "contagem-esquerda", "contagem-direita", "contagem-ia",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `status-text` = texto literal utilizado nesta instrução.
      // `turno-pill` = texto literal utilizado nesta instrução.
      // `status-icon` = texto literal utilizado nesta instrução.
      // `mao-jogador` = texto literal utilizado nesta instrução.
      // `hand-count` = texto literal utilizado nesta instrução.
      // `hand-hint` = texto literal utilizado nesta instrução.
      // `turno-sidebar` = texto literal utilizado nesta instrução.
      // `participantes-info` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "status-text", "turno-pill", "status-icon", "mao-jogador", "hand-count", "hand-hint", "turno-sidebar", "participantes-info",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `extremo-esquerdo` = texto literal utilizado nesta instrução.
      // `extremo-direito` = texto literal utilizado nesta instrução.
      // `monte-contagem` = texto literal utilizado nesta instrução.
      // `btn-jogar-esquerda` = texto literal utilizado nesta instrução.
      // `btn-jogar-direita` = texto literal utilizado nesta instrução.
      // `btn-comprar` = texto literal utilizado nesta instrução.
      // `btn-passar` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "extremo-esquerdo", "extremo-direito", "monte-contagem", "btn-jogar-esquerda", "btn-jogar-direita", "btn-comprar", "btn-passar",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `dica-text` = texto literal utilizado nesta instrução.
      // `game-log` = texto literal utilizado nesta instrução.
      // `btn-limpar-log` = texto literal utilizado nesta instrução.
      // `toast` = texto literal utilizado nesta instrução.
      // `modal` = texto literal utilizado nesta instrução.
      // `modal-content` = texto literal utilizado nesta instrução.
      // `modal-close` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      "dica-text", "game-log", "btn-limpar-log", "toast", "modal", "modal-content", "modal-close"

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    ];

    // Armazena ou atualiza no atributo `el` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el = {};

    // Localiza um elemento da interface HTML e utiliza ou armazena sua referência nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `ids.forEach` = chama o método `forEach` pertencente a `ids`.
    // `document.getElementById` = localiza um elemento HTML pelo atributo id.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    ids.forEach((id) => { this.el[id] = document.getElementById(id); });

    // Localiza um elemento da interface HTML e utiliza ou armazena sua referência nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.modeCards` = acessa o atributo ou método `modeCards` pertencente à instância atual da classe.
    // `document.querySelectorAll` = chama o método `querySelectorAll` pertencente a `document`.
    // `.mode-card` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.modeCards = [...document.querySelectorAll(".mode-card")];

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `bindEventos` responsável por executar a rotina correspondente dentro do jogo.
  // `bindEventos` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  bindEventos() {

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.modeCards` = acessa o atributo ou método `modeCards` pertencente à instância atual da classe.
    // `card.addEventListener` = chama o método `addEventListener` pertencente a `card`.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    this.modeCards.forEach((card) => card.addEventListener("click", () => {

      // Armazena ou atualiza no atributo `modo` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.modo = card.dataset.mode;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.renderMenuModo` = acessa o atributo ou método `renderMenuModo` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.renderMenuModo();

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `menu` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("menu");

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    }));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.iniciarPartida` = acessa o atributo ou método `iniciarPartida` pertencente à instância atual da classe.
    // `btn-iniciar` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-iniciar"].addEventListener("click", () => this.iniciarPartida());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.iniciarPartida` = acessa o atributo ou método `iniciarPartida` pertencente à instância atual da classe.
    // `nome-jogador` = texto literal utilizado nesta instrução.
    // `keydown` = texto literal utilizado nesta instrução.
    // `Enter` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["nome-jogador"].addEventListener("keydown", (e) => { if (e.key === "Enter") this.iniciarPartida(); });

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.alternarSom` = acessa o atributo ou método `alternarSom` pertencente à instância atual da classe.
    // `btn-som-menu` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-som-menu"].addEventListener("click", () => this.alternarSom());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.alternarSom` = acessa o atributo ou método `alternarSom` pertencente à instância atual da classe.
    // `btn-som-jogo` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-som-jogo"].addEventListener("click", () => this.alternarSom());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.abrirRegras` = acessa o atributo ou método `abrirRegras` pertencente à instância atual da classe.
    // `btn-regras-menu` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-regras-menu"].addEventListener("click", () => this.abrirRegras());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.abrirRegras` = acessa o atributo ou método `abrirRegras` pertencente à instância atual da classe.
    // `btn-regras-jogo` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-regras-jogo"].addEventListener("click", () => this.abrirRegras());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.abrirEstatisticas` = acessa o atributo ou método `abrirEstatisticas` pertencente à instância atual da classe.
    // `value.trim` = chama o método `trim` pertencente a `value`.
    // `btn-estatisticas-menu` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `nome-jogador` = texto literal utilizado nesta instrução.
    // `Jogador` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-estatisticas-menu"].addEventListener("click", () => this.abrirEstatisticas(this.el["nome-jogador"].value.trim() || "Jogador"));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.abrirEstatisticas` = acessa o atributo ou método `abrirEstatisticas` pertencente à instância atual da classe.
    // `this.nome` = acessa o atributo ou método `nome` pertencente à instância atual da classe.
    // `btn-estatisticas-jogo` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-estatisticas-jogo"].addEventListener("click", () => this.abrirEstatisticas(this.nome));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.voltarMenu` = acessa o atributo ou método `voltarMenu` pertencente à instância atual da classe.
    // `btn-menu` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-menu"].addEventListener("click", () => this.voltarMenu());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.jogarSelecionada` = acessa o atributo ou método `jogarSelecionada` pertencente à instância atual da classe.
    // `btn-jogar-esquerda` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-jogar-esquerda"].addEventListener("click", () => this.jogarSelecionada(LADO_ESQUERDO));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.jogarSelecionada` = acessa o atributo ou método `jogarSelecionada` pertencente à instância atual da classe.
    // `btn-jogar-direita` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-jogar-direita"].addEventListener("click", () => this.jogarSelecionada(LADO_DIREITO));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.comprarJogador` = acessa o atributo ou método `comprarJogador` pertencente à instância atual da classe.
    // `btn-comprar` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-comprar"].addEventListener("click", () => this.comprarJogador());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.passarJogador` = acessa o atributo ou método `passarJogador` pertencente à instância atual da classe.
    // `btn-passar` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-passar"].addEventListener("click", () => this.passarJogador());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `this.renderLog` = acessa o atributo ou método `renderLog` pertencente à instância atual da classe.
    // `btn-limpar-log` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-limpar-log"].addEventListener("click", () => { this.logs = []; this.renderLog(); });

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.fecharModal` = acessa o atributo ou método `fecharModal` pertencente à instância atual da classe.
    // `modal-close` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["modal-close"].addEventListener("click", () => this.fecharModal());

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.fecharModal` = acessa o atributo ou método `fecharModal` pertencente à instância atual da classe.
    // `modal` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["modal"].addEventListener("click", (e) => { if (e.target === this.el["modal"]) this.fecharModal(); });

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.dragOverMesa` = acessa o atributo ou método `dragOverMesa` pertencente à instância atual da classe.
    // `dragover` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.mesa.addEventListener("dragover", (e) => this.dragOverMesa(e));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.dragLeaveMesa` = acessa o atributo ou método `dragLeaveMesa` pertencente à instância atual da classe.
    // `dragleave` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.mesa.addEventListener("dragleave", (e) => this.dragLeaveMesa(e));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.dropNaMesa` = acessa o atributo ou método `dropNaMesa` pertencente à instância atual da classe.
    // `drop` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.mesa.addEventListener("drop", (e) => this.dropNaMesa(e));

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `window.addEventListener` = chama o método `addEventListener` pertencente a `window`.
    // `resize` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    window.addEventListener("resize", () => {

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `this` = representa a própria instância atual da classe.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
      // `this.renderMesa` = acessa o atributo ou método `renderMesa` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (this.emJogo) this.renderMesa();

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `window.addEventListener` = chama o método `addEventListener` pertencente a `window`.
    // `keydown` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    window.addEventListener("keydown", (e) => {

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `F8` = texto literal utilizado nesta instrução.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      if (e.key === "F8") {

        // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
        // `e.preventDefault` = chama o método `preventDefault` pertencente a `e`.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        e.preventDefault();

        // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.alternarSom` = acessa o atributo ou método `alternarSom` pertencente à instância atual da classe.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.alternarSom();

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `this` = representa a própria instância atual da classe.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `Escape` = texto literal utilizado nesta instrução.
      // `hidden` = texto literal utilizado nesta instrução.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
      // `!` = operador que nega ou inverte um valor lógico.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      if (e.key === "Escape" && !this.el.modal.classList.contains("hidden")) {

        // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.fecharModal` = acessa o atributo ou método `fecharModal` pertencente à instância atual da classe.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.fecharModal();

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `renderMenuModo` responsável por executar a rotina correspondente dentro do jogo.
  // `renderMenuModo` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  renderMenuModo() {

    // Percorre todos os elementos da coleção e executa a função indicada para cada um deles.
    // `this` = representa a própria instância atual da classe.
    // `this.modeCards` = acessa o atributo ou método `modeCards` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    this.modeCards.forEach((card) => {

      // Declara `ativa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `ativa` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const ativa = card.dataset.mode === this.modo;

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `card.classList.toggle` = chama o método `toggle` pertencente a `card.classList`.
      // `selected` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      card.classList.toggle("selected", ativa);

      // Localiza um elemento da interface HTML e utiliza ou armazena sua referência nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `marker` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `card.querySelector` = chama o método `querySelector` pertencente a `card`.
      // `b` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const marker = card.querySelector("b");

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `SELECIONADO` = texto literal utilizado nesta instrução.
      // `SELECIONAR` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (marker) marker.textContent = ativa ? "SELECIONADO" : "SELECIONAR";

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `iniciarPartida` responsável por executar a rotina correspondente dentro do jogo.
  // `iniciarPartida` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  iniciarPartida() {

    // Declara `nome` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `nome` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `value.trim` = chama o método `trim` pertencente a `value`.
    // `nome-jogador` = texto literal utilizado nesta instrução.
    // ` ` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const nome = this.el["nome-jogador"].value.trim().replace(/\s+/g, " ");

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!nome) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `DIGITE SEU NOME` = texto literal utilizado nesta instrução.
      // `1200` = valor numérico 1200 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast("DIGITE SEU NOME", 1200);

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `nome-jogador` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["nome-jogador"].focus();

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
    // `this` = representa a própria instância atual da classe.
    // `this.nome` = acessa o atributo ou método `nome` pertencente à instância atual da classe.
    // `nome.slice` = chama o método `slice` pertencente a `nome`.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `40` = valor numérico 40 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.nome = nome.slice(0, 40);

    // Armazena ou atualiza no atributo `pontosJogador` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.pontosJogador = 0;

    // Armazena ou atualiza no atributo `pontosIA` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.pontosIA = 0;

    // Armazena ou atualiza no atributo `rodada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.rodada = 0;

    // Armazena ou atualiza no atributo `inicioPartida` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.inicioPartida` = acessa o atributo ou método `inicioPartida` pertencente à instância atual da classe.
    // `Date.now` = chama o método `now` pertencente a `Date`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.inicioPartida = Date.now();

    // Armazena ou atualiza no atributo `logs` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.logs = [];

    // Armazena ou atualiza no atributo `emJogo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.emJogo = true;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.cancelarTimers` = acessa o atributo ou método `cancelarTimers` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.cancelarTimers();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mostrarTela` = acessa o atributo ou método `mostrarTela` pertencente à instância atual da classe.
    // `jogo` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mostrarTela("jogo");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.novaRodada` = acessa o atributo ou método `novaRodada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.novaRodada();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `mostrarTela` responsável por executar a rotina correspondente dentro do jogo.
  // `mostrarTela` = nome do método ou função executado por esta rotina.
  // `tela` = parâmetro recebido pela rotina para fornecer o valor relacionado a `tela`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  mostrarTela(tela) {

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `tela-menu` = texto literal utilizado nesta instrução.
    // `screen-active` = texto literal utilizado nesta instrução.
    // `menu` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["tela-menu"].classList.toggle("screen-active", tela === "menu");

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `tela-jogo` = texto literal utilizado nesta instrução.
    // `screen-active` = texto literal utilizado nesta instrução.
    // `jogo` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["tela-jogo"].classList.toggle("screen-active", tela === "jogo");

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `novaRodada` responsável por executar a rotina correspondente dentro do jogo.
  // `novaRodada` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  novaRodada() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.emJogo) return;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
    // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.pontosJogador >= META_PONTOS || this.pontosIA >= META_PONTOS) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.encerrarPartida` = acessa o atributo ou método `encerrarPartida` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.encerrarPartida();

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.rodada += 1;

    // Armazena ou atualiza no atributo `estado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado = new EstadoRodada(this.modo);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.preparar(this.modo);

    // Armazena ou atualiza no atributo `selecionada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.selecionada = null;

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Declara uma variável e armazena nela o valor definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const [primeiro, peca] = this.estado.primeiroParticipante();

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.turno = primeiro;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.jogar(peca, LADO_DIREITO, primeiro);

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.turno = this.estado.proximoParticipante(primeiro);

    // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `peca.texto` = chama o método `texto` pertencente a `peca`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const texto = `${NOMES[primeiro]} abriu a rodada com ${peca.texto()} no centro da mesa.`;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.setStatus(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.adicionarLog(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `abertura` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.tocar("abertura");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
    // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
    // `900` = valor numérico 900 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mostrarToast(`RODADA ${this.rodada}`, 900);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
    // `this.prepararTurnoAtual` = acessa o atributo ou método `prepararTurnoAtual` pertencente à instância atual da classe.
    // `850` = valor numérico 850 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.agendar(850, () => this.prepararTurnoAtual());

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `prepararTurnoAtual` responsável por executar a rotina correspondente dentro do jogo.
  // `prepararTurnoAtual` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  prepararTurnoAtual() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.emJogo || this.estado.encerrada) return;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.estado.turno === JOGADOR) {

      // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `false` = valor lógico falso.
      // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.bloqueado = false;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.renderTudo();

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `Sua vez. Escolha uma peça que combine com um dos extremos.` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus("Sua vez. Escolha uma peça que combine com um dos extremos.");

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Declara `participante` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `participante` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const participante = this.estado.turno;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
    // `this.turnoIA` = acessa o atributo ou método `turnoIA` pertencente à instância atual da classe.
    // `650` = valor numérico 650 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.agendar(650, () => this.turnoIA(participante));

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `selecionarPeca` responsável por executar a rotina correspondente dentro do jogo.
  // `true` = valor lógico verdadeiro.
  // `selecionarPeca` = nome do método ou função executado por esta rotina.
  // `peca` = parâmetro recebido pela rotina para fornecer o valor relacionado a `peca`.
  // `renderizarMao` = parâmetro recebido pela rotina para fornecer o valor relacionado a `renderizarMao`.
  // `true` = valor padrão utilizado para `renderizarMao` quando nenhum valor é fornecido.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  selecionarPeca(peca, renderizarMao = true) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.bloqueado || this.estado.turno !== JOGADOR || this.estado.encerrada) return;

    // Armazena ou atualiza no atributo `selecionada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.selecionada = peca;

    // Declara `lados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lados = this.estado.ladosValidos(peca);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!lados.length) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `peca.texto` = chama o método `texto` pertencente a `peca`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(`A peça ${peca.texto()} não combina com os extremos atuais.`);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else if (lados.length === 1) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `peca.texto` = chama o método `texto` pertencente a `peca`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(`${peca.texto()} selecionada. Arraste-a até o extremo ${lados[0]} ou use o botão lateral.`);

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `peca.texto` = chama o método `texto` pertencente a `peca`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(`${peca.texto()} selecionada. Arraste-a para o extremo esquerdo ou direito.`);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (renderizarMao) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.renderMaoJogador` = acessa o atributo ou método `renderMaoJogador` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.renderMaoJogador();

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Localiza um elemento da interface HTML e utiliza ou armazena sua referência nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `mao-jogador` = texto literal utilizado nesta instrução.
      // `.player-piece` = texto literal utilizado nesta instrução.
      // `=>` = define uma função de seta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      this.el["mao-jogador"].querySelectorAll(".player-piece").forEach((item) => {

        // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
        // `item.classList.toggle` = chama o método `toggle` pertencente a `item.classList`.
        // `selected` = texto literal utilizado nesta instrução.
        // `===` = compara valor e tipo para verificar igualdade estrita.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        item.classList.toggle("selected", item.dataset.id === peca.id);

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      });

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.atualizarAcoes` = acessa o atributo ou método `atualizarAcoes` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.atualizarAcoes();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.atualizarDropTargets` = acessa o atributo ou método `atualizarDropTargets` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.atualizarDropTargets(lados);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `jogarSelecionada` responsável por executar a rotina correspondente dentro do jogo.
  // `jogarSelecionada` = nome do método ou função executado por esta rotina.
  // `lado` = parâmetro recebido pela rotina para fornecer o valor relacionado a `lado`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  jogarSelecionada(lado) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.bloqueado || this.estado.turno !== JOGADOR || !this.selecionada) return;

    // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const peca = this.selecionada;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!this.estado.ladosValidos(peca).includes(lado)) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `A peça selecionada não pode ser colocada nesse lado.` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus("A peça selecionada não pode ser colocada nesse lado.");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `JOGADA INVÁLIDA` = texto literal utilizado nesta instrução.
      // `850` = valor numérico 850 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast("JOGADA INVÁLIDA", 850);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.jogar(peca, lado, JOGADOR);

    // Armazena ou atualiza no atributo `selecionada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.selecionada = null;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `pedra` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.tocar("pedra");

    // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `peca.texto` = chama o método `texto` pertencente a `peca`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const texto = `Você jogou ${peca.texto()} à ${lado}.`;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.setStatus(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.adicionarLog(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.tratarFimRodada` = acessa o atributo ou método `tratarFimRodada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.tratarFimRodada()) return;

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.turno = this.estado.proximoParticipante(JOGADOR);

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
    // `this.prepararTurnoAtual` = acessa o atributo ou método `prepararTurnoAtual` pertencente à instância atual da classe.
    // `500` = valor numérico 500 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.agendar(500, () => this.prepararTurnoAtual());

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `comprarJogador` responsável por executar a rotina correspondente dentro do jogo.
  // `comprarJogador` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  comprarJogador() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.bloqueado || this.estado.turno !== JOGADOR || this.estado.encerrada || this.modo !== MODO_MANO_A_MANO) return;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.estado.possuiJogada(this.estado.maoDe(JOGADOR))) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `Você ainda possui uma jogada válida e não precisa comprar.` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus("Você ainda possui uma jogada válida e não precisa comprar.");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const peca = this.estado.comprar(JOGADOR);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!peca) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `O monte está vazio. Se não houver jogada possível, passe a vez.` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus("O monte está vazio. Se não houver jogada possível, passe a vez.");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.atualizarAcoes` = acessa o atributo ou método `atualizarAcoes` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.atualizarAcoes();

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `peca.texto` = chama o método `texto` pertencente a `peca`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const texto = `Você comprou ${peca.texto()}.`;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.setStatus(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.adicionarLog(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `comprar` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.tocar("comprar");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.estado.ladosValidos(peca).length) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.selecionarPeca` = acessa o atributo ou método `selecionarPeca` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.selecionarPeca(peca);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `PEÇA JOGÁVEL ENCONTRADA` = texto literal utilizado nesta instrução.
      // `950` = valor numérico 950 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast("PEÇA JOGÁVEL ENCONTRADA", 950);

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else if (!this.estado.monte.length) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `peca.texto` = chama o método `texto` pertencente a `peca`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(`Você comprou ${peca.texto()}, mas ela não serve. O monte acabou; passe a vez.`);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `MONTE VAZIO` = texto literal utilizado nesta instrução.
      // `950` = valor numérico 950 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast("MONTE VAZIO", 950);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.atualizarAcoes` = acessa o atributo ou método `atualizarAcoes` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.atualizarAcoes();

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `passarJogador` responsável por executar a rotina correspondente dentro do jogo.
  // `passarJogador` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  passarJogador() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.bloqueado || this.estado.turno !== JOGADOR || this.estado.encerrada) return;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.estado.possuiJogada(this.estado.maoDe(JOGADOR))) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `Você ainda possui uma jogada válida e não pode passar.` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus("Você ainda possui uma jogada válida e não pode passar.");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.estado.monte.length) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `Ainda existem peças no monte. Compre até encontrar uma jogada.` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus("Ainda existem peças no monte. Compre até encontrar uma jogada.");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.registrarPasse(JOGADOR);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
    // `Você passou a vez.` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.setStatus("Você passou a vez.");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
    // `Você passou a vez.` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.adicionarLog("Você passou a vez.");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
    // `VOCÊ PASSOU` = texto literal utilizado nesta instrução.
    // `850` = valor numérico 850 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mostrarToast("VOCÊ PASSOU", 850);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `passar` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.tocar("passar");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.tratarFimRodada` = acessa o atributo ou método `tratarFimRodada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.tratarFimRodada()) return;

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.turno = this.estado.proximoParticipante(JOGADOR);

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
    // `this.prepararTurnoAtual` = acessa o atributo ou método `prepararTurnoAtual` pertencente à instância atual da classe.
    // `500` = valor numérico 500 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.agendar(500, () => this.prepararTurnoAtual());

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `turnoIA` responsável por executar a rotina correspondente dentro do jogo.
  // `turnoIA` = nome do método ou função executado por esta rotina.
  // `participante` = parâmetro recebido pela rotina para fornecer o valor relacionado a `participante`.
  // `compradas` = parâmetro recebido pela rotina para fornecer o valor relacionado a `compradas`.
  // `0` = valor padrão utilizado para `compradas` quando nenhum valor é fornecido.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  turnoIA(participante, compradas = 0) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.emJogo || this.estado.encerrada || this.estado.turno !== participante) return;

    // Declara `nome` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `nome` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const nome = NOMES[participante];

    // Declara `mao` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `mao` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const mao = this.estado.maoDe(participante);

    // Declara `jogada` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `jogada` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.ia` = acessa o atributo ou método `ia` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const jogada = this.ia.escolherJogada(this.estado, mao);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!jogada && this.modo === MODO_MANO_A_MANO && participante === IA && this.estado.podeComprar(participante)) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.estado.comprar(participante);

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      compradas += 1;

      // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const texto = `${nome} comprou uma peça. Restam ${this.estado.monte.length} no monte.`;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(texto);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.adicionarLog(texto);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `IA COMPROU UMA PEÇA` = texto literal utilizado nesta instrução.
      // `650` = valor numérico 650 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast("IA COMPROU UMA PEÇA", 650);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `ia_comprar` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("ia_comprar");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.renderTudo();

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
      // `this.turnoIA` = acessa o atributo ou método `turnoIA` pertencente à instância atual da classe.
      // `560` = valor numérico 560 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `=>` = define uma função de seta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.agendar(560, () => this.turnoIA(participante, compradas));

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!jogada) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.estado.registrarPasse(participante);

      // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      const texto = compradas

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        ? `${nome} comprou ${compradas} peça(s), não encontrou jogada e passou.`

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        : `${nome} não possui jogada e passou a vez.`;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(texto);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.adicionarLog(texto);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `nome.toUpperCase` = chama o método `toUpperCase` pertencente a `nome`.
      // `850` = valor numérico 850 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast(`${nome.toUpperCase()} PASSOU`, 850);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `passar` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("passar");

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.estado.jogar(jogada.peca, jogada.lado, participante);

      // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      const texto = compradas

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `jogada.peca.texto` = chama o método `texto` pertencente a `jogada.peca`.
        ? `${nome} comprou ${compradas} peça(s) e jogou ${jogada.peca.texto()} à ${jogada.lado}.`

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `jogada.peca.texto` = chama o método `texto` pertencente a `jogada.peca`.
        // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        : `${nome} jogou ${jogada.peca.texto()} à ${jogada.lado}.`;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.setStatus(texto);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.adicionarLog(texto);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `pedra` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("pedra");

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.tratarFimRodada` = acessa o atributo ou método `tratarFimRodada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.tratarFimRodada()) return;

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.estado.turno = this.estado.proximoParticipante(participante);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
    // `this.prepararTurnoAtual` = acessa o atributo ou método `prepararTurnoAtual` pertencente à instância atual da classe.
    // `560` = valor numérico 560 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.agendar(560, () => this.prepararTurnoAtual());

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `tratarFimRodada` responsável por executar a rotina correspondente dentro do jogo.
  // `tratarFimRodada` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  tratarFimRodada() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `false` = valor lógico falso.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.estado.encerrada) return false;

    // Declara `pontos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `pontos` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const pontos = this.estado.pontosDaRodada();

    // Declara `titulo` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `titulo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let titulo;

    // Declara `ganhou` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `false` = valor lógico falso.
    // `ganhou` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let ganhou = false;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (this.modo === MODO_DUPLAS) {

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `this` = representa a própria instância atual da classe.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      if (this.estado.vencedor === EQUIPE_JOGADOR) {

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `this` = representa a própria instância atual da classe.
        // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
        // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.pontosJogador += pontos;

        // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
        // `SUA DUPLA VENCEU A RODADA` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        titulo = "SUA DUPLA VENCEU A RODADA";

        // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
        // `true` = valor lógico verdadeiro.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        ganhou = true;

      // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
      // `this` = representa a própria instância atual da classe.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      } else if (this.estado.vencedor === EQUIPE_ADVERSARIA) {

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `this` = representa a própria instância atual da classe.
        // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
        // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.pontosIA += pontos;

        // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
        // `A DUPLA ADVERSÁRIA VENCEU` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        titulo = "A DUPLA ADVERSÁRIA VENCEU";

      // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
      // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      } else {

        // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
        // `RODADA EMPATADA` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        titulo = "RODADA EMPATADA";

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else if (this.estado.vencedor === JOGADOR) {

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.pontosJogador += pontos;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `VOCÊ VENCEU A RODADA` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      titulo = "VOCÊ VENCEU A RODADA";

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `true` = valor lógico verdadeiro.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      ganhou = true;

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else if (this.estado.vencedor === IA) {

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.pontosIA += pontos;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `A IA VENCEU A RODADA` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      titulo = "A IA VENCEU A RODADA";

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `RODADA EMPATADA` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      titulo = "RODADA EMPATADA";

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `empate` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.estado.vencedor === "empate") this.tocar("empate");

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `this` = representa a própria instância atual da classe.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `rodada_vitoria` = texto literal utilizado nesta instrução.
    // `rodada_derrota` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    else this.tocar(ganhou ? "rodada_vitoria" : "rodada_derrota");

    // Declara `complemento` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `complemento` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const complemento = pontos ? ` +${pontos} ponto(s).` : "";

    // Declara `texto` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `texto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const texto = `${this.estado.mensagemFinal}${complemento}`;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.setStatus` = acessa o atributo ou método `setStatus` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.setStatus(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.adicionarLog` = acessa o atributo ou método `adicionarLog` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.adicionarLog(texto);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
    // `1700` = valor numérico 1700 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mostrarToast(titulo, 1700);

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderTudo` = acessa o atributo ou método `renderTudo` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderTudo();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.agendar` = acessa o atributo ou método `agendar` pertencente à instância atual da classe.
    // `this.novaRodada` = acessa o atributo ou método `novaRodada` pertencente à instância atual da classe.
    // `2050` = valor numérico 2050 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.agendar(2050, () => this.novaRodada());

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `true` = valor lógico verdadeiro.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return true;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `encerrarPartida` responsável por executar a rotina correspondente dentro do jogo.
  // `encerrarPartida` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  encerrarPartida() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.emJogo) return;

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Declara `venceu` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `venceu` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const venceu = this.pontosJogador >= META_PONTOS;

    // Declara `duracao` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `duracao` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.inicioPartida` = acessa o atributo ou método `inicioPartida` pertencente à instância atual da classe.
    // `Math.max` = retorna o maior entre os valores informados.
    // `Math.round` = chama o método `round` pertencente a `Math`.
    // `Date.now` = chama o método `now` pertencente a `Date`.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `1000` = valor numérico 1000 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `/` = operador que realiza divisão numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const duracao = Math.max(0, Math.round((Date.now() - this.inicioPartida) / 1000));

    // Inicia o bloco de instruções correspondente à estrutura definida nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.storage` = acessa o atributo ou método `storage` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    this.storage.salvarPartida({

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.nome` = acessa o atributo ou método `nome` pertencente à instância atual da classe.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      nome: this.nome,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `new` = cria uma nova instância da classe informada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      dataHora: new Date().toISOString(),

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `jogador` = texto literal utilizado nesta instrução.
      // `ia` = texto literal utilizado nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      vencedor: venceu ? "jogador" : "ia",

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      pontosJogador: this.pontosJogador,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      pontosIA: this.pontosIA,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      rodadas: this.rodada,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      duracaoSegundos: duracao,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.nomeModo` = acessa o atributo ou método `nomeModo` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      modo: this.nomeModo(),

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `partida_vitoria` = texto literal utilizado nesta instrução.
    // `partida_derrota` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.tocar(venceu ? "partida_vitoria" : "partida_derrota");

    // Declara `titulo` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `titulo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `PARABÉNS!` = texto literal utilizado nesta instrução.
    // `FIM DE PARTIDA` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const titulo = venceu ? "PARABÉNS!" : "FIM DE PARTIDA";

    // Declara `frase` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `frase` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    const frase = this.modo === MODO_DUPLAS

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
      // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      ? (venceu ? `Sua dupla venceu por ${this.pontosJogador} × ${this.pontosIA}.` : `A dupla adversária venceu por ${this.pontosIA} × ${this.pontosJogador}.`)

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
      // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      : (venceu ? `Você venceu por ${this.pontosJogador} × ${this.pontosIA}.` : `A IA venceu por ${this.pontosIA} × ${this.pontosJogador}.`);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.abrirModal` = acessa o atributo ou método `abrirModal` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    this.abrirModal(`
      <span class="section-kicker">PARTIDA ENCERRADA</span>
      <h2 class="modal-title">${titulo}</h2>
      <p class="modal-subtitle">${frase} O resultado foi salvo no histórico local deste navegador.</p>
      <div class="stats-summary">
        <div><b>${this.pontosJogador}</b><span>seus pontos</span></div>
        <div><b>${this.pontosIA}</b><span>adversário</span></div>
        <div><b>${this.rodada}</b><span>rodadas</span></div>
        <div><b>${formatarDuracao(duracao)}</b><span>duração</span></div>
      </div>
      <div class="modal-actions">
        <button class="btn btn-primary" data-modal-action="replay">Jogar novamente</button>
        <button class="btn btn-secondary" data-modal-action="menu">Voltar ao menu</button>
      </div>
    `);

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `modal-content` = texto literal utilizado nesta instrução.
    // `[data-modal-action="replay"]` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    this.el["modal-content"].querySelector('[data-modal-action="replay"]').addEventListener("click", () => {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.fecharModal` = acessa o atributo ou método `fecharModal` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.fecharModal();

      // Armazena ou atualiza no atributo `pontosJogador` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.pontosJogador = 0;

      // Armazena ou atualiza no atributo `pontosIA` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.pontosIA = 0;

      // Armazena ou atualiza no atributo `rodada` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.rodada = 0;

      // Armazena ou atualiza no atributo `inicioPartida` da instância atual o valor definido nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.inicioPartida` = acessa o atributo ou método `inicioPartida` pertencente à instância atual da classe.
      // `Date.now` = chama o método `now` pertencente a `Date`.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.inicioPartida = Date.now();

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.novaRodada` = acessa o atributo ou método `novaRodada` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.novaRodada();

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `modal-content` = texto literal utilizado nesta instrução.
    // `[data-modal-action="menu"]` = texto literal utilizado nesta instrução.
    // `click` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    this.el["modal-content"].querySelector('[data-modal-action="menu"]').addEventListener("click", () => {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.fecharModal` = acessa o atributo ou método `fecharModal` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.fecharModal();

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `true` = valor lógico verdadeiro.
      // `this.voltarMenu` = acessa o atributo ou método `voltarMenu` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.voltarMenu(true);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `renderTudo` responsável por executar a rotina correspondente dentro do jogo.
  // `renderTudo` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  renderTudo() {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.emJogo) return;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.nome` = acessa o atributo ou método `nome` pertencente à instância atual da classe.
    // `header-nome` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["header-nome"].textContent = this.nome;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.nomeModo` = acessa o atributo ou método `nomeModo` pertencente à instância atual da classe.
    // `header-modo` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["header-modo"].textContent = this.nomeModo();

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.pontosJogador` = acessa o atributo ou método `pontosJogador` pertencente à instância atual da classe.
    // `placar-jogador` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["placar-jogador"].textContent = this.pontosJogador;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.pontosIA` = acessa o atributo ou método `pontosIA` pertencente à instância atual da classe.
    // `placar-ia` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["placar-ia"].textContent = this.pontosIA;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.rodada` = acessa o atributo ou método `rodada` pertencente à instância atual da classe.
    // `rodada-label` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["rodada-label"].textContent = `RODADA ${this.rodada}`;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `label-time-jogador` = texto literal utilizado nesta instrução.
    // `SUA DUPLA` = texto literal utilizado nesta instrução.
    // `VOCÊ` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["label-time-jogador"].textContent = this.modo === MODO_DUPLAS ? "SUA DUPLA" : "VOCÊ";

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `label-time-ia` = texto literal utilizado nesta instrução.
    // `DUPLA ADVERSÁRIA` = texto literal utilizado nesta instrução.
    // `IA` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["label-time-ia"].textContent = this.modo === MODO_DUPLAS ? "DUPLA ADVERSÁRIA" : "IA";

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderParticipantes` = acessa o atributo ou método `renderParticipantes` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderParticipantes();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderMesa` = acessa o atributo ou método `renderMesa` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderMesa();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderMaoJogador` = acessa o atributo ou método `renderMaoJogador` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderMaoJogador();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.atualizarAcoes` = acessa o atributo ou método `atualizarAcoes` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.atualizarAcoes();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderLog` = acessa o atributo ou método `renderLog` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderLog();

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `extremo-esquerdo` = texto literal utilizado nesta instrução.
    // `–` = texto literal utilizado nesta instrução.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["extremo-esquerdo"].textContent = this.estado.esquerda ?? "–";

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `extremo-direito` = texto literal utilizado nesta instrução.
    // `–` = texto literal utilizado nesta instrução.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["extremo-direito"].textContent = this.estado.direita ?? "–";

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `monte-contagem` = texto literal utilizado nesta instrução.
    // `—` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["monte-contagem"].textContent = this.modo === MODO_MANO_A_MANO ? this.estado.monte.length : "—";

    // Declara `turnoNome` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `turnoNome` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `—` = texto literal utilizado nesta instrução.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const turnoNome = NOMES[this.estado.turno] || "—";

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `turno-pill` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["turno-pill"].textContent = `Turno: ${turnoNome}`;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `turno-sidebar` = texto literal utilizado nesta instrução.
    // `Rodada encerrada` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["turno-sidebar"].textContent = this.estado.encerrada ? "Rodada encerrada" : `Turno: ${turnoNome}`;

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `status-icon` = texto literal utilizado nesta instrução.
    // `#42d999` = código hexadecimal que representa aproximadamente a cor tom esverdeado.
    // `#d5a84d` = código hexadecimal que representa aproximadamente a cor dourado.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["status-icon"].style.color = this.estado.turno === JOGADOR && !this.bloqueado ? "#42d999" : "#d5a84d";

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `renderParticipantes` responsável por executar a rotina correspondente dentro do jogo.
  // `renderParticipantes` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  renderParticipantes() {

    // Declara `duplas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `duplas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const duplas = this.modo === MODO_DUPLAS;

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `jogador-topo` = texto literal utilizado nesta instrução.
    // `hidden` = texto literal utilizado nesta instrução.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["jogador-topo"].classList.toggle("hidden", !duplas);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `jogador-esquerda` = texto literal utilizado nesta instrução.
    // `hidden` = texto literal utilizado nesta instrução.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["jogador-esquerda"].classList.toggle("hidden", !duplas);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `jogador-direita` = texto literal utilizado nesta instrução.
    // `hidden` = texto literal utilizado nesta instrução.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["jogador-direita"].classList.toggle("hidden", !duplas);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `jogador-ia-mano` = texto literal utilizado nesta instrução.
    // `hidden` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["jogador-ia-mano"].classList.toggle("hidden", duplas);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (duplas) {

      // Declara `topo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `topo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const topo = this.estado.maoDe(PARCEIRA).length;

      // Declara `esq` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `esq` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const esq = this.estado.maoDe(IA_ESQUERDA).length;

      // Declara `dir` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `dir` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const dir = this.estado.maoDe(IA_DIREITA).length;

      // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `contagem-topo` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["contagem-topo"].textContent = `${topo} peça(s)`;

      // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `contagem-esquerda` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["contagem-esquerda"].textContent = `${esq} peça(s)`;

      // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `contagem-direita` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["contagem-direita"].textContent = `${dir} peça(s)`;

      // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `participantes-info` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["participantes-info"].textContent = `Parceira IA: ${topo} peça(s)\nIA direita: ${dir} peça(s)\nIA esquerda: ${esq} peça(s)`;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `renderVersos` = nome do método ou função executado por esta rotina.
      // `topo` = parâmetro recebido pela rotina para fornecer o valor relacionado a `topo`.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `mao-topo` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      renderVersos(this.el["mao-topo"], topo);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `renderVersos` = nome do método ou função executado por esta rotina.
      // `esq` = parâmetro recebido pela rotina para fornecer o valor relacionado a `esq`.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `mao-esquerda` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      renderVersos(this.el["mao-esquerda"], esq);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `renderVersos` = nome do método ou função executado por esta rotina.
      // `dir` = parâmetro recebido pela rotina para fornecer o valor relacionado a `dir`.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `mao-direita` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      renderVersos(this.el["mao-direita"], dir);

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } else {

      // Declara `qtd` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `qtd` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const qtd = this.estado.maoDe(IA).length;

      // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `contagem-ia` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["contagem-ia"].textContent = `${qtd} peça(s)`;

      // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `participantes-info` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["participantes-info"].textContent = `IA: ${qtd} peça(s)\nMonte: ${this.estado.monte.length} peça(s)`;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `renderVersos` = nome do método ou função executado por esta rotina.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `Math.min` = retorna o menor entre os valores informados.
      // `mao-ia` = texto literal utilizado nesta instrução.
      // `12` = valor numérico 12 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      renderVersos(this.el["mao-ia"], Math.min(qtd, 12));

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `renderMesa` responsável por executar a rotina correspondente dentro do jogo.
  // `renderMesa` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  renderMesa() {

    // Declara `chain` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `chain` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `board-chain` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const chain = this.el["board-chain"];

    // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    chain.innerHTML = "";

    // Procura e retorna o índice do primeiro elemento da coleção que atende à condição informada.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `this` = representa a própria instância atual da classe.
    // `indiceCentro` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let indiceCentro = this.estado.mesa.findIndex((peca) => peca.id === this.estado.pecaInicialId);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `Math.floor` = arredonda o valor numérico para baixo até o inteiro mais próximo.
    // `Math.max` = retorna o maior entre os valores informados.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `1` = valor numérico utilizado como índice, posição ou limite nesta operação.
    // `2` = valor numérico utilizado como índice, posição ou limite nesta operação.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `/` = operador que realiza divisão numérica.
    // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (indiceCentro < 0) indiceCentro = Math.floor(Math.max(0, this.estado.mesa.length - 1) / 2);

    // Declara `layout` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `layout` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    const layout = calcularLayoutMesa(

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      this.estado.mesa.length,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `700` = valor numérico 700 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      chain.clientWidth || 700,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `360` = valor numérico 360 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      chain.clientHeight || 360,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      indiceCentro

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    );

    // Declara `posicoes` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `posicoes` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const posicoes = layout.posicoes;

    // Percorre todos os elementos da coleção e executa a função indicada para cada um deles.
    // `this` = representa a própria instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    this.estado.mesa.forEach((peca, indice) => {

      // Declara `pos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `false` = valor lógico falso.
      // `pos` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `50` = valor numérico utilizado como índice, posição ou limite nesta operação.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const pos = posicoes[indice] || { x: 50, y: 50, vertical: false, invertido: false };

      // Declara `wrapper` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `wrapper` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `document.createElement` = chama o método `createElement` pertencente a `document`.
      // `div` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const wrapper = document.createElement("div");

      // Declara `ehInicial` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `ehInicial` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const ehInicial = peca.id === this.estado.pecaInicialId;

      // Declara `ehExtremo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe.
      // `ehExtremo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
      // `1` = valor numérico utilizado como índice, posição ou limite nesta operação.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `-` = operador que realiza subtração numérica.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const ehExtremo = indice === 0 || indice === this.estado.mesa.length - 1;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `vertical` = texto literal utilizado nesta instrução.
      // `` = texto literal utilizado nesta instrução.
      // `opening` = texto literal utilizado nesta instrução.
      // `endpoint` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.className = `board-piece ${pos.vertical || peca.dupla ? "vertical" : ""} ${ehInicial ? "opening" : ""} ${ehExtremo ? "endpoint" : ""}`;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.style.left = `${pos.x}%`;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.style.top = `${pos.y}%`;

      // Declara `a` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
      // `a` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      let a = peca.esquerda;

      // Declara `b` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
      // `b` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      let b = peca.direita;

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `!` = operador que nega ou inverte um valor lógico.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (pos.invertido && !peca.dupla) [a, b] = [b, a];

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `wrapper.appendChild` = chama o método `appendChild` pertencente a `wrapper`.
      // `vertical` = texto literal utilizado nesta instrução.
      // `horizontal` = texto literal utilizado nesta instrução.
      // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.appendChild(criarElementoPeca(a, b, pos.vertical || peca.dupla ? "vertical" : "horizontal"));

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `chain.appendChild` = chama o método `appendChild` pertencente a `chain`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      chain.appendChild(wrapper);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `drop-left-value` = texto literal utilizado nesta instrução.
    // `–` = texto literal utilizado nesta instrução.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-left-value"].textContent = this.estado.esquerda ?? "–";

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `drop-right-value` = texto literal utilizado nesta instrução.
    // `–` = texto literal utilizado nesta instrução.
    // `??` = operador de coalescência nula que usa o valor da direita quando o da esquerda é nulo ou indefinido.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-right-value"].textContent = this.estado.direita ?? "–";

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.posicionarDropTargets` = acessa o atributo ou método `posicionarDropTargets` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.posicionarDropTargets(layout);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `this.atualizarDropTargets` = acessa o atributo ou método `atualizarDropTargets` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.selecionada) this.atualizarDropTargets(this.estado.ladosValidos(this.selecionada));

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `this` = representa a própria instância atual da classe.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `this.atualizarDropTargets` = acessa o atributo ou método `atualizarDropTargets` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    else this.atualizarDropTargets([]);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `posicionarDropTargets` responsável por executar a rotina correspondente dentro do jogo.
  // `posicionarDropTargets` = nome do método ou função executado por esta rotina.
  // `layout` = parâmetro recebido pela rotina para fornecer o valor relacionado a `layout`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  posicionarDropTargets(layout) {

    // Declara `mesaRect` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `mesaRect` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const mesaRect = this.el.mesa.getBoundingClientRect();

    // Declara `chainRect` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `chainRect` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `board-chain` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const chainRect = this.el["board-chain"].getBoundingClientRect();

    // Declara `left` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `left` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const left = this.el["drop-left"];

    // Declara `right` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `right` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const right = this.el["drop-right"];

    // Declara `posicionar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `posicionar` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    const posicionar = (elemento, ponto) => {

      // Declara `x` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `x` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `100` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `-` = operador que realiza subtração numérica.
      // `*` = operador que realiza multiplicação numérica.
      // `/` = operador que realiza divisão numérica.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const x = chainRect.left - mesaRect.left + chainRect.width * ponto.x / 100;

      // Declara `y` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `y` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `100` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `-` = operador que realiza subtração numérica.
      // `*` = operador que realiza multiplicação numérica.
      // `/` = operador que realiza divisão numérica.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const y = chainRect.top - mesaRect.top + chainRect.height * ponto.y / 100;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `Math.max` = retorna o maior entre os valores informados.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      elemento.style.left = `${clamp(x - 43, 18, Math.max(18, mesaRect.width - 104))}px`;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `Math.max` = retorna o maior entre os valores informados.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      elemento.style.top = `${clamp(y - 32, 18, Math.max(18, mesaRect.height - 82))}px`;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    };

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!this.estado.mesa.length) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `posicionar` = nome do método ou função executado por esta rotina.
      // `left` = parâmetro recebido pela rotina para fornecer o valor relacionado a `left`.
      // `44` = valor numérico 44 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      posicionar(left, { x: 44, y: 50 });

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `posicionar` = nome do método ou função executado por esta rotina.
      // `right` = parâmetro recebido pela rotina para fornecer o valor relacionado a `right`.
      // `56` = valor numérico 56 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      posicionar(right, { x: 56, y: 50 });

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `posicionar` = nome do método ou função executado por esta rotina.
    // `left` = parâmetro recebido pela rotina para fornecer o valor relacionado a `left`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    posicionar(left, layout.proximoEsquerda);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `posicionar` = nome do método ou função executado por esta rotina.
    // `right` = parâmetro recebido pela rotina para fornecer o valor relacionado a `right`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    posicionar(right, layout.proximoDireita);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `renderMaoJogador` responsável por executar a rotina correspondente dentro do jogo.
  // `renderMaoJogador` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  renderMaoJogador() {

    // Declara `area` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `area` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `mao-jogador` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const area = this.el["mao-jogador"];

    // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    area.innerHTML = "";

    // Declara `mao` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `mao` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const mao = this.estado.maoDe(JOGADOR);

    // Declara `liberado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `liberado` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const liberado = !this.bloqueado && this.estado.turno === JOGADOR && !this.estado.encerrada;

    // Percorre todos os elementos da coleção e executa a função indicada para cada um deles.
    // `mao.forEach` = chama o método `forEach` pertencente a `mao`.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    mao.forEach((peca) => {

      // Declara `wrapper` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `wrapper` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `document.createElement` = chama o método `createElement` pertencente a `document`.
      // `div` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const wrapper = document.createElement("div");

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `player-piece` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.className = "player-piece";

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `this` = representa a própria instância atual da classe.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
      // `wrapper.classList.add` = chama o método `add` pertencente a `wrapper.classList`.
      // `selected` = texto literal utilizado nesta instrução.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (this.selecionada?.id === peca.id) wrapper.classList.add("selected");

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `this` = representa a própria instância atual da classe.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
      // `wrapper.classList.add` = chama o método `add` pertencente a `wrapper.classList`.
      // `invalid` = texto literal utilizado nesta instrução.
      // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
      // `!` = operador que nega ou inverte um valor lógico.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (liberado && !this.estado.ladosValidos(peca).length) wrapper.classList.add("invalid");

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.dataset.id = peca.id;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `false` = valor lógico falso.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.draggable = false;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `wrapper.appendChild` = chama o método `appendChild` pertencente a `wrapper`.
      // `vertical` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.appendChild(criarElementoPeca(peca.a, peca.b, "vertical"));

      // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
      // `this` = representa a própria instância atual da classe.
      // `this.iniciarArrastePeca` = acessa o atributo ou método `iniciarArrastePeca` pertencente à instância atual da classe.
      // `wrapper.addEventListener` = chama o método `addEventListener` pertencente a `wrapper`.
      // `pointerdown` = texto literal utilizado nesta instrução.
      // `=>` = define uma função de seta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.addEventListener("pointerdown", (e) => this.iniciarArrastePeca(e, peca, wrapper, liberado));

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `area.appendChild` = chama o método `appendChild` pertencente a `area`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      area.appendChild(wrapper);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `hand-count` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["hand-count"].textContent = `${mao.length} peça(s)`;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `iniciarArrastePeca` responsável por executar a rotina correspondente dentro do jogo.
  // `iniciarArrastePeca` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `peca` = parâmetro recebido pela rotina para fornecer o valor relacionado a `peca`.
  // `wrapper` = parâmetro recebido pela rotina para fornecer o valor relacionado a `wrapper`.
  // `liberado` = parâmetro recebido pela rotina para fornecer o valor relacionado a `liberado`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  iniciarArrastePeca(e, peca, wrapper, liberado) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!liberado || e.button > 0) return;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `false` = valor lógico falso.
    // `this.selecionarPeca` = acessa o atributo ou método `selecionarPeca` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.selecionarPeca(peca, false);

    // Armazena ou atualiza no atributo `draggedId` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.draggedId` = acessa o atributo ou método `draggedId` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.draggedId = peca.id;

    // Armazena ou atualiza no atributo `dragState` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    this.dragState = {

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      pointerId: e.pointerId,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      peca,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      wrapper,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      inicioX: e.clientX,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      inicioY: e.clientY,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `false` = valor lógico falso.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      movendo: false,

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `null` = representa ausência intencional de valor.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      ghost: null,

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    };

    // Inicia um bloco protegido para executar uma operação que pode gerar erro.
    // `try` = inicia um bloco protegido para tratamento de possíveis erros.
    // `catch` = captura um erro ocorrido no bloco try.
    // `wrapper.setPointerCapture` = chama o método `setPointerCapture` pertencente a `wrapper`.
    // `*` = operador que realiza multiplicação numérica.
    // `/` = operador que realiza divisão numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    try { wrapper.setPointerCapture(e.pointerId); } catch { /* alguns navegadores não exigem captura */ }

    // Declara `mover` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `mover` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.moverArrastePeca` = acessa o atributo ou método `moverArrastePeca` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const mover = (evento) => this.moverArrastePeca(evento);

    // Declara `soltar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `soltar` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.finalizarArrastePeca` = acessa o atributo ou método `finalizarArrastePeca` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const soltar = (evento) => this.finalizarArrastePeca(evento);

    // Declara `cancelar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `cancelar` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.cancelarArrastePeca` = acessa o atributo ou método `cancelarArrastePeca` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const cancelar = (evento) => this.cancelarArrastePeca(evento);

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `wrapper.addEventListener` = chama o método `addEventListener` pertencente a `wrapper`.
    // `pointermove` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    wrapper.addEventListener("pointermove", mover);

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `true` = valor lógico verdadeiro.
    // `wrapper.addEventListener` = chama o método `addEventListener` pertencente a `wrapper`.
    // `pointerup` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    wrapper.addEventListener("pointerup", soltar, { once: true });

    // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
    // `true` = valor lógico verdadeiro.
    // `wrapper.addEventListener` = chama o método `addEventListener` pertencente a `wrapper`.
    // `pointercancel` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    wrapper.addEventListener("pointercancel", cancelar, { once: true });

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `this` = representa a própria instância atual da classe.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    this.dragState.removerEventos = () => {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `wrapper.removeEventListener` = chama o método `removeEventListener` pertencente a `wrapper`.
      // `pointermove` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.removeEventListener("pointermove", mover);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `wrapper.removeEventListener` = chama o método `removeEventListener` pertencente a `wrapper`.
      // `pointerup` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.removeEventListener("pointerup", soltar);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `wrapper.removeEventListener` = chama o método `removeEventListener` pertencente a `wrapper`.
      // `pointercancel` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      wrapper.removeEventListener("pointercancel", cancelar);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    };

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `e.preventDefault` = chama o método `preventDefault` pertencente a `e`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    e.preventDefault();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `moverArrastePeca` responsável por executar a rotina correspondente dentro do jogo.
  // `moverArrastePeca` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  moverArrastePeca(e) {

    // Declara `drag` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `drag` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const drag = this.dragState;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!drag || e.pointerId !== drag.pointerId) return;

    // Declara `distancia` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `distancia` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `Math.hypot` = chama o método `hypot` pertencente a `Math`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const distancia = Math.hypot(e.clientX - drag.inicioX, e.clientY - drag.inicioY);

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `6` = valor numérico 6 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!drag.movendo && distancia >= 6) {

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `true` = valor lógico verdadeiro.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      drag.movendo = true;

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `drag.wrapper.classList.add` = chama o método `add` pertencente a `drag.wrapper.classList`.
      // `dragging` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      drag.wrapper.classList.add("dragging");

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `true` = valor lógico verdadeiro.
      // `drag.wrapper.cloneNode` = chama o método `cloneNode` pertencente a `drag.wrapper`.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      drag.ghost = drag.wrapper.cloneNode(true);

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `drag.ghost.classList.remove` = chama o método `remove` pertencente a `drag.ghost.classList`.
      // `selected` = texto literal utilizado nesta instrução.
      // `dragging` = texto literal utilizado nesta instrução.
      // `invalid` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      drag.ghost.classList.remove("selected", "dragging", "invalid");

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `drag.ghost.classList.add` = chama o método `add` pertencente a `drag.ghost.classList`.
      // `drag-ghost` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      drag.ghost.classList.add("drag-ghost");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `document.body.appendChild` = chama o método `appendChild` pertencente a `document.body`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      document.body.appendChild(drag.ghost);

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `drag-active` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el.mesa.classList.add("drag-active");

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!drag.movendo) return;

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    drag.ghost.style.left = `${e.clientX}px`;

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    drag.ghost.style.top = `${e.clientY}px`;

    // Declara `lados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lados = this.estado.ladosValidos(drag.peca);

    // Declara `lado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lado` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.pontoEstaNaMesa` = acessa o atributo ou método `pontoEstaNaMesa` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    const lado = this.pontoEstaNaMesa(e.clientX, e.clientY)

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `this` = representa a própria instância atual da classe.
      // `this.ladoPeloPonto` = acessa o atributo ou método `ladoPeloPonto` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      ? this.ladoPeloPonto(e.clientX, e.clientY, lados)

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `null` = representa ausência intencional de valor.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      : null;

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-left"].classList.toggle("hot", lado === LADO_ESQUERDO);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-right"].classList.toggle("hot", lado === LADO_DIREITO);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `e.preventDefault` = chama o método `preventDefault` pertencente a `e`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    e.preventDefault();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `finalizarArrastePeca` responsável por executar a rotina correspondente dentro do jogo.
  // `finalizarArrastePeca` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  finalizarArrastePeca(e) {

    // Declara `drag` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `drag` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const drag = this.dragState;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!drag || e.pointerId !== drag.pointerId) return;

    // Declara `estavaMovendo` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `estavaMovendo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const estavaMovendo = drag.movendo;

    // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const peca = drag.peca;

    // Declara `dentroDaMesa` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `dentroDaMesa` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.pontoEstaNaMesa` = acessa o atributo ou método `pontoEstaNaMesa` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const dentroDaMesa = this.pontoEstaNaMesa(e.clientX, e.clientY);

    // Declara `lados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lados = this.estado.ladosValidos(peca);

    // Declara `lado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `lado` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.ladoPeloPonto` = acessa o atributo ou método `ladoPeloPonto` pertencente à instância atual da classe.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lado = estavaMovendo && dentroDaMesa ? this.ladoPeloPonto(e.clientX, e.clientY, lados) : null;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.limparArraste` = acessa o atributo ou método `limparArraste` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.limparArraste();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!estavaMovendo) {

      // A seleção já foi feita no pointerdown; aqui apenas redesenhamos a mão.

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.renderMaoJogador` = acessa o atributo ou método `renderMaoJogador` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.renderMaoJogador();

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.atualizarAcoes` = acessa o atributo ou método `atualizarAcoes` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.atualizarAcoes();

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!lado) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `SOLTE PRÓXIMO A UM EXTREMO VÁLIDO` = texto literal utilizado nesta instrução.
      // `ARRASTE A PEÇA ATÉ A MESA` = texto literal utilizado nesta instrução.
      // `1100` = valor numérico 1100 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast(dentroDaMesa ? "SOLTE PRÓXIMO A UM EXTREMO VÁLIDO" : "ARRASTE A PEÇA ATÉ A MESA", 1100);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.renderMaoJogador` = acessa o atributo ou método `renderMaoJogador` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.renderMaoJogador();

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.jogarSelecionada` = acessa o atributo ou método `jogarSelecionada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.jogarSelecionada(lado);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `cancelarArrastePeca` responsável por executar a rotina correspondente dentro do jogo.
  // `cancelarArrastePeca` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  cancelarArrastePeca(e) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `!==` = compara valor e tipo para verificar diferença estrita.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.dragState || e.pointerId !== this.dragState.pointerId) return;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.limparArraste` = acessa o atributo ou método `limparArraste` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.limparArraste();

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderMaoJogador` = acessa o atributo ou método `renderMaoJogador` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderMaoJogador();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `limparArraste` responsável por executar a rotina correspondente dentro do jogo.
  // `limparArraste` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  limparArraste() {

    // Declara `drag` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `drag` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const drag = this.dragState;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!drag) return;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `drag.removerEventos` = chama o método `removerEventos` pertencente a `drag`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (drag.removerEventos) drag.removerEventos();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `drag.ghost.parentNode.removeChild` = chama o método `removeChild` pertencente a `drag.ghost.parentNode`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (drag.ghost?.parentNode) drag.ghost.parentNode.removeChild(drag.ghost);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `classList.remove` = chama o método `remove` pertencente a `classList`.
    // `dragging` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    drag.wrapper?.classList.remove("dragging");

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `drag-active` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.mesa.classList.remove("drag-active");

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.remove` = chama o método `remove` pertencente a `classList`.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-left"].classList.remove("hot");

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.remove` = chama o método `remove` pertencente a `classList`.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-right"].classList.remove("hot");

    // Armazena ou atualiza no atributo `draggedId` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.draggedId` = acessa o atributo ou método `draggedId` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.draggedId = null;

    // Armazena ou atualiza no atributo `dragState` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.dragState` = acessa o atributo ou método `dragState` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.dragState = null;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `pontoEstaNaMesa` responsável por executar a rotina correspondente dentro do jogo.
  // `pontoEstaNaMesa` = nome do método ou função executado por esta rotina.
  // `clientX` = parâmetro recebido pela rotina para fornecer o valor relacionado a `clientX`.
  // `clientY` = parâmetro recebido pela rotina para fornecer o valor relacionado a `clientY`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  pontoEstaNaMesa(clientX, clientY) {

    // Declara `r` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `r` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const r = this.el.mesa.getBoundingClientRect();

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `atualizarAcoes` responsável por executar a rotina correspondente dentro do jogo.
  // `atualizarAcoes` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  atualizarAcoes() {

    // Declara `liberado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `liberado` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const liberado = !this.bloqueado && this.estado.turno === JOGADOR && !this.estado.encerrada;

    // Declara `lados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lados = this.selecionada ? this.estado.ladosValidos(this.selecionada) : [];

    // Declara `podeJogar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `podeJogar` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const podeJogar = liberado && this.estado.possuiJogada(this.estado.maoDe(JOGADOR));

    // Declara `podeComprar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `podeComprar` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const podeComprar = liberado && this.estado.podeComprar(JOGADOR);

    // Declara `podePassar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `podePassar` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const podePassar = liberado && this.estado.podePassar(JOGADOR);

    // Verifica se a coleção contém o valor informado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `lados.includes` = chama o método `includes` pertencente a `lados`.
    // `btn-jogar-esquerda` = texto literal utilizado nesta instrução.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-jogar-esquerda"].disabled = !(liberado && lados.includes(LADO_ESQUERDO));

    // Verifica se a coleção contém o valor informado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `lados.includes` = chama o método `includes` pertencente a `lados`.
    // `btn-jogar-direita` = texto literal utilizado nesta instrução.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-jogar-direita"].disabled = !(liberado && lados.includes(LADO_DIREITO));

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `btn-comprar` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-comprar"].disabled = !podeComprar;

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `btn-passar` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-passar"].disabled = !podePassar;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
    // `btn-passar` = texto literal utilizado nesta instrução.
    // `Passar (monte vazio)` = texto literal utilizado nesta instrução.
    // `Passar a vez` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-passar"].textContent = podePassar && this.modo === MODO_MANO_A_MANO ? "Passar (monte vazio)" : "Passar a vez";

    // Declara `dica` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `dica` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let dica;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `Rodada encerrada. A próxima distribuição começa em instantes.` = texto literal utilizado nesta instrução.
    // `IA` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!liberado) dica = this.estado.encerrada ? "Rodada encerrada. A próxima distribuição começa em instantes." : `Aguarde: ${NOMES[this.estado.turno] || "IA"} está jogando.`;

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `Clique em uma peça válida ou segure e arraste-a até o extremo desejado da mesa.` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    else if (podeJogar) dica = "Clique em uma peça válida ou segure e arraste-a até o extremo desejado da mesa.";

    // Verifica uma condição alternativa quando a condição anterior não foi satisfeita.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    else if (this.estado.monte.length) dica = `Você não possui jogada válida. Compre uma peça; restam ${this.estado.monte.length} no monte.`;

    // Executa o caminho alternativo quando a condição anterior não foi satisfeita.
    // `else` = define o caminho alternativo executado quando a condição anterior não for satisfeita.
    // `Você não possui jogada válida e o monte está vazio. Passe a vez.` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    else dica = "Você não possui jogada válida e o monte está vazio. Passe a vez.";

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `dica-text` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["dica-text"].textContent = dica;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `hand-hint` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["hand-hint"].textContent = dica;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `atualizarDropTargets` responsável por executar a rotina correspondente dentro do jogo.
  // `atualizarDropTargets` = nome do método ou função executado por esta rotina.
  // `lados` = parâmetro recebido pela rotina para fornecer o valor relacionado a `lados`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  atualizarDropTargets(lados) {

    // Declara `show` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `show` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const show = !this.bloqueado && this.estado.turno === JOGADOR && !!this.selecionada;

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `lados.includes` = chama o método `includes` pertencente a `lados`.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `visible` = texto literal utilizado nesta instrução.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-left"].classList.toggle("visible", show && lados.includes(LADO_ESQUERDO));

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `lados.includes` = chama o método `includes` pertencente a `lados`.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `visible` = texto literal utilizado nesta instrução.
    // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-right"].classList.toggle("visible", show && lados.includes(LADO_DIREITO));

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `dragOverMesa` responsável por executar a rotina correspondente dentro do jogo.
  // `dragOverMesa` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  dragOverMesa(e) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.draggedId` = acessa o atributo ou método `draggedId` pertencente à instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.draggedId || !this.selecionada) return;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `e.preventDefault` = chama o método `preventDefault` pertencente a `e`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    e.preventDefault();

    // Declara `lado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lado` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.ladoPeloPonto` = acessa o atributo ou método `ladoPeloPonto` pertencente à instância atual da classe.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lado = this.ladoPeloPonto(e.clientX, e.clientY, this.estado.ladosValidos(this.selecionada));

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-left"].classList.toggle("hot", lado === LADO_ESQUERDO);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.toggle` = chama o método `toggle` pertencente a `classList`.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-right"].classList.toggle("hot", lado === LADO_DIREITO);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `dragLeaveMesa` responsável por executar a rotina correspondente dentro do jogo.
  // `dragLeaveMesa` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  dragLeaveMesa(e) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!this.el.mesa.contains(e.relatedTarget)) {

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `classList.remove` = chama o método `remove` pertencente a `classList`.
      // `drop-left` = texto literal utilizado nesta instrução.
      // `hot` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["drop-left"].classList.remove("hot");

      // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
      // `this` = representa a própria instância atual da classe.
      // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
      // `classList.remove` = chama o método `remove` pertencente a `classList`.
      // `drop-right` = texto literal utilizado nesta instrução.
      // `hot` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.el["drop-right"].classList.remove("hot");

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `dropNaMesa` responsável por executar a rotina correspondente dentro do jogo.
  // `dropNaMesa` = nome do método ou função executado por esta rotina.
  // `e` = parâmetro recebido pela rotina para fornecer o valor relacionado a `e`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  dropNaMesa(e) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.draggedId` = acessa o atributo ou método `draggedId` pertencente à instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.draggedId || !this.selecionada) return;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `e.preventDefault` = chama o método `preventDefault` pertencente a `e`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    e.preventDefault();

    // Declara `lados` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lados` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.estado` = acessa o atributo ou método `estado` pertencente à instância atual da classe.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lados = this.estado.ladosValidos(this.selecionada);

    // Declara `lado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `lado` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.ladoPeloPonto` = acessa o atributo ou método `ladoPeloPonto` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const lado = this.ladoPeloPonto(e.clientX, e.clientY, lados);

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.remove` = chama o método `remove` pertencente a `classList`.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-left"].classList.remove("hot");

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `classList.remove` = chama o método `remove` pertencente a `classList`.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `hot` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["drop-right"].classList.remove("hot");

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!lado) {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.mostrarToast` = acessa o atributo ou método `mostrarToast` pertencente à instância atual da classe.
      // `SOLTE EM UM EXTREMO VÁLIDO` = texto literal utilizado nesta instrução.
      // `1000` = valor numérico 1000 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.mostrarToast("SOLTE EM UM EXTREMO VÁLIDO", 1000);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
      // `erro` = texto literal utilizado nesta instrução.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.tocar("erro");

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.jogarSelecionada` = acessa o atributo ou método `jogarSelecionada` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.jogarSelecionada(lado);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `ladoPeloPonto` responsável por executar a rotina correspondente dentro do jogo.
  // `ladoPeloPonto` = nome do método ou função executado por esta rotina.
  // `clientX` = parâmetro recebido pela rotina para fornecer o valor relacionado a `clientX`.
  // `clientY` = parâmetro recebido pela rotina para fornecer o valor relacionado a `clientY`.
  // `lados` = parâmetro recebido pela rotina para fornecer o valor relacionado a `lados`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  ladoPeloPonto(clientX, clientY, lados) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `null` = representa ausência intencional de valor.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!lados.length) return null;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `0` = representa ausência de elementos e é usado para verificar se a coleção está vazia.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (lados.length === 1) return lados[0];

    // Declara `centro` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `centro` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    const centro = (el) => {

      // Declara `r` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `r` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `el.getBoundingClientRect` = chama o método `getBoundingClientRect` pertencente a `el`.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const r = el.getBoundingClientRect();

      // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `/` = operador que realiza divisão numérica.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    };

    // Declara `a` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `a` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `drop-left` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const a = centro(this.el["drop-left"]);

    // Declara `b` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `b` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `drop-right` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const b = centro(this.el["drop-right"]);

    // Declara `da` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `da` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `Math.hypot` = chama o método `hypot` pertencente a `Math`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const da = Math.hypot(clientX - a.x, clientY - a.y);

    // Declara `db` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `db` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `Math.hypot` = chama o método `hypot` pertencente a `Math`.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const db = Math.hypot(clientX - b.x, clientY - b.y);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return da <= db ? LADO_ESQUERDO : LADO_DIREITO;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `setStatus` responsável por executar a rotina correspondente dentro do jogo.
  // `setStatus` = nome do método ou função executado por esta rotina.
  // `texto` = parâmetro recebido pela rotina para fornecer o valor relacionado a `texto`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  setStatus(texto) {

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `status-text` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["status-text"].textContent = texto;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `adicionarLog` responsável por executar a rotina correspondente dentro do jogo.
  // `adicionarLog` = nome do método ou função executado por esta rotina.
  // `texto` = parâmetro recebido pela rotina para fornecer o valor relacionado a `texto`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  adicionarLog(texto) {

    // Adiciona o valor informado ao início da coleção utilizada nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `new` = cria uma nova instância da classe informada.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.logs.unshift({ texto, hora: new Date() });

    // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
    // `this` = representa a própria instância atual da classe.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `30` = valor numérico 30 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.logs = this.logs.slice(0, 30);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.renderLog` = acessa o atributo ou método `renderLog` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.renderLog();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `renderLog` responsável por executar a rotina correspondente dentro do jogo.
  // `renderLog` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  renderLog() {

    // Declara `area` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `area` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `game-log` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const area = this.el["game-log"];

    // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
    // `` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    area.innerHTML = "";

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!this.logs.length) {

      // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
      // `<div class="log-item">As jogadas aparecerão aqui.</div>` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      area.innerHTML = '<div class="log-item">As jogadas aparecerão aqui.</div>';

      // Encerra a execução da rotina atual e retorna imediatamente ao ponto que a chamou.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
    // `this` = representa a própria instância atual da classe.
    // `this.logs` = acessa o atributo ou método `logs` pertencente à instância atual da classe.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `8` = valor numérico 8 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    this.logs.slice(0, 8).forEach((item) => {

      // Declara `div` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `div` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `document.createElement` = chama o método `createElement` pertencente a `document`.
      // `div` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const div = document.createElement("div");

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `log-item` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      div.className = "log-item";

      // Declara `hora` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `hora` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `item.hora.toLocaleTimeString` = chama o método `toLocaleTimeString` pertencente a `item.hora`.
      // `pt-BR` = texto literal utilizado nesta instrução.
      // `2-digit` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const hora = item.hora.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

      // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      div.innerHTML = `<time>${hora}</time>${escapeHTML(item.texto)}`;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `area.appendChild` = chama o método `appendChild` pertencente a `area`.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      area.appendChild(div);

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    });

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `nomeModo` responsável por executar a rotina correspondente dentro do jogo.
  // `this` = representa a própria instância atual da classe.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `nomeModo` = nome do método ou função executado por esta rotina.
  // `this.modo` = acessa o atributo ou método `modo` pertencente à instância atual da classe.
  // `Duplas - 4 jogadores` = texto literal utilizado nesta instrução.
  // `Mano a mano` = texto literal utilizado nesta instrução.
  // `===` = compara valor e tipo para verificar igualdade estrita.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  nomeModo() { return this.modo === MODO_DUPLAS ? "Duplas - 4 jogadores" : "Mano a mano"; }

  // Define o método `voltarMenu` responsável por executar a rotina correspondente dentro do jogo.
  // `false` = valor lógico falso.
  // `voltarMenu` = nome do método ou função executado por esta rotina.
  // `forcar` = parâmetro recebido pela rotina para fornecer o valor relacionado a `forcar`.
  // `false` = valor padrão utilizado para `forcar` quando nenhum valor é fornecido.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  voltarMenu(forcar = false) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.emJogo) return;

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    if (!forcar) {

      // Declara `ok` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ok` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `window.confirm` = chama o método `confirm` pertencente a `window`.
      // `A partida atual será abandonada e não será registrada. Voltar ao menu?` = texto literal utilizado nesta instrução.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const ok = window.confirm("A partida atual será abandonada e não será registrada. Voltar ao menu?");

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor especificado.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `!` = operador que nega ou inverte um valor lógico.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (!ok) return;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.cancelarTimers` = acessa o atributo ou método `cancelarTimers` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.cancelarTimers();

    // Armazena ou atualiza no atributo `emJogo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `false` = valor lógico falso.
    // `this.emJogo` = acessa o atributo ou método `emJogo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.emJogo = false;

    // Armazena ou atualiza no atributo `bloqueado` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `true` = valor lógico verdadeiro.
    // `this.bloqueado` = acessa o atributo ou método `bloqueado` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.bloqueado = true;

    // Armazena ou atualiza no atributo `selecionada` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `null` = representa ausência intencional de valor.
    // `this.selecionada` = acessa o atributo ou método `selecionada` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.selecionada = null;

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.nome` = acessa o atributo ou método `nome` pertencente à instância atual da classe.
    // `nome-jogador` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["nome-jogador"].value = this.nome;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.mostrarTela` = acessa o atributo ou método `mostrarTela` pertencente à instância atual da classe.
    // `menu` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.mostrarTela("menu");

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `abrirRegras` responsável por executar a rotina correspondente dentro do jogo.
  // `abrirRegras` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  abrirRegras() {

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.abrirModal` = acessa o atributo ou método `abrirModal` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    this.abrirModal(`
      <span class="section-kicker">COMO JOGAR</span>
      <h2 class="modal-title">Regras do Dominó Pro</h2>
      <p class="modal-subtitle">A versão web mantém as regras e os dois modos do projeto original.</p>
      <div class="rules-grid">
        <div class="rule-box"><strong>Conjunto</strong><p>São usadas as 28 peças do dominó tradicional duplo-seis, de 0|0 até 6|6.</p></div>
        <div class="rule-box"><strong>Abertura</strong><p>A maior dupla disponível inicia a rodada. Se ninguém tiver dupla, abre a peça de maior soma.</p></div>
        <div class="rule-box"><strong>Mano a Mano</strong><p>Você e a IA recebem 7 peças. As outras 14 formam o monte. Sem jogada, compre até encontrar uma combinação ou esgotar o monte.</p></div>
        <div class="rule-box"><strong>Duplas</strong><p>Você joga com uma IA parceira contra duas IAs adversárias. As 28 peças são distribuídas: 7 para cada participante e sem monte.</p></div>
        <div class="rule-box"><strong>Jogada</strong><p>Uma peça precisa combinar com o valor aberto da esquerda ou da direita. Clique para selecionar ou segure e arraste a peça até uma das extremidades destacadas da mesa.</p></div>
        <div class="rule-box"><strong>Passe</strong><p>O passe só é permitido quando não existe jogada válida e não há peças disponíveis no monte.</p></div>
        <div class="rule-box"><strong>Rodada bloqueada</strong><p>Quando todos passam consecutivamente, vence quem tiver menos pontos restantes na mão; em duplas, compara-se a soma da equipe.</p></div>
        <div class="rule-box"><strong>Pontuação</strong><p>Os pontos restantes dos adversários são convertidos em pontos da rodada. A partida continua até uma equipe atingir 100 pontos.</p></div>
      </div>
    `);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `abrirEstatisticas` responsável por executar a rotina correspondente dentro do jogo.
  // `abrirEstatisticas` = nome do método ou função executado por esta rotina.
  // `nome` = parâmetro recebido pela rotina para fornecer o valor relacionado a `nome`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  abrirEstatisticas(nome) {

    // Declara `partidas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `partidas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.storage` = acessa o atributo ou método `storage` pertencente à instância atual da classe.
    // `b.dataHora.localeCompare` = chama o método `localeCompare` pertencente a `b.dataHora`.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const partidas = this.storage.partidasDoJogador(nome).sort((a, b) => b.dataHora.localeCompare(a.dataHora));

    // Filtra a coleção e cria uma nova coleção apenas com os elementos que atendem à condição.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `vitorias` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `partidas.filter` = chama o método `filter` pertencente a `partidas`.
    // `jogador` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const vitorias = partidas.filter((p) => p.vencedor === "jogador").length;

    // Filtra a coleção e cria uma nova coleção apenas com os elementos que atendem à condição.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `derrotas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `partidas.filter` = chama o método `filter` pertencente a `partidas`.
    // `ia` = texto literal utilizado nesta instrução.
    // `===` = compara valor e tipo para verificar igualdade estrita.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const derrotas = partidas.filter((p) => p.vencedor === "ia").length;

    // Declara `pontos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `pontos` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `partidas.reduce` = chama o método `reduce` pertencente a `partidas`.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const pontos = partidas.reduce((s, p) => s + p.pontosJogador, 0);

    // Declara `ranking` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância atual da classe.
    // `ranking` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `this.storage` = acessa o atributo ou método `storage` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const ranking = this.storage.ranking();

    // Declara `historicoHTML` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `historicoHTML` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    const historicoHTML = partidas.length

      // Obtém uma parte da coleção entre os limites informados sem alterar a coleção original.
      // `partidas.slice` = chama o método `slice` pertencente a `partidas`.
      // `stats-table` = texto literal utilizado nesta instrução.
      ? `<table class="stats-table"><thead><tr><th>DATA</th><th>MODO</th><th>RESULTADO</th><th>PLACAR</th></tr></thead><tbody>${partidas.slice(0, 10).map((p) => {
          const data = new Date(p.dataHora).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
          const win = p.vencedor === "jogador";
          return `<tr><td>${data}</td><td>${escapeHTML(p.modo)}</td><td class="${win ? "win" : "loss"}">${win ? "Vitória" : "Derrota"}</td><td>${p.pontosJogador} × ${p.pontosIA}</td></tr>`;
        }).join("")}</tbody></table>`

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      : '<div class="empty-state">Ainda não existem partidas registradas para este nome neste navegador.</div>';

    // Declara `rankingHTML` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `rankingHTML` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    const rankingHTML = ranking.length

      // Percorre a coleção e cria uma nova coleção com os valores transformados pela função indicada.
      // `ranking.map` = chama o método `map` pertencente a `ranking`.
      // `stats-table` = texto literal utilizado nesta instrução.
      // `` = texto literal utilizado nesta instrução.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `/` = operador que realiza divisão numérica.
      // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
      // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      ? `<table class="stats-table"><thead><tr><th>#</th><th>JOGADOR</th><th>PARTIDAS</th><th>VITÓRIAS</th><th>PONTOS</th></tr></thead><tbody>${ranking.map((r, i) => `<tr><td>${i + 1}</td><td>${escapeHTML(r.nome)}</td><td>${r.partidas}</td><td>${r.vitorias}</td><td>${r.pontos}</td></tr>`).join("")}</tbody></table>`

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      : '<div class="empty-state">O ranking será formado conforme as partidas forem concluídas.</div>';

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.abrirModal` = acessa o atributo ou método `abrirModal` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    this.abrirModal(`
      <span class="section-kicker">DESEMPENHO LOCAL</span>
      <h2 class="modal-title">Estatísticas de ${escapeHTML(nome)}</h2>
      <p class="modal-subtitle">Os dados ficam salvos somente neste navegador.</p>
      <div class="stats-summary">
        <div><b>${partidas.length}</b><span>partidas</span></div>
        <div><b>${vitorias}</b><span>vitórias</span></div>
        <div><b>${derrotas}</b><span>derrotas</span></div>
        <div><b>${pontos}</b><span>pontos acumulados</span></div>
      </div>
      <span class="section-kicker">ÚLTIMAS PARTIDAS</span>
      ${historicoHTML}
      <div style="height:18px"></div>
      <span class="section-kicker">RANKING GERAL</span>
      ${rankingHTML}
    `);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `abrirModal` responsável por executar a rotina correspondente dentro do jogo.
  // `abrirModal` = nome do método ou função executado por esta rotina.
  // `html` = parâmetro recebido pela rotina para fornecer o valor relacionado a `html`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  abrirModal(html) {

    // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `modal-content` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["modal-content"].innerHTML = html;

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `hidden` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.modal.classList.remove("hidden");

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `fecharModal` responsável por executar a rotina correspondente dentro do jogo.
  // `this` = representa a própria instância atual da classe.
  // `fecharModal` = nome do método ou função executado por esta rotina.
  // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
  // `hidden` = texto literal utilizado nesta instrução.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  fecharModal() { this.el.modal.classList.add("hidden"); }

  // Define o método `mostrarToast` responsável por executar a rotina correspondente dentro do jogo.
  // `mostrarToast` = nome do método ou função executado por esta rotina.
  // `texto` = parâmetro recebido pela rotina para fornecer o valor relacionado a `texto`.
  // `duracao` = parâmetro recebido pela rotina para fornecer o valor relacionado a `duracao`.
  // `1000` = valor padrão utilizado para `duracao` quando nenhum valor é fornecido.
  // `1000` = valor numérico 1000 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  mostrarToast(texto, duracao = 1000) {

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `clearTimeout` = nome do método ou função executado por esta rotina.
    // `this.toastTimer` = acessa o atributo ou método `toastTimer` pertencente à instância atual da classe.
    // `clearTimeout` = cancela um temporizador anteriormente criado.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    clearTimeout(this.toastTimer);

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.toast.textContent = texto;

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `show` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el.toast.classList.add("show");

    // Altera as classes CSS do elemento indicado para atualizar seu estado visual na interface.
    // `this` = representa a própria instância atual da classe.
    // `this.toastTimer` = acessa o atributo ou método `toastTimer` pertencente à instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `setTimeout` = agenda a execução de uma função após o intervalo informado.
    // `show` = texto literal utilizado nesta instrução.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.toastTimer = setTimeout(() => this.el.toast.classList.remove("show"), duracao);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `tocar` responsável por executar a rotina correspondente dentro do jogo.
  // `tocar` = nome do método ou função executado por esta rotina.
  // `nome` = parâmetro recebido pela rotina para fornecer o valor relacionado a `nome`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  tocar(nome) {

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
    // `!` = operador que nega ou inverte um valor lógico.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (!this.somAtivo || !AUDIO[nome]) return;

    // Inicia um bloco protegido para executar uma operação que pode gerar erro.
    // `try` = inicia um bloco protegido para tratamento de possíveis erros.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    try {

      // Declara `audio` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
      // `this` = representa a própria instância atual da classe.
      // `get` = define um acessor de leitura que se comporta como propriedade.
      // `audio` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `this.audioCache` = acessa o atributo ou método `audioCache` pertencente à instância atual da classe.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      let audio = this.audioCache.get(nome);

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `!` = operador que nega ou inverte um valor lógico.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      if (!audio) {

        // Cria um objeto de áudio associado ao arquivo sonoro informado para utilização durante o jogo.
        // `new` = cria uma nova instância da classe informada.
        // `Audio` = classe nativa utilizada para criar e controlar um áudio.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
        // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        audio = new Audio(AUDIO[nome]);

        // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
        // `auto` = texto literal utilizado nesta instrução.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        audio.preload = "auto";

        // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
        // `this` = representa a própria instância atual da classe.
        // `this.audioCache` = acessa o atributo ou método `audioCache` pertencente à instância atual da classe.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        this.audioCache.set(nome, audio);

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      audio.currentTime = 0;

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `catch` = captura um erro ocorrido no bloco try.
      // `audio.play` = chama o método `play` pertencente a `audio`.
      // `=>` = define uma função de seta.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      audio.play().catch(() => {});

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `catch` = captura um erro ocorrido no bloco try.
    // `*` = operador que realiza multiplicação numérica.
    // `/` = operador que realiza divisão numérica.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    } catch { /* o jogo continua normalmente mesmo quando o navegador bloqueia áudio */ }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `alternarSom` responsável por executar a rotina correspondente dentro do jogo.
  // `alternarSom` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  alternarSom() {

    // Armazena ou atualiza no atributo `somAtivo` da instância atual o valor definido nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `!` = operador que nega ou inverte um valor lógico.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.somAtivo = !this.somAtivo;

    // Salva os dados informados no armazenamento local do navegador.
    // `this` = representa a própria instância atual da classe.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `localStorage.setItem` = salva um valor associado a uma chave no armazenamento local do navegador.
    // `1` = texto literal utilizado nesta instrução.
    // `0` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    localStorage.setItem(SOM_KEY, this.somAtivo ? "1" : "0");

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.atualizarBotoesSom` = acessa o atributo ou método `atualizarBotoesSom` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.atualizarBotoesSom();

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `this` = representa a própria instância atual da classe.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `this.tocar` = acessa o atributo ou método `tocar` pertencente à instância atual da classe.
    // `menu` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (this.somAtivo) this.tocar("menu");

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `atualizarBotoesSom` responsável por executar a rotina correspondente dentro do jogo.
  // `atualizarBotoesSom` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  atualizarBotoesSom() {

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `btn-som-menu` = texto literal utilizado nesta instrução.
    // `ligado` = texto literal utilizado nesta instrução.
    // `desligado` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-som-menu"].textContent = `Som: ${this.somAtivo ? "ligado" : "desligado"}`;

    // Atualiza ou consulta o conteúdo textual do elemento HTML indicado.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `btn-som-jogo` = texto literal utilizado nesta instrução.
    // `🔊` = texto literal utilizado nesta instrução.
    // `🔇` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-som-jogo"].textContent = this.somAtivo ? "🔊" : "🔇";

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `this` = representa a própria instância atual da classe.
    // `this.el` = acessa o atributo ou método `el` pertencente à instância atual da classe.
    // `this.somAtivo` = acessa o atributo ou método `somAtivo` pertencente à instância atual da classe.
    // `btn-som-jogo` = texto literal utilizado nesta instrução.
    // `Som ligado (F8)` = texto literal utilizado nesta instrução.
    // `Som desligado (F8)` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.el["btn-som-jogo"].title = this.somAtivo ? "Som ligado (F8)" : "Som desligado (F8)";

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `agendar` responsável por executar a rotina correspondente dentro do jogo.
  // `agendar` = nome do método ou função executado por esta rotina.
  // `ms` = parâmetro recebido pela rotina para fornecer o valor relacionado a `ms`.
  // `funcao` = parâmetro recebido pela rotina para fornecer o valor relacionado a `funcao`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  agendar(ms, funcao) {

    // Declara `id` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `id` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `setTimeout` = agenda a execução de uma função após o intervalo informado.
    // `=>` = define uma função de seta.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    const id = setTimeout(() => {

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `this` = representa a própria instância atual da classe.
      // `this.timerIds` = acessa o atributo ou método `timerIds` pertencente à instância atual da classe.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      this.timerIds.delete(id);

      // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
      // `funcao` = nome do método ou função executado por esta rotina.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      funcao();

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    }, ms);

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.timerIds` = acessa o atributo ou método `timerIds` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.timerIds.add(id);

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return id;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Define o método `cancelarTimers` responsável por executar a rotina correspondente dentro do jogo.
  // `cancelarTimers` = nome do método ou função executado por esta rotina.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  cancelarTimers() {

    // Percorre todos os elementos da coleção e executa a função indicada para cada um deles.
    // `this` = representa a própria instância atual da classe.
    // `this.timerIds` = acessa o atributo ou método `timerIds` pertencente à instância atual da classe.
    // `clearTimeout` = cancela um temporizador anteriormente criado.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.timerIds.forEach((id) => clearTimeout(id));

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `this` = representa a própria instância atual da classe.
    // `this.timerIds` = acessa o atributo ou método `timerIds` pertencente à instância atual da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    this.timerIds.clear();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `renderVersos` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `renderVersos` = nome atribuído à função definida nesta linha.
// `container` = parâmetro recebido pela função para fornecer o valor relacionado a `container`.
// `quantidade` = parâmetro recebido pela função para fornecer o valor relacionado a `quantidade`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
function renderVersos(container, quantidade) {

  // Atualiza ou consulta o conteúdo HTML interno do elemento indicado.
  // `` = texto literal utilizado nesta instrução.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  container.innerHTML = "";

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
  // `for` = inicia uma estrutura de repetição.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `<` = operador que verifica se o valor da esquerda é menor que o da direita.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  for (let i = 0; i < quantidade; i += 1) {

    // Declara `verso` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `verso` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `document.createElement` = chama o método `createElement` pertencente a `document`.
    // `span` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const verso = document.createElement("span");

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `tile-back` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    verso.className = "tile-back";

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `container.appendChild` = chama o método `appendChild` pertencente a `container`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    container.appendChild(verso);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `criarElementoPeca` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `criarElementoPeca` = nome atribuído à função definida nesta linha.
// `a` = parâmetro recebido pela função para fornecer o valor relacionado a `a`.
// `b` = parâmetro recebido pela função para fornecer o valor relacionado a `b`.
// `orientacao = "vertical"` = parâmetro recebido pela função para fornecer o valor relacionado a `orientacao = "vertical"`.
// `vertical` = texto literal utilizado nesta instrução.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
function criarElementoPeca(a, b, orientacao = "vertical") {

  // Declara `tile` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `tile` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `document.createElement` = chama o método `createElement` pertencente a `document`.
  // `div` = texto literal utilizado nesta instrução.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const tile = document.createElement("div");

  // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  tile.className = `domino-tile ${orientacao}`;

  // Declara `halfA` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `halfA` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `document.createElement` = chama o método `createElement` pertencente a `document`.
  // `div` = texto literal utilizado nesta instrução.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const halfA = document.createElement("div");

  // Declara `halfB` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `halfB` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `document.createElement` = chama o método `createElement` pertencente a `document`.
  // `div` = texto literal utilizado nesta instrução.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const halfB = document.createElement("div");

  // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
  // `domino-half half-a` = texto literal utilizado nesta instrução.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  halfA.className = "domino-half half-a";

  // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
  // `domino-half half-b` = texto literal utilizado nesta instrução.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  halfB.className = "domino-half half-b";

  // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
  // `desenharPontos` = nome do método ou função executado por esta rotina.
  // `halfA` = parâmetro recebido pela rotina para fornecer o valor relacionado a `halfA`.
  // `a` = parâmetro recebido pela rotina para fornecer o valor relacionado a `a`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  desenharPontos(halfA, a);

  // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
  // `desenharPontos` = nome do método ou função executado por esta rotina.
  // `halfB` = parâmetro recebido pela rotina para fornecer o valor relacionado a `halfB`.
  // `b` = parâmetro recebido pela rotina para fornecer o valor relacionado a `b`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  desenharPontos(halfB, b);

  // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
  // `tile.append` = chama o método `append` pertencente a `tile`.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  tile.append(halfA, halfB);

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return tile;

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `desenharPontos` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `desenharPontos` = nome atribuído à função definida nesta linha.
// `half` = parâmetro recebido pela função para fornecer o valor relacionado a `half`.
// `valor` = parâmetro recebido pela função para fornecer o valor relacionado a `valor`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
function desenharPontos(half, valor) {

  // Declara `posicoes` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `posicoes` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  const posicoes = {

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    0: [],

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    1: [[50, 50]],

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `28` = valor numérico 28 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `72` = valor numérico 72 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    2: [[28, 28], [72, 72]],

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `3` = valor numérico 3 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `28` = valor numérico 28 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `72` = valor numérico 72 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    3: [[28, 28], [50, 50], [72, 72]],

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `4` = valor numérico 4 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `28` = valor numérico 28 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `72` = valor numérico 72 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    4: [[28, 28], [72, 28], [28, 72], [72, 72]],

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `5` = valor numérico 5 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `28` = valor numérico 28 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `72` = valor numérico 72 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    5: [[28, 28], [72, 28], [50, 50], [28, 72], [72, 72]],

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `6` = valor numérico 6 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `28` = valor numérico 28 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `23` = valor numérico 23 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `72` = valor numérico 72 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `77` = valor numérico 77 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    6: [[28, 23], [72, 23], [28, 50], [72, 50], [28, 77], [72, 77]],

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  };

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `for` = inicia uma estrutura de repetição.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  for (const [x, y] of posicoes[valor]) {

    // Declara `pip` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `pip` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `document.createElement` = chama o método `createElement` pertencente a `document`.
    // `span` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const pip = document.createElement("span");

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `pip` = texto literal utilizado nesta instrução.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    pip.className = "pip";

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    pip.style.left = `${x}%`;

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    pip.style.top = `${y}%`;

    // Executa a função ou método indicado utilizando os argumentos definidos nesta linha.
    // `half.appendChild` = chama o método `appendChild` pertencente a `half`.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    half.appendChild(pip);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `calcularLayoutMesa` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `calcularLayoutMesa` = nome atribuído à função definida nesta linha.
// `quantidade` = parâmetro recebido pela função para fornecer o valor relacionado a `quantidade`.
// `largura` = parâmetro recebido pela função para fornecer o valor relacionado a `largura`.
// `altura` = parâmetro recebido pela função para fornecer o valor relacionado a `altura`.
// `indiceCentro = 0` = parâmetro recebido pela função para fornecer o valor relacionado a `indiceCentro = 0`.
// `0` = valor numérico utilizado como índice, posição ou limite nesta operação.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
function calcularLayoutMesa(quantidade, largura, altura, indiceCentro = 0) {

  // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
  // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
  // `!` = operador que nega ou inverte um valor lógico.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  if (!quantidade) {

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    return {

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
      // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      posicoes: [],

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `false` = valor lógico falso.
      // `44` = valor numérico 44 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      proximoEsquerda: { x: 44, y: 50, vertical: false, invertido: false },

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `false` = valor lógico falso.
      // `56` = valor numérico 56 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      proximoDireita: { x: 56, y: 50, vertical: false, invertido: false },

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    };

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Declara `w` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `w` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `Math.max` = retorna o maior entre os valores informados.
  // `320` = valor numérico 320 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `700` = valor numérico 700 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const w = Math.max(320, largura || 700);

  // Declara `h` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `h` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `Math.max` = retorna o maior entre os valores informados.
  // `180` = valor numérico 180 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `360` = valor numérico 360 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `||` = operador lógico OU que aceita quando pelo menos uma condição é verdadeira.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const h = Math.max(180, altura || 360);

  // Declara `centro` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `centro` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `0` = valor numérico utilizado como índice, posição ou limite nesta operação.
  // `1` = valor numérico utilizado como índice, posição ou limite nesta operação.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const centro = clamp(indiceCentro, 0, quantidade - 1);

  // Declara `qtdEsquerda` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `qtdEsquerda` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const qtdEsquerda = centro;

  // Declara `qtdDireita` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `qtdDireita` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const qtdDireita = quantidade - centro - 1;

  // Declara `comprimentoPeca` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `comprimentoPeca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `62` = valor numérico 62 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const comprimentoPeca = 62;

  // Declara `larguraPeca` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `larguraPeca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `32` = valor numérico 32 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const larguraPeca = 32;

  // Declara `espacoEntrePecas` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `espacoEntrePecas` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `4` = valor numérico 4 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const espacoEntrePecas = 4;

  // Declara `passoX` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `passoX` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const passoX = comprimentoPeca + espacoEntrePecas;

  // Declara `margemHorizontal` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `margemHorizontal` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `24` = valor numérico 24 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const margemHorizontal = 24;

  // Declara `meiaLarguraPeca` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `meiaLarguraPeca` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `/` = operador que realiza divisão numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const meiaLarguraPeca = larguraPeca / 2;

  // Declara `deslocamentoCurva` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `deslocamentoCurva` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // `/` = operador que realiza divisão numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const deslocamentoCurva = comprimentoPeca / 2 + meiaLarguraPeca + espacoEntrePecas;

  // Declara `limiteCurvaEsquerda` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `limiteCurvaEsquerda` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const limiteCurvaEsquerda = margemHorizontal + meiaLarguraPeca;

  // Declara `limiteCurvaDireita` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `limiteCurvaDireita` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const limiteCurvaDireita = w - margemHorizontal - meiaLarguraPeca;

  // Declara `limiteHorizontalEsquerda` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `limiteHorizontalEsquerda` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const limiteHorizontalEsquerda = limiteCurvaEsquerda + deslocamentoCurva;

  // Declara `limiteHorizontalDireita` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `limiteHorizontalDireita` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const limiteHorizontalDireita = limiteCurvaDireita - deslocamentoCurva;

  // Declara `centroX` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `centroX` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `/` = operador que realiza divisão numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const centroX = w / 2;

  // Declara `construirRamo` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `construirRamo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=>` = define uma função de seta.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  const construirRamo = (quantidadeRamo, sinalX) => {

    // Declara `pontos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `pontos` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    const pontos = [];

    // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    if (quantidadeRamo <= 0) return pontos;

    // Declara `restantes` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `restantes` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let restantes = quantidadeRamo;

    // Declara `linha` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `linha` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let linha = 0;

    // Declara `direcao` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `direcao` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let direcao = sinalX;

    // Declara `x` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
    // `x` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `*` = operador que realiza multiplicação numérica.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    let x = centroX + direcao * passoX;

    // Repete o bloco enquanto a condição informada permanecer verdadeira.
    // `while` = inicia uma repetição que continua enquanto a condição permanecer verdadeira.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    while (restantes > 0) {

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      x = clamp(x, limiteHorizontalEsquerda, limiteHorizontalDireita);

      // Adiciona o valor informado ao final da coleção utilizada nesta linha.
      // `false` = valor lógico falso.
      // `pontos.push` = chama o método `push` pertencente a `pontos`.
      // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `===` = compara valor e tipo para verificar igualdade estrita.
      // `%` = operador que obtém o resto da divisão inteira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      pontos.push({ xPx: x, nivel: linha, vertical: false, invertido: linha % 2 === 1 });

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `-=` = subtrai o valor da direita do valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      restantes -= 1;

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `break` = encerra imediatamente a estrutura de repetição atual.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (restantes <= 0) break;

      // Declara `proximoX` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `proximoX` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `*` = operador que realiza multiplicação numérica.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const proximoX = x + direcao * passoX;

      // Declara `cabeNaMesmaLinha` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `cabeNaMesmaLinha` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      const cabeNaMesmaLinha = proximoX >= limiteHorizontalEsquerda && proximoX <= limiteHorizontalDireita;

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      if (cabeNaMesmaLinha) {

        // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
        // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        x = proximoX;

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `continue` = interrompe a iteração atual e segue para a próxima repetição.
        // O ponto e vírgula = encerra a instrução JavaScript atual.
        continue;

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      }

      // Declara `curvaX` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `curvaX` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      const curvaX = clamp(

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
        // `*` = operador que realiza multiplicação numérica.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
        x + direcao * deslocamentoCurva,

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
        limiteCurvaEsquerda,

        // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
        limiteCurvaDireita

      // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      );

      // Adiciona o valor informado ao final da coleção utilizada nesta linha.
      // `true` = valor lógico verdadeiro.
      // `false` = valor lógico falso.
      // `pontos.push` = chama o método `push` pertencente a `pontos`.
      // `0.5` = valor numérico 0.5 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
      // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
      // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      pontos.push({ xPx: curvaX, nivel: linha + 0.5, vertical: true, invertido: false });

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `-=` = subtrai o valor da direita do valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      restantes -= 1;

      // Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
      // `if` = inicia uma condição executada quando a expressão informada for verdadeira.
      // `break` = encerra imediatamente a estrutura de repetição atual.
      // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      if (restantes <= 0) break;

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
      // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      linha += 1;

      // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
      // `-1` = valor numérico -1 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
      // `*=` = multiplica o valor existente pelo valor da direita e armazena o resultado.
      // `-` = operador que realiza subtração numérica.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      direcao *= -1;

      // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
      // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
      // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
      // `*` = operador que realiza multiplicação numérica.
      // O ponto e vírgula = encerra a instrução JavaScript atual.
      x = curvaX + direcao * deslocamentoCurva;

    // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    }

    // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    return pontos;

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  };

  // Declara `ramoEsquerdo` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `ramoEsquerdo` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `-1` = valor numérico -1 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // `-` = operador que realiza subtração numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const ramoEsquerdo = construirRamo(qtdEsquerda + 1, -1);

  // Declara `ramoDireito` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `ramoDireito` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const ramoDireito = construirRamo(qtdDireita + 1, 1);

  // Declara `maiorNivel` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `maiorNivel` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `Math.max` = retorna o maior entre os valores informados.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  const maiorNivel = Math.max(

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    0,

    // Percorre a coleção e cria uma nova coleção com os valores transformados pela função indicada.
    // `ramoEsquerdo.map` = chama o método `map` pertencente a `ramoEsquerdo`.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    ...ramoEsquerdo.map((ponto) => ponto.nivel),

    // Percorre a coleção e cria uma nova coleção com os valores transformados pela função indicada.
    // `ramoDireito.map` = chama o método `map` pertencente a `ramoDireito`.
    // `=>` = define uma função de seta.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    ...ramoDireito.map((ponto) => ponto.nivel)

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  );

  // Declara `margemVertical` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `margemVertical` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `8` = valor numérico 8 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const margemVertical = 8;

  // Declara `meiaAlturaCurva` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `meiaAlturaCurva` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `/` = operador que realiza divisão numérica.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const meiaAlturaCurva = comprimentoPeca / 2;

  // Declara `espacoVerticalDisponivel` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `espacoVerticalDisponivel` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `Math.max` = retorna o maior entre os valores informados.
  // `36` = valor numérico 36 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `2` = valor numérico 2 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // `/` = operador que realiza divisão numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const espacoVerticalDisponivel = Math.max(36, h / 2 - meiaAlturaCurva - margemVertical);

  // Declara `passoYIdeal` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `passoYIdeal` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `82` = valor numérico 82 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const passoYIdeal = 82;

  // Declara `passoY` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `passoY` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `0` = valor numérico zero, utilizado como valor inicial, limite inferior, índice inicial ou indicação de ausência, conforme a operação desta linha.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `>` = operador que verifica se o valor da esquerda é maior que o da direita.
  const passoY = maiorNivel > 0

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `Math.max` = retorna o maior entre os valores informados.
    // `Math.min` = retorna o menor entre os valores informados.
    // `36` = valor numérico 36 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `/` = operador que realiza divisão numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    ? Math.max(36, Math.min(passoYIdeal, espacoVerticalDisponivel / maiorNivel))

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    : passoYIdeal;

  // Declara `converterPonto` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `converterPonto` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=>` = define uma função de seta.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  const converterPonto = (ponto, sinalY) => ({

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `100` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
    // `2` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
    // `98` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
    // `*` = operador que realiza multiplicação numérica.
    // `/` = operador que realiza divisão numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    x: clamp((ponto.xPx / w) * 100, 2, 98),

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `2` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
    // `100` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
    // `98` = valor numérico utilizado como meta de pontos necessária para vencer a partida.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `*` = operador que realiza multiplicação numérica.
    // `/` = operador que realiza divisão numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    y: clamp(((h / 2 + sinalY * ponto.nivel * passoY) / h) * 100, 2, 98),

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    vertical: ponto.vertical,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `false` = valor lógico falso.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    invertido: ponto.vertical ? false : ponto.invertido,

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  });

  // Declara `posicoes` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `new` = cria uma nova instância da classe informada.
  // `posicoes` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const posicoes = new Array(quantidade);

  // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
  // `false` = valor lógico falso.
  // `50` = valor numérico 50 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  posicoes[centro] = { x: 50, y: 50, vertical: false, invertido: false };

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
  // `for` = inicia uma estrutura de repetição.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
  // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  for (let passo = 1; passo <= qtdEsquerda; passo += 1) {

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `-1` = valor numérico -1 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    posicoes[centro - passo] = converterPonto(ramoEsquerdo[passo - 1], -1);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Percorre os elementos ou repetições definidos nesta estrutura e executa o bloco para cada ocorrência.
  // `let` = declara uma variável com escopo de bloco cujo valor pode ser alterado.
  // `for` = inicia uma estrutura de repetição.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
  // `+=` = soma o valor da direita ao valor existente e armazena o resultado.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  for (let passo = 1; passo <= qtdDireita; passo += 1) {

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `+` = operador que realiza soma numérica ou concatenação de textos, conforme os valores envolvidos.
    // `-` = operador que realiza subtração numérica.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
    // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    posicoes[centro + passo] = converterPonto(ramoDireito[passo - 1], 1);

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  }

  // Declara `proximoEsquerda` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `proximoEsquerda` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `-1` = valor numérico -1 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `-` = operador que realiza subtração numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const proximoEsquerda = converterPonto(ramoEsquerdo[qtdEsquerda], -1);

  // Declara `proximoDireita` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `proximoDireita` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `1` = valor numérico um, utilizado para representar uma unidade, incremento ou primeira ocorrência, conforme a operação desta linha.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre um array, acesso por índice ou expressão de chave calculada, conforme o contexto.
  // `]` = fecha o array, acesso por índice ou expressão de chave calculada correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const proximoDireita = converterPonto(ramoDireito[qtdDireita], 1);

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  return {

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    posicoes,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    proximoEsquerda,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    proximoDireita,

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  };

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `calcularPosicoesSerpentina` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `calcularPosicoesSerpentina` = nome atribuído à função definida nesta linha.
// `quantidade` = parâmetro recebido pela função para fornecer o valor relacionado a `quantidade`.
// `largura` = parâmetro recebido pela função para fornecer o valor relacionado a `largura`.
// `altura` = parâmetro recebido pela função para fornecer o valor relacionado a `altura`.
// `indiceCentro = 0` = parâmetro recebido pela função para fornecer o valor relacionado a `indiceCentro = 0`.
// `0` = valor numérico utilizado como índice, posição ou limite nesta operação.
// `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
function calcularPosicoesSerpentina(quantidade, largura, altura, indiceCentro = 0) {

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return calcularLayoutMesa(quantidade, largura, altura, indiceCentro).posicoes;

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `clamp` responsável por executar a rotina correspondente nesta parte do jogo.
// `return` = encerra a rotina atual e devolve o valor especificado.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `clamp` = nome atribuído à função definida nesta linha.
// `valor` = parâmetro recebido pela função para fornecer o valor relacionado a `valor`.
// `min` = parâmetro recebido pela função para fornecer o valor relacionado a `min`.
// `max` = parâmetro recebido pela função para fornecer o valor relacionado a `max`.
// `Math.max` = retorna o maior entre os valores informados.
// `Math.min` = retorna o menor entre os valores informados.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
// O ponto e vírgula = encerra a instrução JavaScript atual.
function clamp(valor, min, max) { return Math.max(min, Math.min(max, valor)); }

// Define a função `escapeHTML` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `escapeHTML` = nome atribuído à função definida nesta linha.
// `texto` = parâmetro recebido pela função para fornecer o valor relacionado a `texto`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
function escapeHTML(texto) {

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a função atual e devolve o texto convertido e protegido para uso seguro no HTML.
  // `String` = converte o valor recebido para texto antes de realizar as substituições.
  // `texto` = parâmetro que contém o conteúdo que será convertido e tratado.
  // `.replace` = percorre as ocorrências encontradas pela expressão regular e substitui cada caractere pelo equivalente seguro.
  // `/[&<>'"]/g` = expressão regular que localiza globalmente os caracteres especiais &, <, >, apóstrofo e aspas duplas.
  // `g` = modificador da expressão regular que faz a busca continuar por todas as ocorrências do texto.
  // `c` = parâmetro da função de seta que recebe cada caractere especial encontrado.
  // `=>` = define a função de seta executada para escolher a substituição correspondente.
  // `&amp;` = entidade HTML utilizada para representar o caractere & com segurança.
  // `&lt;` = entidade HTML utilizada para representar o caractere < com segurança.
  // `&gt;` = entidade HTML utilizada para representar o caractere > com segurança.
  // `&#39;` = entidade HTML utilizada para representar o apóstrofo com segurança.
  // `&quot;` = entidade HTML utilizada para representar aspas duplas com segurança.
  // `[c]` = acessa no objeto de substituições o valor associado ao caractere armazenado em `c`.
  // `(` = abre a lista de argumentos ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos ou agrupamento correspondente.
  // `{` = abre o objeto que associa cada caractere especial à entidade HTML equivalente.
  // `}` = fecha o objeto de substituições.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return String(texto).replace(/[&<>'"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[c]));

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Define a função `formatarDuracao` responsável por executar a rotina correspondente nesta parte do jogo.
// `function` = palavra-chave utilizada para definir uma função nomeada.
// `formatarDuracao` = nome atribuído à função definida nesta linha.
// `segundos` = parâmetro recebido pela função para fornecer o valor relacionado a `segundos`.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
function formatarDuracao(segundos) {

  // Declara `m` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `m` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `Math.floor` = arredonda o valor numérico para baixo até o inteiro mais próximo.
  // `60` = valor numérico 60 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `/` = operador que realiza divisão numérica.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const m = Math.floor(segundos / 60);

  // Declara `s` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `s` = identificador utilizado para armazenar ou acessar o valor relacionado a esta parte da lógica do jogo.
  // `60` = valor numérico 60 utilizado nesta instrução para definir, comparar ou calcular o comportamento correspondente.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `%` = operador que obtém o resto da divisão inteira.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  const s = segundos % 60;

  // Retorna o valor ou resultado desta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado.
  // `String` = converte o valor informado para texto.
  // `0` = texto literal utilizado nesta instrução.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  return `${m}:${String(s).padStart(2, "0")}`;

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
// `if` = inicia uma condição executada quando a expressão informada for verdadeira.
// `typeof` = retorna uma descrição textual do tipo do valor analisado.
// `undefined` = texto literal utilizado nesta instrução.
// `!==` = compara valor e tipo para verificar diferença estrita.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
if (typeof window !== "undefined") {

  // Registra um evento no elemento indicado para executar a função definida quando a interação correspondente acontecer.
  // `window.addEventListener` = chama o método `addEventListener` pertencente a `window`.
  // `DOMContentLoaded` = texto literal utilizado nesta instrução.
  // `=>` = define uma função de seta.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
  window.addEventListener("DOMContentLoaded", () => {

    // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
    // `new` = cria uma nova instância da classe informada.
    // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // O ponto e vírgula = encerra a instrução JavaScript atual.
    window.dominoApp = new DominoApp();

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  });

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}

// Exportações opcionais para testes automatizados executados com Node.js.

// Verifica a condição informada e executa a instrução ou bloco correspondente somente quando ela for verdadeira.
// `if` = inicia uma condição executada quando a expressão informada for verdadeira.
// `typeof` = retorna uma descrição textual do tipo do valor analisado.
// `undefined` = texto literal utilizado nesta instrução.
// `!==` = compara valor e tipo para verificar diferença estrita.
// `&&` = operador lógico E que exige que as condições relacionadas sejam verdadeiras.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
if (typeof module !== "undefined" && module.exports) {

  // Armazena ou atualiza no elemento à esquerda o valor calculado ou informado à direita.
  // `=` = operador de atribuição utilizado para armazenar ou associar o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
  module.exports = {

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    PecaDomino,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    EstadoRodada,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    InteligenciaDomino,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    criarConjuntoCompleto,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    melhorPecaInicial,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    calcularPosicoesSerpentina,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    calcularLayoutMesa,

    // Executa a instrução JavaScript desta linha para construir ou controlar o comportamento correspondente do Jogo de Dominó.
    // `{` = abre um bloco de instruções ou objeto, conforme o contexto desta linha.
    // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta estrutura.
    // `:` = separa uma chave de seu valor em objeto ou marca a estrutura correspondente, conforme o contexto.
    constantes: { MODO_MANO_A_MANO, MODO_DUPLAS, JOGADOR, IA, PARCEIRA, IA_DIREITA, IA_ESQUERDA, LADO_ESQUERDO, LADO_DIREITO }

  // Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
  // O ponto e vírgula = encerra a instrução JavaScript atual.
  };

// Encerra a estrutura, coleção, chamada ou bloco iniciado nas linhas anteriores.
// `}` = fecha um bloco de instruções ou objeto iniciado anteriormente.
}
