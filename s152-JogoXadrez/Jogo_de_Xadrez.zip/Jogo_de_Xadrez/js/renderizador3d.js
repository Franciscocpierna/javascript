// Cria e executa uma função isolada para manter as variáveis do jogo protegidas no próprio escopo.
// `function` = define uma nova função para agrupar uma rotina reutilizável.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
(function () {

  // Ativa o modo estrito do JavaScript para tornar a execução mais segura e impedir determinados usos ambíguos da linguagem.
  // `'use strict'` = texto literal utilizado nesta instrução, contendo use strict.
  // `;` = encerra a instrução JavaScript atual.
  'use strict';

  // Declara `ARQUIVOS` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `ARQUIVOS` = identificador utilizado para armazenar ou acessar o valor relacionado a ARQUIVOS.
  // `'abcdefgh'` = texto literal utilizado nesta instrução, contendo abcdefgh.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const ARQUIVOS = 'abcdefgh';

  // Define a classe `RenderizadorXadrez3D`, responsável por agrupar dados e comportamentos relacionados a esta parte do jogo.
  // `class` = define uma classe utilizada para criar objetos com dados e comportamentos relacionados.
  // `RenderizadorXadrez3D` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  class RenderizadorXadrez3D {

    // Define o método construtor responsável por inicializar os dados e estados da nova instância da classe.
    // `constructor` = define o método construtor executado automaticamente ao criar uma instância da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `canvas` = elemento gráfico utilizado como área de desenho do tabuleiro ou da cena.
    // `aoClicarCasa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a aoClicarCasa.
    constructor(canvas, aoClicarCasa) {

      // Armazena ou atualiza o valor de `this.canvas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.canvas = canvas;

      // Armazena ou atualiza o valor de `this.ctx` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.ctx` = acessa o atributo ou método `ctx` pertencente à própria instância atual.
      // `canvas.getContext` = chama a função ou método `getContext` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'2d'` = texto literal utilizado nesta instrução, contendo 2d.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `getContext` = identificador de propriedade ou método chamado `getContext`, acessado a partir do objeto indicado antes do ponto.
      // `alpha` = valor utilizado como limite alfa no algoritmo Alpha-Beta da Inteligência Artificial.
      this.ctx = canvas.getContext('2d', { alpha: false });

      // Armazena ou atualiza o valor de `this.aoClicarCasa` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.aoClicarCasa` = acessa o atributo ou método `aoClicarCasa` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.aoClicarCasa = aoClicarCasa;

      // Armazena ou atualiza o valor de `this.camera` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.camera = 'superior';

      // Armazena ou atualiza o valor de `this.dados` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.dados = null;

      // Armazena ou atualiza o valor de `this.poligonos` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.poligonos` = acessa o atributo ou método `poligonos` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.poligonos = [];

      // Armazena ou atualiza o valor de `this.hover` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.hover = null;

      // Armazena ou atualiza o valor de `this._ultimoTamanho` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._ultimoTamanho` = acessa o atributo ou método `_ultimoTamanho` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `w` = identificador usado como nome da propriedade `w` dentro do objeto atual.
      // `h` = identificador usado como nome da propriedade `h` dentro do objeto atual.
      // `dpr` = identificador usado como nome da propriedade `dpr` dentro do objeto atual.
      this._ultimoTamanho = { w: 0, h: 0, dpr: 1 };

      // Armazena ou atualiza o valor de `this._raf` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._raf` = acessa o atributo ou método `_raf` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._raf = 0;

      // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._clicar` = acessa o atributo ou método `_clicar` pertencente à própria instância atual.
      // `canvas.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
      // `this._clicar` = chama o método ou recurso `_clicar` pertencente à instância atual.
      // `'click'` = texto literal utilizado nesta instrução, contendo click.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `canvas` = elemento gráfico utilizado como área de desenho do tabuleiro ou da cena.
      // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
      // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
      canvas.addEventListener('click', (evento) => this._clicar(evento));

      // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._mover` = acessa o atributo ou método `_mover` pertencente à própria instância atual.
      // `canvas.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
      // `this._mover` = chama o método ou recurso `_mover` pertencente à instância atual.
      // `'pointermove'` = texto literal utilizado nesta instrução, contendo pointermove.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      canvas.addEventListener('pointermove', (evento) => this._mover(evento));

      // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
      // `canvas.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'pointerleave'` = texto literal utilizado nesta instrução, contendo pointerleave.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      canvas.addEventListener('pointerleave', () => {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (this.hover) {

          // Armazena ou atualiza o valor de `this.hover` utilizando o resultado definido nesta linha.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          this.hover = null;

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._agendarRender` = acessa o atributo ou método `_agendarRender` pertencente à própria instância atual.
          // `this._agendarRender` = chama o método ou recurso `_agendarRender` pertencente à instância atual.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          this._agendarRender();

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `typeof` = obtém o tipo do valor ou expressão indicada.
      // `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `ResizeObserver` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ResizeObserver.
      if (typeof ResizeObserver !== 'undefined') {

        // Armazena ou atualiza o valor de `this.observador` utilizando o resultado definido nesta linha.
        // `new` = cria uma nova instância da classe ou construtor indicado.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.observador` = acessa o atributo ou método `observador` pertencente à própria instância atual.
        // `this._agendarRender` = acessa o atributo ou método `_agendarRender` pertencente à própria instância atual.
        // `this._agendarRender` = chama o método ou recurso `_agendarRender` pertencente à instância atual.
        // `ResizeObserver` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        this.observador = new ResizeObserver(() => this._agendarRender());

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.observador` = acessa o atributo ou método `observador` pertencente à própria instância atual.
        // `this.observador.observe` = chama o método ou recurso `observe` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `observe` = identificador de propriedade ou método chamado `observe`, acessado a partir do objeto indicado antes do ponto.
        // `canvas` = elemento gráfico utilizado como área de desenho do tabuleiro ou da cena.
        this.observador.observe(canvas);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `definirCamera` para executar a rotina correspondente a definirCamera.
    // `definirCamera` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `camera` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a camera.
    definirCamera(camera) {

      // Armazena ou atualiza o valor de `this.camera` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.camera = camera || 'superior';

      // Armazena ou atualiza o valor de `this.hover` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.hover = null;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._agendarRender` = acessa o atributo ou método `_agendarRender` pertencente à própria instância atual.
      // `this._agendarRender` = chama o método ou recurso `_agendarRender` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._agendarRender();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `renderizar` para executar a rotina correspondente a renderizar.
    // `renderizar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `dados` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dados.
    renderizar(dados) {

      // Armazena ou atualiza o valor de `this.dados` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.dados = dados;

      // Armazena ou atualiza o valor de `this.camera` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.camera = dados?.camera || this.camera;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._agendarRender` = acessa o atributo ou método `_agendarRender` pertencente à própria instância atual.
      // `this._agendarRender` = chama o método ou recurso `_agendarRender` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._agendarRender();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_agendarRender` para executar a rotina correspondente a agendarRender.
    // `_agendarRender` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _agendarRender() {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._raf` = acessa o atributo ou método `_raf` pertencente à própria instância atual.
      // `cancelAnimationFrame` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      cancelAnimationFrame(this._raf);

      // Armazena ou atualiza o valor de `this._raf` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._raf` = acessa o atributo ou método `_raf` pertencente à própria instância atual.
      // `this._desenhar` = acessa o atributo ou método `_desenhar` pertencente à própria instância atual.
      // `this._desenhar` = chama o método ou recurso `_desenhar` pertencente à instância atual.
      // `requestAnimationFrame` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._raf = requestAnimationFrame(() => this._desenhar());

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_ajustarCanvas` para executar a rotina correspondente a ajustarCanvas.
    // `_ajustarCanvas` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _ajustarCanvas() {

      // Declara `rect` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `rect` = identificador utilizado para armazenar ou acessar o valor relacionado a rect.
      // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
      // `this.canvas.getBoundingClientRect` = chama o método ou recurso `getBoundingClientRect` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `getBoundingClientRect` = identificador de propriedade ou método chamado `getBoundingClientRect`, acessado a partir do objeto indicado antes do ponto.
      const rect = this.canvas.getBoundingClientRect();

      // Declara `w` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `w` = identificador utilizado para armazenar ou acessar o valor relacionado a w.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.round` = chama a função ou método `round` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `round` = identificador de propriedade ou método chamado `round`, acessado a partir do objeto indicado antes do ponto.
      // `width` = identificador de propriedade ou método chamado `width`, acessado a partir do objeto indicado antes do ponto.
      const w = Math.max(1, Math.round(rect.width));

      // Declara `h` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `h` = identificador utilizado para armazenar ou acessar o valor relacionado a h.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.round` = chama a função ou método `round` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `height` = identificador de propriedade ou método chamado `height`, acessado a partir do objeto indicado antes do ponto.
      const h = Math.max(1, Math.round(rect.height));

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `30` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (w < 30 || h < 30) return null;

      // Declara `dpr` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `dpr` = identificador utilizado para armazenar ou acessar o valor relacionado a dpr.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
      // `devicePixelRatio` = identificador de propriedade ou método chamado `devicePixelRatio`, acessado a partir do objeto indicado antes do ponto.
      const dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1));

      // Declara `pw` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `pw` = identificador utilizado para armazenar ou acessar o valor relacionado a pw.
      // `Math.round` = chama a função ou método `round` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `round` = identificador de propriedade ou método chamado `round`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      const pw = Math.round(w * dpr);

      // Declara `ph` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ph` = identificador utilizado para armazenar ou acessar o valor relacionado a ph.
      // `Math.round` = chama a função ou método `round` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const ph = Math.round(h * dpr);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `width` = identificador de propriedade ou método chamado `width`, acessado a partir do objeto indicado antes do ponto.
      // `height` = identificador de propriedade ou método chamado `height`, acessado a partir do objeto indicado antes do ponto.
      if (this.canvas.width !== pw || this.canvas.height !== ph) {

        // Armazena ou atualiza o valor de `this.canvas.width` utilizando o resultado definido nesta linha.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        this.canvas.width = pw;

        // Armazena ou atualiza o valor de `this.canvas.height` utilizando o resultado definido nesta linha.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        this.canvas.height = ph;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.ctx` = acessa o atributo ou método `ctx` pertencente à própria instância atual.
      // `this.ctx.setTransform` = chama o método ou recurso `setTransform` pertencente à instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `setTransform` = identificador de propriedade ou método chamado `setTransform`, acessado a partir do objeto indicado antes do ponto.
      // `dpr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dpr.
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Armazena ou atualiza o valor de `this._ultimoTamanho` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._ultimoTamanho` = acessa o atributo ou método `_ultimoTamanho` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      this._ultimoTamanho = { w, h, dpr };

      // Retorna `{ w, h }` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      return { w, h };

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_configuracao` para executar a rotina correspondente a configuracao.
    // `_configuracao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `camera` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a camera.
    _configuracao(camera, w, h) {

      // Declara `cx` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `cx` = identificador utilizado para armazenar ou acessar o valor relacionado a cx.
      // `0.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const cx = w * 0.5;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `'lateral'` = texto literal utilizado nesta instrução, contendo lateral.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (camera === 'lateral') {

        // Retorna `{` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        return {

          // Define a propriedade `farL` do objeto com o valor informado nesta linha.
          // `0.215` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0.285` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `*` = realiza multiplicação.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `farL` = identificador usado como nome da propriedade `farL` dentro do objeto atual.
          // `x` = identificador usado como nome da propriedade `x` dentro do objeto atual.
          // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
          // `y` = identificador usado como nome da propriedade `y` dentro do objeto atual.
          // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
          farL: { x: cx - w * 0.215, y: h * 0.285 },

          // Define a propriedade `farR` do objeto com o valor informado nesta linha.
          // `0.215` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0.285` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `*` = realiza multiplicação.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `farR` = identificador usado como nome da propriedade `farR` dentro do objeto atual.
          farR: { x: cx + w * 0.215, y: h * 0.285 },

          // Define a propriedade `nearL` do objeto com o valor informado nesta linha.
          // `0.455` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0.885` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `*` = realiza multiplicação.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `nearL` = identificador usado como nome da propriedade `nearL` dentro do objeto atual.
          // `cx` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cx.
          nearL: { x: cx - w * 0.455, y: h * 0.885 },

          // Define a propriedade `nearR` do objeto com o valor informado nesta linha.
          // `0.455` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0.885` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `*` = realiza multiplicação.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `nearR` = identificador usado como nome da propriedade `nearR` dentro do objeto atual.
          nearR: { x: cx + w * 0.455, y: h * 0.885 },

          // Define a propriedade `titulo` do objeto com o valor informado nesta linha.
          // `'CÂMERA IMERSIVA • DENTRO DO TABULEIRO'` = texto literal utilizado nesta instrução, contendo CÂMERA IMERSIVA • DENTRO DO TABULEIRO.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `titulo` = identificador usado como nome da propriedade `titulo` dentro do objeto atual.
          titulo: 'CÂMERA IMERSIVA • DENTRO DO TABULEIRO',

          // Define a propriedade `subtitulo` do objeto com o valor informado nesta linha.
          // `'Peças em pé com perspectiva baixa e tabuleiro 100% visível'` = texto literal utilizado nesta instrução, contendo Peças em pé com perspectiva baixa e tabuleiro 100% visível.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `subtitulo` = identificador usado como nome da propriedade `subtitulo` dentro do objeto atual.
          subtitulo: 'Peças em pé com perspectiva baixa e tabuleiro 100% visível',

          // Define a propriedade `escalaPeca` do objeto com o valor informado nesta linha.
          // `1.08` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `escalaPeca` = identificador usado como nome da propriedade `escalaPeca` dentro do objeto atual.
          escalaPeca: 1.08,

          // Define a propriedade `ambiente` do objeto com o valor informado nesta linha.
          // `'imersivo'` = texto literal utilizado nesta instrução, contendo imersivo.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `ambiente` = identificador usado como nome da propriedade `ambiente` dentro do objeto atual.
          ambiente: 'imersivo',

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        };

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `{` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      return {

        // Define a propriedade `farL` do objeto com o valor informado nesta linha.
        // `0.235` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.205` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `farL` = identificador usado como nome da propriedade `farL` dentro do objeto atual.
        // `x` = identificador usado como nome da propriedade `x` dentro do objeto atual.
        // `cx` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cx.
        // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
        // `y` = identificador usado como nome da propriedade `y` dentro do objeto atual.
        // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
        farL: { x: cx - w * 0.235, y: h * 0.205 },

        // Define a propriedade `farR` do objeto com o valor informado nesta linha.
        // `0.235` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.205` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `*` = realiza multiplicação.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `farR` = identificador usado como nome da propriedade `farR` dentro do objeto atual.
        farR: { x: cx + w * 0.235, y: h * 0.205 },

        // Define a propriedade `nearL` do objeto com o valor informado nesta linha.
        // `0.445` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.875` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `nearL` = identificador usado como nome da propriedade `nearL` dentro do objeto atual.
        nearL: { x: cx - w * 0.445, y: h * 0.875 },

        // Define a propriedade `nearR` do objeto com o valor informado nesta linha.
        // `0.445` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.875` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `*` = realiza multiplicação.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `nearR` = identificador usado como nome da propriedade `nearR` dentro do objeto atual.
        nearR: { x: cx + w * 0.445, y: h * 0.875 },

        // Define a propriedade `titulo` do objeto com o valor informado nesta linha.
        // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
        // `'PERSPECTIVA 3D • PRETAS'` = texto literal utilizado nesta instrução, contendo PERSPECTIVA 3D • PRETAS.
        // `'PERSPECTIVA 3D • BRANCAS'` = texto literal utilizado nesta instrução, contendo PERSPECTIVA 3D • BRANCAS.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `titulo` = identificador usado como nome da propriedade `titulo` dentro do objeto atual.
        // `camera` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a camera.
        titulo: camera === 'pretas' ? 'PERSPECTIVA 3D • PRETAS' : 'PERSPECTIVA 3D • BRANCAS',

        // Define a propriedade `subtitulo` do objeto com o valor informado nesta linha.
        // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
        // `'Visão defensiva a partir do lado das peças pretas'` = texto literal utilizado nesta instrução, contendo Visão defensiva a partir do lado das peças pretas.
        // `'Visão clássica a partir do lado das peças brancas'` = texto literal utilizado nesta instrução, contendo Visão clássica a partir do lado das peças brancas.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `subtitulo` = identificador usado como nome da propriedade `subtitulo` dentro do objeto atual.
        subtitulo: camera === 'pretas' ? 'Visão defensiva a partir do lado das peças pretas' : 'Visão clássica a partir do lado das peças brancas',

        // Define a propriedade `escalaPeca` do objeto com o valor informado nesta linha.
        // `0.96` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `escalaPeca` = identificador usado como nome da propriedade `escalaPeca` dentro do objeto atual.
        escalaPeca: 0.96,

        // Define a propriedade `ambiente` do objeto com o valor informado nesta linha.
        // `'classico'` = texto literal utilizado nesta instrução, contendo classico.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `ambiente` = identificador usado como nome da propriedade `ambiente` dentro do objeto atual.
        ambiente: 'classico',

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_projetar` para executar a rotina correspondente a projetar.
    // `_projetar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `u` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a u.
    // `t` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a t.
    // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
    _projetar(u, t, cfg) {

      // Declara `tt` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `tt` = identificador utilizado para armazenar ou acessar o valor relacionado a tt.
      // `Math.pow` = chama a função ou método `pow` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0.94` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `pow` = identificador de propriedade ou método chamado `pow`, acessado a partir do objeto indicado antes do ponto.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      const tt = Math.pow(Math.max(0, Math.min(1, t)), 0.94);

      // Declara `fx` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `fx` = identificador utilizado para armazenar ou acessar o valor relacionado a fx.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `farL` = identificador de propriedade ou método chamado `farL`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
      // `farR` = identificador de propriedade ou método chamado `farR`, acessado a partir do objeto indicado antes do ponto.
      const fx = cfg.farL.x + (cfg.farR.x - cfg.farL.x) * u;

      // Declara `fy` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `fy` = identificador utilizado para armazenar ou acessar o valor relacionado a fy.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
      // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
      // `u` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a u.
      const fy = cfg.farL.y + (cfg.farR.y - cfg.farL.y) * u;

      // Declara `nx` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `nx` = identificador utilizado para armazenar ou acessar o valor relacionado a nx.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nearL` = identificador de propriedade ou método chamado `nearL`, acessado a partir do objeto indicado antes do ponto.
      // `nearR` = identificador de propriedade ou método chamado `nearR`, acessado a partir do objeto indicado antes do ponto.
      const nx = cfg.nearL.x + (cfg.nearR.x - cfg.nearL.x) * u;

      // Declara `ny` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ny` = identificador utilizado para armazenar ou acessar o valor relacionado a ny.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const ny = cfg.nearL.y + (cfg.nearR.y - cfg.nearL.y) * u;

      // Retorna `{` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      return {

        // Define a propriedade `x` do objeto com o valor informado nesta linha.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `x` = identificador usado como nome da propriedade `x` dentro do objeto atual.
        // `fx` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fx.
        // `tt` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tt.
        x: fx + (nx - fx) * tt,

        // Define a propriedade `y` do objeto com o valor informado nesta linha.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `y` = identificador usado como nome da propriedade `y` dentro do objeto atual.
        // `fy` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fy.
        y: fy + (ny - fy) * tt,

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_viewRow` para executar a rotina correspondente a viewRow.
    // `_viewRow` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
    _viewRow(row) {

      // Retorna `this.camera === 'pretas' ? 7 - row : row` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
      // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return this.camera === 'pretas' ? 7 - row : row;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_viewCol` para executar a rotina correspondente a viewCol.
    // `_viewCol` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
    _viewCol(col) {

      // Retorna `this.camera === 'pretas' ? 7 - col : col` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
      // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return this.camera === 'pretas' ? 7 - col : col;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_actualRow` para executar a rotina correspondente a actualRow.
    // `_actualRow` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `vr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vr.
    _actualRow(vr) {

      // Retorna `this.camera === 'pretas' ? 7 - vr : vr` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
      // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return this.camera === 'pretas' ? 7 - vr : vr;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_actualCol` para executar a rotina correspondente a actualCol.
    // `_actualCol` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
    _actualCol(vc) {

      // Retorna `this.camera === 'pretas' ? 7 - vc : vc` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
      // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return this.camera === 'pretas' ? 7 - vc : vc;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenhar` para executar a rotina correspondente a desenhar.
    // `_desenhar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _desenhar() {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.ctx` = acessa o atributo ou método `ctx` pertencente à própria instância atual.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (!this.ctx || !this.dados || this.camera === 'superior') return;

      // Declara `tamanho` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `tamanho` = identificador utilizado para armazenar ou acessar o valor relacionado a tamanho.
      // `this._ajustarCanvas` = acessa o atributo ou método `_ajustarCanvas` pertencente à própria instância atual.
      // `this._ajustarCanvas` = chama o método ou recurso `_ajustarCanvas` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const tamanho = this._ajustarCanvas();

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!tamanho) return;

      // Declara constantes por desestruturação, extraindo propriedades do objeto indicado para identificadores individuais.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const { w, h } = tamanho;

      // Declara `ctx` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `ctx` = identificador utilizado para armazenar ou acessar o valor relacionado a ctx.
      // `this.ctx` = acessa o atributo ou método `ctx` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const ctx = this.ctx;

      // Declara `cfg` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `cfg` = identificador utilizado para armazenar ou acessar o valor relacionado a cfg.
      // `this._configuracao` = acessa o atributo ou método `_configuracao` pertencente à própria instância atual.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `this._configuracao` = chama o método ou recurso `_configuracao` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const cfg = this._configuracao(this.camera, w, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.clearRect` = chama a função ou método `clearRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `clearRect` = identificador de propriedade ou método chamado `clearRect`, acessado a partir do objeto indicado antes do ponto.
      ctx.clearRect(0, 0, w, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desenharAmbiente` = acessa o atributo ou método `_desenharAmbiente` pertencente à própria instância atual.
      // `this._desenharAmbiente` = chama o método ou recurso `_desenharAmbiente` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._desenharAmbiente(ctx, w, h, cfg);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desenharMesa` = acessa o atributo ou método `_desenharMesa` pertencente à própria instância atual.
      // `this._desenharMesa` = chama o método ou recurso `_desenharMesa` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      this._desenharMesa(ctx, w, h, cfg);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desenharTabuleiro` = acessa o atributo ou método `_desenharTabuleiro` pertencente à própria instância atual.
      // `this._desenharTabuleiro` = chama o método ou recurso `_desenharTabuleiro` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
      this._desenharTabuleiro(ctx, w, h, cfg);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desenharPecas` = acessa o atributo ou método `_desenharPecas` pertencente à própria instância atual.
      // `this._desenharPecas` = chama o método ou recurso `_desenharPecas` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._desenharPecas(ctx, w, h, cfg);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desenharLegendaCamera` = acessa o atributo ou método `_desenharLegendaCamera` pertencente à própria instância atual.
      // `this._desenharLegendaCamera` = chama o método ou recurso `_desenharLegendaCamera` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._desenharLegendaCamera(ctx, w, h, cfg);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharAmbiente` para executar a rotina correspondente a desenharAmbiente.
    // `_desenharAmbiente` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _desenharAmbiente(ctx, w, h, cfg) {

      // Declara `fundo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `fundo` = identificador utilizado para armazenar ou acessar o valor relacionado a fundo.
      // `ctx.createLinearGradient` = chama a função ou método `createLinearGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `createLinearGradient` = identificador de propriedade ou método chamado `createLinearGradient`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const fundo = ctx.createLinearGradient(0, 0, 0, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `fundo.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'#07100d'` = texto literal utilizado nesta instrução, contendo #07100d.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      fundo.addColorStop(0, '#07100d');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `fundo.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'#101713'` = texto literal utilizado nesta instrução, contendo #101713.
      // `0.35` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      fundo.addColorStop(0.35, '#101713');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `fundo.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'#17150f'` = texto literal utilizado nesta instrução, contendo #17150f.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      fundo.addColorStop(0.72, '#17150f');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `fundo.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'#080a08'` = texto literal utilizado nesta instrução, contendo #080a08.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fundo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fundo.
      fundo.addColorStop(1, '#080a08');

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = fundo;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillRect` = chama a função ou método `fillRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillRect` = identificador de propriedade ou método chamado `fillRect`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.fillRect(0, 0, w, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `0.55` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = 0.55;

      // Armazena ou atualiza o valor de `ctx.filter` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
      ctx.filter = `blur(${Math.max(8, w * 0.012)}px)`;

      // Declara `brilho1` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `brilho1` = identificador utilizado para armazenar ou acessar o valor relacionado a brilho1.
      // `ctx.createRadialGradient` = chama a função ou método `createRadialGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.19` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `createRadialGradient` = identificador de propriedade ou método chamado `createRadialGradient`, acessado a partir do objeto indicado antes do ponto.
      const brilho1 = ctx.createRadialGradient(w * 0.16, h * 0.20, 2, w * 0.16, h * 0.20, w * 0.19);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `brilho1.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(244,186,103,.78)'` = texto literal utilizado nesta instrução, contendo rgba(244,186,103,.78).
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      brilho1.addColorStop(0, 'rgba(244,186,103,.78)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `brilho1.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(212,133,58,.30)'` = texto literal utilizado nesta instrução, contendo rgba(212,133,58,.30).
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      brilho1.addColorStop(0.18, 'rgba(212,133,58,.30)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `brilho1.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(80,44,12,0)'` = texto literal utilizado nesta instrução, contendo rgba(80,44,12,0).
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      brilho1.addColorStop(1, 'rgba(80,44,12,0)');

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `brilho1` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a brilho1.
      ctx.fillStyle = brilho1;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillRect` = chama a função ou método `fillRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `0.58` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillRect` = identificador de propriedade ou método chamado `fillRect`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.fillRect(0, 0, w, h * 0.58);

      // Declara `brilho2` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `brilho2` = identificador utilizado para armazenar ou acessar o valor relacionado a brilho2.
      // `ctx.createRadialGradient` = chama a função ou método `createRadialGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.83` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.24` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `createRadialGradient` = identificador de propriedade ou método chamado `createRadialGradient`, acessado a partir do objeto indicado antes do ponto.
      const brilho2 = ctx.createRadialGradient(w * 0.83, h * 0.25, 2, w * 0.83, h * 0.25, w * 0.24);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `brilho2.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(255,215,142,.48)'` = texto literal utilizado nesta instrução, contendo rgba(255,215,142,.48).
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      brilho2.addColorStop(0, 'rgba(255,215,142,.48)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `brilho2.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(128,95,53,.18)'` = texto literal utilizado nesta instrução, contendo rgba(128,95,53,.18).
      // `0.22` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      brilho2.addColorStop(0.22, 'rgba(128,95,53,.18)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `brilho2.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(45,64,50,0)'` = texto literal utilizado nesta instrução, contendo rgba(45,64,50,0).
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      brilho2.addColorStop(1, 'rgba(45,64,50,0)');

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `brilho2` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a brilho2.
      ctx.fillStyle = brilho2;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillRect` = chama a função ou método `fillRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.52` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `0.48` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.62` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillRect` = identificador de propriedade ou método chamado `fillRect`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.fillRect(w * 0.52, 0, w * 0.48, h * 0.62);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = 0.16;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      for (let i = 0; i < 8; i += 1) {

        // Declara `x` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `x` = identificador utilizado para armazenar ou acessar o valor relacionado a x.
        // `0.055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `*` = realiza multiplicação.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
        const x = w * 0.055 + i * w * 0.035;

        // Declara `altura` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `altura` = identificador utilizado para armazenar ou acessar o valor relacionado a altura.
        // `0.11` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.025` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `*` = realiza multiplicação.
        // `%` = calcula o resto de uma divisão inteira.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
        const altura = h * (0.11 + (i % 3) * 0.025);

        // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
        // `'#7b5a35'` = texto literal utilizado nesta instrução, contendo #7b5a35.
        // `'#4e3a27'` = texto literal utilizado nesta instrução, contendo #4e3a27.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `%` = calcula o resto de uma divisão inteira.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
        ctx.fillStyle = i % 2 ? '#7b5a35' : '#4e3a27';

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.fillRect` = chama a função ou método `fillRect` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0.05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.022` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `fillRect` = identificador de propriedade ou método chamado `fillRect`, acessado a partir do objeto indicado antes do ponto.
        // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
        ctx.fillRect(x, h * 0.05 + (h * 0.17 - altura), w * 0.022, altura);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `'imersivo'` = texto literal utilizado nesta instrução, contendo imersivo.
      // `0.23` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.34` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
      // `ambiente` = identificador de propriedade ou método chamado `ambiente`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = cfg.ambiente === 'imersivo' ? 0.23 : 0.34;

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `'#d5b477'` = texto literal utilizado nesta instrução, contendo #d5b477.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = '#d5b477';

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.82` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.moveTo(w * 0.82, h * 0.09);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.88` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.lineTo(w * 0.88, h * 0.09);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.90` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      ctx.lineTo(w * 0.90, h * 0.18);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.80` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.lineTo(w * 0.80, h * 0.18);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `'#695035'` = texto literal utilizado nesta instrução, contendo #695035.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = '#695035';

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillRect` = chama a função ou método `fillRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.848` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.008` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.11` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillRect` = identificador de propriedade ou método chamado `fillRect`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.fillRect(w * 0.848, h * 0.18, w * 0.008, h * 0.11);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Declara `vinheta` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `vinheta` = identificador utilizado para armazenar ou acessar o valor relacionado a vinheta.
      // `ctx.createRadialGradient` = chama a função ou método `createRadialGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.46` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.52` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.68` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `createRadialGradient` = identificador de propriedade ou método chamado `createRadialGradient`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      const vinheta = ctx.createRadialGradient(w * 0.5, h * 0.46, Math.min(w, h) * 0.18, w * 0.5, h * 0.52, Math.max(w, h) * 0.68);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `vinheta.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(0,0,0,0)'` = texto literal utilizado nesta instrução, contendo rgba(0,0,0,0).
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      vinheta.addColorStop(0, 'rgba(0,0,0,0)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `vinheta.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(0,0,0,.08)'` = texto literal utilizado nesta instrução, contendo rgba(0,0,0,.08).
      // `0.66` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      vinheta.addColorStop(0.66, 'rgba(0,0,0,.08)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `vinheta.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(0,0,0,.64)'` = texto literal utilizado nesta instrução, contendo rgba(0,0,0,.64).
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `vinheta` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vinheta.
      vinheta.addColorStop(1, 'rgba(0,0,0,.64)');

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = vinheta;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillRect` = chama a função ou método `fillRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillRect` = identificador de propriedade ou método chamado `fillRect`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.fillRect(0, 0, w, h);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharMesa` para executar a rotina correspondente a desenharMesa.
    // `_desenharMesa` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
    _desenharMesa(ctx, w, h, cfg) {

      // Declara `y` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `y` = identificador utilizado para armazenar ou acessar o valor relacionado a y.
      // `0.005` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nearL` = identificador de propriedade ou método chamado `nearL`, acessado a partir do objeto indicado antes do ponto.
      const y = cfg.nearL.y - h * 0.005;

      // Declara `mesa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `mesa` = identificador utilizado para armazenar ou acessar o valor relacionado a mesa.
      // `ctx.createLinearGradient` = chama a função ou método `createLinearGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `0.12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `createLinearGradient` = identificador de propriedade ou método chamado `createLinearGradient`, acessado a partir do objeto indicado antes do ponto.
      const mesa = ctx.createLinearGradient(0, y - h * 0.12, 0, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mesa.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(83,58,32,.72)'` = texto literal utilizado nesta instrução, contendo rgba(83,58,32,.72).
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      mesa.addColorStop(0, 'rgba(83,58,32,.72)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mesa.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(56,37,21,.95)'` = texto literal utilizado nesta instrução, contendo rgba(56,37,21,.95).
      // `0.24` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      mesa.addColorStop(0.24, 'rgba(56,37,21,.95)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mesa.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'#120c08'` = texto literal utilizado nesta instrução, contendo #120c08.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      mesa.addColorStop(1, '#120c08');

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `mesa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a mesa.
      ctx.fillStyle = mesa;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.08` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `y` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a y.
      ctx.moveTo(0, Math.max(h * 0.72, y - h * 0.08));

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.08` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      ctx.lineTo(w, Math.max(h * 0.72, y - h * 0.08));

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.lineTo(w, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      ctx.lineTo(0, h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = 0.15;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `9` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      for (let i = 0; i < 9; i += 1) {

        // Declara `yy` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `yy` = identificador utilizado para armazenar ou acessar o valor relacionado a yy.
        // `0.76` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `*` = realiza multiplicação.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
        const yy = h * 0.76 + i * h * 0.035;

        // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
        // `'#b68854'` = texto literal utilizado nesta instrução, contendo #b68854.
        // `'#5b3a22'` = texto literal utilizado nesta instrução, contendo #5b3a22.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `%` = calcula o resto de uma divisão inteira.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
        ctx.strokeStyle = i % 2 ? '#b68854' : '#5b3a22';

        // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
        // `1.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
        ctx.lineWidth = 1.5;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
        ctx.beginPath();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
        ctx.moveTo(0, yy);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0.25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
        // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
        // `yy` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a yy.
        ctx.bezierCurveTo(w * 0.25, yy - 4, w * 0.7, yy + 5, w, yy - 2);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
        ctx.stroke();

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharTabuleiro` para executar a rotina correspondente a desenharTabuleiro.
    // `_desenharTabuleiro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
    // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
    _desenharTabuleiro(ctx, w, h, cfg) {

      // Armazena ou atualiza o valor de `this.poligonos` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.poligonos` = acessa o atributo ou método `poligonos` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.poligonos = [];

      // Declara `p1` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p1` = identificador utilizado para armazenar ou acessar o valor relacionado a p1.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `farL` = identificador de propriedade ou método chamado `farL`, acessado a partir do objeto indicado antes do ponto.
      const p1 = cfg.farL;

      // Declara `p2` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p2` = identificador utilizado para armazenar ou acessar o valor relacionado a p2.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `farR` = identificador de propriedade ou método chamado `farR`, acessado a partir do objeto indicado antes do ponto.
      const p2 = cfg.farR;

      // Declara `p3` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p3` = identificador utilizado para armazenar ou acessar o valor relacionado a p3.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nearR` = identificador de propriedade ou método chamado `nearR`, acessado a partir do objeto indicado antes do ponto.
      const p3 = cfg.nearR;

      // Declara `p4` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `p4` = identificador utilizado para armazenar ou acessar o valor relacionado a p4.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nearL` = identificador de propriedade ou método chamado `nearL`, acessado a partir do objeto indicado antes do ponto.
      const p4 = cfg.nearL;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.lineJoin` utilizando o resultado definido nesta linha.
      // `'round'` = texto literal utilizado nesta instrução, contendo round.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineJoin` = identificador de propriedade ou método chamado `lineJoin`, acessado a partir do objeto indicado antes do ponto.
      ctx.lineJoin = 'round';

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `'#24170f'` = texto literal utilizado nesta instrução, contendo #24170f.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = '#24170f';

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineWidth = Math.max(18, Math.min(w, h) * 0.035);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `p1` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p1.
      // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
      // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `p2` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p2.
      // `p3` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p3.
      // `p4` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p4.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.lineTo(p3.x, p3.y); ctx.lineTo(p4.x, p4.y); ctx.closePath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.stroke();

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `'rgba(201,151,88,.38)'` = texto literal utilizado nesta instrução, contendo rgba(201,151,88,.38).
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = 'rgba(201,151,88,.38)';

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.006` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineWidth = Math.max(3, Math.min(w, h) * 0.006);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Declara `selecionada` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `selecionada` = identificador utilizado para armazenar ou acessar o valor relacionado a selecionada.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const selecionada = this.dados.selecionada;

      // Declara `legais` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `legais` = identificador utilizado para armazenar ou acessar o valor relacionado a legais.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
      const legais = this.dados.movimentosSelecionados || [];

      // Declara `ultimo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `ultimo` = identificador utilizado para armazenar ou acessar o valor relacionado a ultimo.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ultimoMovimentoIA` = identificador de propriedade ou método chamado `ultimoMovimentoIA`, acessado a partir do objeto indicado antes do ponto.
      const ultimo = this.dados.ultimoMovimentoIA;

      // Declara `reiXeque` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `reiXeque` = identificador utilizado para armazenar ou acessar o valor relacionado a reiXeque.
      // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const reiXeque = this.dados.reiXeque;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `vr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vr.
      for (let vr = 0; vr < 8; vr += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
        for (let vc = 0; vc < 8; vc += 1) {

          // Declara `row` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `row` = identificador utilizado para armazenar ou acessar o valor relacionado a row.
          // `this._actualRow` = acessa o atributo ou método `_actualRow` pertencente à própria instância atual.
          // `this._actualRow` = chama o método ou recurso `_actualRow` pertencente à instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const row = this._actualRow(vr);

          // Declara `col` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `col` = identificador utilizado para armazenar ou acessar o valor relacionado a col.
          // `this._actualCol` = acessa o atributo ou método `_actualCol` pertencente à própria instância atual.
          // `this._actualCol` = chama o método ou recurso `_actualCol` pertencente à instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const col = this._actualCol(vc);

          // Declara `poly` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `poly` = identificador utilizado para armazenar ou acessar o valor relacionado a poly.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          const poly = [

            // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
            // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
            // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `/` = realiza divisão.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `vr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vr.
            // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
            this._projetar(vc / 8, vr / 8, cfg),

            // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
            // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
            // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
            // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
            // `/` = realiza divisão.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
            this._projetar((vc + 1) / 8, vr / 8, cfg),

            // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
            // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
            // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
            // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
            // `/` = realiza divisão.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            this._projetar((vc + 1) / 8, (vr + 1) / 8, cfg),

            // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
            // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
            // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
            // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
            // `/` = realiza divisão.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            this._projetar(vc / 8, (vr + 1) / 8, cfg),

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          ];

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.poligonos` = acessa o atributo ou método `poligonos` pertencente à própria instância atual.
          // `this.poligonos.push` = chama o método ou recurso `push` pertencente à instância atual.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
          // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
          // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
          this.poligonos.push({ row, col, poly });

          // Declara `clara` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `clara` = identificador utilizado para armazenar ou acessar o valor relacionado a clara.
          // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `%` = calcula o resto de uma divisão inteira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          const clara = (row + col) % 2 === 0;

          // Declara `centro` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `centro` = identificador utilizado para armazenar ou acessar o valor relacionado a centro.
          // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
          // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
          // `0.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `/` = realiza divisão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
          // `vr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vr.
          // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
          const centro = this._projetar((vc + 0.5) / 8, (vr + 0.5) / 8, cfg);

          // Declara `grad` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `grad` = identificador utilizado para armazenar ou acessar o valor relacionado a grad.
          // `ctx.createLinearGradient` = chama a função ou método `createLinearGradient` pertencente ao objeto ou recurso indicado antes do ponto.
          // `0.05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0.03` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0.04` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `*` = realiza multiplicação.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
          // `createLinearGradient` = identificador de propriedade ou método chamado `createLinearGradient`, acessado a partir do objeto indicado antes do ponto.
          // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
          // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
          // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
          // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
          const grad = ctx.createLinearGradient(centro.x - w * 0.05, centro.y - h * 0.03, centro.x + w * 0.05, centro.y + h * 0.04);

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `clara` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a clara.
          if (clara) {

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
            // `'#f0d9ad'` = texto literal utilizado nesta instrução, contendo #f0d9ad.
            // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
            grad.addColorStop(0, '#f0d9ad');

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
            // `'#d9bc86'` = texto literal utilizado nesta instrução, contendo #d9bc86.
            // `0.45` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `grad` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a grad.
            grad.addColorStop(0.45, '#d9bc86');

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
            // `'#b99362'` = texto literal utilizado nesta instrução, contendo #b99362.
            // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            grad.addColorStop(1, '#b99362');

          // Executa o bloco alternativo quando a condição anterior não foi atendida.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          } else {

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
            // `'#6a482d'` = texto literal utilizado nesta instrução, contendo #6a482d.
            // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            grad.addColorStop(0, '#6a482d');

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
            // `'#4d321f'` = texto literal utilizado nesta instrução, contendo #4d321f.
            // `0.45` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
            grad.addColorStop(0.45, '#4d321f');

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
            // `'#2f2016'` = texto literal utilizado nesta instrução, contendo #2f2016.
            // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `grad` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a grad.
            grad.addColorStop(1, '#2f2016');

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
          // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
          ctx.fillStyle = grad;

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._preencherPoligono` = acessa o atributo ou método `_preencherPoligono` pertencente à própria instância atual.
          // `this._preencherPoligono` = chama o método ou recurso `_preencherPoligono` pertencente à instância atual.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
          this._preencherPoligono(ctx, poly);

          // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
          // `'rgba(76,47,26,.12)'` = texto literal utilizado nesta instrução, contendo rgba(76,47,26,.12).
          // `'rgba(239,205,153,.08)'` = texto literal utilizado nesta instrução, contendo rgba(239,205,153,.08).
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
          // `clara` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a clara.
          ctx.strokeStyle = clara ? 'rgba(76,47,26,.12)' : 'rgba(239,205,153,.08)';

          // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
          // `0.7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
          ctx.lineWidth = 0.7;

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._contornarPoligono` = acessa o atributo ou método `_contornarPoligono` pertencente à própria instância atual.
          // `this._contornarPoligono` = chama o método ou recurso `_contornarPoligono` pertencente à instância atual.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          this._contornarPoligono(ctx, poly);

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._mesma` = acessa o atributo ou método `_mesma` pertencente à própria instância atual.
          // `this._mesma` = chama o método ou recurso `_mesma` pertencente à instância atual.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `ultimo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ultimo.
          // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
          // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `destino` = identificador que representa a casa de destino de um movimento.
          if (ultimo && (this._mesma([row, col], ultimo.origem) || this._mesma([row, col], ultimo.destino))) {

            // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
            // `'rgba(226,181,59,.32)'` = texto literal utilizado nesta instrução, contendo rgba(226,181,59,.32).
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
            // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
            ctx.fillStyle = 'rgba(226,181,59,.32)';

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._preencherPoligono` = acessa o atributo ou método `_preencherPoligono` pertencente à própria instância atual.
            // `this._preencherPoligono` = chama o método ou recurso `_preencherPoligono` pertencente à instância atual.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
            this._preencherPoligono(ctx, poly);

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._mesma` = acessa o atributo ou método `_mesma` pertencente à própria instância atual.
          // `this._mesma` = chama o método ou recurso `_mesma` pertencente à instância atual.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
          if (selecionada && this._mesma([row, col], selecionada)) {

            // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
            // `'rgba(255,214,74,.42)'` = texto literal utilizado nesta instrução, contendo rgba(255,214,74,.42).
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            ctx.fillStyle = 'rgba(255,214,74,.42)';

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._preencherPoligono` = acessa o atributo ou método `_preencherPoligono` pertencente à própria instância atual.
            // `this._preencherPoligono` = chama o método ou recurso `_preencherPoligono` pertencente à instância atual.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
            this._preencherPoligono(ctx, poly);

            // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
            // `'rgba(255,235,139,.90)'` = texto literal utilizado nesta instrução, contendo rgba(255,235,139,.90).
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
            ctx.strokeStyle = 'rgba(255,235,139,.90)';

            // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
            // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
            // `1.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `0.0025` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `*` = realiza multiplicação.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
            // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
            // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
            // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
            ctx.lineWidth = Math.max(1.5, w * 0.0025);

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._contornarPoligono` = acessa o atributo ou método `_contornarPoligono` pertencente à própria instância atual.
            // `this._contornarPoligono` = chama o método ou recurso `_contornarPoligono` pertencente à instância atual.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
            this._contornarPoligono(ctx, poly);

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._mesma` = acessa o atributo ou método `_mesma` pertencente à própria instância atual.
          // `this._mesma` = chama o método ou recurso `_mesma` pertencente à instância atual.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `reiXeque` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a reiXeque.
          // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
          // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
          if (reiXeque && this._mesma([row, col], reiXeque)) {

            // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
            // `'rgba(205,55,55,.50)'` = texto literal utilizado nesta instrução, contendo rgba(205,55,55,.50).
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
            // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
            ctx.fillStyle = 'rgba(205,55,55,.50)';

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._preencherPoligono` = acessa o atributo ou método `_preencherPoligono` pertencente à própria instância atual.
            // `this._preencherPoligono` = chama o método ou recurso `_preencherPoligono` pertencente à instância atual.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            this._preencherPoligono(ctx, poly);

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          if (this.hover && this.hover.row === row && this.hover.col === col) {

            // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
            // `'rgba(255,255,255,.09)'` = texto literal utilizado nesta instrução, contendo rgba(255,255,255,.09).
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            ctx.fillStyle = 'rgba(255,255,255,.09)';

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `this._preencherPoligono` = acessa o atributo ou método `_preencherPoligono` pertencente à própria instância atual.
            // `this._preencherPoligono` = chama o método ou recurso `_preencherPoligono` pertencente à instância atual.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
            this._preencherPoligono(ctx, poly);

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Declara `legal` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `legal` = identificador utilizado para armazenar ou acessar o valor relacionado a legal.
          // `this._mesma` = acessa o atributo ou método `_mesma` pertencente à própria instância atual.
          // `legais.find` = chama a função ou método `find` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._mesma` = chama o método ou recurso `_mesma` pertencente à instância atual.
          // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `legais` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a legais.
          // `find` = identificador de propriedade ou método chamado `find`, acessado a partir do objeto indicado antes do ponto.
          // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
          // `destino` = identificador que representa a casa de destino de um movimento.
          // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
          // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
          const legal = legais.find((m) => this._mesma(m.destino, [row, col]));

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          if (legal) {

            // Declara `meio` e armazena nele o valor ou resultado definido nesta linha.
            // `const` = declara uma constante que recebe um valor na própria declaração.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `meio` = identificador utilizado para armazenar ou acessar o valor relacionado a meio.
            // `this._centroPoligono` = acessa o atributo ou método `_centroPoligono` pertencente à própria instância atual.
            // `this._centroPoligono` = chama o método ou recurso `_centroPoligono` pertencente à instância atual.
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            const meio = this._centroPoligono(poly);

            // Declara `largura` e armazena nele o valor ou resultado definido nesta linha.
            // `const` = declara uma constante que recebe um valor na própria declaração.
            // `largura` = identificador utilizado para armazenar ou acessar o valor relacionado a largura.
            // `Math.hypot` = chama a função ou método `hypot` pertencente ao objeto ou recurso indicado antes do ponto.
            // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
            // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
            // `]` = fecha a lista, o acesso por índice ou a chave calculada.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
            // `hypot` = identificador de propriedade ou método chamado `hypot`, acessado a partir do objeto indicado antes do ponto.
            // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
            // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
            // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
            const largura = Math.hypot(poly[1].x - poly[0].x, poly[1].y - poly[0].y);

            // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
            // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
            // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `legal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a legal.
            // `capturada` = identificador que representa a peça capturada em uma jogada.
            // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
            if (legal.capturada || legal.enPassant) {

              // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
              // `'rgba(216,74,66,.94)'` = texto literal utilizado nesta instrução, contendo rgba(216,74,66,.94).
              // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
              // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
              ctx.strokeStyle = 'rgba(216,74,66,.94)';

              // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
              // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
              // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `0.075` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
              // `*` = realiza multiplicação.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
              // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
              // `largura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a largura.
              ctx.lineWidth = Math.max(2, largura * 0.075);

              // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
              // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
              ctx.beginPath();

              // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
              // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
              // `0.28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
              // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `*` = realiza multiplicação.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
              // `meio` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a meio.
              // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
              // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
              // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
              // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
              ctx.ellipse(meio.x, meio.y, largura * 0.28, largura * 0.16, 0, 0, Math.PI * 2);

              // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
              // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
              // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
              ctx.stroke();

            // Executa o bloco alternativo quando a condição anterior não foi atendida.
            // `else` = define o caminho executado quando a condição anterior não é atendida.
            // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
            // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
            } else {

              // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
              // `'rgba(62,150,91,.88)'` = texto literal utilizado nesta instrução, contendo rgba(62,150,91,.88).
              // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
              ctx.fillStyle = 'rgba(62,150,91,.88)';

              // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
              // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
              ctx.beginPath();

              // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
              // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
              // `0.09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `0.055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
              // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
              // `*` = realiza multiplicação.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
              // `meio` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a meio.
              // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
              // `largura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a largura.
              ctx.ellipse(meio.x, meio.y, largura * 0.09, largura * 0.055, 0, 0, Math.PI * 2);

              // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
              // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
              // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
              // `;` = encerra a instrução JavaScript atual.
              // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
              // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
              // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
              ctx.fill();

            // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
            // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
            }

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desenharCoordenadas` = acessa o atributo ou método `_desenharCoordenadas` pertencente à própria instância atual.
      // `this._desenharCoordenadas` = chama o método ou recurso `_desenharCoordenadas` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
      // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      this._desenharCoordenadas(ctx, cfg, w, h);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharCoordenadas` para executar a rotina correspondente a desenharCoordenadas.
    // `_desenharCoordenadas` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _desenharCoordenadas(ctx, cfg, w, h) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.font` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `font` = identificador de propriedade ou método chamado `font`, acessado a partir do objeto indicado antes do ponto.
      ctx.font = `700 ${Math.max(9, Math.min(14, w * 0.013))}px Segoe UI, Arial`;

      // Armazena ou atualiza o valor de `ctx.textAlign` utilizando o resultado definido nesta linha.
      // `'center'` = texto literal utilizado nesta instrução, contendo center.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `textAlign` = identificador de propriedade ou método chamado `textAlign`, acessado a partir do objeto indicado antes do ponto.
      ctx.textAlign = 'center';

      // Armazena ou atualiza o valor de `ctx.textBaseline` utilizando o resultado definido nesta linha.
      // `'middle'` = texto literal utilizado nesta instrução, contendo middle.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `textBaseline` = identificador de propriedade ou método chamado `textBaseline`, acessado a partir do objeto indicado antes do ponto.
      ctx.textBaseline = 'middle';

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `'rgba(244,224,187,.78)'` = texto literal utilizado nesta instrução, contendo rgba(244,224,187,.78).
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = 'rgba(244,224,187,.78)';

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
      for (let vc = 0; vc < 8; vc += 1) {

        // Declara `col` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `col` = identificador utilizado para armazenar ou acessar o valor relacionado a col.
        // `this._actualCol` = acessa o atributo ou método `_actualCol` pertencente à própria instância atual.
        // `this._actualCol` = chama o método ou recurso `_actualCol` pertencente à instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const col = this._actualCol(vc);

        // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
        // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
        // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
        // `0.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.993` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `/` = realiza divisão.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
        const p = this._projetar((vc + 0.5) / 8, 0.993, cfg);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.fillText` = chama a função ou método `fillText` pertencente ao objeto ou recurso indicado antes do ponto.
        // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
        // `9` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `fillText` = identificador de propriedade ou método chamado `fillText`, acessado a partir do objeto indicado antes do ponto.
        // `ARQUIVOS` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ARQUIVOS.
        // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
        // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
        // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
        ctx.fillText(ARQUIVOS[col], p.x, Math.min(h - 9, p.y - 4));

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Armazena ou atualiza o valor de `ctx.textAlign` utilizando o resultado definido nesta linha.
      // `'left'` = texto literal utilizado nesta instrução, contendo left.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `textAlign` = identificador de propriedade ou método chamado `textAlign`, acessado a partir do objeto indicado antes do ponto.
      ctx.textAlign = 'left';

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `vr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vr.
      for (let vr = 0; vr < 8; vr += 1) {

        // Declara `row` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `row` = identificador utilizado para armazenar ou acessar o valor relacionado a row.
        // `this._actualRow` = acessa o atributo ou método `_actualRow` pertencente à própria instância atual.
        // `this._actualRow` = chama o método ou recurso `_actualRow` pertencente à instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const row = this._actualRow(vr);

        // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
        // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
        // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
        // `0.005` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.52` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `/` = realiza divisão.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
        const p = this._projetar(0.005, (vr + 0.52) / 8, cfg);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.fillText` = chama a função ou método `fillText` pertencente ao objeto ou recurso indicado antes do ponto.
        // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
        // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `fillText` = identificador de propriedade ou método chamado `fillText`, acessado a partir do objeto indicado antes do ponto.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
        // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
        // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
        ctx.fillText(String(8 - row), Math.max(5, p.x + 5), p.y);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharPecas` para executar a rotina correspondente a desenharPecas.
    // `_desenharPecas` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
    // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
    _desenharPecas(ctx, w, h, cfg) {

      // Declara `pecas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `pecas` = identificador utilizado para armazenar ou acessar o valor relacionado a pecas.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const pecas = [];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
      for (let row = 0; row < 8; row += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
        for (let col = 0; col < 8; col += 1) {

          // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
          // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
          // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
          const peca = this.dados.tabuleiro?.[row]?.[col];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `continue` = encerra a iteração atual e avança para a próxima repetição.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          if (!peca) continue;

          // Declara `vr` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `vr` = identificador utilizado para armazenar ou acessar o valor relacionado a vr.
          // `this._viewRow` = acessa o atributo ou método `_viewRow` pertencente à própria instância atual.
          // `this._viewRow` = chama o método ou recurso `_viewRow` pertencente à instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
          const vr = this._viewRow(row);

          // Declara `vc` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `vc` = identificador utilizado para armazenar ou acessar o valor relacionado a vc.
          // `this._viewCol` = acessa o atributo ou método `_viewCol` pertencente à própria instância atual.
          // `this._viewCol` = chama o método ou recurso `_viewCol` pertencente à instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
          const vc = this._viewCol(col);

          // Declara `t` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `t` = identificador utilizado para armazenar ou acessar o valor relacionado a t.
          // `0.86` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `/` = realiza divisão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const t = (vr + 0.86) / 8;

          // Declara `base` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `base` = identificador utilizado para armazenar ou acessar o valor relacionado a base.
          // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
          // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
          // `0.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `/` = realiza divisão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
          const base = this._projetar((vc + 0.5) / 8, t, cfg);

          // Declara `esq` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `esq` = identificador utilizado para armazenar ou acessar o valor relacionado a esq.
          // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
          // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
          // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `/` = realiza divisão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
          const esq = this._projetar(vc / 8, t, cfg);

          // Declara `dir` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `dir` = identificador utilizado para armazenar ou acessar o valor relacionado a dir.
          // `this._projetar` = acessa o atributo ou método `_projetar` pertencente à própria instância atual.
          // `this._projetar` = chama o método ou recurso `_projetar` pertencente à instância atual.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `/` = realiza divisão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `t` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a t.
          const dir = this._projetar((vc + 1) / 8, t, cfg);

          // Declara `larguraCasa` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `larguraCasa` = identificador utilizado para armazenar ou acessar o valor relacionado a larguraCasa.
          // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
          // `Math.hypot` = chama a função ou método `hypot` pertencente ao objeto ou recurso indicado antes do ponto.
          // `12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
          // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
          // `hypot` = identificador de propriedade ou método chamado `hypot`, acessado a partir do objeto indicado antes do ponto.
          // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
          // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
          const larguraCasa = Math.max(12, Math.hypot(dir.x - esq.x, dir.y - esq.y));

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `pecas.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `pecas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pecas.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `row` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a row.
          // `col` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a col.
          // `vr` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vr.
          // `vc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a vc.
          // `peca` = identificador que representa uma peça de xadrez.
          // `base` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a base.
          pecas.push({ row, col, vr, vc, peca, base, larguraCasa });

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `pecas.sort` = chama a função ou método `sort` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `sort` = identificador de propriedade ou método chamado `sort`, acessado a partir do objeto indicado antes do ponto.
      // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
      // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
      pecas.sort((a, b) => a.vr - b.vr || a.vc - b.vc);

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `item` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a item.
      for (const item of pecas) {

        // Declara `selecionada` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `selecionada` = identificador utilizado para armazenar ou acessar o valor relacionado a selecionada.
        // `this.dados` = acessa o atributo ou método `dados` pertencente à própria instância atual.
        // `this._mesma` = acessa o atributo ou método `_mesma` pertencente à própria instância atual.
        // `this._mesma` = chama o método ou recurso `_mesma` pertencente à instância atual.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `row` = identificador de propriedade ou método chamado `row`, acessado a partir do objeto indicado antes do ponto.
        // `col` = identificador de propriedade ou método chamado `col`, acessado a partir do objeto indicado antes do ponto.
        const selecionada = this.dados.selecionada && this._mesma(this.dados.selecionada, [item.row, item.col]);

        // Declara `escala` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `escala` = identificador utilizado para armazenar ou acessar o valor relacionado a escala.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `*` = realiza multiplicação.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `larguraCasa` = identificador de propriedade ou método chamado `larguraCasa`, acessado a partir do objeto indicado antes do ponto.
        // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
        // `escalaPeca` = identificador de propriedade ou método chamado `escalaPeca`, acessado a partir do objeto indicado antes do ponto.
        const escala = item.larguraCasa * cfg.escalaPeca;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
        ctx.save();

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `'blur(0.35px)'` = texto literal utilizado nesta instrução, contendo blur(0.35px).
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `item` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a item.
        // `vr` = identificador de propriedade ou método chamado `vr`, acessado a partir do objeto indicado antes do ponto.
        // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
        if (item.vr <= 1) ctx.filter = 'blur(0.35px)';

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this._desenharPeca` = acessa o atributo ou método `_desenharPeca` pertencente à própria instância atual.
        // `this._desenharPeca` = chama o método ou recurso `_desenharPeca` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `base` = identificador de propriedade ou método chamado `base`, acessado a partir do objeto indicado antes do ponto.
        // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
        // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
        // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
        this._desenharPeca(ctx, item.peca.tipo, item.peca.cor, item.base.x, item.base.y, escala, selecionada, item.vr);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
        ctx.restore();

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_paleta` para executar a rotina correspondente a paleta.
    // `_paleta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _paleta(cor) {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `'branco'` = texto literal utilizado nesta instrução, contendo branco.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (cor === 'branco') {

        // Retorna `{` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        return {

          // Define a propriedade `claro` do objeto com o valor informado nesta linha.
          // `'#fffef8'` = texto literal utilizado nesta instrução, contendo #fffef8.
          // `'#efe4d1'` = texto literal utilizado nesta instrução, contendo #efe4d1.
          // `'#d6c3a4'` = texto literal utilizado nesta instrução, contendo #d6c3a4.
          // `'#9a8160'` = texto literal utilizado nesta instrução, contendo #9a8160.
          // `'rgba(104,82,55,.62)'` = texto literal utilizado nesta instrução, contendo rgba(104,82,55,.62).
          // `'rgba(255,255,255,.94)'` = texto literal utilizado nesta instrução, contendo rgba(255,255,255,.94).
          // `'rgba(39,27,17,.48)'` = texto literal utilizado nesta instrução, contendo rgba(39,27,17,.48).
          // `'#23543a'` = texto literal utilizado nesta instrução, contendo #23543a.
          // `'#32271e'` = texto literal utilizado nesta instrução, contendo #32271e.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `claro` = identificador usado como nome da propriedade `claro` dentro do objeto atual.
          // `medio` = identificador usado como nome da propriedade `medio` dentro do objeto atual.
          // `base` = identificador usado como nome da propriedade `base` dentro do objeto atual.
          // `escuro` = identificador usado como nome da propriedade `escuro` dentro do objeto atual.
          // `borda` = identificador usado como nome da propriedade `borda` dentro do objeto atual.
          // `reflexo` = identificador usado como nome da propriedade `reflexo` dentro do objeto atual.
          // `sombra` = identificador usado como nome da propriedade `sombra` dentro do objeto atual.
          // `feltro` = identificador usado como nome da propriedade `feltro` dentro do objeto atual.
          // `olho` = identificador usado como nome da propriedade `olho` dentro do objeto atual.
          claro: '#fffef8', medio: '#efe4d1', base: '#d6c3a4', escuro: '#9a8160', borda: 'rgba(104,82,55,.62)', reflexo: 'rgba(255,255,255,.94)', sombra: 'rgba(39,27,17,.48)', feltro: '#23543a', olho: '#32271e',

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        };

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `{` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      return {

        // Define a propriedade `claro` do objeto com o valor informado nesta linha.
        // `'#858278'` = texto literal utilizado nesta instrução, contendo #858278.
        // `'#3a3c36'` = texto literal utilizado nesta instrução, contendo #3a3c36.
        // `'#1a1c19'` = texto literal utilizado nesta instrução, contendo #1a1c19.
        // `'#050605'` = texto literal utilizado nesta instrução, contendo #050605.
        // `'rgba(0,0,0,.82)'` = texto literal utilizado nesta instrução, contendo rgba(0,0,0,.82).
        // `'rgba(244,222,169,.30)'` = texto literal utilizado nesta instrução, contendo rgba(244,222,169,.30).
        // `'rgba(0,0,0,.72)'` = texto literal utilizado nesta instrução, contendo rgba(0,0,0,.72).
        // `'#17442f'` = texto literal utilizado nesta instrução, contendo #17442f.
        // `'#d7b86f'` = texto literal utilizado nesta instrução, contendo #d7b86f.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        claro: '#858278', medio: '#3a3c36', base: '#1a1c19', escuro: '#050605', borda: 'rgba(0,0,0,.82)', reflexo: 'rgba(244,222,169,.30)', sombra: 'rgba(0,0,0,.72)', feltro: '#17442f', olho: '#d7b86f',

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharPeca` para executar a rotina correspondente a desenharPeca.
    // `_desenharPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
    // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
    // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
    // `escala` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a escala.
    // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
    // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
    _desenharPeca(ctx, tipo, cor, x, baseY, escala, selecionada, profundidade) {

      // Declara `fatores` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `fatores` = identificador utilizado para armazenar ou acessar o valor relacionado a fatores.
      // `1.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.58` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.80` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `2.02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `2.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peao` = identificador usado como nome da propriedade `peao` dentro do objeto atual.
      // `torre` = identificador usado como nome da propriedade `torre` dentro do objeto atual.
      // `cavalo` = identificador usado como nome da propriedade `cavalo` dentro do objeto atual.
      // `bispo` = identificador usado como nome da propriedade `bispo` dentro do objeto atual.
      // `dama` = identificador usado como nome da propriedade `dama` dentro do objeto atual.
      // `rei` = identificador usado como nome da propriedade `rei` dentro do objeto atual.
      const fatores = { peao: 1.38, torre: 1.58, cavalo: 1.72, bispo: 1.80, dama: 2.02, rei: 2.13 };

      // Declara `h` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `h` = identificador utilizado para armazenar ou acessar o valor relacionado a h.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `26` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      const h = Math.max(26, escala * (fatores[tipo] || 1.6));

      // Declara `maxH` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `maxH` = identificador utilizado para armazenar ou acessar o valor relacionado a maxH.
      // `this._ultimoTamanho` = acessa o atributo ou método `_ultimoTamanho` pertencente à própria instância atual.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'lateral'` = texto literal utilizado nesta instrução, contendo lateral.
      // `0.55` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.43` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const maxH = this._ultimoTamanho.h * (this.camera === 'lateral' ? 0.55 : 0.43);

      // Declara `altura` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `altura` = identificador utilizado para armazenar ou acessar o valor relacionado a altura.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      const altura = Math.min(h, maxH);

      // Declara `pal` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `pal` = identificador utilizado para armazenar ou acessar o valor relacionado a pal.
      // `this._paleta` = acessa o atributo ou método `_paleta` pertencente à própria instância atual.
      // `this._paleta` = chama o método ou recurso `_paleta` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
      const pal = this._paleta(cor);

      // Declara `opacidadeSombra` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `opacidadeSombra` = identificador utilizado para armazenar ou acessar o valor relacionado a opacidadeSombra.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.66` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `0.30` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `0.04` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
      const opacidadeSombra = Math.min(0.66, 0.30 + profundidade * 0.04);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = opacidadeSombra;

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `'#000'` = texto literal utilizado nesta instrução, contendo #000.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = '#000';

      // Armazena ou atualiza o valor de `ctx.filter` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
      ctx.filter = `blur(${Math.max(1, escala * 0.055)}px)`;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.065` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.04` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `escala` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a escala.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      // `-0.04` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      ctx.ellipse(x + escala * 0.06, baseY + escala * 0.065, escala * 0.38, escala * 0.12, -0.04, 0, Math.PI * 2);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
      if (selecionada) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
        ctx.save();

        // Armazena ou atualiza o valor de `ctx.shadowColor` utilizando o resultado definido nesta linha.
        // `'rgba(255,213,91,.9)'` = texto literal utilizado nesta instrução, contendo rgba(255,213,91,.9).
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `shadowColor` = identificador de propriedade ou método chamado `shadowColor`, acessado a partir do objeto indicado antes do ponto.
        ctx.shadowColor = 'rgba(255,213,91,.9)';

        // Armazena ou atualiza o valor de `ctx.shadowBlur` utilizando o resultado definido nesta linha.
        // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
        // `12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `shadowBlur` = identificador de propriedade ou método chamado `shadowBlur`, acessado a partir do objeto indicado antes do ponto.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
        // `escala` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a escala.
        ctx.shadowBlur = Math.max(12, escala * 0.28);

        // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
        // `'rgba(255,225,121,.82)'` = texto literal utilizado nesta instrução, contendo rgba(255,225,121,.82).
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
        ctx.strokeStyle = 'rgba(255,225,121,.82)';

        // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
        // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
        ctx.lineWidth = Math.max(2, escala * 0.035);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
        ctx.beginPath();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0.40` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
        // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
        // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
        // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
        ctx.ellipse(x, baseY, escala * 0.40, escala * 0.12, 0, 0, Math.PI * 2);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
        ctx.stroke();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
        ctx.restore();

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `feltro` = identificador de propriedade ou método chamado `feltro`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = pal.feltro;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.01` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.34` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `escala` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a escala.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      ctx.ellipse(x, baseY - escala * 0.01, escala * 0.34, escala * 0.105, 0, 0, Math.PI * 2);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._cavalo` = acessa o atributo ou método `_cavalo` pertencente à própria instância atual.
      // `this._cavalo` = chama o método ou recurso `_cavalo` pertencente à instância atual.
      // `'cavalo'` = texto literal utilizado nesta instrução, contendo cavalo.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
      // `altura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a altura.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      if (tipo === 'cavalo') this._cavalo(ctx, x, baseY, altura, pal);

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._torre` = acessa o atributo ou método `_torre` pertencente à própria instância atual.
      // `this._torre` = chama o método ou recurso `_torre` pertencente à instância atual.
      // `'torre'` = texto literal utilizado nesta instrução, contendo torre.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      else if (tipo === 'torre') this._torre(ctx, x, baseY, altura, pal);

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._bispo` = acessa o atributo ou método `_bispo` pertencente à própria instância atual.
      // `this._bispo` = chama o método ou recurso `_bispo` pertencente à instância atual.
      // `'bispo'` = texto literal utilizado nesta instrução, contendo bispo.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      else if (tipo === 'bispo') this._bispo(ctx, x, baseY, altura, pal);

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._dama` = acessa o atributo ou método `_dama` pertencente à própria instância atual.
      // `this._dama` = chama o método ou recurso `_dama` pertencente à instância atual.
      // `'dama'` = texto literal utilizado nesta instrução, contendo dama.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
      else if (tipo === 'dama') this._dama(ctx, x, baseY, altura, pal);

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._rei` = acessa o atributo ou método `_rei` pertencente à própria instância atual.
      // `this._rei` = chama o método ou recurso `_rei` pertencente à instância atual.
      // `'rei'` = texto literal utilizado nesta instrução, contendo rei.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `altura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a altura.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      else if (tipo === 'rei') this._rei(ctx, x, baseY, altura, pal);

      // Executa o bloco alternativo quando a condição anterior não foi atendida.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._peao` = acessa o atributo ou método `_peao` pertencente à própria instância atual.
      // `this._peao` = chama o método ou recurso `_peao` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      else this._peao(ctx, x, baseY, altura, pal);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_gradienteMaterial` para executar a rotina correspondente a gradienteMaterial.
    // `_gradienteMaterial` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `largura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a largura.
    _gradienteMaterial(ctx, x, largura, pal) {

      // Declara `g` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `g` = identificador utilizado para armazenar ou acessar o valor relacionado a g.
      // `ctx.createLinearGradient` = chama a função ou método `createLinearGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `createLinearGradient` = identificador de propriedade ou método chamado `createLinearGradient`, acessado a partir do objeto indicado antes do ponto.
      const g = ctx.createLinearGradient(x - largura, 0, x + largura, 0);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `escuro` = identificador de propriedade ou método chamado `escuro`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0, pal.escuro);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `base` = identificador de propriedade ou método chamado `base`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0.20, pal.base);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.43` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `claro` = identificador de propriedade ou método chamado `claro`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0.43, pal.claro);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.58` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `g` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a g.
      // `medio` = identificador de propriedade ou método chamado `medio`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0.58, pal.medio);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.82` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      g.addColorStop(0.82, pal.base);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `escuro` = identificador de propriedade ou método chamado `escuro`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(1, pal.escuro);

      // Retorna `g` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return g;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_basePeca` para executar a rotina correspondente a basePeca.
    // `_basePeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `0.245` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
    // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
    // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
    // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
    // `largura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a largura.
    _basePeca(ctx, x, baseY, h, pal, largura = 0.245) {

      // Declara `r` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `r` = identificador utilizado para armazenar ou acessar o valor relacionado a r.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      const r = h * largura;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      ctx.fillStyle = this._gradienteMaterial(ctx, x, r, pal);

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = pal.borda;

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.007` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineWidth = Math.max(0.8, h * 0.007);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.92` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `r` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a r.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      ctx.moveTo(x - r * 0.92, baseY - h * 0.055);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1.10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.92` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.bezierCurveTo(x - r * 1.10, baseY - h * 0.105, x - r * 0.92, baseY - h * 0.15, x - r * 0.72, baseY - h * 0.18);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineTo(x + r * 0.72, baseY - h * 0.18);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.92` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `r` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a r.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      ctx.bezierCurveTo(x + r * 0.92, baseY - h * 0.15, x + r * 1.10, baseY - h * 0.105, x + r * 0.92, baseY - h * 0.055);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.quadraticCurveTo` = chama a função ou método `quadraticCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.015` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.92` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `quadraticCurveTo` = identificador de propriedade ou método chamado `quadraticCurveTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.quadraticCurveTo(x, baseY + h * 0.015, x - r * 0.92, baseY - h * 0.055);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill(); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.75` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.052` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `r` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a r.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      ctx.ellipse(x, baseY - h * 0.18, r * 0.75, h * 0.052, 0, 0, Math.PI * 2);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.fill(); ctx.stroke();

      // Declara `shine` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `shine` = identificador utilizado para armazenar ou acessar o valor relacionado a shine.
      // `ctx.createLinearGradient` = chama a função ou método `createLinearGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `0.35` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `createLinearGradient` = identificador de propriedade ou método chamado `createLinearGradient`, acessado a partir do objeto indicado antes do ponto.
      const shine = ctx.createLinearGradient(x - r * 0.4, 0, x + r * 0.35, 0);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `shine.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(255,255,255,0)'` = texto literal utilizado nesta instrução, contendo rgba(255,255,255,0).
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      shine.addColorStop(0, 'rgba(255,255,255,0)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `shine.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.55` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `reflexo` = identificador de propriedade ou método chamado `reflexo`, acessado a partir do objeto indicado antes do ponto.
      shine.addColorStop(0.55, pal.reflexo);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `shine.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(255,255,255,0)'` = texto literal utilizado nesta instrução, contendo rgba(255,255,255,0).
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `shine` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a shine.
      shine.addColorStop(1, 'rgba(255,255,255,0)');

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `0.28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = 0.28;

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = shine;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.116` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.62` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.046` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `r` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a r.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      ctx.ellipse(x - r * 0.12, baseY - h * 0.116, r * 0.62, h * 0.046, 0, 0, Math.PI * 2);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_corpoPerfil` para executar a rotina correspondente a corpoPerfil.
    // `_corpoPerfil` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    // `perfil` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a perfil.
    // `inicioY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a inicioY.
    _corpoPerfil(ctx, x, baseY, h, pal, perfil, inicioY = 0.18) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Declara `maxR` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `maxR` = identificador utilizado para armazenar ou acessar o valor relacionado a maxR.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `perfil.map` = chama a função ou método `map` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
      // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const maxR = Math.max(...perfil.map((p) => p[1])) * h;

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      ctx.fillStyle = this._gradienteMaterial(ctx, x, maxR, pal);

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = pal.borda;

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.006` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      ctx.lineWidth = Math.max(0.8, h * 0.006);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Declara `primeiro` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `primeiro` = identificador utilizado para armazenar ou acessar o valor relacionado a primeiro.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `perfil` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a perfil.
      const primeiro = perfil[0];

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      ctx.moveTo(x - primeiro[1] * h, baseY - primeiro[0] * h);

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      for (let i = 1; i < perfil.length; i += 1) {

        // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        const p = perfil[i];

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
        ctx.lineTo(x - p[1] * h, baseY - p[0] * h);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `perfil` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a perfil.
      for (let i = perfil.length - 1; i >= 0; i -= 1) {

        // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
        const p = perfil[i];

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
        // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
        // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
        // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
        ctx.lineTo(x + p[1] * h, baseY - p[0] * h);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill(); ctx.stroke();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `0.29` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = 0.29;

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `reflexo` = identificador de propriedade ou método chamado `reflexo`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = pal.reflexo;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `maxR` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a maxR.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `inicioY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a inicioY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.moveTo(x - maxR * 0.28, baseY - inicioY * h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.34` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.58` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.bezierCurveTo(x - maxR * 0.06, baseY - h * 0.34, x - maxR * 0.05, baseY - h * 0.58, x - maxR * 0.10, baseY - h * 0.72);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.lineTo(x + maxR * 0.02, baseY - h * 0.72);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.50` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.30` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `maxR` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a maxR.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `inicioY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a inicioY.
      ctx.bezierCurveTo(x + maxR * 0.05, baseY - h * 0.50, x + maxR * 0.02, baseY - h * 0.30, x - maxR * 0.13, baseY - inicioY * h);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_anel` para executar a rotina correspondente a anel.
    // `_anel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
    // `y` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a y.
    // `rx` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a rx.
    // `ry` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ry.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    _anel(ctx, x, y, rx, ry, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      ctx.fillStyle = this._gradienteMaterial(ctx, x, rx, pal);

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = pal.borda;

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      ctx.lineWidth = Math.max(0.7, rx * 0.035);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.ellipse` = chama a função ou método `ellipse` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      // `ellipse` = identificador de propriedade ou método chamado `ellipse`, acessado a partir do objeto indicado antes do ponto.
      // `y` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a y.
      // `rx` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a rx.
      // `ry` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ry.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_esfera` para executar a rotina correspondente a esfera.
    // `_esfera` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
    // `r` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a r.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    _esfera(ctx, x, y, r, pal) {

      // Declara `g` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `g` = identificador utilizado para armazenar ou acessar o valor relacionado a g.
      // `ctx.createRadialGradient` = chama a função ou método `createRadialGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.35` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.42` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.08` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `createRadialGradient` = identificador de propriedade ou método chamado `createRadialGradient`, acessado a partir do objeto indicado antes do ponto.
      const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.42, r * 0.08, x, y, r * 1.15);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      // `claro` = identificador de propriedade ou método chamado `claro`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0, pal.claro);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.34` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `medio` = identificador de propriedade ou método chamado `medio`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0.34, pal.medio);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `base` = identificador de propriedade ou método chamado `base`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(0.72, pal.base);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `g` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a g.
      // `escuro` = identificador de propriedade ou método chamado `escuro`, acessado a partir do objeto indicado antes do ponto.
      g.addColorStop(1, pal.escuro);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = g;

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = pal.borda;

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.08` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `r` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a r.
      ctx.lineWidth = Math.max(0.8, r * 0.08);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.arc` = chama a função ou método `arc` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      // `arc` = identificador de propriedade ou método chamado `arc`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `y` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a y.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_peao` para executar a rotina correspondente a peao.
    // `_peao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
    // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    _peao(ctx, x, baseY, h, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._basePeca` = acessa o atributo ou método `_basePeca` pertencente à própria instância atual.
      // `this._basePeca` = chama o método ou recurso `_basePeca` pertencente à instância atual.
      // `0.24` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._basePeca(ctx, x, baseY, h, pal, 0.24);

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._corpoPerfil` = acessa o atributo ou método `_corpoPerfil` pertencente à própria instância atual.
      // `this._corpoPerfil` = chama o método ou recurso `_corpoPerfil` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      this._corpoPerfil(ctx, x, baseY, h, pal, [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.23` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.54` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.075` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.61` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.11` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.64` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        [0.18,0.18],[0.23,0.15],[0.38,0.105],[0.54,0.075],[0.61,0.11],[0.64,0.13],

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._anel` = acessa o atributo ou método `_anel` pertencente à própria instância atual.
      // `this._anel` = chama o método ou recurso `_anel` pertencente à instância atual.
      // `0.64` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.032` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._anel(ctx, x, baseY - h * 0.64, h * 0.13, h * 0.032, pal);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._esfera` = acessa o atributo ou método `_esfera` pertencente à própria instância atual.
      // `this._esfera` = chama o método ou recurso `_esfera` pertencente à instância atual.
      // `0.78` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      this._esfera(ctx, x, baseY - h * 0.78, h * 0.13, pal);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_torre` para executar a rotina correspondente a torre.
    // `_torre` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _torre(ctx, x, baseY, h, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._basePeca` = acessa o atributo ou método `_basePeca` pertencente à própria instância atual.
      // `this._basePeca` = chama o método ou recurso `_basePeca` pertencente à instância atual.
      // `0.255` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._basePeca(ctx, x, baseY, h, pal, 0.255);

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._corpoPerfil` = acessa o atributo ou método `_corpoPerfil` pertencente à própria instância atual.
      // `this._corpoPerfil` = chama o método ou recurso `_corpoPerfil` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._corpoPerfil(ctx, x, baseY, h, pal, [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.19` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.50` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.66` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        [0.18,0.19],[0.25,0.16],[0.50,0.105],[0.66,0.12],[0.70,0.19],

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._anel` = acessa o atributo ou método `_anel` pertencente à própria instância atual.
      // `this._anel` = chama o método ou recurso `_anel` pertencente à instância atual.
      // `0.70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      this._anel(ctx, x, baseY - h * 0.70, h * 0.20, h * 0.035, pal);

      // Declara `topY` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `topY` = identificador utilizado para armazenar ou acessar o valor relacionado a topY.
      // `0.89` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const topY = baseY - h * 0.89;

      // Declara `half` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `half` = identificador utilizado para armazenar ou acessar o valor relacionado a half.
      // `0.205` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const half = h * 0.205;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      ctx.fillStyle = this._gradienteMaterial(ctx, x, half, pal);

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      ctx.strokeStyle = pal.borda;

      // Armazena ou atualiza o valor de `ctx.lineWidth` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.006` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineWidth = Math.max(0.8, h * 0.006);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `half` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a half.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      ctx.moveTo(x - half, baseY - h * 0.72);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `topY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a topY.
      ctx.lineTo(x - half, topY);

      // Declara `d` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `d` = identificador utilizado para armazenar ou acessar o valor relacionado a d.
      // `0.42` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const d = half * 0.42;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineTo(x - half, topY - h * 0.06);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      ctx.lineTo(x - half + d, topY - h * 0.06);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `half` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a half.
      ctx.lineTo(x - half + d, topY);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `d` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a d.
      // `topY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a topY.
      ctx.lineTo(x - d * 0.38, topY);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineTo(x - d * 0.38, topY - h * 0.06);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      ctx.lineTo(x + d * 0.38, topY - h * 0.06);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.38` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.lineTo(x + d * 0.38, topY);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `half` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a half.
      // `d` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a d.
      // `topY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a topY.
      ctx.lineTo(x + half - d, topY);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.lineTo(x + half - d, topY - h * 0.06);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      ctx.lineTo(x + half, topY - h * 0.06);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      ctx.lineTo(x + half, baseY - h * 0.72);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.fill(); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_bispo` para executar a rotina correspondente a bispo.
    // `_bispo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
    // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    _bispo(ctx, x, baseY, h, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._basePeca` = acessa o atributo ou método `_basePeca` pertencente à própria instância atual.
      // `this._basePeca` = chama o método ou recurso `_basePeca` pertencente à instância atual.
      // `0.245` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      this._basePeca(ctx, x, baseY, h, pal, 0.245);

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._corpoPerfil` = acessa o atributo ou método `_corpoPerfil` pertencente à própria instância atual.
      // `this._corpoPerfil` = chama o método ou recurso `_corpoPerfil` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      this._corpoPerfil(ctx, x, baseY, h, pal, [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.45` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.62` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.07` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.73` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.135` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        [0.18,0.18],[0.25,0.15],[0.45,0.09],[0.62,0.07],[0.70,0.12],[0.73,0.135],

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._anel` = acessa o atributo ou método `_anel` pertencente à própria instância atual.
      // `this._anel` = chama o método ou recurso `_anel` pertencente à instância atual.
      // `0.72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.135` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.028` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._anel(ctx, x, baseY - h * 0.72, h * 0.135, h * 0.028, pal);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Declara `g` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `g` = identificador utilizado para armazenar ou acessar o valor relacionado a g.
      // `ctx.createRadialGradient` = chama a função ou método `createRadialGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.86` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.015` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.85` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `createRadialGradient` = identificador de propriedade ou método chamado `createRadialGradient`, acessado a partir do objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      const g = ctx.createRadialGradient(x - h * 0.035, baseY - h * 0.86, h * 0.015, x, baseY - h * 0.85, h * 0.16);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `g.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `48` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      // `claro` = identificador de propriedade ou método chamado `claro`, acessado a partir do objeto indicado antes do ponto.
      // `medio` = identificador de propriedade ou método chamado `medio`, acessado a partir do objeto indicado antes do ponto.
      // `escuro` = identificador de propriedade ou método chamado `escuro`, acessado a partir do objeto indicado antes do ponto.
      // `.48` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      g.addColorStop(0, pal.claro); g.addColorStop(.48, pal.medio); g.addColorStop(1, pal.escuro);

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `006` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `.8` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.006` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.fillStyle = g; ctx.strokeStyle = pal.borda; ctx.lineWidth = Math.max(.8, h * .006);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1.02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      ctx.moveTo(x, baseY - h * 1.02);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.94` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.82` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.74` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      ctx.bezierCurveTo(x - h * 0.13, baseY - h * 0.94, x - h * 0.15, baseY - h * 0.82, x, baseY - h * 0.74);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.82` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.94` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      ctx.bezierCurveTo(x + h * 0.15, baseY - h * 0.82, x + h * 0.13, baseY - h * 0.94, x, baseY - h * 1.02);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.fill(); ctx.stroke();

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1.1` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.018` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `78` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `escuro` = identificador de propriedade ou método chamado `escuro`, acessado a partir do objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      // `.78` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.strokeStyle = pal.escuro; ctx.lineWidth = Math.max(1.1, h * 0.018); ctx.globalAlpha = .78;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `045` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `94` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `82` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `.045` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.94` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.05` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.82` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.beginPath(); ctx.moveTo(x - h * .045, baseY - h * .94); ctx.lineTo(x + h * .05, baseY - h * .82); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_dama` para executar a rotina correspondente a dama.
    // `_dama` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    _dama(ctx, x, baseY, h, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._basePeca` = acessa o atributo ou método `_basePeca` pertencente à própria instância atual.
      // `this._basePeca` = chama o método ou recurso `_basePeca` pertencente à instância atual.
      // `0.26` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._basePeca(ctx, x, baseY, h, pal, 0.26);

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._corpoPerfil` = acessa o atributo ou método `_corpoPerfil` pertencente à própria instância atual.
      // `this._corpoPerfil` = chama o método ou recurso `_corpoPerfil` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      this._corpoPerfil(ctx, x, baseY, h, pal, [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.19` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.48` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.095` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.66` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.075` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.73` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.76` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        [0.18,0.19],[0.25,0.16],[0.48,0.095],[0.66,0.075],[0.73,0.14],[0.76,0.16],

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._anel` = acessa o atributo ou método `_anel` pertencente à própria instância atual.
      // `this._anel` = chama o método ou recurso `_anel` pertencente à instância atual.
      // `0.75` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.031` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._anel(ctx, x, baseY - h * 0.75, h * 0.17, h * 0.031, pal);

      // Declara `cy` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `cy` = identificador utilizado para armazenar ou acessar o valor relacionado a cy.
      // `0.86` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const cy = baseY - h * 0.86;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `.18` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.fillStyle = this._gradienteMaterial(ctx, x, h * .18, pal);

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `.8` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.0055` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.strokeStyle = pal.borda; ctx.lineWidth = Math.max(.8, h * .0055);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `cy` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cy.
      // `.17` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.05` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.moveTo(x - h*.17, cy + h*.05);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `.14` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.09` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x - h*.14, cy - h*.09);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `065` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `015` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `.065` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.015` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x - h*.065, cy - h*.015);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `.13` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x, cy - h*.13);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `065` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `015` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `cy` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cy.
      ctx.lineTo(x + h*.065, cy - h*.015);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `.14` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.09` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x + h*.14, cy - h*.09);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `.17` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.05` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x + h*.17, cy + h*.05);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.fill(); ctx.stroke();

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `this._esfera` = acessa o atributo ou método `_esfera` pertencente à própria instância atual.
      // `this._esfera` = chama o método ou recurso `_esfera` pertencente à instância atual.
      // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `065` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `01` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `145` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `027` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dx` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dx.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `cy` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cy.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `abs` = identificador de propriedade ou método chamado `abs`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `-.14` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      // `-.065` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      // `.065` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.14` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.01` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.145` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.105` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.027` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      for (const dx of [-.14,-.065,0,.065,.14]) this._esfera(ctx, x + h*dx, cy - h*(Math.abs(dx) < .01 ? .145 : .105), h*.027, pal);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_rei` para executar a rotina correspondente a rei.
    // `_rei` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
    _rei(ctx, x, baseY, h, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._basePeca` = acessa o atributo ou método `_basePeca` pertencente à própria instância atual.
      // `this._basePeca` = chama o método ou recurso `_basePeca` pertencente à instância atual.
      // `0.27` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._basePeca(ctx, x, baseY, h, pal, 0.27);

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._corpoPerfil` = acessa o atributo ou método `_corpoPerfil` pertencente à própria instância atual.
      // `this._corpoPerfil` = chama o método ou recurso `_corpoPerfil` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._corpoPerfil(ctx, x, baseY, h, pal, [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.26` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.50` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.69` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.078` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.75` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.145` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.78` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0.16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        [0.18,0.20],[0.26,0.17],[0.50,0.10],[0.69,0.078],[0.75,0.145],[0.78,0.16],

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._anel` = acessa o atributo ou método `_anel` pertencente à própria instância atual.
      // `this._anel` = chama o método ou recurso `_anel` pertencente à instância atual.
      // `0.77` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.165` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.032` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      this._anel(ctx, x, baseY - h * 0.77, h * 0.165, h * 0.032, pal);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._esfera` = acessa o atributo ou método `_esfera` pertencente à própria instância atual.
      // `this._esfera` = chama o método ou recurso `_esfera` pertencente à instância atual.
      // `0.87` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.07` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._esfera(ctx, x, baseY - h * 0.87, h * 0.07, pal);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `07` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `.07` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.fillStyle = this._gradienteMaterial(ctx, x, h * .07, pal);

      // Armazena ou atualiza o valor de `ctx.strokeStyle` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `006` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `.8` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.006` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.strokeStyle = pal.borda; ctx.lineWidth = Math.max(.8, h * .006);

      // Declara `y` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `y` = identificador utilizado para armazenar ou acessar o valor relacionado a y.
      // `1.02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const y = baseY - h * 1.02;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.roundRect` = chama a função ou método `roundRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `032` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `064` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `015` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `roundRect` = identificador de propriedade ou método chamado `roundRect`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `.032` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.064` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.18` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.015` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.roundRect(x - h*.032, y, h*.064, h*.18, h*.015);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill(); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.roundRect` = chama a função ou método `roundRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `09` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `055` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `014` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `y` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a y.
      // `.09` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.055` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.06` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.014` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.roundRect(x - h*.09, y + h*.055, h*.18, h*.06, h*.014);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.fill(); ctx.stroke();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_cavalo` para executar a rotina correspondente a cavalo.
    // `_cavalo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
    // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
    // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
    _cavalo(ctx, x, baseY, h, pal) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._basePeca` = acessa o atributo ou método `_basePeca` pertencente à própria instância atual.
      // `this._basePeca` = chama o método ou recurso `_basePeca` pertencente à instância atual.
      // `0.26` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      this._basePeca(ctx, x, baseY, h, pal, 0.26);

      // Declara `g` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `g` = identificador utilizado para armazenar ou acessar o valor relacionado a g.
      // `this._gradienteMaterial` = acessa o atributo ou método `_gradienteMaterial` pertencente à própria instância atual.
      // `this._gradienteMaterial` = chama o método ou recurso `_gradienteMaterial` pertencente à instância atual.
      // `25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `.25` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      const g = this._gradienteMaterial(ctx, x, h * .25, pal);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `006` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `strokeStyle` = identificador de propriedade ou método chamado `strokeStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `borda` = identificador de propriedade ou método chamado `borda`, acessado a partir do objeto indicado antes do ponto.
      // `lineWidth` = identificador de propriedade ou método chamado `lineWidth`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `.8` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.006` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.fillStyle = g; ctx.strokeStyle = pal.borda; ctx.lineWidth = Math.max(.8, h * .006);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `.18` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.moveTo(x - h*.18, baseY - h*.18);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `36` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `11` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `50` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `04` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `62` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      // `.16` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.36` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.11` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.50` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.04` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.62` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x - h*.16, baseY - h*.36, x - h*.11, baseY - h*.50, x - h*.04, baseY - h*.62);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `11` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `79` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `90` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `.02` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.70` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.79` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.13` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.90` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x - h*.02, baseY - h*.70, x - h*.11, baseY - h*.79, x - h*.13, baseY - h*.90);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `07` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.00` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `.07` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x - h*.07, baseY - h*1.00);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `015` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `91` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `.015` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.91` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x - h*.015, baseY - h*.91);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `96` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `15` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `91` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `83` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      // `.05` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.96` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.15` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.20` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.83` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x + h*.05, baseY - h*.96, x + h*.15, baseY - h*.91, x + h*.20, baseY - h*.83);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `75` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `.28` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.75` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x + h*.28, baseY - h*.75);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `30` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `66` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `67` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `.30` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.70` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.25` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.66` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.18` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.67` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x + h*.30, baseY - h*.70, x + h*.25, baseY - h*.66, x + h*.18, baseY - h*.67);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `08` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `69` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `.08` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.69` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x + h*.08, baseY - h*.69);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `59` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `49` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `16` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `36` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `.13` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.59` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.17` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.49` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.16` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.36` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x + h*.13, baseY - h*.59, x + h*.17, baseY - h*.49, x + h*.16, baseY - h*.36);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `17` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `21` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `.21` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x + h*.17, baseY - h*.21);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.quadraticCurveTo` = chama a função ou método `quadraticCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `quadraticCurveTo` = identificador de propriedade ou método chamado `quadraticCurveTo`, acessado a partir do objeto indicado antes do ponto.
      // `.18` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.quadraticCurveTo(x, baseY - h*.13, x - h*.18, baseY - h*.18);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.fill(); ctx.stroke();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `24` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `reflexo` = identificador de propriedade ou método chamado `reflexo`, acessado a partir do objeto indicado antes do ponto.
      // `.24` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.globalAlpha = .24; ctx.fillStyle = pal.reflexo;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `83` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `.06` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.83` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.moveTo(x - h*.06, baseY - h*.83);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `02` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `89` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `84` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `19` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `77` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `bezierCurveTo` = identificador de propriedade ou método chamado `bezierCurveTo`, acessado a partir do objeto indicado antes do ponto.
      // `.02` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.89` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.14` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.84` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.19` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.77` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x + h*.02, baseY - h*.89, x + h*.14, baseY - h*.84, x + h*.19, baseY - h*.77);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `12` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `76` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      // `.12` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.76` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.lineTo(x + h*.12, baseY - h*.76);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.bezierCurveTo` = chama a função ou método `bezierCurveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `05` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `80` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `78` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `06` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `72` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `.05` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.80` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.78` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.06` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.72` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.bezierCurveTo(x + h*.05, baseY - h*.80, x, baseY - h*.78, x - h*.06, baseY - h*.72);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.fill();

      // Armazena ou atualiza o valor de `ctx.globalAlpha` utilizando o resultado definido nesta linha.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `globalAlpha` = identificador de propriedade ou método chamado `globalAlpha`, acessado a partir do objeto indicado antes do ponto.
      ctx.globalAlpha = 1;

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      // `olho` = identificador de propriedade ou método chamado `olho`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = pal.olho;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.arc` = chama a função ou método `arc` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `105` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `81` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1.1` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `012` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      // `arc` = identificador de propriedade ou método chamado `arc`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      // `baseY` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a baseY.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `PI` = identificador de propriedade ou método chamado `PI`, acessado a partir do objeto indicado antes do ponto.
      // `.105` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.81` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      // `.012` = valor numérico utilizado nesta linha como índice, quantidade, coordenada, limite, pontuação, tempo ou parte de um cálculo.
      ctx.beginPath(); ctx.arc(x + h*.105, baseY - h*.81, Math.max(1.1, h*.012), 0, Math.PI*2); ctx.fill();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._anel` = acessa o atributo ou método `_anel` pertencente à própria instância atual.
      // `this._anel` = chama o método ou recurso `_anel` pertencente à instância atual.
      // `0.20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.18` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.035` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `pal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pal.
      this._anel(ctx, x, baseY - h * 0.20, h * 0.18, h * 0.035, pal);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desenharLegendaCamera` para executar a rotina correspondente a desenharLegendaCamera.
    // `_desenharLegendaCamera` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `w` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a w.
    // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
    _desenharLegendaCamera(ctx, w, h, cfg) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.save` = chama a função ou método `save` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `save` = identificador de propriedade ou método chamado `save`, acessado a partir do objeto indicado antes do ponto.
      ctx.save();

      // Declara `margem` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `margem` = identificador utilizado para armazenar ou acessar o valor relacionado a margem.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.018` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      const margem = Math.max(14, w * 0.018);

      // Declara `caixaW` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `caixaW` = identificador utilizado para armazenar ou acessar o valor relacionado a caixaW.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.54` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `430` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      const caixaW = Math.min(w * 0.54, 430);

      // Declara `caixaH` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `caixaH` = identificador utilizado para armazenar ou acessar o valor relacionado a caixaH.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `42` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0.078` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `h` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a h.
      const caixaH = Math.max(42, h * 0.078);

      // Declara `grad` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `grad` = identificador utilizado para armazenar ou acessar o valor relacionado a grad.
      // `ctx.createLinearGradient` = chama a função ou método `createLinearGradient` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `createLinearGradient` = identificador de propriedade ou método chamado `createLinearGradient`, acessado a partir do objeto indicado antes do ponto.
      // `margem` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a margem.
      const grad = ctx.createLinearGradient(margem, 0, margem + caixaW, 0);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(7,13,10,.84)'` = texto literal utilizado nesta instrução, contendo rgba(7,13,10,.84).
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addColorStop` = identificador de propriedade ou método chamado `addColorStop`, acessado a partir do objeto indicado antes do ponto.
      grad.addColorStop(0, 'rgba(7,13,10,.84)');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `grad.addColorStop` = chama a função ou método `addColorStop` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'rgba(7,13,10,.20)'` = texto literal utilizado nesta instrução, contendo rgba(7,13,10,.20).
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      grad.addColorStop(1, 'rgba(7,13,10,.20)');

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = grad;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.roundRect` = chama a função ou método `roundRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `roundRect` = identificador de propriedade ou método chamado `roundRect`, acessado a partir do objeto indicado antes do ponto.
      // `caixaW` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a caixaW.
      // `caixaH` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a caixaH.
      ctx.roundRect(margem, margem, caixaW, caixaH, 10);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.fill();

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `'#d7b86f'` = texto literal utilizado nesta instrução, contendo #d7b86f.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.fillStyle = '#d7b86f';

      // Armazena ou atualiza o valor de `ctx.font` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `font` = identificador de propriedade ou método chamado `font`, acessado a partir do objeto indicado antes do ponto.
      ctx.font = `800 ${Math.max(10, Math.min(13, w * 0.012))}px Segoe UI, Arial`;

      // Armazena ou atualiza o valor de `ctx.textAlign` utilizando o resultado definido nesta linha.
      // `'left'` = texto literal utilizado nesta instrução, contendo left.
      // `'top'` = texto literal utilizado nesta instrução, contendo top.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `textAlign` = identificador de propriedade ou método chamado `textAlign`, acessado a partir do objeto indicado antes do ponto.
      // `textBaseline` = identificador de propriedade ou método chamado `textBaseline`, acessado a partir do objeto indicado antes do ponto.
      ctx.textAlign = 'left'; ctx.textBaseline = 'top';

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillText` = chama a função ou método `fillText` pertencente ao objeto ou recurso indicado antes do ponto.
      // `13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `9` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `fillText` = identificador de propriedade ou método chamado `fillText`, acessado a partir do objeto indicado antes do ponto.
      // `cfg` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cfg.
      // `titulo` = identificador de propriedade ou método chamado `titulo`, acessado a partir do objeto indicado antes do ponto.
      // `margem` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a margem.
      ctx.fillText(cfg.titulo, margem + 13, margem + 9);

      // Armazena ou atualiza o valor de `ctx.fillStyle` utilizando o resultado definido nesta linha.
      // `'rgba(232,236,230,.72)'` = texto literal utilizado nesta instrução, contendo rgba(232,236,230,.72).
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `fillStyle` = identificador de propriedade ou método chamado `fillStyle`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillStyle = 'rgba(232,236,230,.72)';

      // Armazena ou atualiza o valor de `ctx.font` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      ctx.font = `500 ${Math.max(9, Math.min(12, w * 0.011))}px Segoe UI, Arial`;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.fillText` = chama a função ou método `fillText` pertencente ao objeto ou recurso indicado antes do ponto.
      // `13` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `27` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `subtitulo` = identificador de propriedade ou método chamado `subtitulo`, acessado a partir do objeto indicado antes do ponto.
      ctx.fillText(cfg.subtitulo, margem + 13, margem + 27);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.restore` = chama a função ou método `restore` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `restore` = identificador de propriedade ou método chamado `restore`, acessado a partir do objeto indicado antes do ponto.
      ctx.restore();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_preencherPoligono` para executar a rotina correspondente a preencherPoligono.
    // `_preencherPoligono` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
    _preencherPoligono(ctx, poly) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
      // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
      ctx.moveTo(poly[0].x, poly[0].y);

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      for (let i = 1; i < poly.length; i += 1) ctx.lineTo(poly[i].x, poly[i].y);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.fill` = chama a função ou método `fill` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.fill();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_contornarPoligono` para executar a rotina correspondente a contornarPoligono.
    // `_contornarPoligono` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
    // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
    _contornarPoligono(ctx, poly) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.beginPath` = chama a função ou método `beginPath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `beginPath` = identificador de propriedade ou método chamado `beginPath`, acessado a partir do objeto indicado antes do ponto.
      ctx.beginPath();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.moveTo` = chama a função ou método `moveTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `moveTo` = identificador de propriedade ou método chamado `moveTo`, acessado a partir do objeto indicado antes do ponto.
      // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
      // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
      ctx.moveTo(poly[0].x, poly[0].y);

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `ctx.lineTo` = chama a função ou método `lineTo` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      // `lineTo` = identificador de propriedade ou método chamado `lineTo`, acessado a partir do objeto indicado antes do ponto.
      for (let i = 1; i < poly.length; i += 1) ctx.lineTo(poly[i].x, poly[i].y);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ctx.closePath` = chama a função ou método `closePath` pertencente ao objeto ou recurso indicado antes do ponto.
      // `ctx.stroke` = chama a função ou método `stroke` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ctx` = contexto gráfico utilizado para executar os comandos de desenho no canvas.
      // `closePath` = identificador de propriedade ou método chamado `closePath`, acessado a partir do objeto indicado antes do ponto.
      // `stroke` = identificador de propriedade ou método chamado `stroke`, acessado a partir do objeto indicado antes do ponto.
      ctx.closePath(); ctx.stroke();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_centroPoligono` para executar a rotina correspondente a centroPoligono.
    // `_centroPoligono` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
    _centroPoligono(poly) {

      // Retorna `{` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      return {

        // Define a propriedade `x` do objeto com o valor informado nesta linha.
        // `poly.reduce` = chama a função ou método `reduce` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `/` = realiza divisão.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
        // `reduce` = identificador de propriedade ou método chamado `reduce`, acessado a partir do objeto indicado antes do ponto.
        // `s` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a s.
        // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
        x: poly.reduce((s, p) => s + p.x, 0) / poly.length,

        // Define a propriedade `y` do objeto com o valor informado nesta linha.
        // `poly.reduce` = chama a função ou método `reduce` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `/` = realiza divisão.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
        // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
        y: poly.reduce((s, p) => s + p.y, 0) / poly.length,

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_mesma` para executar a rotina correspondente a mesma.
    // `_mesma` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
    // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
    _mesma(a, b) {

      // Retorna `Array.isArray(a) && Array.isArray(b) && a[0] === b[0] && a[1] === b[1]` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `Array.isArray` = chama a função ou método `isArray` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Array` = construtor e recurso nativo utilizado para trabalhar com listas de valores.
      // `isArray` = identificador de propriedade ou método chamado `isArray`, acessado a partir do objeto indicado antes do ponto.
      return Array.isArray(a) && Array.isArray(b) && a[0] === b[0] && a[1] === b[1];

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_pontoNoPoligono` para executar a rotina correspondente a pontoNoPoligono.
    // `_pontoNoPoligono` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
    // `poly` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a poly.
    _pontoNoPoligono(x, y, poly) {

      // Declara `dentro` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `dentro` = identificador utilizado para armazenar ou acessar o valor relacionado a dentro.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let dentro = false;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `++` = incrementa o valor em uma unidade.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `j` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a j.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {

        // Declara `xi` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `xi` = identificador utilizado para armazenar ou acessar o valor relacionado a xi.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `yi` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a yi.
        // `y` = identificador de propriedade ou método chamado `y`, acessado a partir do objeto indicado antes do ponto.
        const xi = poly[i].x; const yi = poly[i].y;

        // Declara `xj` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `xj` = identificador utilizado para armazenar ou acessar o valor relacionado a xj.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `x` = identificador de propriedade ou método chamado `x`, acessado a partir do objeto indicado antes do ponto.
        // `yj` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a yj.
        const xj = poly[j].x; const yj = poly[j].y;

        // Declara `cruza` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `cruza` = identificador utilizado para armazenar ou acessar o valor relacionado a cruza.
        // `0.000001` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `>` = verifica se o valor da esquerda é maior que o valor da direita.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `*` = realiza multiplicação.
        // `/` = realiza divisão.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const cruza = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / ((yj - yi) || 0.000001) + xi);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `dentro` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dentro.
        if (cruza) dentro = !dentro;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `dentro` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return dentro;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_casaNoPonto` para executar a rotina correspondente a casaNoPonto.
    // `_casaNoPonto` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
    _casaNoPonto(evento) {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.camera` = acessa o atributo ou método `camera` pertencente à própria instância atual.
      // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (this.camera === 'superior') return null;

      // Declara `rect` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `rect` = identificador utilizado para armazenar ou acessar o valor relacionado a rect.
      // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
      // `this.canvas.getBoundingClientRect` = chama o método ou recurso `getBoundingClientRect` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `getBoundingClientRect` = identificador de propriedade ou método chamado `getBoundingClientRect`, acessado a partir do objeto indicado antes do ponto.
      const rect = this.canvas.getBoundingClientRect();

      // Declara `x` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `x` = identificador utilizado para armazenar ou acessar o valor relacionado a x.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `clientX` = identificador de propriedade ou método chamado `clientX`, acessado a partir do objeto indicado antes do ponto.
      // `left` = identificador de propriedade ou método chamado `left`, acessado a partir do objeto indicado antes do ponto.
      const x = evento.clientX - rect.left;

      // Declara `y` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `y` = identificador utilizado para armazenar ou acessar o valor relacionado a y.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `clientY` = identificador de propriedade ou método chamado `clientY`, acessado a partir do objeto indicado antes do ponto.
      // `top` = identificador de propriedade ou método chamado `top`, acessado a partir do objeto indicado antes do ponto.
      const y = evento.clientY - rect.top;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.poligonos` = acessa o atributo ou método `poligonos` pertencente à própria instância atual.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      for (let i = this.poligonos.length - 1; i >= 0; i -= 1) {

        // Declara `item` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `item` = identificador utilizado para armazenar ou acessar o valor relacionado a item.
        // `this.poligonos` = acessa o atributo ou método `poligonos` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const item = this.poligonos[i];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this._pontoNoPoligono` = acessa o atributo ou método `_pontoNoPoligono` pertencente à própria instância atual.
        // `this._pontoNoPoligono` = chama o método ou recurso `_pontoNoPoligono` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `x` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a x.
        // `y` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a y.
        // `poly` = identificador de propriedade ou método chamado `poly`, acessado a partir do objeto indicado antes do ponto.
        if (this._pontoNoPoligono(x, y, item.poly)) return item;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `null` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return null;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_clicar` para executar a rotina correspondente a clicar.
    // `_clicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
    _clicar(evento) {

      // Declara `casa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `casa` = identificador utilizado para armazenar ou acessar o valor relacionado a casa.
      // `this._casaNoPonto` = acessa o atributo ou método `_casaNoPonto` pertencente à própria instância atual.
      // `this._casaNoPonto` = chama o método ou recurso `_casaNoPonto` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const casa = this._casaNoPonto(evento);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `typeof` = obtém o tipo do valor ou expressão indicada.
      // `this.aoClicarCasa` = acessa o atributo ou método `aoClicarCasa` pertencente à própria instância atual.
      // `this.aoClicarCasa` = chama o método ou recurso `aoClicarCasa` pertencente à instância atual.
      // `'function'` = texto literal utilizado nesta instrução, contendo function.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `row` = identificador de propriedade ou método chamado `row`, acessado a partir do objeto indicado antes do ponto.
      // `col` = identificador de propriedade ou método chamado `col`, acessado a partir do objeto indicado antes do ponto.
      if (casa && typeof this.aoClicarCasa === 'function') this.aoClicarCasa(casa.row, casa.col);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_mover` para executar a rotina correspondente a mover.
    // `_mover` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _mover(evento) {

      // Declara `casa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `casa` = identificador utilizado para armazenar ou acessar o valor relacionado a casa.
      // `this._casaNoPonto` = acessa o atributo ou método `_casaNoPonto` pertencente à própria instância atual.
      // `this._casaNoPonto` = chama o método ou recurso `_casaNoPonto` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
      const casa = this._casaNoPonto(evento);

      // Declara `nova` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `nova` = identificador utilizado para armazenar ou acessar o valor relacionado a nova.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const nova = casa ? { row: casa.row, col: casa.col } : null;

      // Declara `mudou` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `mudou` = identificador utilizado para armazenar ou acessar o valor relacionado a mudou.
      // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `row` = identificador de propriedade ou método chamado `row`, acessado a partir do objeto indicado antes do ponto.
      // `col` = identificador de propriedade ou método chamado `col`, acessado a partir do objeto indicado antes do ponto.
      const mudou = (!this.hover && nova) || (this.hover && !nova) || (this.hover && nova && (this.hover.row !== nova.row || this.hover.col !== nova.col));

      // Armazena ou atualiza o valor de `this.canvas.style.cursor` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.canvas` = acessa o atributo ou método `canvas` pertencente à própria instância atual.
      // `'pointer'` = texto literal utilizado nesta instrução, contendo pointer.
      // `'default'` = texto literal utilizado nesta instrução, contendo default.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `style` = identificador de propriedade ou método chamado `style`, acessado a partir do objeto indicado antes do ponto.
      // `cursor` = identificador de propriedade ou método chamado `cursor`, acessado a partir do objeto indicado antes do ponto.
      this.canvas.style.cursor = casa ? 'pointer' : 'default';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (mudou) {

        // Armazena ou atualiza o valor de `this.hover` utilizando o resultado definido nesta linha.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.hover` = acessa o atributo ou método `hover` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `nova` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a nova.
        this.hover = nova;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this._agendarRender` = acessa o atributo ou método `_agendarRender` pertencente à própria instância atual.
        // `this._agendarRender` = chama o método ou recurso `_agendarRender` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        this._agendarRender();

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Armazena ou atualiza o valor de `window.RenderizadorXadrez3D` utilizando o resultado definido nesta linha.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
  // `RenderizadorXadrez3D` = identificador de propriedade ou método chamado `RenderizadorXadrez3D`, acessado a partir do objeto indicado antes do ponto.
  window.RenderizadorXadrez3D = RenderizadorXadrez3D;

// Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
// `;` = encerra a instrução JavaScript atual.
})();
