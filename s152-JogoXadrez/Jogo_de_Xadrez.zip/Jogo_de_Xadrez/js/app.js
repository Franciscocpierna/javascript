// Cria e executa uma função isolada para manter as variáveis do jogo protegidas no próprio escopo.
// `function` = define uma nova função para agrupar uma rotina reutilizável.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
(function () {

  // Ativa o modo estrito do JavaScript para tornar a execução mais segura e impedir determinados usos ambíguos da linguagem.
  // `'use strict'` = texto literal utilizado nesta instrução, contendo use strict.
  // `;` = encerra a instrução JavaScript atual.
  'use strict';

  // Declara `M` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `M` = identificador utilizado para armazenar ou acessar o valor relacionado a M.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
  // `XadrezMotor` = identificador de propriedade ou método chamado `XadrezMotor`, acessado a partir do objeto indicado antes do ponto.
  const M = window.XadrezMotor;

  // Declara constantes por desestruturação, extraindo propriedades do objeto indicado para identificadores individuais.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `InteligenciaXadrez` = classe responsável pelas decisões da Inteligência Artificial do jogo.
  // `XadrezIA` = identificador de propriedade ou método chamado `XadrezIA`, acessado a partir do objeto indicado antes do ponto.
  const { InteligenciaXadrez } = window.XadrezIA;

  // Declara constantes por desestruturação, extraindo propriedades do objeto indicado para identificadores individuais.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  const {

    // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
    // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
    // `REI` = constante que identifica a peça Rei.
    // `DAMA` = constante que identifica a peça Dama.
    // `TORRE` = constante que identifica a peça Torre.
    // `BISPO` = constante que identifica a peça Bispo.
    // `CAVALO` = constante que identifica a peça Cavalo.
    // `PEAO` = constante que identifica a peça Peão.
    BRANCO, PRETO, REI, DAMA, TORRE, BISPO, CAVALO, PEAO,

    // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `corOposta` = função que obtém a cor adversária em relação à cor informada.
    // `posIgual` = função que verifica se duas posições do tabuleiro representam a mesma casa.
    // `EstadoXadrez` = classe responsável por representar e controlar o estado completo de uma partida de xadrez.
    // `notacaoSimples` = função que transforma um movimento em uma notação textual simples para exibição.
    corOposta, posIgual, EstadoXadrez, notacaoSimples,

  // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  } = M;

  // Declara `SIMBOLOS` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `SIMBOLOS` = identificador utilizado para armazenar ou acessar o valor relacionado a SIMBOLOS.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  const SIMBOLOS = {

    // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
    // `'♔'` = texto literal utilizado nesta instrução, contendo ♔.
    // `'♕'` = texto literal utilizado nesta instrução, contendo ♕.
    // `'♖'` = texto literal utilizado nesta instrução, contendo ♖.
    // `'♗'` = texto literal utilizado nesta instrução, contendo ♗.
    // `'♘'` = texto literal utilizado nesta instrução, contendo ♘.
    // `'♙'` = texto literal utilizado nesta instrução, contendo ♙.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    [BRANCO]: { [REI]: '♔', [DAMA]: '♕', [TORRE]: '♖', [BISPO]: '♗', [CAVALO]: '♘', [PEAO]: '♙' },

    // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
    // `'♚'` = texto literal utilizado nesta instrução, contendo ♚.
    // `'♛'` = texto literal utilizado nesta instrução, contendo ♛.
    // `'♜'` = texto literal utilizado nesta instrução, contendo ♜.
    // `'♝'` = texto literal utilizado nesta instrução, contendo ♝.
    // `'♞'` = texto literal utilizado nesta instrução, contendo ♞.
    // `'♟'` = texto literal utilizado nesta instrução, contendo ♟.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
    // `REI` = constante que identifica a peça Rei.
    // `DAMA` = constante que identifica a peça Dama.
    // `TORRE` = constante que identifica a peça Torre.
    // `BISPO` = constante que identifica a peça Bispo.
    // `CAVALO` = constante que identifica a peça Cavalo.
    // `PEAO` = constante que identifica a peça Peão.
    [PRETO]: { [REI]: '♚', [DAMA]: '♛', [TORRE]: '♜', [BISPO]: '♝', [CAVALO]: '♞', [PEAO]: '♟' },

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  };

  // Declara `NOMES_PECAS` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `NOMES_PECAS` = identificador utilizado para armazenar ou acessar o valor relacionado a NOMES PECAS.
  // `'Rei'` = texto literal utilizado nesta instrução, contendo Rei.
  // `'Dama'` = texto literal utilizado nesta instrução, contendo Dama.
  // `'Torre'` = texto literal utilizado nesta instrução, contendo Torre.
  // `'Bispo'` = texto literal utilizado nesta instrução, contendo Bispo.
  // `'Cavalo'` = texto literal utilizado nesta instrução, contendo Cavalo.
  // `'Peão'` = texto literal utilizado nesta instrução, contendo Peão.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
  // `]` = fecha a lista, o acesso por índice ou a chave calculada.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
  // `;` = encerra a instrução JavaScript atual.
  const NOMES_PECAS = { [REI]: 'Rei', [DAMA]: 'Dama', [TORRE]: 'Torre', [BISPO]: 'Bispo', [CAVALO]: 'Cavalo', [PEAO]: 'Peão' };

  // Declara `NOMES_NIVEIS` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `NOMES_NIVEIS` = identificador utilizado para armazenar ou acessar o valor relacionado a NOMES NIVEIS.
  // `'Fácil'` = texto literal utilizado nesta instrução, contendo Fácil.
  // `'Intermediário'` = texto literal utilizado nesta instrução, contendo Intermediário.
  // `'Avançado'` = texto literal utilizado nesta instrução, contendo Avançado.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
  // `;` = encerra a instrução JavaScript atual.
  // `facil` = identificador usado como nome da propriedade `facil` dentro do objeto atual.
  // `intermediario` = identificador usado como nome da propriedade `intermediario` dentro do objeto atual.
  // `avancado` = identificador usado como nome da propriedade `avancado` dentro do objeto atual.
  const NOMES_NIVEIS = { facil: 'Fácil', intermediario: 'Intermediário', avancado: 'Avançado' };

  // Declara `NOMES_CAMERAS` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `NOMES_CAMERAS` = identificador utilizado para armazenar ou acessar o valor relacionado a NOMES CAMERAS.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  const NOMES_CAMERAS = {

    // Define a propriedade `superior` do objeto com o valor informado nesta linha.
    // `'Câmera 1 — Superior clássica'` = texto literal utilizado nesta instrução, contendo Câmera 1 — Superior clássica.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `superior` = identificador usado como nome da propriedade `superior` dentro do objeto atual.
    superior: 'Câmera 1 — Superior clássica',

    // Define a propriedade `brancas` do objeto com o valor informado nesta linha.
    // `'Câmera 2 — Perspectiva 3D das Brancas'` = texto literal utilizado nesta instrução, contendo Câmera 2 — Perspectiva 3D das Brancas.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `brancas` = identificador usado como nome da propriedade `brancas` dentro do objeto atual.
    brancas: 'Câmera 2 — Perspectiva 3D das Brancas',

    // Define a propriedade `pretas` do objeto com o valor informado nesta linha.
    // `'Câmera 3 — Perspectiva 3D das Pretas'` = texto literal utilizado nesta instrução, contendo Câmera 3 — Perspectiva 3D das Pretas.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `pretas` = identificador usado como nome da propriedade `pretas` dentro do objeto atual.
    pretas: 'Câmera 3 — Perspectiva 3D das Pretas',

    // Define a propriedade `lateral` do objeto com o valor informado nesta linha.
    // `'Câmera 4 — Dentro do tabuleiro 3D'` = texto literal utilizado nesta instrução, contendo Câmera 4 — Dentro do tabuleiro 3D.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `lateral` = identificador usado como nome da propriedade `lateral` dentro do objeto atual.
    lateral: 'Câmera 4 — Dentro do tabuleiro 3D',

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  };

  // Declara `$` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `$` = identificador utilizado para armazenar ou acessar o valor relacionado a $.
  // `document.getElementById` = chama a função ou método `getElementById` pertencente ao objeto ou recurso indicado antes do ponto.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `id` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a id.
  // `document` = objeto que representa o documento HTML carregado no navegador.
  // `getElementById` = identificador de propriedade ou método chamado `getElementById`, acessado a partir do objeto indicado antes do ponto.
  const $ = (id) => document.getElementById(id);

  // Declara `ui` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `ui` = identificador utilizado para armazenar ou acessar o valor relacionado a ui.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  const ui = {

    // Define a propriedade `telaMenu` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'telaMenu'` = texto literal utilizado nesta instrução, contendo telaMenu.
    // `'telaJogo'` = texto literal utilizado nesta instrução, contendo telaJogo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `telaMenu` = identificador usado como nome da propriedade `telaMenu` dentro do objeto atual.
    // `telaJogo` = identificador usado como nome da propriedade `telaJogo` dentro do objeto atual.
    telaMenu: $('telaMenu'), telaJogo: $('telaJogo'),

    // Define a propriedade `nomeJogador` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'nomeJogador'` = texto literal utilizado nesta instrução, contendo nomeJogador.
    // `'modoJogo'` = texto literal utilizado nesta instrução, contendo modoJogo.
    // `'corJogador'` = texto literal utilizado nesta instrução, contendo corJogador.
    // `'dificuldade'` = texto literal utilizado nesta instrução, contendo dificuldade.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `nomeJogador` = identificador usado como nome da propriedade `nomeJogador` dentro do objeto atual.
    // `modoJogo` = identificador usado como nome da propriedade `modoJogo` dentro do objeto atual.
    // `corJogador` = identificador usado como nome da propriedade `corJogador` dentro do objeto atual.
    // `dificuldade` = identificador usado como nome da propriedade `dificuldade` dentro do objeto atual.
    nomeJogador: $('nomeJogador'), modoJogo: $('modoJogo'), corJogador: $('corJogador'), dificuldade: $('dificuldade'),

    // Define a propriedade `campoCor` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'campoCor'` = texto literal utilizado nesta instrução, contendo campoCor.
    // `'cameraMenu'` = texto literal utilizado nesta instrução, contendo cameraMenu.
    // `'cameraJogo'` = texto literal utilizado nesta instrução, contendo cameraJogo.
    // `'cameraScene'` = texto literal utilizado nesta instrução, contendo cameraScene.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `campoCor` = identificador usado como nome da propriedade `campoCor` dentro do objeto atual.
    // `cameraMenu` = identificador usado como nome da propriedade `cameraMenu` dentro do objeto atual.
    // `cameraJogo` = identificador usado como nome da propriedade `cameraJogo` dentro do objeto atual.
    // `cameraScene` = identificador usado como nome da propriedade `cameraScene` dentro do objeto atual.
    campoCor: $('campoCor'), cameraMenu: $('cameraMenu'), cameraJogo: $('cameraJogo'), cameraScene: $('cameraScene'),

    // Define a propriedade `boardZone` do objeto com o valor informado nesta linha.
    // `document.querySelector` = chama a função ou método `querySelector` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'.board-zone'` = texto literal utilizado nesta instrução, contendo .board-zone.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `boardZone` = identificador usado como nome da propriedade `boardZone` dentro do objeto atual.
    // `document` = objeto que representa o documento HTML carregado no navegador.
    // `querySelector` = identificador de propriedade ou método chamado `querySelector`, acessado a partir do objeto indicado antes do ponto.
    boardZone: document.querySelector('.board-zone'),

    // Define a propriedade `btnIniciar` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'btnIniciar'` = texto literal utilizado nesta instrução, contendo btnIniciar.
    // `'btnComoJogar'` = texto literal utilizado nesta instrução, contendo btnComoJogar.
    // `'btnEstatisticas'` = texto literal utilizado nesta instrução, contendo btnEstatisticas.
    // `'btnRanking'` = texto literal utilizado nesta instrução, contendo btnRanking.
    // `'btnHistoricoGeral'` = texto literal utilizado nesta instrução, contendo btnHistoricoGeral.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `btnIniciar` = identificador usado como nome da propriedade `btnIniciar` dentro do objeto atual.
    // `btnComoJogar` = identificador usado como nome da propriedade `btnComoJogar` dentro do objeto atual.
    // `btnEstatisticas` = identificador usado como nome da propriedade `btnEstatisticas` dentro do objeto atual.
    // `btnRanking` = identificador usado como nome da propriedade `btnRanking` dentro do objeto atual.
    // `btnHistoricoGeral` = identificador usado como nome da propriedade `btnHistoricoGeral` dentro do objeto atual.
    btnIniciar: $('btnIniciar'), btnComoJogar: $('btnComoJogar'), btnEstatisticas: $('btnEstatisticas'), btnRanking: $('btnRanking'), btnHistoricoGeral: $('btnHistoricoGeral'),

    // Define a propriedade `btnSom` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'btnSom'` = texto literal utilizado nesta instrução, contendo btnSom.
    // `'btnTelaCheia'` = texto literal utilizado nesta instrução, contendo btnTelaCheia.
    // `'btnVoltarMenu'` = texto literal utilizado nesta instrução, contendo btnVoltarMenu.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `btnSom` = identificador usado como nome da propriedade `btnSom` dentro do objeto atual.
    // `btnTelaCheia` = identificador usado como nome da propriedade `btnTelaCheia` dentro do objeto atual.
    // `btnVoltarMenu` = identificador usado como nome da propriedade `btnVoltarMenu` dentro do objeto atual.
    btnSom: $('btnSom'), btnTelaCheia: $('btnTelaCheia'), btnVoltarMenu: $('btnVoltarMenu'),

    // Define a propriedade `btnReivindicar` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'btnReivindicar'` = texto literal utilizado nesta instrução, contendo btnReivindicar.
    // `'btnOferecer'` = texto literal utilizado nesta instrução, contendo btnOferecer.
    // `'btnDesistir'` = texto literal utilizado nesta instrução, contendo btnDesistir.
    // `'btnPausarIA'` = texto literal utilizado nesta instrução, contendo btnPausarIA.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `btnReivindicar` = identificador usado como nome da propriedade `btnReivindicar` dentro do objeto atual.
    // `btnOferecer` = identificador usado como nome da propriedade `btnOferecer` dentro do objeto atual.
    // `btnDesistir` = identificador usado como nome da propriedade `btnDesistir` dentro do objeto atual.
    // `btnPausarIA` = identificador usado como nome da propriedade `btnPausarIA` dentro do objeto atual.
    btnReivindicar: $('btnReivindicar'), btnOferecer: $('btnOferecer'), btnDesistir: $('btnDesistir'), btnPausarIA: $('btnPausarIA'),

    // Define a propriedade `tabuleiro` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'tabuleiro'` = texto literal utilizado nesta instrução, contendo tabuleiro.
    // `'tabuleiro3dCanvas'` = texto literal utilizado nesta instrução, contendo tabuleiro3dCanvas.
    // `'statusTurno'` = texto literal utilizado nesta instrução, contendo statusTurno.
    // `'statusJogo'` = texto literal utilizado nesta instrução, contendo statusJogo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
    // `tabuleiro3d` = identificador usado como nome da propriedade `tabuleiro3d` dentro do objeto atual.
    // `statusTurno` = identificador usado como nome da propriedade `statusTurno` dentro do objeto atual.
    // `statusJogo` = identificador usado como nome da propriedade `statusJogo` dentro do objeto atual.
    tabuleiro: $('tabuleiro'), tabuleiro3d: $('tabuleiro3dCanvas'), statusTurno: $('statusTurno'), statusJogo: $('statusJogo'),

    // Define a propriedade `nomePainel` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'nomePainel'` = texto literal utilizado nesta instrução, contendo nomePainel.
    // `'modoPainel'` = texto literal utilizado nesta instrução, contendo modoPainel.
    // `'nivelPainel'` = texto literal utilizado nesta instrução, contendo nivelPainel.
    // `'corPainel'` = texto literal utilizado nesta instrução, contendo corPainel.
    // `'numeroLance'` = texto literal utilizado nesta instrução, contendo numeroLance.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `nomePainel` = identificador usado como nome da propriedade `nomePainel` dentro do objeto atual.
    // `modoPainel` = identificador usado como nome da propriedade `modoPainel` dentro do objeto atual.
    // `nivelPainel` = identificador usado como nome da propriedade `nivelPainel` dentro do objeto atual.
    // `corPainel` = identificador usado como nome da propriedade `corPainel` dentro do objeto atual.
    // `numeroLance` = identificador usado como nome da propriedade `numeroLance` dentro do objeto atual.
    nomePainel: $('nomePainel'), modoPainel: $('modoPainel'), nivelPainel: $('nivelPainel'), corPainel: $('corPainel'), numeroLance: $('numeroLance'),

    // Define a propriedade `capturadasBrancas` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'capturadasBrancas'` = texto literal utilizado nesta instrução, contendo capturadasBrancas.
    // `'capturadasPretas'` = texto literal utilizado nesta instrução, contendo capturadasPretas.
    // `'historicoLances'` = texto literal utilizado nesta instrução, contendo historicoLances.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `capturadasBrancas` = identificador usado como nome da propriedade `capturadasBrancas` dentro do objeto atual.
    // `capturadasPretas` = identificador usado como nome da propriedade `capturadasPretas` dentro do objeto atual.
    // `historicoLances` = identificador usado como nome da propriedade `historicoLances` dentro do objeto atual.
    capturadasBrancas: $('capturadasBrancas'), capturadasPretas: $('capturadasPretas'), historicoLances: $('historicoLances'),

    // Define a propriedade `avisoCaptura` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'avisoCaptura'` = texto literal utilizado nesta instrução, contendo avisoCaptura.
    // `'pensando'` = texto literal utilizado nesta instrução, contendo pensando.
    // `'toast'` = texto literal utilizado nesta instrução, contendo toast.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `avisoCaptura` = identificador usado como nome da propriedade `avisoCaptura` dentro do objeto atual.
    // `pensando` = identificador usado como nome da propriedade `pensando` dentro do objeto atual.
    // `toast` = identificador usado como nome da propriedade `toast` dentro do objeto atual.
    avisoCaptura: $('avisoCaptura'), pensando: $('pensando'), toast: $('toast'),

    // Define a propriedade `modal` do objeto com o valor informado nesta linha.
    // `$` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'modal'` = texto literal utilizado nesta instrução, contendo modal.
    // `'modalTitulo'` = texto literal utilizado nesta instrução, contendo modalTitulo.
    // `'modalConteudo'` = texto literal utilizado nesta instrução, contendo modalConteudo.
    // `'modalAcoes'` = texto literal utilizado nesta instrução, contendo modalAcoes.
    // `'btnFecharModal'` = texto literal utilizado nesta instrução, contendo btnFecharModal.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `modal` = identificador usado como nome da propriedade `modal` dentro do objeto atual.
    // `modalTitulo` = identificador usado como nome da propriedade `modalTitulo` dentro do objeto atual.
    // `modalConteudo` = identificador usado como nome da propriedade `modalConteudo` dentro do objeto atual.
    // `modalAcoes` = identificador usado como nome da propriedade `modalAcoes` dentro do objeto atual.
    // `btnFecharModal` = identificador usado como nome da propriedade `btnFecharModal` dentro do objeto atual.
    modal: $('modal'), modalTitulo: $('modalTitulo'), modalConteudo: $('modalConteudo'), modalAcoes: $('modalAcoes'), btnFecharModal: $('btnFecharModal'),

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  };

  // Define a classe `ArmazenamentoLocal`, responsável por agrupar dados e comportamentos relacionados a esta parte do jogo.
  // `class` = define uma classe utilizada para criar objetos com dados e comportamentos relacionados.
  // `ArmazenamentoLocal` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  class ArmazenamentoLocal {

    // Define o método construtor responsável por inicializar os dados e estados da nova instância da classe.
    // `constructor` = define o método construtor executado automaticamente ao criar uma instância da classe.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    constructor() {

      // Armazena ou atualiza o valor de `this.chave` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.chave` = acessa o atributo ou método `chave` pertencente à própria instância atual.
      // `'jogo_xadrez_dados'` = texto literal utilizado nesta instrução, contendo jogo_xadrez_dados.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.chave = 'jogo_xadrez_dados';

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_ler` para executar a rotina correspondente a ler.
    // `_ler` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _ler() {

      // Inicia um bloco protegido para executar operações que podem gerar uma exceção durante a execução.
      // `try` = inicia um bloco protegido para executar instruções que podem gerar uma exceção.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      try {

        // Declara `dados` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `dados` = identificador utilizado para armazenar ou acessar o valor relacionado a dados.
        // `this.chave` = acessa o atributo ou método `chave` pertencente à própria instância atual.
        // `JSON.parse` = chama a função ou método `parse` pertencente ao objeto ou recurso indicado antes do ponto.
        // `localStorage.getItem` = chama a função ou método `getItem` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'{}'` = texto literal utilizado nesta instrução, contendo {}.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `JSON` = objeto nativo utilizado para converter dados entre objetos JavaScript e texto no formato JSON.
        // `parse` = identificador de propriedade ou método chamado `parse`, acessado a partir do objeto indicado antes do ponto.
        // `localStorage` = recurso do navegador utilizado para armazenar dados persistentes localmente.
        // `getItem` = identificador de propriedade ou método chamado `getItem`, acessado a partir do objeto indicado antes do ponto.
        const dados = JSON.parse(localStorage.getItem(this.chave) || '{}');

        // Retorna `{` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        return {

          // Define a propriedade `jogadores` do objeto com o valor informado nesta linha.
          // `typeof` = obtém o tipo do valor ou expressão indicada.
          // `'object'` = texto literal utilizado nesta instrução, contendo object.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `jogadores` = identificador de propriedade ou método chamado `jogadores`, acessado a partir do objeto indicado antes do ponto.
          jogadores: dados.jogadores && typeof dados.jogadores === 'object' ? dados.jogadores : {},

          // Define a propriedade `partidas` do objeto com o valor informado nesta linha.
          // `Array.isArray` = chama a função ou método `isArray` pertencente ao objeto ou recurso indicado antes do ponto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `partidas` = identificador de propriedade ou método chamado `partidas`, acessado a partir do objeto indicado antes do ponto.
          // `Array` = construtor e recurso nativo utilizado para trabalhar com listas de valores.
          // `isArray` = identificador de propriedade ou método chamado `isArray`, acessado a partir do objeto indicado antes do ponto.
          partidas: Array.isArray(dados.partidas) ? dados.partidas : [],

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        };

      // Captura e trata uma possível exceção produzida pelas instruções executadas no bloco protegido anterior.
      // `catch` = captura uma exceção produzida no bloco try e permite tratá-la.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `_` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a  .
      } catch (_) {

        // Retorna `{ jogadores: {}, partidas: [] }` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        return { jogadores: {}, partidas: [] };

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_salvar` para executar a rotina correspondente a salvar.
    // `_salvar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `dados` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dados.
    _salvar(dados) {

      // Inicia um bloco protegido para executar operações que podem gerar uma exceção durante a execução.
      // `try` = inicia um bloco protegido para executar instruções que podem gerar uma exceção.
      // `catch` = captura uma exceção produzida no bloco try e permite tratá-la.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.chave` = acessa o atributo ou método `chave` pertencente à própria instância atual.
      // `localStorage.setItem` = chama a função ou método `setItem` pertencente ao objeto ou recurso indicado antes do ponto.
      // `JSON.stringify` = chama a função ou método `stringify` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `localStorage` = recurso do navegador utilizado para armazenar dados persistentes localmente.
      // `setItem` = identificador de propriedade ou método chamado `setItem`, acessado a partir do objeto indicado antes do ponto.
      // `JSON` = objeto nativo utilizado para converter dados entre objetos JavaScript e texto no formato JSON.
      // `stringify` = identificador de propriedade ou método chamado `stringify`, acessado a partir do objeto indicado antes do ponto.
      try { localStorage.setItem(this.chave, JSON.stringify(dados)); } catch (_) {  }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `registrarPartida` para executar a rotina correspondente a registrarPartida.
    // `registrarPartida` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `jogador` = identificador que representa o jogador associado à operação atual.
    // `modo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a modo.
    // `corJogador` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corJogador.
    // `dificuldade` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dificuldade.
    // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
    // `totalLances` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a totalLances.
    registrarPartida({ jogador, modo, corJogador, dificuldade, resultado, totalLances }) {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'Jogador x IA'` = texto literal utilizado nesta instrução, contendo Jogador x IA.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (modo !== 'Jogador x IA') return;

      // Declara `dados` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `dados` = identificador utilizado para armazenar ou acessar o valor relacionado a dados.
      // `this._ler` = acessa o atributo ou método `_ler` pertencente à própria instância atual.
      // `this._ler` = chama o método ou recurso `_ler` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const dados = this._ler();

      // Declara `nome` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `nome` = identificador utilizado para armazenar ou acessar o valor relacionado a nome.
      // `'Jogador'` = texto literal utilizado nesta instrução, contendo Jogador.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `trim` = identificador de propriedade ou método chamado `trim`, acessado a partir do objeto indicado antes do ponto.
      const nome = (jogador || 'Jogador').trim() || 'Jogador';

      // Declara `chaveNome` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `chaveNome` = identificador utilizado para armazenar ou acessar o valor relacionado a chaveNome.
      // `nome.toLocaleLowerCase` = chama a função ou método `toLocaleLowerCase` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'pt-BR'` = texto literal utilizado nesta instrução, contendo pt-BR.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `toLocaleLowerCase` = identificador de propriedade ou método chamado `toLocaleLowerCase`, acessado a partir do objeto indicado antes do ponto.
      const chaveNome = nome.toLocaleLowerCase('pt-BR');

      // Declara `atual` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `atual` = identificador utilizado para armazenar ou acessar o valor relacionado a atual.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `jogadores` = identificador de propriedade ou método chamado `jogadores`, acessado a partir do objeto indicado antes do ponto.
      const atual = dados.jogadores[chaveNome] || {

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `''` = texto literal utilizado nesta instrução.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `partidas` = identificador usado como nome da propriedade `partidas` dentro do objeto atual.
        // `vitorias` = identificador usado como nome da propriedade `vitorias` dentro do objeto atual.
        // `empates` = identificador usado como nome da propriedade `empates` dentro do objeto atual.
        // `derrotas` = identificador usado como nome da propriedade `derrotas` dentro do objeto atual.
        // `pontos` = identificador usado como nome da propriedade `pontos` dentro do objeto atual.
        // `placar` = identificador usado como nome da propriedade `placar` dentro do objeto atual.
        // `atualizadoEm` = identificador usado como nome da propriedade `atualizadoEm` dentro do objeto atual.
        nome, partidas: 0, vitorias: 0, empates: 0, derrotas: 0, pontos: 0, placar: 0, atualizadoEm: '',

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

      // Armazena ou atualiza o valor de `atual.nome` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
      atual.nome = nome;

      // Armazena ou atualiza o valor de `atual.partidas` utilizando o resultado definido nesta linha.
      // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      atual.partidas += 1;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `'vitoria'` = texto literal utilizado nesta instrução, contendo vitoria.
      // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
      // `3` = quantidade de pontos adicionada ao ranking por uma vitória.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
      // `atual` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a atual.
      if (resultado === 'vitoria') { atual.vitorias += 1; atual.pontos += 3; atual.placar += 3; }

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `'empate'` = texto literal utilizado nesta instrução, contendo empate.
      // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `empates` = identificador de propriedade ou método chamado `empates`, acessado a partir do objeto indicado antes do ponto.
      // `pontos` = identificador de propriedade ou método chamado `pontos`, acessado a partir do objeto indicado antes do ponto.
      // `placar` = identificador de propriedade ou método chamado `placar`, acessado a partir do objeto indicado antes do ponto.
      else if (resultado === 'empate') { atual.empates += 1; atual.pontos += 1; atual.placar += 1; }

      // Executa o bloco alternativo quando a condição anterior não foi atendida.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `derrotas` = identificador de propriedade ou método chamado `derrotas`, acessado a partir do objeto indicado antes do ponto.
      else atual.derrotas += 1;

      // Armazena ou atualiza o valor de `atual.atualizadoEm` utilizando o resultado definido nesta linha.
      // `new` = cria uma nova instância da classe ou construtor indicado.
      // `Date` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `atualizadoEm` = identificador de propriedade ou método chamado `atualizadoEm`, acessado a partir do objeto indicado antes do ponto.
      // `toISOString` = identificador de propriedade ou método chamado `toISOString`, acessado a partir do objeto indicado antes do ponto.
      atual.atualizadoEm = new Date().toISOString();

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dados` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dados.
      // `jogadores` = identificador de propriedade ou método chamado `jogadores`, acessado a partir do objeto indicado antes do ponto.
      // `chaveNome` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a chaveNome.
      dados.jogadores[chaveNome] = atual;

      // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
      // `dados.partidas.unshift` = chama a função ou método `unshift` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `partidas` = identificador de propriedade ou método chamado `partidas`, acessado a partir do objeto indicado antes do ponto.
      // `unshift` = identificador de propriedade ou método chamado `unshift`, acessado a partir do objeto indicado antes do ponto.
      dados.partidas.unshift({

        // Define a propriedade `id` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `id` = identificador usado como nome da propriedade `id` dentro do objeto atual.
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,

        // Define a propriedade `dataHora` do objeto com o valor informado nesta linha.
        // `new` = cria uma nova instância da classe ou construtor indicado.
        // `Date` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `dataHora` = identificador usado como nome da propriedade `dataHora` dentro do objeto atual.
        // `jogador` = identificador que representa o jogador associado à operação atual.
        // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
        // `modo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a modo.
        // `corJogador` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corJogador.
        // `dificuldade` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dificuldade.
        // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
        // `totalLances` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a totalLances.
        dataHora: new Date().toISOString(), jogador: nome, modo, corJogador, dificuldade, resultado, totalLances,

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

      // Armazena ou atualiza o valor de `dados.partidas` utilizando o resultado definido nesta linha.
      // `dados.partidas.slice` = chama a função ou método `slice` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = indica que a operação deve começar no primeiro elemento da coleção.
      // `150` = limita o histórico persistido às 150 partidas mais recentes.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dados` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dados.
      // `slice` = identificador de propriedade ou método chamado `slice`, acessado a partir do objeto indicado antes do ponto.
      dados.partidas = dados.partidas.slice(0, 150);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._salvar` = acessa o atributo ou método `_salvar` pertencente à própria instância atual.
      // `this._salvar` = chama o método ou recurso `_salvar` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._salvar(dados);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `estatisticas` para executar a rotina correspondente a estatisticas.
    // `estatisticas` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    estatisticas(nome) {

      // Declara `dados` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `dados` = identificador utilizado para armazenar ou acessar o valor relacionado a dados.
      // `this._ler` = acessa o atributo ou método `_ler` pertencente à própria instância atual.
      // `this._ler` = chama o método ou recurso `_ler` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const dados = this._ler();

      // Retorna `dados.jogadores[(nome || '').trim().toLocaleLowerCase('pt-BR')] || null` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `''` = texto literal utilizado nesta instrução.
      // `'pt-BR'` = texto literal utilizado nesta instrução, contendo pt-BR.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `jogadores` = identificador de propriedade ou método chamado `jogadores`, acessado a partir do objeto indicado antes do ponto.
      // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
      // `trim` = identificador de propriedade ou método chamado `trim`, acessado a partir do objeto indicado antes do ponto.
      // `toLocaleLowerCase` = identificador de propriedade ou método chamado `toLocaleLowerCase`, acessado a partir do objeto indicado antes do ponto.
      return dados.jogadores[(nome || '').trim().toLocaleLowerCase('pt-BR')] || null;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `ranking` para executar a rotina correspondente a ranking.
    // `ranking` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    ranking() {

      // Retorna `Object.values(this._ler().jogadores).sort((a, b) => b.placar - a.placar || b.vitorias - a.vitorias || a.partidas - b.partidas || a.nome.localeCompare(b.nome))` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._ler` = acessa o atributo ou método `_ler` pertencente à própria instância atual.
      // `Object.values` = chama a função ou método `values` pertencente ao objeto ou recurso indicado antes do ponto.
      // `this._ler` = chama o método ou recurso `_ler` pertencente à instância atual.
      // `a.nome.localeCompare` = chama a função ou método `localeCompare` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Object` = objeto nativo que oferece operações relacionadas a objetos JavaScript.
      // `values` = identificador de propriedade ou método chamado `values`, acessado a partir do objeto indicado antes do ponto.
      // `sort` = identificador de propriedade ou método chamado `sort`, acessado a partir do objeto indicado antes do ponto.
      // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
      // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
      // `placar` = identificador de propriedade ou método chamado `placar`, acessado a partir do objeto indicado antes do ponto.
      // `vitorias` = identificador de propriedade ou método chamado `vitorias`, acessado a partir do objeto indicado antes do ponto.
      // `partidas` = identificador de propriedade ou método chamado `partidas`, acessado a partir do objeto indicado antes do ponto.
      // `localeCompare` = identificador de propriedade ou método chamado `localeCompare`, acessado a partir do objeto indicado antes do ponto.
      return Object.values(this._ler().jogadores).sort((a, b) => b.placar - a.placar || b.vitorias - a.vitorias || a.partidas - b.partidas || a.nome.localeCompare(b.nome));

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `this` = representa a própria instância atual da classe ou objeto.
    // `this._ler` = acessa o atributo ou método `_ler` pertencente à própria instância atual.
    // `this._ler` = chama o método ou recurso `_ler` pertencente à instância atual.
    // `historico` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    historico() { return this._ler().partidas; }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Declara `banco` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `new` = cria uma nova instância da classe ou construtor indicado.
  // `banco` = identificador utilizado para armazenar ou acessar o valor relacionado a banco.
  // `ArmazenamentoLocal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  const banco = new ArmazenamentoLocal();

  // Declara `sons` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `sons` = identificador utilizado para armazenar ou acessar o valor relacionado a sons.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  const sons = {};

  // Declara `somLigado` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `somLigado` = identificador utilizado para armazenar ou acessar o valor relacionado a somLigado.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let somLigado = true;

  // Declara `arquivosSom` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `arquivosSom` = identificador utilizado para armazenar ou acessar o valor relacionado a arquivosSom.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  const arquivosSom = {

    // Define a propriedade `menu` do objeto com o valor informado nesta linha.
    // `'sons/menu.wav'` = texto literal utilizado nesta instrução, contendo sons/menu.wav.
    // `'sons/inicio.wav'` = texto literal utilizado nesta instrução, contendo sons/inicio.wav.
    // `'sons/selecao.wav'` = texto literal utilizado nesta instrução, contendo sons/selecao.wav.
    // `'sons/movimento.wav'` = texto literal utilizado nesta instrução, contendo sons/movimento.wav.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `menu` = identificador usado como nome da propriedade `menu` dentro do objeto atual.
    // `inicio` = identificador usado como nome da propriedade `inicio` dentro do objeto atual.
    // `selecao` = identificador usado como nome da propriedade `selecao` dentro do objeto atual.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    menu: 'sons/menu.wav', inicio: 'sons/inicio.wav', selecao: 'sons/selecao.wav', movimento: 'sons/movimento.wav',

    // Define a propriedade `invalido` do objeto com o valor informado nesta linha.
    // `'sons/invalido.wav'` = texto literal utilizado nesta instrução, contendo sons/invalido.wav.
    // `'sons/captura.wav'` = texto literal utilizado nesta instrução, contendo sons/captura.wav.
    // `'sons/xeque.wav'` = texto literal utilizado nesta instrução, contendo sons/xeque.wav.
    // `'sons/roque.wav'` = texto literal utilizado nesta instrução, contendo sons/roque.wav.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `invalido` = identificador usado como nome da propriedade `invalido` dentro do objeto atual.
    // `captura` = identificador usado como nome da propriedade `captura` dentro do objeto atual.
    // `xeque` = identificador usado como nome da propriedade `xeque` dentro do objeto atual.
    // `roque` = identificador usado como nome da propriedade `roque` dentro do objeto atual.
    invalido: 'sons/invalido.wav', captura: 'sons/captura.wav', xeque: 'sons/xeque.wav', roque: 'sons/roque.wav',

    // Define a propriedade `promocao` do objeto com o valor informado nesta linha.
    // `'sons/promocao.wav'` = texto literal utilizado nesta instrução, contendo sons/promocao.wav.
    // `'sons/vitoria.wav'` = texto literal utilizado nesta instrução, contendo sons/vitoria.wav.
    // `'sons/derrota.wav'` = texto literal utilizado nesta instrução, contendo sons/derrota.wav.
    // `'sons/empate.wav'` = texto literal utilizado nesta instrução, contendo sons/empate.wav.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `promocao` = identificador usado como nome da propriedade `promocao` dentro do objeto atual.
    // `vitoria` = identificador usado como nome da propriedade `vitoria` dentro do objeto atual.
    // `derrota` = identificador usado como nome da propriedade `derrota` dentro do objeto atual.
    // `empate` = identificador usado como nome da propriedade `empate` dentro do objeto atual.
    promocao: 'sons/promocao.wav', vitoria: 'sons/vitoria.wav', derrota: 'sons/derrota.wav', empate: 'sons/empate.wav',

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  };

  // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
  // `of` = indica os valores percorridos em uma estrutura for...of.
  // `Object.entries` = chama a função ou método `entries` pertencente ao objeto ou recurso indicado antes do ponto.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
  // `]` = fecha a lista, o acesso por índice ou a chave calculada.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
  // `caminho` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a caminho.
  // `Object` = objeto nativo que oferece operações relacionadas a objetos JavaScript.
  // `entries` = identificador de propriedade ou método chamado `entries`, acessado a partir do objeto indicado antes do ponto.
  // `arquivosSom` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a arquivosSom.
  for (const [nome, caminho] of Object.entries(arquivosSom)) {

    // Declara `audio` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `new` = cria uma nova instância da classe ou construtor indicado.
    // `audio` = identificador utilizado para armazenar ou acessar o valor relacionado a audio.
    // `Audio` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    const audio = new Audio(caminho);

    // Armazena ou atualiza o valor de `audio.preload` utilizando o resultado definido nesta linha.
    // `'auto'` = texto literal utilizado nesta instrução, contendo auto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `preload` = identificador de propriedade ou método chamado `preload`, acessado a partir do objeto indicado antes do ponto.
    audio.preload = 'auto';

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `sons` = objeto que armazena os recursos de áudio utilizados pelo jogo.
    sons[nome] = audio;

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `tocarSom` para executar a rotina correspondente a tocarSom.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `tocarSom` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function tocarSom(nome) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `somLigado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a somLigado.
    // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
    if (!somLigado || !sons[nome]) return;

    // Inicia um bloco protegido para executar operações que podem gerar uma exceção durante a execução.
    // `try` = inicia um bloco protegido para executar instruções que podem gerar uma exceção.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    try {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `0` = reposiciona o áudio no início antes de reproduzi-lo novamente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `currentTime` = identificador de propriedade ou método chamado `currentTime`, acessado a partir do objeto indicado antes do ponto.
      sons[nome].currentTime = 0;

      // Declara `promessa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `promessa` = identificador utilizado para armazenar ou acessar o valor relacionado a promessa.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `sons` = objeto que armazena os recursos de áudio utilizados pelo jogo.
      // `play` = identificador de propriedade ou método chamado `play`, acessado a partir do objeto indicado antes do ponto.
      const promessa = sons[nome].play();

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `catch` = captura uma exceção produzida no bloco try e permite tratá-la.
      // `typeof` = obtém o tipo do valor ou expressão indicada.
      // `promessa.catch` = chama a função ou método `catch` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'function'` = texto literal utilizado nesta instrução, contendo function.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (promessa && typeof promessa.catch === 'function') promessa.catch(() => {});

    // Captura e trata uma possível exceção produzida pelas instruções executadas no bloco protegido anterior.
    // `catch` = captura uma exceção produzida no bloco try e permite tratá-la.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `_` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a  .
    } catch (_) {  }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Declara `estado` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `new` = cria uma nova instância da classe ou construtor indicado.
  // `estado` = identificador utilizado para armazenar ou acessar o valor relacionado a estado.
  // `EstadoXadrez` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  let estado = new EstadoXadrez();

  // Declara `ia` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `new` = cria uma nova instância da classe ou construtor indicado.
  // `ia` = identificador utilizado para armazenar ou acessar o valor relacionado a ia.
  // `InteligenciaXadrez` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'intermediario'` = texto literal utilizado nesta instrução, contendo intermediario.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  let ia = new InteligenciaXadrez('intermediario');

  // Declara `configuracao` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `configuracao` = identificador utilizado para armazenar ou acessar o valor relacionado a configuracao.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let configuracao = null;

  // Declara `selecionada` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `selecionada` = identificador utilizado para armazenar ou acessar o valor relacionado a selecionada.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let selecionada = null;

  // Declara `movimentosSelecionados` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `movimentosSelecionados` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentosSelecionados.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
  // `]` = fecha a lista, o acesso por índice ou a chave calculada.
  // `;` = encerra a instrução JavaScript atual.
  let movimentosSelecionados = [];

  // Declara `ultimoMovimentoIA` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `ultimoMovimentoIA` = identificador utilizado para armazenar ou acessar o valor relacionado a ultimoMovimentoIA.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let ultimoMovimentoIA = null;

  // Declara `partidaEncerrada` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `partidaEncerrada` = identificador utilizado para armazenar ou acessar o valor relacionado a partidaEncerrada.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let partidaEncerrada = false;

  // Declara `iaPensando` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `iaPensando` = identificador utilizado para armazenar ou acessar o valor relacionado a iaPensando.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let iaPensando = false;

  // Declara `iaPausada` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `iaPausada` = identificador utilizado para armazenar ou acessar o valor relacionado a iaPausada.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let iaPausada = false;

  // Declara `temporizadorIA` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `temporizadorIA` = identificador utilizado para armazenar ou acessar o valor relacionado a temporizadorIA.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let temporizadorIA = null;

  // Declara `temporizadorCaptura` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `temporizadorCaptura` = identificador utilizado para armazenar ou acessar o valor relacionado a temporizadorCaptura.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let temporizadorCaptura = null;

  // Declara `idPartida` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `idPartida` = identificador utilizado para armazenar ou acessar o valor relacionado a idPartida.
  // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let idPartida = 0;

  // Declara `toastTimer` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `toastTimer` = identificador utilizado para armazenar ou acessar o valor relacionado a toastTimer.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let toastTimer = null;

  // Declara `modalBloqueante` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `modalBloqueante` = identificador utilizado para armazenar ou acessar o valor relacionado a modalBloqueante.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let modalBloqueante = false;

  // Declara `renderizador3D` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `renderizador3D` = identificador utilizado para armazenar ou acessar o valor relacionado a renderizador3D.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let renderizador3D = null;

  // Declara `quadroEnquadramento3D` e armazena nele o valor ou resultado definido nesta linha.
  // `let` = declara uma variável que pode receber novos valores durante a execução.
  // `quadroEnquadramento3D` = identificador utilizado para armazenar ou acessar o valor relacionado a quadroEnquadramento3D.
  // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  let quadroEnquadramento3D = 0;

  // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
  // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
  // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
  // `RenderizadorXadrez3D` = identificador de propriedade ou método chamado `RenderizadorXadrez3D`, acessado a partir do objeto indicado antes do ponto.
  // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
  // `tabuleiro3d` = identificador de propriedade ou método chamado `tabuleiro3d`, acessado a partir do objeto indicado antes do ponto.
  if (window.RenderizadorXadrez3D && ui.tabuleiro3d) {

    // Armazena ou atualiza em `renderizador3D` o valor ou resultado definido nesta linha.
    // `new` = cria uma nova instância da classe ou construtor indicado.
    // `window.RenderizadorXadrez3D` = chama a função ou método `RenderizadorXadrez3D` pertencente ao objeto ou recurso indicado antes do ponto.
    // `clicarCasa` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `linha` = identificador que representa a linha de uma casa no tabuleiro.
    // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
    renderizador3D = new window.RenderizadorXadrez3D(ui.tabuleiro3d, (linha, coluna) => clicarCasa(linha, coluna));

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `nomeCor` para executar a rotina correspondente a nomeCor.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
  // `nomeCor` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `nomeCor` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'Brancas'` = texto literal utilizado nesta instrução, contendo Brancas.
  // `'Pretas'` = texto literal utilizado nesta instrução, contendo Pretas.
  // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
  // `;` = encerra a instrução JavaScript atual.
  // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
  // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
  function nomeCor(cor) { return cor === BRANCO ? 'Brancas' : 'Pretas'; }

  // Define a função `corHumana` para executar a rotina correspondente a corHumana.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
  // `corHumana` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
  // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
  function corHumana() { return configuracao?.cor || BRANCO; }

  // Define a função `ajustarEnquadramento3D` para executar a rotina correspondente a ajustarEnquadramento3D.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `ajustarEnquadramento3D` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `ajustarEnquadramento3D` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function ajustarEnquadramento3D() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `cancelAnimationFrame` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `quadroEnquadramento3D` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a quadroEnquadramento3D.
    cancelAnimationFrame(quadroEnquadramento3D);

    // Armazena ou atualiza em `quadroEnquadramento3D` o valor ou resultado definido nesta linha.
    // `requestAnimationFrame` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    quadroEnquadramento3D = requestAnimationFrame(() => {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
      // `cameraScene` = identificador de propriedade ou método chamado `cameraScene`, acessado a partir do objeto indicado antes do ponto.
      // `boardZone` = identificador de propriedade ou método chamado `boardZone`, acessado a partir do objeto indicado antes do ponto.
      if (!ui.cameraScene || !ui.boardZone) return;

      // Declara `camera` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `camera` = identificador utilizado para armazenar ou acessar o valor relacionado a camera.
      // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cameraJogo` = identificador de propriedade ou método chamado `cameraJogo`, acessado a partir do objeto indicado antes do ponto.
      // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
      // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
      const camera = ui.cameraJogo.value || configuracao?.camera || 'superior';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (camera === 'superior') {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ui.cameraScene.style.removeProperty` = chama a função ou método `removeProperty` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'width'` = texto literal utilizado nesta instrução, contendo width.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `style` = identificador de propriedade ou método chamado `style`, acessado a partir do objeto indicado antes do ponto.
        // `removeProperty` = identificador de propriedade ou método chamado `removeProperty`, acessado a partir do objeto indicado antes do ponto.
        ui.cameraScene.style.removeProperty('width');

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ui.cameraScene.style.removeProperty` = chama a função ou método `removeProperty` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'height'` = texto literal utilizado nesta instrução, contendo height.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        ui.cameraScene.style.removeProperty('height');

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ui.cameraScene.style.removeProperty` = chama a função ou método `removeProperty` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'max-width'` = texto literal utilizado nesta instrução, contendo max-width.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
        // `cameraScene` = identificador de propriedade ou método chamado `cameraScene`, acessado a partir do objeto indicado antes do ponto.
        ui.cameraScene.style.removeProperty('max-width');

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ui.cameraScene.style.removeProperty` = chama a função ou método `removeProperty` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'max-height'` = texto literal utilizado nesta instrução, contendo max-height.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        ui.cameraScene.style.removeProperty('max-height');

        // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `;` = encerra a instrução JavaScript atual.
        return;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `ui.telaJogo.classList.contains` = chama a função ou método `contains` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `telaJogo` = identificador de propriedade ou método chamado `telaJogo`, acessado a partir do objeto indicado antes do ponto.
      // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
      // `contains` = identificador de propriedade ou método chamado `contains`, acessado a partir do objeto indicado antes do ponto.
      if (ui.telaJogo.classList.contains('hidden')) return;

      // Declara `zona` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `zona` = identificador utilizado para armazenar ou acessar o valor relacionado a zona.
      // `ui.boardZone.getBoundingClientRect` = chama a função ou método `getBoundingClientRect` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `boardZone` = identificador de propriedade ou método chamado `boardZone`, acessado a partir do objeto indicado antes do ponto.
      // `getBoundingClientRect` = identificador de propriedade ou método chamado `getBoundingClientRect`, acessado a partir do objeto indicado antes do ponto.
      const zona = ui.boardZone.getBoundingClientRect();

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `width` = identificador de propriedade ou método chamado `width`, acessado a partir do objeto indicado antes do ponto.
      // `height` = identificador de propriedade ou método chamado `height`, acessado a partir do objeto indicado antes do ponto.
      if (zona.width < 20 || zona.height < 20) return;

      // Declara `dimensoes` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `dimensoes` = identificador utilizado para armazenar ou acessar o valor relacionado a dimensoes.
      // `'lateral'` = texto literal utilizado nesta instrução, contendo lateral.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `camera` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a camera.
      const dimensoes = camera === 'lateral'

        // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
        // `980` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `620` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `largura` = identificador usado como nome da propriedade `largura` dentro do objeto atual.
        // `altura` = identificador usado como nome da propriedade `altura` dentro do objeto atual.
        ? { largura: 980, altura: 620 }

        // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
        // `940` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `600` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        : { largura: 940, altura: 600 };

      // Declara `proporcao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `proporcao` = identificador utilizado para armazenar ou acessar o valor relacionado a proporcao.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `/` = realiza divisão.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const proporcao = dimensoes.largura / dimensoes.altura;

      // Declara `margemHorizontal` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `margemHorizontal` = identificador utilizado para armazenar ou acessar o valor relacionado a margemHorizontal.
      // `860` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
      // `innerWidth` = identificador de propriedade ou método chamado `innerWidth`, acessado a partir do objeto indicado antes do ponto.
      const margemHorizontal = window.innerWidth <= 860 ? 4 : 8;

      // Declara `margemInferior` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `margemInferior` = identificador utilizado para armazenar ou acessar o valor relacionado a margemInferior.
      // `10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const margemInferior = 10;

      // Declara `larguraDisponivel` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `larguraDisponivel` = identificador utilizado para armazenar ou acessar o valor relacionado a larguraDisponivel.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      // `dimensoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dimensoes.
      // `largura` = identificador de propriedade ou método chamado `largura`, acessado a partir do objeto indicado antes do ponto.
      // `zona` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a zona.
      // `width` = identificador de propriedade ou método chamado `width`, acessado a partir do objeto indicado antes do ponto.
      const larguraDisponivel = Math.max(1, Math.min(dimensoes.largura, zona.width - margemHorizontal * 2));

      // Declara `topoVisivel` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `topoVisivel` = identificador utilizado para armazenar ou acessar o valor relacionado a topoVisivel.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `top` = identificador de propriedade ou método chamado `top`, acessado a partir do objeto indicado antes do ponto.
      const topoVisivel = Math.max(0, zona.top);

      // Declara `alturaNoViewport` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `alturaNoViewport` = identificador utilizado para armazenar ou acessar o valor relacionado a alturaNoViewport.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
      // `innerHeight` = identificador de propriedade ou método chamado `innerHeight`, acessado a partir do objeto indicado antes do ponto.
      // `margemInferior` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a margemInferior.
      const alturaNoViewport = Math.max(1, window.innerHeight - topoVisivel - margemInferior);

      // Declara `alturaNaZona` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `alturaNaZona` = identificador utilizado para armazenar ou acessar o valor relacionado a alturaNaZona.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      // `height` = identificador de propriedade ou método chamado `height`, acessado a partir do objeto indicado antes do ponto.
      const alturaNaZona = Math.max(1, zona.height - margemInferior);

      // Declara `alturaDisponivel` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `alturaDisponivel` = identificador utilizado para armazenar ou acessar o valor relacionado a alturaDisponivel.
      // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
      // `dimensoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dimensoes.
      // `altura` = identificador de propriedade ou método chamado `altura`, acessado a partir do objeto indicado antes do ponto.
      const alturaDisponivel = Math.min(dimensoes.altura, alturaNoViewport, alturaNaZona);

      // Declara `largura` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `largura` = identificador utilizado para armazenar ou acessar o valor relacionado a largura.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `larguraDisponivel` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a larguraDisponivel.
      let largura = larguraDisponivel;

      // Declara `altura` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `altura` = identificador utilizado para armazenar ou acessar o valor relacionado a altura.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `/` = realiza divisão.
      // `;` = encerra a instrução JavaScript atual.
      // `proporcao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a proporcao.
      let altura = largura / proporcao;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `>` = verifica se o valor da esquerda é maior que o valor da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (altura > alturaDisponivel) {

        // Armazena ou atualiza em `altura` o valor ou resultado definido nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        altura = alturaDisponivel;

        // Armazena ou atualiza em `largura` o valor ou resultado definido nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `*` = realiza multiplicação.
        // `;` = encerra a instrução JavaScript atual.
        largura = altura * proporcao;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Armazena ou atualiza o valor de `ui.cameraScene.style.width` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
      // `cameraScene` = identificador de propriedade ou método chamado `cameraScene`, acessado a partir do objeto indicado antes do ponto.
      // `style` = identificador de propriedade ou método chamado `style`, acessado a partir do objeto indicado antes do ponto.
      // `width` = identificador de propriedade ou método chamado `width`, acessado a partir do objeto indicado antes do ponto.
      ui.cameraScene.style.width = `${Math.max(1, Math.floor(largura))}px`;

      // Armazena ou atualiza o valor de `ui.cameraScene.style.height` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `height` = identificador de propriedade ou método chamado `height`, acessado a partir do objeto indicado antes do ponto.
      ui.cameraScene.style.height = `${Math.max(1, Math.floor(altura))}px`;

      // Armazena ou atualiza o valor de `ui.cameraScene.style.maxWidth` utilizando o resultado definido nesta linha.
      // `'100%'` = texto literal utilizado nesta instrução, contendo 100%.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `maxWidth` = identificador de propriedade ou método chamado `maxWidth`, acessado a partir do objeto indicado antes do ponto.
      ui.cameraScene.style.maxWidth = '100%';

      // Armazena ou atualiza o valor de `ui.cameraScene.style.maxHeight` utilizando o resultado definido nesta linha.
      // `'100%'` = texto literal utilizado nesta instrução, contendo 100%.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `maxHeight` = identificador de propriedade ou método chamado `maxHeight`, acessado a partir do objeto indicado antes do ponto.
      ui.cameraScene.style.maxHeight = '100%';

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    });

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `cameraAplicar` para executar a rotina correspondente a cameraAplicar.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `cameraAplicar` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `valor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a valor.
  function cameraAplicar(valor) {

    // Declara `camera` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `camera` = identificador utilizado para armazenar ou acessar o valor relacionado a camera.
    // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `NOMES_CAMERAS` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a NOMES CAMERAS.
    const camera = NOMES_CAMERAS[valor] ? valor : 'superior';

    // Armazena ou atualiza o valor de `ui.cameraScene.className` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `cameraScene` = identificador de propriedade ou método chamado `cameraScene`, acessado a partir do objeto indicado antes do ponto.
    // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
    ui.cameraScene.className = `camera-scene camera-${camera}`;

    // Armazena ou atualiza o valor de `ui.cameraJogo.value` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `cameraJogo` = identificador de propriedade ou método chamado `cameraJogo`, acessado a partir do objeto indicado antes do ponto.
    // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
    ui.cameraJogo.value = camera;

    // Armazena ou atualiza o valor de `ui.cameraMenu.value` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `cameraMenu` = identificador de propriedade ou método chamado `cameraMenu`, acessado a partir do objeto indicado antes do ponto.
    ui.cameraMenu.value = camera;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    if (configuracao) configuracao.camera = camera;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `renderizador3D.definirCamera` = chama a função ou método `definirCamera` pertencente ao objeto ou recurso indicado antes do ponto.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `renderizador3D` = objeto responsável por desenhar e atualizar a visualização tridimensional do tabuleiro.
    // `definirCamera` = identificador de propriedade ou método chamado `definirCamera`, acessado a partir do objeto indicado antes do ponto.
    // `camera` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a camera.
    if (renderizador3D) renderizador3D.definirCamera(camera);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ajustarEnquadramento3D` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    ajustarEnquadramento3D();

    // Declara `casas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `casas` = identificador utilizado para armazenar ou acessar o valor relacionado a casas.
    // `ui.tabuleiro.querySelectorAll` = chama a função ou método `querySelectorAll` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'.square'` = texto literal utilizado nesta instrução, contendo .square.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
    // `querySelectorAll` = identificador de propriedade ou método chamado `querySelectorAll`, acessado a partir do objeto indicado antes do ponto.
    const casas = ui.tabuleiro.querySelectorAll('.square');

    // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
    // `casas.forEach` = chama a função ou método `forEach` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `forEach` = identificador de propriedade ou método chamado `forEach`, acessado a partir do objeto indicado antes do ponto.
    // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
    casas.forEach((casa) => {

      // Declara `linha` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `linha` = identificador utilizado para armazenar ou acessar o valor relacionado a linha.
      // `Number` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dataset` = identificador de propriedade ou método chamado `dataset`, acessado a partir do objeto indicado antes do ponto.
      const linha = Number(casa.dataset.linha);

      // Declara `coluna` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `coluna` = identificador utilizado para armazenar ou acessar o valor relacionado a coluna.
      // `Number` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const coluna = Number(casa.dataset.coluna);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
      // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
      // `20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `camera` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a camera.
      // `style` = identificador de propriedade ou método chamado `style`, acessado a partir do objeto indicado antes do ponto.
      // `zIndex` = identificador de propriedade ou método chamado `zIndex`, acessado a partir do objeto indicado antes do ponto.
      if (camera === 'pretas') casa.style.zIndex = String((7 - linha) * 20 + (7 - coluna));

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'lateral'` = texto literal utilizado nesta instrução, contendo lateral.
      // `20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      else if (camera === 'lateral') casa.style.zIndex = String(linha * 20 + (7 - coluna));

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'brancas'` = texto literal utilizado nesta instrução, contendo brancas.
      // `20` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      else if (camera === 'brancas') casa.style.zIndex = String(linha * 20 + coluna);

      // Executa o bloco alternativo quando a condição anterior não foi atendida.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `''` = texto literal utilizado nesta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      else casa.style.zIndex = '';

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    });

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `atualizarCampoCor` para executar a rotina correspondente a atualizarCampoCor.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `atualizarCampoCor` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `atualizarCampoCor` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function atualizarCampoCor() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.campoCor.classList.toggle` = chama a função ou método `toggle` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `campoCor` = identificador de propriedade ou método chamado `campoCor`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `toggle` = identificador de propriedade ou método chamado `toggle`, acessado a partir do objeto indicado antes do ponto.
    // `modoJogo` = identificador de propriedade ou método chamado `modoJogo`, acessado a partir do objeto indicado antes do ponto.
    // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
    ui.campoCor.classList.toggle('hidden', ui.modoJogo.value === 'ia-ia');

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `mostrarToast` para executar a rotina correspondente a mostrarToast.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `mostrarToast` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `''` = texto literal utilizado nesta instrução.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `texto` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a texto.
  // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
  function mostrarToast(texto, tipo = '') {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `toastTimer` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a toastTimer.
    clearTimeout(toastTimer);

    // Armazena ou atualiza o valor de `ui.toast.textContent` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `toast` = identificador de propriedade ou método chamado `toast`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    ui.toast.textContent = texto;

    // Armazena ou atualiza o valor de `ui.toast.className` utilizando o resultado definido nesta linha.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
    // `$` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a $.
    ui.toast.className = `toast${tipo ? ` ${tipo}` : ''}`;

    // Armazena ou atualiza em `toastTimer` o valor ou resultado definido nesta linha.
    // `ui.toast.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `setTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `4200` = define um intervalo de tempo em milissegundos utilizado nesta temporização.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    toastTimer = setTimeout(() => ui.toast.classList.add('hidden'), 4200);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `abrirModal` para executar a rotina correspondente a abrirModal.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `abrirModal` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
  // `]` = fecha a lista, o acesso por índice ou a chave calculada.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `titulo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a titulo.
  // `html` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a html.
  // `acoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a acoes.
  // `bloqueante` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a bloqueante.
  function abrirModal(titulo, html, acoes = [], bloqueante = false) {

    // Armazena ou atualiza em `modalBloqueante` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `modalBloqueante` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a modalBloqueante.
    modalBloqueante = bloqueante;

    // Armazena ou atualiza o valor de `ui.modalTitulo.textContent` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modalTitulo` = identificador de propriedade ou método chamado `modalTitulo`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    ui.modalTitulo.textContent = titulo;

    // Armazena ou atualiza o valor de `ui.modalConteudo.innerHTML` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modalConteudo` = identificador de propriedade ou método chamado `modalConteudo`, acessado a partir do objeto indicado antes do ponto.
    // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
    ui.modalConteudo.innerHTML = html;

    // Armazena ou atualiza o valor de `ui.modalAcoes.innerHTML` utilizando o resultado definido nesta linha.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `modalAcoes` = identificador de propriedade ou método chamado `modalAcoes`, acessado a partir do objeto indicado antes do ponto.
    ui.modalAcoes.innerHTML = '';

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.btnFecharModal.classList.toggle` = chama a função ou método `toggle` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `btnFecharModal` = identificador de propriedade ou método chamado `btnFecharModal`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `toggle` = identificador de propriedade ou método chamado `toggle`, acessado a partir do objeto indicado antes do ponto.
    ui.btnFecharModal.classList.toggle('hidden', bloqueante);

    // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
    // `of` = indica os valores percorridos em uma estrutura for...of.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `acao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a acao.
    // `acoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a acoes.
    for (const acao of acoes) {

      // Declara `botao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `botao` = identificador utilizado para armazenar ou acessar o valor relacionado a botao.
      // `document.createElement` = chama a função ou método `createElement` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'button'` = texto literal utilizado nesta instrução, contendo button.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `document` = objeto que representa o documento HTML carregado no navegador.
      // `createElement` = identificador de propriedade ou método chamado `createElement`, acessado a partir do objeto indicado antes do ponto.
      const botao = document.createElement('button');

      // Armazena ou atualiza o valor de `botao.type` utilizando o resultado definido nesta linha.
      // `'button'` = texto literal utilizado nesta instrução, contendo button.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `type` = identificador de propriedade ou método chamado `type`, acessado a partir do objeto indicado antes do ponto.
      botao.type = 'button';

      // Armazena ou atualiza o valor de `botao.className` utilizando o resultado definido nesta linha.
      // `'secondary-button'` = texto literal utilizado nesta instrução, contendo secondary-button.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
      // `classe` = identificador de propriedade ou método chamado `classe`, acessado a partir do objeto indicado antes do ponto.
      botao.className = acao.classe || 'secondary-button';

      // Armazena ou atualiza o valor de `botao.textContent` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
      // `texto` = identificador de propriedade ou método chamado `texto`, acessado a partir do objeto indicado antes do ponto.
      botao.textContent = acao.texto;

      // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
      // `botao.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
      // `acao.aoClicar` = chama a função ou método `aoClicar` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'click'` = texto literal utilizado nesta instrução, contendo click.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
      // `acao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a acao.
      // `aoClicar` = identificador de propriedade ou método chamado `aoClicar`, acessado a partir do objeto indicado antes do ponto.
      botao.addEventListener('click', () => acao.aoClicar(botao));

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ui.modalAcoes.appendChild` = chama a função ou método `appendChild` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
      // `modalAcoes` = identificador de propriedade ou método chamado `modalAcoes`, acessado a partir do objeto indicado antes do ponto.
      // `appendChild` = identificador de propriedade ou método chamado `appendChild`, acessado a partir do objeto indicado antes do ponto.
      // `botao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a botao.
      ui.modalAcoes.appendChild(botao);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.modal.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modal` = identificador de propriedade ou método chamado `modal`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.modal.classList.remove('hidden');

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `fecharModal` para executar a rotina correspondente a fecharModal.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `fecharModal` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `fecharModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function fecharModal() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `modalBloqueante` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a modalBloqueante.
    if (modalBloqueante) return;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.modal.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    ui.modal.classList.add('hidden');

    // Armazena ou atualiza o valor de `ui.modalConteudo.innerHTML` utilizando o resultado definido nesta linha.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modalConteudo` = identificador de propriedade ou método chamado `modalConteudo`, acessado a partir do objeto indicado antes do ponto.
    // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
    ui.modalConteudo.innerHTML = '';

    // Armazena ou atualiza o valor de `ui.modalAcoes.innerHTML` utilizando o resultado definido nesta linha.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modalAcoes` = identificador de propriedade ou método chamado `modalAcoes`, acessado a partir do objeto indicado antes do ponto.
    ui.modalAcoes.innerHTML = '';

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `fecharModalForcado` para executar a rotina correspondente a fecharModalForcado.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `fecharModalForcado` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function fecharModalForcado() {

    // Armazena ou atualiza em `modalBloqueante` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    modalBloqueante = false;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.btnFecharModal.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `btnFecharModal` = identificador de propriedade ou método chamado `btnFecharModal`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.btnFecharModal.classList.remove('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `fecharModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    fecharModal();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `criarTabuleiroDOM` para executar a rotina correspondente a criarTabuleiroDOM.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `criarTabuleiroDOM` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `criarTabuleiroDOM` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function criarTabuleiroDOM() {

    // Armazena ou atualiza o valor de `ui.tabuleiro.innerHTML` utilizando o resultado definido nesta linha.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
    // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
    ui.tabuleiro.innerHTML = '';

    // Declara `letras` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `letras` = identificador utilizado para armazenar ou acessar o valor relacionado a letras.
    // `'abcdefgh'` = texto literal utilizado nesta instrução, contendo abcdefgh.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    const letras = 'abcdefgh';

    // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
    // `0` = representa o primeiro índice possível quando a contagem começa em zero.
    // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
    // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
    // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
    // `<` = verifica se o valor da esquerda é menor que o valor da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `linha` = identificador que representa a linha de uma casa no tabuleiro.
    for (let linha = 0; linha < 8; linha += 1) {

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      for (let coluna = 0; coluna < 8; coluna += 1) {

        // Declara `casa` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `casa` = identificador utilizado para armazenar ou acessar o valor relacionado a casa.
        // `document.createElement` = chama a função ou método `createElement` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'div'` = texto literal utilizado nesta instrução, contendo div.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `document` = objeto que representa o documento HTML carregado no navegador.
        // `createElement` = identificador de propriedade ou método chamado `createElement`, acessado a partir do objeto indicado antes do ponto.
        const casa = document.createElement('div');

        // Armazena ou atualiza o valor de `casa.className` utilizando o resultado definido nesta linha.
        // `'light'` = texto literal utilizado nesta instrução, contendo light.
        // `'dark'` = texto literal utilizado nesta instrução, contendo dark.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
        casa.className = `square ${(linha + coluna) % 2 === 0 ? 'light' : 'dark'}`;

        // Armazena ou atualiza o valor de `casa.dataset.linha` utilizando o resultado definido nesta linha.
        // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `dataset` = identificador de propriedade ou método chamado `dataset`, acessado a partir do objeto indicado antes do ponto.
        casa.dataset.linha = String(linha);

        // Armazena ou atualiza o valor de `casa.dataset.coluna` utilizando o resultado definido nesta linha.
        // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        casa.dataset.coluna = String(coluna);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `casa.setAttribute` = chama a função ou método `setAttribute` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'role'` = texto literal utilizado nesta instrução, contendo role.
        // `'gridcell'` = texto literal utilizado nesta instrução, contendo gridcell.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `setAttribute` = identificador de propriedade ou método chamado `setAttribute`, acessado a partir do objeto indicado antes do ponto.
        casa.setAttribute('role', 'gridcell');

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `casa.setAttribute` = chama a função ou método `setAttribute` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'aria-label'` = texto literal utilizado nesta instrução, contendo aria-label.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
        casa.setAttribute('aria-label', `${letras[coluna]}${8 - linha}`);

        // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
        // `casa.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
        // `clicarCasa` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'click'` = texto literal utilizado nesta instrução, contendo click.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        casa.addEventListener('click', () => clicarCasa(linha, coluna));

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        if (linha === 7) {

          // Declara `coord` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `coord` = identificador utilizado para armazenar ou acessar o valor relacionado a coord.
          // `document.createElement` = chama a função ou método `createElement` pertencente ao objeto ou recurso indicado antes do ponto.
          // `'span'` = texto literal utilizado nesta instrução, contendo span.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `document` = objeto que representa o documento HTML carregado no navegador.
          // `createElement` = identificador de propriedade ou método chamado `createElement`, acessado a partir do objeto indicado antes do ponto.
          const coord = document.createElement('span');

          // Armazena ou atualiza o valor de `coord.className` utilizando o resultado definido nesta linha.
          // `'coord file'` = texto literal utilizado nesta instrução, contendo coord file.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
          coord.className = 'coord file';

          // Armazena ou atualiza o valor de `coord.textContent` utilizando o resultado definido nesta linha.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
          // `letras` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a letras.
          coord.textContent = letras[coluna];

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `casa.appendChild` = chama a função ou método `appendChild` pertencente ao objeto ou recurso indicado antes do ponto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
          // `appendChild` = identificador de propriedade ou método chamado `appendChild`, acessado a partir do objeto indicado antes do ponto.
          casa.appendChild(coord);

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        if (coluna === 0) {

          // Declara `coord` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `coord` = identificador utilizado para armazenar ou acessar o valor relacionado a coord.
          // `document.createElement` = chama a função ou método `createElement` pertencente ao objeto ou recurso indicado antes do ponto.
          // `'span'` = texto literal utilizado nesta instrução, contendo span.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `document` = objeto que representa o documento HTML carregado no navegador.
          // `createElement` = identificador de propriedade ou método chamado `createElement`, acessado a partir do objeto indicado antes do ponto.
          const coord = document.createElement('span');

          // Armazena ou atualiza o valor de `coord.className` utilizando o resultado definido nesta linha.
          // `'coord rank'` = texto literal utilizado nesta instrução, contendo coord rank.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
          coord.className = 'coord rank';

          // Armazena ou atualiza o valor de `coord.textContent` utilizando o resultado definido nesta linha.
          // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
          // `linha` = identificador que representa a linha de uma casa no tabuleiro.
          coord.textContent = String(8 - linha);

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `casa.appendChild` = chama a função ou método `appendChild` pertencente ao objeto ou recurso indicado antes do ponto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
          // `appendChild` = identificador de propriedade ou método chamado `appendChild`, acessado a partir do objeto indicado antes do ponto.
          casa.appendChild(coord);

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `ui.tabuleiro.appendChild` = chama a função ou método `appendChild` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
        // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
        ui.tabuleiro.appendChild(casa);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `renderizarTabuleiro` para executar a rotina correspondente a renderizarTabuleiro.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `renderizarTabuleiro` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `renderizarTabuleiro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function renderizarTabuleiro() {

    // Declara `casas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `casas` = identificador utilizado para armazenar ou acessar o valor relacionado a casas.
    // `ui.tabuleiro.querySelectorAll` = chama a função ou método `querySelectorAll` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'.square'` = texto literal utilizado nesta instrução, contendo .square.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `querySelectorAll` = identificador de propriedade ou método chamado `querySelectorAll`, acessado a partir do objeto indicado antes do ponto.
    const casas = ui.tabuleiro.querySelectorAll('.square');

    // Declara `reiXeque` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `reiXeque` = identificador utilizado para armazenar ou acessar o valor relacionado a reiXeque.
    // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
    // `estado.encontrarRei` = chama a função ou método `encontrarRei` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    // `encontrarRei` = identificador de propriedade ou método chamado `encontrarRei`, acessado a partir do objeto indicado antes do ponto.
    const reiXeque = estado.estaEmXeque(estado.turno) ? estado.encontrarRei(estado.turno) : null;

    // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
    // `casas.forEach` = chama a função ou método `forEach` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `forEach` = identificador de propriedade ou método chamado `forEach`, acessado a partir do objeto indicado antes do ponto.
    // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
    casas.forEach((casa) => {

      // Declara `linha` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `linha` = identificador utilizado para armazenar ou acessar o valor relacionado a linha.
      // `Number` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dataset` = identificador de propriedade ou método chamado `dataset`, acessado a partir do objeto indicado antes do ponto.
      const linha = Number(casa.dataset.linha);

      // Declara `coluna` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `coluna` = identificador utilizado para armazenar ou acessar o valor relacionado a coluna.
      // `Number` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const coluna = Number(casa.dataset.coluna);

      // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
      const peca = estado.tabuleiro[linha][coluna];

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `casa.querySelectorAll` = chama a função ou método `querySelectorAll` pertencente ao objeto ou recurso indicado antes do ponto.
      // `el.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'.piece'` = texto literal utilizado nesta instrução, contendo .piece.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `querySelectorAll` = identificador de propriedade ou método chamado `querySelectorAll`, acessado a partir do objeto indicado antes do ponto.
      // `el` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a el.
      // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
      casa.querySelectorAll('.piece').forEach((el) => el.remove());

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `casa.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'selected'` = texto literal utilizado nesta instrução, contendo selected.
      // `'legal'` = texto literal utilizado nesta instrução, contendo legal.
      // `'capture'` = texto literal utilizado nesta instrução, contendo capture.
      // `'last'` = texto literal utilizado nesta instrução, contendo last.
      // `'check'` = texto literal utilizado nesta instrução, contendo check.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
      // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
      casa.classList.remove('selected', 'legal', 'capture', 'last', 'check');

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `casa.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'selected'` = texto literal utilizado nesta instrução, contendo selected.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
      if (selecionada && posIgual(selecionada, [linha, coluna])) casa.classList.add('selected');

      // Declara `legal` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `legal` = identificador utilizado para armazenar ou acessar o valor relacionado a legal.
      // `movimentosSelecionados.find` = chama a função ou método `find` pertencente ao objeto ou recurso indicado antes do ponto.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
      // `find` = identificador de propriedade ou método chamado `find`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `destino` = identificador que representa a casa de destino de um movimento.
      const legal = movimentosSelecionados.find((m) => posIgual(m.destino, [linha, coluna]));

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `casa.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'capture'` = texto literal utilizado nesta instrução, contendo capture.
      // `'legal'` = texto literal utilizado nesta instrução, contendo legal.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
      // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
      // `capturada` = identificador que representa a peça capturada em uma jogada.
      // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
      if (legal) casa.classList.add(legal.capturada || legal.enPassant ? 'capture' : 'legal');

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `casa.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'last'` = texto literal utilizado nesta instrução, contendo last.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ultimoMovimentoIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ultimoMovimentoIA.
      // `origem` = identificador que representa a casa de origem de um movimento.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
      if (ultimoMovimentoIA && (posIgual(ultimoMovimentoIA.origem, [linha, coluna]) || posIgual(ultimoMovimentoIA.destino, [linha, coluna]))) casa.classList.add('last');

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `casa.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'check'` = texto literal utilizado nesta instrução, contendo check.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `reiXeque` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a reiXeque.
      if (reiXeque && posIgual(reiXeque, [linha, coluna])) casa.classList.add('check');

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `peca` = identificador que representa uma peça de xadrez.
      if (peca) {

        // Declara `span` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `span` = identificador utilizado para armazenar ou acessar o valor relacionado a span.
        // `document.createElement` = chama a função ou método `createElement` pertencente ao objeto ou recurso indicado antes do ponto.
        // `'span'` = texto literal utilizado nesta instrução, contendo span.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `document` = objeto que representa o documento HTML carregado no navegador.
        // `createElement` = identificador de propriedade ou método chamado `createElement`, acessado a partir do objeto indicado antes do ponto.
        const span = document.createElement('span');

        // Armazena ou atualiza o valor de `span.className` utilizando o resultado definido nesta linha.
        // `'white'` = texto literal utilizado nesta instrução, contendo white.
        // `'black'` = texto literal utilizado nesta instrução, contendo black.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
        span.className = `piece ${peca.cor === BRANCO ? 'white' : 'black'}`;

        // Armazena ou atualiza o valor de `span.dataset.tipo` utilizando o resultado definido nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `dataset` = identificador de propriedade ou método chamado `dataset`, acessado a partir do objeto indicado antes do ponto.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        span.dataset.tipo = peca.tipo;

        // Armazena ou atualiza o valor de `span.textContent` utilizando o resultado definido nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
        // `SIMBOLOS` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a SIMBOLOS.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        span.textContent = SIMBOLOS[peca.cor][peca.tipo];

        // Armazena ou atualiza o valor de `span.title` utilizando o resultado definido nesta linha.
        // `'branco'` = texto literal utilizado nesta instrução, contendo branco.
        // `'preto'` = texto literal utilizado nesta instrução, contendo preto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `title` = identificador de propriedade ou método chamado `title`, acessado a partir do objeto indicado antes do ponto.
        span.title = `${NOMES_PECAS[peca.tipo]} ${peca.cor === BRANCO ? 'branco' : 'preto'}`;

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `casa.appendChild` = chama a função ou método `appendChild` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
        // `appendChild` = identificador de propriedade ou método chamado `appendChild`, acessado a partir do objeto indicado antes do ponto.
        // `span` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a span.
        casa.appendChild(span);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    });

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `renderizador3D` = objeto responsável por desenhar e atualizar a visualização tridimensional do tabuleiro.
    if (renderizador3D) {

      // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
      // `renderizador3D.renderizar` = chama a função ou método `renderizar` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `renderizar` = identificador de propriedade ou método chamado `renderizar`, acessado a partir do objeto indicado antes do ponto.
      renderizador3D.renderizar({

        // Define a propriedade `tabuleiro` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
        // `estado` = identificador que representa o estado atual da partida de xadrez.
        tabuleiro: estado.tabuleiro,

        // Define a propriedade `camera` do objeto com o valor informado nesta linha.
        // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `camera` = identificador de propriedade ou método chamado `camera`, acessado a partir do objeto indicado antes do ponto.
        // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
        // `cameraJogo` = identificador de propriedade ou método chamado `cameraJogo`, acessado a partir do objeto indicado antes do ponto.
        // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
        // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
        camera: ui.cameraJogo.value || configuracao?.camera || 'superior',

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
        selecionada,

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
        movimentosSelecionados,

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `ultimoMovimentoIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ultimoMovimentoIA.
        ultimoMovimentoIA,

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `reiXeque` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a reiXeque.
        reiXeque,

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `atualizarHistoricoLances` para executar a rotina correspondente a atualizarHistoricoLances.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `atualizarHistoricoLances` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `atualizarHistoricoLances` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function atualizarHistoricoLances() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    if (!estado.historico.length) {

      // Armazena ou atualiza o valor de `ui.historicoLances.innerHTML` utilizando o resultado definido nesta linha.
      // `'<p class="empty-state">Nenhum lance realizado.</p>'` = texto literal utilizado nesta instrução, contendo <p class="empty-state">Nenhum lance realizado.</p>.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
      // `historicoLances` = identificador de propriedade ou método chamado `historicoLances`, acessado a partir do objeto indicado antes do ponto.
      // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
      ui.historicoLances.innerHTML = '<p class="empty-state">Nenhum lance realizado.</p>';

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `linhas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `linhas` = identificador utilizado para armazenar ou acessar o valor relacionado a linhas.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    const linhas = [];

    // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
    // `0` = representa o primeiro índice possível quando a contagem começa em zero.
    // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
    // `<` = verifica se o valor da esquerda é menor que o valor da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
    for (let i = 0; i < estado.historico.length; i += 2) {

      // Declara `brancas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `brancas` = identificador utilizado para armazenar ou acessar o valor relacionado a brancas.
      // `notacaoSimples` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `''` = texto literal utilizado nesta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
      const brancas = estado.historico[i] ? notacaoSimples(estado.historico[i]) : '';

      // Declara `pretas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `pretas` = identificador utilizado para armazenar ou acessar o valor relacionado a pretas.
      // `notacaoSimples` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `''` = texto literal utilizado nesta instrução.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const pretas = estado.historico[i + 1] ? notacaoSimples(estado.historico[i + 1]) : '';

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `linhas.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
      // `"move-row"` = texto literal utilizado nesta instrução, contendo move-row.
      // `"num"` = texto literal utilizado nesta instrução, contendo num.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `linhas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhas.
      // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
      linhas.push(`<div class="move-row"><span class="num">${Math.floor(i / 2) + 1}.</span><span>${brancas}</span><span>${pretas}</span></div>`);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Armazena ou atualiza o valor de `ui.historicoLances.innerHTML` utilizando o resultado definido nesta linha.
    // `linhas.join` = chama a função ou método `join` pertencente ao objeto ou recurso indicado antes do ponto.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `historicoLances` = identificador de propriedade ou método chamado `historicoLances`, acessado a partir do objeto indicado antes do ponto.
    // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
    // `join` = identificador de propriedade ou método chamado `join`, acessado a partir do objeto indicado antes do ponto.
    ui.historicoLances.innerHTML = linhas.join('');

    // Armazena ou atualiza o valor de `ui.historicoLances.scrollTop` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `scrollTop` = identificador de propriedade ou método chamado `scrollTop`, acessado a partir do objeto indicado antes do ponto.
    // `scrollHeight` = identificador de propriedade ou método chamado `scrollHeight`, acessado a partir do objeto indicado antes do ponto.
    ui.historicoLances.scrollTop = ui.historicoLances.scrollHeight;

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `simbolosCapturados` para executar a rotina correspondente a simbolosCapturados.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `simbolosCapturados` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `simbolosCapturados` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `lista` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a lista.
  function simbolosCapturados(lista) {

    // Retorna `lista.length ? lista.map((p) => SIMBOLOS[p.cor][p.tipo]).join(' ') : '—'` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `lista.map` = chama a função ou método `map` pertencente ao objeto ou recurso indicado antes do ponto.
    // `' '` = texto literal utilizado nesta instrução, contendo  .
    // `'—'` = texto literal utilizado nesta instrução, contendo —.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
    // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
    // `SIMBOLOS` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a SIMBOLOS.
    // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
    // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
    return lista.length ? lista.map((p) => SIMBOLOS[p.cor][p.tipo]).join(' ') : '—';

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `turnoControladoPorIA` para executar a rotina correspondente a turnoControladoPorIA.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `turnoControladoPorIA` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `turnoControladoPorIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function turnoControladoPorIA() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    if (!configuracao || partidaEncerrada) return false;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    if (configuracao.modo === 'ia-ia') return true;

    // Retorna `estado.turno !== corHumana()` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    return estado.turno !== corHumana();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `atualizarPainel` para executar a rotina correspondente a atualizarPainel.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `atualizarPainel` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `atualizarPainel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function atualizarPainel() {

    // Armazena ou atualiza o valor de `ui.statusTurno.textContent` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `statusTurno` = identificador de propriedade ou método chamado `statusTurno`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    ui.statusTurno.textContent = `Turno: ${nomeCor(estado.turno)}`;

    // Armazena ou atualiza o valor de `ui.numeroLance.textContent` utilizando o resultado definido nesta linha.
    // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `numeroLance` = identificador de propriedade ou método chamado `numeroLance`, acessado a partir do objeto indicado antes do ponto.
    ui.numeroLance.textContent = String(estado.numeroLance);

    // Armazena ou atualiza o valor de `ui.capturadasBrancas.textContent` utilizando o resultado definido nesta linha.
    // `simbolosCapturados` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `capturadasBrancas` = identificador de propriedade ou método chamado `capturadasBrancas`, acessado a partir do objeto indicado antes do ponto.
    ui.capturadasBrancas.textContent = simbolosCapturados(estado.capturadasBrancas);

    // Armazena ou atualiza o valor de `ui.capturadasPretas.textContent` utilizando o resultado definido nesta linha.
    // `simbolosCapturados` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `capturadasPretas` = identificador de propriedade ou método chamado `capturadasPretas`, acessado a partir do objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    ui.capturadasPretas.textContent = simbolosCapturados(estado.capturadasPretas);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `atualizarHistoricoLances` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    atualizarHistoricoLances();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `'Partida encerrada'` = texto literal utilizado nesta instrução, contendo Partida encerrada.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `statusJogo` = identificador de propriedade ou método chamado `statusJogo`, acessado a partir do objeto indicado antes do ponto.
    if (partidaEncerrada) ui.statusJogo.textContent = 'Partida encerrada';

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    else if (iaPensando) ui.statusJogo.textContent = `IA ${nomeCor(estado.turno)} está analisando...`;

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    else if (estado.estaEmXeque(estado.turno)) ui.statusJogo.textContent = `Xeque nas ${nomeCor(estado.turno)}.`;

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `'IA x IA pausada.'` = texto literal utilizado nesta instrução, contendo IA x IA pausada..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    // `iaPausada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPausada.
    else if (configuracao?.modo === 'ia-ia' && iaPausada) ui.statusJogo.textContent = 'IA x IA pausada.';

    // Executa o bloco alternativo quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `turnoControladoPorIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Sua vez de jogar.'` = texto literal utilizado nesta instrução, contendo Sua vez de jogar..
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `statusJogo` = identificador de propriedade ou método chamado `statusJogo`, acessado a partir do objeto indicado antes do ponto.
    else ui.statusJogo.textContent = turnoControladoPorIA() ? `Vez da IA ${nomeCor(estado.turno)}.` : 'Sua vez de jogar.';

    // Declara `jogadorIA` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `jogadorIA` = identificador utilizado para armazenar ou acessar o valor relacionado a jogadorIA.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    const jogadorIA = configuracao?.modo === 'ia-ia';

    // Declara `habilitarHumanos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `habilitarHumanos` = identificador utilizado para armazenar ou acessar o valor relacionado a habilitarHumanos.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    const habilitarHumanos = configuracao?.modo === 'jogador-ia' && !partidaEncerrada;

    // Armazena ou atualiza o valor de `ui.btnReivindicar.disabled` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `btnReivindicar` = identificador de propriedade ou método chamado `btnReivindicar`, acessado a partir do objeto indicado antes do ponto.
    // `disabled` = identificador de propriedade ou método chamado `disabled`, acessado a partir do objeto indicado antes do ponto.
    ui.btnReivindicar.disabled = !habilitarHumanos;

    // Armazena ou atualiza o valor de `ui.btnOferecer.disabled` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `btnOferecer` = identificador de propriedade ou método chamado `btnOferecer`, acessado a partir do objeto indicado antes do ponto.
    ui.btnOferecer.disabled = !habilitarHumanos;

    // Armazena ou atualiza o valor de `ui.btnDesistir.disabled` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `btnDesistir` = identificador de propriedade ou método chamado `btnDesistir`, acessado a partir do objeto indicado antes do ponto.
    ui.btnDesistir.disabled = !habilitarHumanos;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.btnPausarIA.classList.toggle` = chama a função ou método `toggle` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `btnPausarIA` = identificador de propriedade ou método chamado `btnPausarIA`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `toggle` = identificador de propriedade ou método chamado `toggle`, acessado a partir do objeto indicado antes do ponto.
    // `jogadorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a jogadorIA.
    ui.btnPausarIA.classList.toggle('hidden', !jogadorIA);

    // Armazena ou atualiza o valor de `ui.btnPausarIA.textContent` utilizando o resultado definido nesta linha.
    // `'Continuar IA x IA'` = texto literal utilizado nesta instrução, contendo Continuar IA x IA.
    // `'Pausar IA x IA'` = texto literal utilizado nesta instrução, contendo Pausar IA x IA.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    // `iaPausada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPausada.
    ui.btnPausarIA.textContent = iaPausada ? 'Continuar IA x IA' : 'Pausar IA x IA';

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `renderizarTudo` para executar a rotina correspondente a renderizarTudo.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `renderizarTudo` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `renderizarTudo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function renderizarTudo() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `renderizarTabuleiro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    renderizarTabuleiro();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `atualizarPainel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    atualizarPainel();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `limparSelecao` para executar a rotina correspondente a limparSelecao.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `limparSelecao` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `limparSelecao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function limparSelecao() {

    // Armazena ou atualiza em `selecionada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
    selecionada = null;

    // Armazena ou atualiza em `movimentosSelecionados` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
    movimentosSelecionados = [];

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `clicarCasa` para executar a rotina correspondente a clicarCasa.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `clicarCasa` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `clicarCasa` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `linha` = identificador que representa a linha de uma casa no tabuleiro.
  // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
  function clicarCasa(linha, coluna) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `ui.modal.classList.contains` = chama a função ou método `contains` pertencente ao objeto ou recurso indicado antes do ponto.
    // `turnoControladoPorIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `modal` = identificador de propriedade ou método chamado `modal`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `contains` = identificador de propriedade ou método chamado `contains`, acessado a partir do objeto indicado antes do ponto.
    if (partidaEncerrada || iaPensando || turnoControladoPorIA() || !ui.modal.classList.contains('hidden')) return;

    // Declara `pos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `pos` = identificador utilizado para armazenar ou acessar o valor relacionado a pos.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const pos = [linha, coluna];

    // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
    // `estado.pecaEm` = chama a função ou método `pecaEm` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `pecaEm` = identificador de propriedade ou método chamado `pecaEm`, acessado a partir do objeto indicado antes do ponto.
    const peca = estado.pecaEm(pos);

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
    if (!selecionada) {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!peca) return;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
      if (peca.cor !== estado.turno) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'invalido'` = texto literal utilizado nesta instrução, contendo invalido.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        tocarSom('invalido');

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'Essa peça pertence ao adversário. Selecione uma peça da sua cor.'` = texto literal utilizado nesta instrução, contendo Essa peça pertence ao adversário. Selecione uma peça da sua cor..
        // `'error'` = texto literal utilizado nesta instrução, contendo error.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        mostrarToast('Essa peça pertence ao adversário. Selecione uma peça da sua cor.', 'error');

        // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `;` = encerra a instrução JavaScript atual.
        return;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Armazena ou atualiza em `selecionada` o valor ou resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
      // `pos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pos.
      selecionada = pos;

      // Armazena ou atualiza em `movimentosSelecionados` o valor ou resultado definido nesta linha.
      // `estado.movimentosDaCasa` = chama a função ou método `movimentosDaCasa` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `movimentosDaCasa` = identificador de propriedade ou método chamado `movimentosDaCasa`, acessado a partir do objeto indicado antes do ponto.
      movimentosSelecionados = estado.movimentosDaCasa(pos);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'selecao'` = texto literal utilizado nesta instrução, contendo selecao.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      tocarSom('selecao');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTabuleiro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      renderizarTabuleiro();

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `peca` = identificador que representa uma peça de xadrez.
    // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    if (peca && peca.cor === estado.turno) {

      // Armazena ou atualiza em `selecionada` o valor ou resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
      // `pos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pos.
      selecionada = pos;

      // Armazena ou atualiza em `movimentosSelecionados` o valor ou resultado definido nesta linha.
      // `estado.movimentosDaCasa` = chama a função ou método `movimentosDaCasa` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `movimentosDaCasa` = identificador de propriedade ou método chamado `movimentosDaCasa`, acessado a partir do objeto indicado antes do ponto.
      movimentosSelecionados = estado.movimentosDaCasa(pos);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'selecao'` = texto literal utilizado nesta instrução, contendo selecao.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      tocarSom('selecao');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTabuleiro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      renderizarTabuleiro();

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `candidatos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `candidatos` = identificador utilizado para armazenar ou acessar o valor relacionado a candidatos.
    // `movimentosSelecionados.filter` = chama a função ou método `filter` pertencente ao objeto ou recurso indicado antes do ponto.
    // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
    // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
    // `destino` = identificador que representa a casa de destino de um movimento.
    // `pos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pos.
    const candidatos = movimentosSelecionados.filter((m) => posIgual(m.destino, pos));

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    if (!candidatos.length) {

      // Declara `explicacao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `explicacao` = identificador utilizado para armazenar ou acessar o valor relacionado a explicacao.
      // `estado.explicarMovimentoInvalido` = chama a função ou método `explicarMovimentoInvalido` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `explicarMovimentoInvalido` = identificador de propriedade ou método chamado `explicarMovimentoInvalido`, acessado a partir do objeto indicado antes do ponto.
      // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
      const explicacao = estado.explicarMovimentoInvalido(selecionada, pos);

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'invalido'` = texto literal utilizado nesta instrução, contendo invalido.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      tocarSom('invalido');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'error'` = texto literal utilizado nesta instrução, contendo error.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      mostrarToast(explicacao, 'error');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `limparSelecao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      limparSelecao();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTabuleiro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      renderizarTabuleiro();

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `candidatos.some` = chama a função ou método `some` pertencente ao objeto ou recurso indicado antes do ponto.
    // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `>` = verifica se o valor da esquerda é maior que o valor da direita.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `candidatos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a candidatos.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    // `some` = identificador de propriedade ou método chamado `some`, acessado a partir do objeto indicado antes do ponto.
    // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
    // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
    if (candidatos.length > 1 && candidatos.some((m) => m.promocao)) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `abrirPromocao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      abrirPromocao(candidatos);

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `executarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    executarMovimento(candidatos[0], false);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `abrirPromocao` para executar a rotina correspondente a abrirPromocao.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `abrirPromocao` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `abrirPromocao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function abrirPromocao(candidatos) {

    // Declara `cor` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `cor` = identificador utilizado para armazenar ou acessar o valor relacionado a cor.
    // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `candidatos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a candidatos.
    // `peca` = identificador que representa uma peça de xadrez.
    const cor = candidatos[0].peca.cor;

    // Armazena ou atualiza em `modalBloqueante` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `modalBloqueante` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a modalBloqueante.
    modalBloqueante = true;

    // Armazena ou atualiza o valor de `ui.modalTitulo.textContent` utilizando o resultado definido nesta linha.
    // `'Promoção do peão'` = texto literal utilizado nesta instrução, contendo Promoção do peão.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `modalTitulo` = identificador de propriedade ou método chamado `modalTitulo`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    ui.modalTitulo.textContent = 'Promoção do peão';

    // Armazena ou atualiza o valor de `ui.modalConteudo.innerHTML` utilizando o resultado definido nesta linha.
    // `'<p>Escolha a peça para a qual o peão será promovido.</p><div id="gradePromocao" class="promotion-grid"></div>'` = texto literal utilizado nesta instrução, contendo <p>Escolha a peça para a qual o peão será promovido.</p><div id="gradePromoca....
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modalConteudo` = identificador de propriedade ou método chamado `modalConteudo`, acessado a partir do objeto indicado antes do ponto.
    // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
    ui.modalConteudo.innerHTML = '<p>Escolha a peça para a qual o peão será promovido.</p><div id="gradePromocao" class="promotion-grid"></div>';

    // Armazena ou atualiza o valor de `ui.modalAcoes.innerHTML` utilizando o resultado definido nesta linha.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modalAcoes` = identificador de propriedade ou método chamado `modalAcoes`, acessado a partir do objeto indicado antes do ponto.
    ui.modalAcoes.innerHTML = '';

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.btnFecharModal.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `btnFecharModal` = identificador de propriedade ou método chamado `btnFecharModal`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    ui.btnFecharModal.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.modal.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modal` = identificador de propriedade ou método chamado `modal`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.modal.classList.remove('hidden');

    // Declara `grade` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `grade` = identificador utilizado para armazenar ou acessar o valor relacionado a grade.
    // `document.getElementById` = chama a função ou método `getElementById` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'gradePromocao'` = texto literal utilizado nesta instrução, contendo gradePromocao.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `document` = objeto que representa o documento HTML carregado no navegador.
    // `getElementById` = identificador de propriedade ou método chamado `getElementById`, acessado a partir do objeto indicado antes do ponto.
    const grade = document.getElementById('gradePromocao');

    // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
    // `of` = indica os valores percorridos em uma estrutura for...of.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
    // `DAMA` = constante que identifica a peça Dama.
    // `TORRE` = constante que identifica a peça Torre.
    // `BISPO` = constante que identifica a peça Bispo.
    // `CAVALO` = constante que identifica a peça Cavalo.
    for (const tipo of [DAMA, TORRE, BISPO, CAVALO]) {

      // Declara `movimento` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimento` = identificador utilizado para armazenar ou acessar o valor relacionado a movimento.
      // `candidatos.find` = chama a função ou método `find` pertencente ao objeto ou recurso indicado antes do ponto.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `candidatos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a candidatos.
      // `find` = identificador de propriedade ou método chamado `find`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
      const movimento = candidatos.find((m) => m.promocao === tipo);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `continue` = encerra a iteração atual e avança para a próxima repetição.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!movimento) continue;

      // Declara `botao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `botao` = identificador utilizado para armazenar ou acessar o valor relacionado a botao.
      // `document.createElement` = chama a função ou método `createElement` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'button'` = texto literal utilizado nesta instrução, contendo button.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `document` = objeto que representa o documento HTML carregado no navegador.
      // `createElement` = identificador de propriedade ou método chamado `createElement`, acessado a partir do objeto indicado antes do ponto.
      const botao = document.createElement('button');

      // Armazena ou atualiza o valor de `botao.type` utilizando o resultado definido nesta linha.
      // `'button'` = texto literal utilizado nesta instrução, contendo button.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `type` = identificador de propriedade ou método chamado `type`, acessado a partir do objeto indicado antes do ponto.
      botao.type = 'button';

      // Armazena ou atualiza o valor de `botao.className` utilizando o resultado definido nesta linha.
      // `'promotion-button'` = texto literal utilizado nesta instrução, contendo promotion-button.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `className` = identificador de propriedade ou método chamado `className`, acessado a partir do objeto indicado antes do ponto.
      botao.className = 'promotion-button';

      // Armazena ou atualiza o valor de `botao.innerHTML` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `innerHTML` = identificador de propriedade ou método chamado `innerHTML`, acessado a partir do objeto indicado antes do ponto.
      botao.innerHTML = `${SIMBOLOS[cor][tipo]}<small>${NOMES_PECAS[tipo]}</small>`;

      // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
      // `botao.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'click'` = texto literal utilizado nesta instrução, contendo click.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
      botao.addEventListener('click', () => {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        fecharModalForcado();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `executarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
        executarMovimento(movimento, false);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `grade.appendChild` = chama a função ou método `appendChild` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `grade` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a grade.
      // `appendChild` = identificador de propriedade ou método chamado `appendChild`, acessado a partir do objeto indicado antes do ponto.
      // `botao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a botao.
      grade.appendChild(botao);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `executarMovimento` para executar a rotina correspondente a executarMovimento.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `executarMovimento` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `executarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `feitoPorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a feitoPorIA.
  function executarMovimento(movimento, feitoPorIA) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    if (partidaEncerrada) return;

    // Declara `autorCor` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `autorCor` = identificador utilizado para armazenar ou acessar o valor relacionado a autorCor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    // `peca` = identificador que representa uma peça de xadrez.
    // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
    const autorCor = movimento.peca.cor;

    // Declara `capturadaAntes` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `capturadaAntes` = identificador utilizado para armazenar ou acessar o valor relacionado a capturadaAntes.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `capturada` = identificador que representa a peça capturada em uma jogada.
    const capturadaAntes = movimento.capturada;

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `aplicado` = identificador utilizado para armazenar ou acessar o valor relacionado a aplicado.
    // `;` = encerra a instrução JavaScript atual.
    let aplicado;

    // Inicia um bloco protegido para executar operações que podem gerar uma exceção durante a execução.
    // `try` = inicia um bloco protegido para executar instruções que podem gerar uma exceção.
    // `estado.aplicarMovimento` = chama a função ou método `aplicarMovimento` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `aplicarMovimento` = identificador de propriedade ou método chamado `aplicarMovimento`, acessado a partir do objeto indicado antes do ponto.
    try { aplicado = estado.aplicarMovimento(movimento); }

    // Captura e trata uma possível exceção produzida pelas instruções executadas no bloco protegido anterior.
    // `catch` = captura uma exceção produzida no bloco try e permite tratá-la.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `erro` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a erro.
    catch (erro) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'invalido'` = texto literal utilizado nesta instrução, contendo invalido.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      tocarSom('invalido');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Movimento inválido.'` = texto literal utilizado nesta instrução, contendo Movimento inválido..
      // `'error'` = texto literal utilizado nesta instrução, contendo error.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `message` = identificador de propriedade ou método chamado `message`, acessado a partir do objeto indicado antes do ponto.
      mostrarToast(erro.message || 'Movimento inválido.', 'error');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `limparSelecao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      limparSelecao();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `renderizarTudo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      renderizarTudo();

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `limparSelecao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    limparSelecao();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `feitoPorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a feitoPorIA.
    // `ultimoMovimentoIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ultimoMovimentoIA.
    // `aplicado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a aplicado.
    if (feitoPorIA) ultimoMovimentoIA = aplicado;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'promocao'` = texto literal utilizado nesta instrução, contendo promocao.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
    if (aplicado.promocao) tocarSom('promocao');

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'roque'` = texto literal utilizado nesta instrução, contendo roque.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
    else if (aplicado.roque) tocarSom('roque');

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'captura'` = texto literal utilizado nesta instrução, contendo captura.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `capturadaAntes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a capturadaAntes.
    // `capturada` = identificador que representa a peça capturada em uma jogada.
    // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
    else if (capturadaAntes || aplicado.capturada || aplicado.enPassant) tocarSom('captura');

    // Executa o bloco alternativo quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'movimento'` = texto literal utilizado nesta instrução, contendo movimento.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    else tocarSom('movimento');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `renderizarTudo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    renderizarTudo();

    // Declara `resultado` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `resultado` = identificador utilizado para armazenar ou acessar o valor relacionado a resultado.
    // `estado.resultado` = chama a função ou método `resultado` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    const resultado = estado.resultado();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    if (resultado) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      finalizarResultado(resultado);

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'xeque'` = texto literal utilizado nesta instrução, contendo xeque.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    if (estado.estaEmXeque(estado.turno)) tocarSom('xeque');

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `aplicado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a aplicado.
    // `capturada` = identificador que representa a peça capturada em uma jogada.
    // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
    if (aplicado.capturada || aplicado.enPassant) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mostrarAvisoCaptura` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `feitoPorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a feitoPorIA.
      mostrarAvisoCaptura(aplicado, feitoPorIA);

    // Executa o bloco alternativo quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `agendarIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    } else agendarIA();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `mostrarAvisoCaptura` para executar a rotina correspondente a mostrarAvisoCaptura.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `mostrarAvisoCaptura` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `mostrarAvisoCaptura` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
  function mostrarAvisoCaptura(movimento, feitoPorIA) {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorCaptura.
    clearTimeout(temporizadorCaptura);

    // Declara `capturada` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `capturada` = identificador utilizado para armazenar ou acessar o valor relacionado a capturada.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    const capturada = movimento.capturada;

    // Declara `autor` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `autor` = identificador utilizado para armazenar ou acessar o valor relacionado a autor.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    const autor = configuracao.modo === 'ia-ia'

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      ? `IA ${nomeCor(movimento.peca.cor)}`

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
      : (movimento.peca.cor === corHumana() ? configuracao.nome : `IA ${nomeCor(movimento.peca.cor)}`);

    // Armazena ou atualiza o valor de `ui.avisoCaptura.textContent` utilizando o resultado definido nesta linha.
    // `'uma peça'` = texto literal utilizado nesta instrução, contendo uma peça.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `avisoCaptura` = identificador de propriedade ou método chamado `avisoCaptura`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    ui.avisoCaptura.textContent = `${autor} capturou ${capturada ? NOMES_PECAS[capturada.tipo].toLowerCase() : 'uma peça'}.`;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.avisoCaptura.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.avisoCaptura.classList.remove('hidden');

    // Armazena ou atualiza em `temporizadorCaptura` o valor ou resultado definido nesta linha.
    // `setTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `temporizadorCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorCaptura.
    temporizadorCaptura = setTimeout(() => {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ui.avisoCaptura.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
      ui.avisoCaptura.classList.add('hidden');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `agendarIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      agendarIA();

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `1150` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `1750` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `feitoPorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a feitoPorIA.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    }, feitoPorIA || configuracao.modo === 'ia-ia' ? 1150 : 1750);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `agendarIA` para executar a rotina correspondente a agendarIA.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `agendarIA` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `agendarIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function agendarIA() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorIA.
    clearTimeout(temporizadorIA);

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `turnoControladoPorIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `iaPausada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPausada.
    if (partidaEncerrada || !turnoControladoPorIA() || (configuracao.modo === 'ia-ia' && iaPausada)) return;

    // Declara `partidaAtual` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `partidaAtual` = identificador utilizado para armazenar ou acessar o valor relacionado a partidaAtual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `idPartida` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a idPartida.
    const partidaAtual = idPartida;

    // Declara `atraso` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `atraso` = identificador utilizado para armazenar ou acessar o valor relacionado a atraso.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `900` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `420` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    const atraso = configuracao.modo === 'ia-ia' ? 900 : 420;

    // Armazena ou atualiza em `temporizadorIA` o valor ou resultado definido nesta linha.
    // `setTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    temporizadorIA = setTimeout(() => {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (partidaAtual !== idPartida || partidaEncerrada) return;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `iniciarCalculoIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      iniciarCalculoIA(partidaAtual);

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    }, atraso);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `iniciarCalculoIA` para executar a rotina correspondente a iniciarCalculoIA.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `iniciarCalculoIA` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `iniciarCalculoIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `partidaAtual` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaAtual.
  function iniciarCalculoIA(partidaAtual) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `idPartida` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a idPartida.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    // `iaPausada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPausada.
    if (partidaAtual !== idPartida || partidaEncerrada || iaPensando || (configuracao.modo === 'ia-ia' && iaPausada)) return;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `ia.deveReivindicarEmpate` = chama a função ou método `deveReivindicarEmpate` pertencente ao objeto ou recurso indicado antes do ponto.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ia` = identificador que representa a Inteligência Artificial utilizada na partida.
    // `deveReivindicarEmpate` = identificador de propriedade ou método chamado `deveReivindicarEmpate`, acessado a partir do objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    if (ia.deveReivindicarEmpate(estado, estado.turno)) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'empate_reivindicado_ia'` = texto literal utilizado nesta instrução, contendo empate_reivindicado_ia.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      finalizarResultado('empate_reivindicado_ia');

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Armazena ou atualiza em `iaPensando` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    iaPensando = true;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.pensando.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `pensando` = identificador de propriedade ou método chamado `pensando`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.pensando.classList.remove('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `atualizarPainel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    atualizarPainel();

    // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
    // `setTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    setTimeout(() => {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `partidaAtual` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaAtual.
      // `idPartida` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a idPartida.
      // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
      if (partidaAtual !== idPartida || partidaEncerrada) return;

      // Declara `movimento` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimento` = identificador utilizado para armazenar ou acessar o valor relacionado a movimento.
      // `ia.escolherMovimento` = chama a função ou método `escolherMovimento` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ia` = identificador que representa a Inteligência Artificial utilizada na partida.
      // `escolherMovimento` = identificador de propriedade ou método chamado `escolherMovimento`, acessado a partir do objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
      const movimento = ia.escolherMovimento(estado, estado.turno);

      // Armazena ou atualiza em `iaPensando` o valor ou resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
      iaPensando = false;

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `ui.pensando.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
      // `pensando` = identificador de propriedade ou método chamado `pensando`, acessado a partir do objeto indicado antes do ponto.
      // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
      // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
      ui.pensando.classList.add('hidden');

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (partidaAtual !== idPartida || partidaEncerrada) return;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (!movimento) {

        // Declara `resultado` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `resultado` = identificador utilizado para armazenar ou acessar o valor relacionado a resultado.
        // `estado.resultado` = chama a função ou método `resultado` pertencente ao objeto ou recurso indicado antes do ponto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const resultado = estado.resultado();

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        if (resultado) finalizarResultado(resultado);

        // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `;` = encerra a instrução JavaScript atual.
        return;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `executarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      executarMovimento(movimento, true);

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `35` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    }, 35);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `iniciarPartida` para executar a rotina correspondente a iniciarPartida.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `iniciarPartida` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `iniciarPartida` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function iniciarPartida() {

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorIA.
    clearTimeout(temporizadorIA);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorCaptura.
    clearTimeout(temporizadorCaptura);

    // Armazena ou atualiza em `idPartida` o valor ou resultado definido nesta linha.
    // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
    // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
    // `;` = encerra a instrução JavaScript atual.
    // `idPartida` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a idPartida.
    idPartida += 1;

    // Armazena ou atualiza em `partidaEncerrada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    partidaEncerrada = false;

    // Armazena ou atualiza em `iaPensando` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
    iaPensando = false;

    // Armazena ou atualiza em `iaPausada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `iaPausada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPausada.
    iaPausada = false;

    // Armazena ou atualiza em `selecionada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `selecionada` = identificador que representa a casa ou peça atualmente selecionada pelo jogador.
    selecionada = null;

    // Armazena ou atualiza em `movimentosSelecionados` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `movimentosSelecionados` = lista que armazena os movimentos legais disponíveis para a peça selecionada.
    movimentosSelecionados = [];

    // Armazena ou atualiza em `ultimoMovimentoIA` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `ultimoMovimentoIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ultimoMovimentoIA.
    ultimoMovimentoIA = null;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.avisoCaptura.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `avisoCaptura` = identificador de propriedade ou método chamado `avisoCaptura`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    ui.avisoCaptura.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.pensando.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `pensando` = identificador de propriedade ou método chamado `pensando`, acessado a partir do objeto indicado antes do ponto.
    ui.pensando.classList.add('hidden');

    // Declara `modo` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `modo` = identificador utilizado para armazenar ou acessar o valor relacionado a modo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modoJogo` = identificador de propriedade ou método chamado `modoJogo`, acessado a partir do objeto indicado antes do ponto.
    // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
    const modo = ui.modoJogo.value;

    // Armazena ou atualiza em `configuracao` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    configuracao = {

      // Define a propriedade `nome` do objeto com o valor informado nesta linha.
      // `'Jogador'` = texto literal utilizado nesta instrução, contendo Jogador.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
      // `nomeJogador` = identificador de propriedade ou método chamado `nomeJogador`, acessado a partir do objeto indicado antes do ponto.
      // `trim` = identificador de propriedade ou método chamado `trim`, acessado a partir do objeto indicado antes do ponto.
      nome: (ui.nomeJogador.value || 'Jogador').trim() || 'Jogador',

      // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      modo,

      // Define a propriedade `cor` do objeto com o valor informado nesta linha.
      // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador usado como nome da propriedade `cor` dentro do objeto atual.
      // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
      // `corJogador` = identificador de propriedade ou método chamado `corJogador`, acessado a partir do objeto indicado antes do ponto.
      cor: modo === 'jogador-ia' ? ui.corJogador.value : null,

      // Define a propriedade `dificuldade` do objeto com o valor informado nesta linha.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dificuldade` = identificador de propriedade ou método chamado `dificuldade`, acessado a partir do objeto indicado antes do ponto.
      dificuldade: ui.dificuldade.value,

      // Define a propriedade `camera` do objeto com o valor informado nesta linha.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `camera` = identificador usado como nome da propriedade `camera` dentro do objeto atual.
      // `cameraMenu` = identificador de propriedade ou método chamado `cameraMenu`, acessado a partir do objeto indicado antes do ponto.
      camera: ui.cameraMenu.value,

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    };

    // Armazena ou atualiza em `estado` o valor ou resultado definido nesta linha.
    // `new` = cria uma nova instância da classe ou construtor indicado.
    // `EstadoXadrez` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    estado = new EstadoXadrez();

    // Armazena ou atualiza em `ia` o valor ou resultado definido nesta linha.
    // `new` = cria uma nova instância da classe ou construtor indicado.
    // `InteligenciaXadrez` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ia` = identificador que representa a Inteligência Artificial utilizada na partida.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    ia = new InteligenciaXadrez(configuracao.dificuldade);

    // Armazena ou atualiza o valor de `ui.nomePainel.textContent` utilizando o resultado definido nesta linha.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `'IA x IA'` = texto literal utilizado nesta instrução, contendo IA x IA.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `nomePainel` = identificador de propriedade ou método chamado `nomePainel`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
    ui.nomePainel.textContent = configuracao.modo === 'ia-ia' ? 'IA x IA' : configuracao.nome;

    // Armazena ou atualiza o valor de `ui.modoPainel.textContent` utilizando o resultado definido nesta linha.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `'IA x IA'` = texto literal utilizado nesta instrução, contendo IA x IA.
    // `'Jogador x IA'` = texto literal utilizado nesta instrução, contendo Jogador x IA.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `modoPainel` = identificador de propriedade ou método chamado `modoPainel`, acessado a partir do objeto indicado antes do ponto.
    ui.modoPainel.textContent = configuracao.modo === 'ia-ia' ? 'IA x IA' : 'Jogador x IA';

    // Armazena ou atualiza o valor de `ui.nivelPainel.textContent` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `nivelPainel` = identificador de propriedade ou método chamado `nivelPainel`, acessado a partir do objeto indicado antes do ponto.
    // `NOMES_NIVEIS` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a NOMES NIVEIS.
    // `dificuldade` = identificador de propriedade ou método chamado `dificuldade`, acessado a partir do objeto indicado antes do ponto.
    ui.nivelPainel.textContent = NOMES_NIVEIS[configuracao.dificuldade];

    // Armazena ou atualiza o valor de `ui.corPainel.textContent` utilizando o resultado definido nesta linha.
    // `nomeCor` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `'Automático'` = texto literal utilizado nesta instrução, contendo Automático.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `corPainel` = identificador de propriedade ou método chamado `corPainel`, acessado a partir do objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
    ui.corPainel.textContent = configuracao.modo === 'ia-ia' ? 'Automático' : nomeCor(configuracao.cor);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `camera` = identificador de propriedade ou método chamado `camera`, acessado a partir do objeto indicado antes do ponto.
    cameraAplicar(configuracao.camera);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.telaMenu.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `telaMenu` = identificador de propriedade ou método chamado `telaMenu`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    ui.telaMenu.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.telaJogo.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `telaJogo` = identificador de propriedade ou método chamado `telaJogo`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.telaJogo.classList.remove('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `window.scrollTo` = chama a função ou método `scrollTo` pertencente ao objeto ou recurso indicado antes do ponto.
    // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
    // `scrollTo` = identificador de propriedade ou método chamado `scrollTo`, acessado a partir do objeto indicado antes do ponto.
    window.scrollTo(0, 0);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    fecharModalForcado();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ajustarEnquadramento3D` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    ajustarEnquadramento3D();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `renderizarTudo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    renderizarTudo();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'inicio'` = texto literal utilizado nesta instrução, contendo inicio.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    tocarSom('inicio');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `agendarIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    agendarIA();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `traduzirResultado` para executar a rotina correspondente a traduzirResultado.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `traduzirResultado` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `traduzirResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
  function traduzirResultado(resultado) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'vitoria_branco'` = texto literal utilizado nesta instrução, contendo vitoria_branco.
    // `'Vitória das Brancas'` = texto literal utilizado nesta instrução, contendo Vitória das Brancas.
    // `'Xeque-mate! As Brancas venceram a partida.'` = texto literal utilizado nesta instrução, contendo Xeque-mate! As Brancas venceram a partida..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `titulo` = identificador usado como nome da propriedade `titulo` dentro do objeto atual.
    // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
    // `vencedor` = identificador usado como nome da propriedade `vencedor` dentro do objeto atual.
    // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
    if (resultado === 'vitoria_branco') return { titulo: 'Vitória das Brancas', texto: 'Xeque-mate! As Brancas venceram a partida.', vencedor: BRANCO };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'vitoria_preto'` = texto literal utilizado nesta instrução, contendo vitoria_preto.
    // `'Vitória das Pretas'` = texto literal utilizado nesta instrução, contendo Vitória das Pretas.
    // `'Xeque-mate! As Pretas venceram a partida.'` = texto literal utilizado nesta instrução, contendo Xeque-mate! As Pretas venceram a partida..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
    if (resultado === 'vitoria_preto') return { titulo: 'Vitória das Pretas', texto: 'Xeque-mate! As Pretas venceram a partida.', vencedor: PRETO };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'vitoria_branco_desistencia'` = texto literal utilizado nesta instrução, contendo vitoria_branco_desistencia.
    // `'Vitória das Brancas'` = texto literal utilizado nesta instrução, contendo Vitória das Brancas.
    // `'As Pretas desistiram da partida. As Brancas venceram.'` = texto literal utilizado nesta instrução, contendo As Pretas desistiram da partida. As Brancas venceram..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
    if (resultado === 'vitoria_branco_desistencia') return { titulo: 'Vitória das Brancas', texto: 'As Pretas desistiram da partida. As Brancas venceram.', vencedor: BRANCO };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'vitoria_preto_desistencia'` = texto literal utilizado nesta instrução, contendo vitoria_preto_desistencia.
    // `'Vitória das Pretas'` = texto literal utilizado nesta instrução, contendo Vitória das Pretas.
    // `'As Brancas desistiram da partida. As Pretas venceram.'` = texto literal utilizado nesta instrução, contendo As Brancas desistiram da partida. As Pretas venceram..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `titulo` = identificador usado como nome da propriedade `titulo` dentro do objeto atual.
    // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
    // `vencedor` = identificador usado como nome da propriedade `vencedor` dentro do objeto atual.
    if (resultado === 'vitoria_preto_desistencia') return { titulo: 'Vitória das Pretas', texto: 'As Brancas desistiram da partida. As Pretas venceram.', vencedor: PRETO };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_afogamento'` = texto literal utilizado nesta instrução, contendo empate_afogamento.
    // `'Empate'` = texto literal utilizado nesta instrução, contendo Empate.
    // `'Empate por afogamento: o jogador da vez não está em xeque, mas não possui nenhum movimento legal.'` = texto literal utilizado nesta instrução, contendo Empate por afogamento: o jogador da vez não está em xeque, mas não possui nen....
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    if (resultado === 'empate_afogamento') return { titulo: 'Empate', texto: 'Empate por afogamento: o jogador da vez não está em xeque, mas não possui nenhum movimento legal.', vencedor: null };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_material'` = texto literal utilizado nesta instrução, contendo empate_material.
    // `'Empate'` = texto literal utilizado nesta instrução, contendo Empate.
    // `'A partida terminou empatada por material insuficiente para xeque-mate.'` = texto literal utilizado nesta instrução, contendo A partida terminou empatada por material insuficiente para xeque-mate..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
    if (resultado === 'empate_material') return { titulo: 'Empate', texto: 'A partida terminou empatada por material insuficiente para xeque-mate.', vencedor: null };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_5_repeticoes'` = texto literal utilizado nesta instrução, contendo empate_5_repeticoes.
    // `'Empate'` = texto literal utilizado nesta instrução, contendo Empate.
    // `'A mesma posição ocorreu cinco vezes. Pela regra automática, a partida termina empatada.'` = texto literal utilizado nesta instrução, contendo A mesma posição ocorreu cinco vezes. Pela regra automática, a partida termina....
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `titulo` = identificador usado como nome da propriedade `titulo` dentro do objeto atual.
    // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
    if (resultado === 'empate_5_repeticoes') return { titulo: 'Empate', texto: 'A mesma posição ocorreu cinco vezes. Pela regra automática, a partida termina empatada.', vencedor: null };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_75_lances'` = texto literal utilizado nesta instrução, contendo empate_75_lances.
    // `'Empate'` = texto literal utilizado nesta instrução, contendo Empate.
    // `'A partida terminou empatada pela regra automática dos 75 lances.'` = texto literal utilizado nesta instrução, contendo A partida terminou empatada pela regra automática dos 75 lances..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `vencedor` = identificador usado como nome da propriedade `vencedor` dentro do objeto atual.
    if (resultado === 'empate_75_lances') return { titulo: 'Empate', texto: 'A partida terminou empatada pela regra automática dos 75 lances.', vencedor: null };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_reivindicado'` = texto literal utilizado nesta instrução, contendo empate_reivindicado.
    // `'Empate reivindicado'` = texto literal utilizado nesta instrução, contendo Empate reivindicado.
    // `'O empate foi reivindicado corretamente pelas regras da partida.'` = texto literal utilizado nesta instrução, contendo O empate foi reivindicado corretamente pelas regras da partida..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
    if (resultado === 'empate_reivindicado') return { titulo: 'Empate reivindicado', texto: 'O empate foi reivindicado corretamente pelas regras da partida.', vencedor: null };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_reivindicado_ia'` = texto literal utilizado nesta instrução, contendo empate_reivindicado_ia.
    // `'Empate reivindicado pela IA'` = texto literal utilizado nesta instrução, contendo Empate reivindicado pela IA.
    // `'A Inteligência Artificial utilizou um direito válido de reivindicação de empate.'` = texto literal utilizado nesta instrução, contendo A Inteligência Artificial utilizou um direito válido de reivindicação de empate..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `titulo` = identificador usado como nome da propriedade `titulo` dentro do objeto atual.
    // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
    if (resultado === 'empate_reivindicado_ia') return { titulo: 'Empate reivindicado pela IA', texto: 'A Inteligência Artificial utilizou um direito válido de reivindicação de empate.', vencedor: null };

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'empate_acordo'` = texto literal utilizado nesta instrução, contendo empate_acordo.
    // `'Empate por acordo'` = texto literal utilizado nesta instrução, contendo Empate por acordo.
    // `'A proposta de empate foi aceita pela Inteligência Artificial.'` = texto literal utilizado nesta instrução, contendo A proposta de empate foi aceita pela Inteligência Artificial..
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `vencedor` = identificador usado como nome da propriedade `vencedor` dentro do objeto atual.
    if (resultado === 'empate_acordo') return { titulo: 'Empate por acordo', texto: 'A proposta de empate foi aceita pela Inteligência Artificial.', vencedor: null };

    // Retorna `{ titulo: 'Partida encerrada', texto: 'A partida foi encerrada.', vencedor: null }` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'Partida encerrada'` = texto literal utilizado nesta instrução, contendo Partida encerrada.
    // `'A partida foi encerrada.'` = texto literal utilizado nesta instrução, contendo A partida foi encerrada..
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    return { titulo: 'Partida encerrada', texto: 'A partida foi encerrada.', vencedor: null };

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `finalizarResultado` para executar a rotina correspondente a finalizarResultado.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `finalizarResultado` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
  function finalizarResultado(resultado) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    if (partidaEncerrada) return;

    // Armazena ou atualiza em `partidaEncerrada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    partidaEncerrada = true;

    // Armazena ou atualiza em `iaPensando` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
    iaPensando = false;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorIA.
    clearTimeout(temporizadorIA);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorCaptura.
    clearTimeout(temporizadorCaptura);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.pensando.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `pensando` = identificador de propriedade ou método chamado `pensando`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    ui.pensando.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.avisoCaptura.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `avisoCaptura` = identificador de propriedade ou método chamado `avisoCaptura`, acessado a partir do objeto indicado antes do ponto.
    ui.avisoCaptura.classList.add('hidden');

    // Declara `info` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `info` = identificador utilizado para armazenar ou acessar o valor relacionado a info.
    // `traduzirResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
    const info = traduzirResultado(resultado);

    // Declara `resultadoBanco` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `resultadoBanco` = identificador utilizado para armazenar ou acessar o valor relacionado a resultadoBanco.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    let resultadoBanco = null;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    if (configuracao.modo === 'jogador-ia') {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `'empate'` = texto literal utilizado nesta instrução, contendo empate.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `vencedor` = identificador de propriedade ou método chamado `vencedor`, acessado a partir do objeto indicado antes do ponto.
      if (!info.vencedor) resultadoBanco = 'empate';

      // Executa o bloco alternativo quando a condição anterior não foi atendida.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'vitoria'` = texto literal utilizado nesta instrução, contendo vitoria.
      // `'derrota'` = texto literal utilizado nesta instrução, contendo derrota.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `info` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a info.
      else resultadoBanco = info.vencedor === corHumana() ? 'vitoria' : 'derrota';

      // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
      // `banco.registrarPartida` = chama a função ou método `registrarPartida` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `banco` = objeto responsável pelo armazenamento local de jogadores, ranking e histórico.
      // `registrarPartida` = identificador de propriedade ou método chamado `registrarPartida`, acessado a partir do objeto indicado antes do ponto.
      banco.registrarPartida({

        // Define a propriedade `jogador` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `jogador` = identificador que representa o jogador associado à operação atual.
        // `nome` = identificador que representa um nome textual utilizado nesta parte do programa.
        jogador: configuracao.nome,

        // Define a propriedade `modo` do objeto com o valor informado nesta linha.
        // `'Jogador x IA'` = texto literal utilizado nesta instrução, contendo Jogador x IA.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `modo` = identificador usado como nome da propriedade `modo` dentro do objeto atual.
        modo: 'Jogador x IA',

        // Define a propriedade `corJogador` do objeto com o valor informado nesta linha.
        // `nomeCor` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `corJogador` = identificador usado como nome da propriedade `corJogador` dentro do objeto atual.
        corJogador: nomeCor(corHumana()),

        // Define a propriedade `dificuldade` do objeto com o valor informado nesta linha.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `dificuldade` = identificador de propriedade ou método chamado `dificuldade`, acessado a partir do objeto indicado antes do ponto.
        // `NOMES_NIVEIS` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a NOMES NIVEIS.
        // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
        dificuldade: NOMES_NIVEIS[configuracao.dificuldade],

        // Define a propriedade `resultado` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `resultado` = identificador que representa o resultado obtido na partida ou operação atual.
        // `resultadoBanco` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a resultadoBanco.
        resultado: resultadoBanco,

        // Define a propriedade `totalLances` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `totalLances` = identificador usado como nome da propriedade `totalLances` dentro do objeto atual.
        // `estado` = identificador que representa o estado atual da partida de xadrez.
        // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
        // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
        totalLances: estado.historico.length,

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'empate'` = texto literal utilizado nesta instrução, contendo empate.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `info` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a info.
    // `vencedor` = identificador de propriedade ou método chamado `vencedor`, acessado a partir do objeto indicado antes do ponto.
    if (!info.vencedor) tocarSom('empate');

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `'vitoria'` = texto literal utilizado nesta instrução, contendo vitoria.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    else if (configuracao.modo === 'jogador-ia' && info.vencedor === corHumana()) tocarSom('vitoria');

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `'derrota'` = texto literal utilizado nesta instrução, contendo derrota.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    else if (configuracao.modo === 'jogador-ia') tocarSom('derrota');

    // Executa o bloco alternativo quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'vitoria'` = texto literal utilizado nesta instrução, contendo vitoria.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    else tocarSom('vitoria');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `renderizarTudo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    renderizarTudo();

    // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `info` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a info.
    // `titulo` = identificador de propriedade ou método chamado `titulo`, acessado a partir do objeto indicado antes do ponto.
    abrirModal(info.titulo,

      // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
      // `'vitoria'` = texto literal utilizado nesta instrução, contendo vitoria.
      // `'Vitória (+3 pontos)'` = texto literal utilizado nesta instrução, contendo Vitória (+3 pontos).
      // `'empate'` = texto literal utilizado nesta instrução, contendo empate.
      // `'Empate (+1 ponto)'` = texto literal utilizado nesta instrução, contendo Empate (+1 ponto).
      // `'Derrota'` = texto literal utilizado nesta instrução, contendo Derrota.
      // `''` = texto literal utilizado nesta instrução.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `>` = verifica se o valor da esquerda é maior que o valor da direita.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `/` = realiza divisão.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
      // `strong` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a strong.
      // `Resultado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a Resultado.
      // `jogador` = identificador que representa o jogador associado à operação atual.
      // `$` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a $.
      // `resultadoBanco` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a resultadoBanco.
      `<p>${info.texto}</p><p><strong>Total de movimentos:</strong> ${estado.historico.length}</p>${resultadoBanco ? `<p><strong>Resultado do jogador:</strong> ${resultadoBanco === 'vitoria' ? 'Vitória (+3 pontos)' : resultadoBanco === 'empate' ? 'Empate (+1 ponto)' : 'Derrota'}</p>` : ''}`,

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `iniciarPartida` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'Nova partida'` = texto literal utilizado nesta instrução, contendo Nova partida.
        // `'primary-button'` = texto literal utilizado nesta instrução, contendo primary-button.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
        // `classe` = identificador usado como nome da propriedade `classe` dentro do objeto atual.
        // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
        { texto: 'Nova partida', classe: 'primary-button', aoClicar: () => { fecharModalForcado(); iniciarPartida(); } },

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `voltarMenu` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'Voltar ao menu'` = texto literal utilizado nesta instrução, contendo Voltar ao menu.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        { texto: 'Voltar ao menu', aoClicar: () => voltarMenu(true) },

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      ], true);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `reivindicarEmpate` para executar a rotina correspondente a reivindicarEmpate.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `reivindicarEmpate` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `reivindicarEmpate` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function reivindicarEmpate() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    if (partidaEncerrada || configuracao.modo !== 'jogador-ia') return;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    if (estado.turno !== corHumana()) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'A reivindicação de empate só pode ser feita quando for a sua vez.'` = texto literal utilizado nesta instrução, contendo A reivindicação de empate só pode ser feita quando for a sua vez..
      // `'error'` = texto literal utilizado nesta instrução, contendo error.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      mostrarToast('A reivindicação de empate só pode ser feita quando for a sua vez.', 'error');

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `motivos` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `motivos` = identificador utilizado para armazenar ou acessar o valor relacionado a motivos.
    // `estado.motivosEmpateReivindicavel` = chama a função ou método `motivosEmpateReivindicavel` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `motivosEmpateReivindicavel` = identificador de propriedade ou método chamado `motivosEmpateReivindicavel`, acessado a partir do objeto indicado antes do ponto.
    const motivos = estado.motivosEmpateReivindicavel();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    if (!motivos.length) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Ainda não existe um motivo válido para reivindicar empate. São necessárias três repetições ou a regra dos 50 lances.'` = texto literal utilizado nesta instrução, contendo Ainda não existe um motivo válido para reivindicar empate. São necessárias tr....
      // `'error'` = texto literal utilizado nesta instrução, contendo error.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      mostrarToast('Ainda não existe um motivo válido para reivindicar empate. São necessárias três repetições ou a regra dos 50 lances.', 'error');

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Reivindicar empate'` = texto literal utilizado nesta instrução, contendo Reivindicar empate.
    // `''` = texto literal utilizado nesta instrução.
    // `>` = verifica se o valor da esquerda é maior que o valor da direita.
    // `<` = verifica se o valor da esquerda é menor que o valor da direita.
    // `/` = realiza divisão.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `li` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a li.
    // `$` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a $.
    // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
    abrirModal('Reivindicar empate', `<p>Você possui direito de reivindicar empate por:</p><ul>${motivos.map((m) => `<li>${m}</li>`).join('')}</ul>`, [

      // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
      // `'Cancelar'` = texto literal utilizado nesta instrução, contendo Cancelar.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
      // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
      // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
      { texto: 'Cancelar', aoClicar: fecharModalForcado },

      // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
      // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Reivindicar empate'` = texto literal utilizado nesta instrução, contendo Reivindicar empate.
      // `'primary-button'` = texto literal utilizado nesta instrução, contendo primary-button.
      // `'empate_reivindicado'` = texto literal utilizado nesta instrução, contendo empate_reivindicado.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `classe` = identificador usado como nome da propriedade `classe` dentro do objeto atual.
      { texto: 'Reivindicar empate', classe: 'primary-button', aoClicar: () => { fecharModalForcado(); finalizarResultado('empate_reivindicado'); } },

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    ]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `oferecerEmpate` para executar a rotina correspondente a oferecerEmpate.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `oferecerEmpate` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `oferecerEmpate` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function oferecerEmpate() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    if (partidaEncerrada || configuracao.modo !== 'jogador-ia') return;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    if (estado.turno !== corHumana()) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Aguarde sua vez para oferecer empate.'` = texto literal utilizado nesta instrução, contendo Aguarde sua vez para oferecer empate..
      // `'error'` = texto literal utilizado nesta instrução, contendo error.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      mostrarToast('Aguarde sua vez para oferecer empate.', 'error');

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `corIA` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `corIA` = identificador utilizado para armazenar ou acessar o valor relacionado a corIA.
    // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    const corIA = corOposta(corHumana());

    // Declara `avaliacaoIA` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `avaliacaoIA` = identificador utilizado para armazenar ou acessar o valor relacionado a avaliacaoIA.
    // `ia.avaliar` = chama a função ou método `avaliar` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ia` = identificador que representa a Inteligência Artificial utilizada na partida.
    // `avaliar` = identificador de propriedade ou método chamado `avaliar`, acessado a partir do objeto indicado antes do ponto.
    const avaliacaoIA = ia.avaliar(estado, corIA);

    // Declara `pecasAtivas` e armazena nele o valor ou resultado definido nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `pecasAtivas` = identificador utilizado para armazenar ou acessar o valor relacionado a pecasAtivas.
    // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    let pecasAtivas = 0;

    // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
    // `of` = indica os valores percorridos em uma estrutura for...of.
    // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `linha` = identificador que representa a linha de uma casa no tabuleiro.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
    // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
    // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
    // `REI` = constante que identifica a peça Rei.
    for (const linha of estado.tabuleiro) for (const p of linha) if (p && p.tipo !== REI) pecasAtivas += 1;

    // Declara `aceitar` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `aceitar` = identificador utilizado para armazenar ou acessar o valor relacionado a aceitar.
    // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
    // `70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `60` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `50` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
    // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `<` = verifica se o valor da esquerda é menor que o valor da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `avaliacaoIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a avaliacaoIA.
    // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
    // `abs` = identificador de propriedade ou método chamado `abs`, acessado a partir do objeto indicado antes do ponto.
    // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    // `-70` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
    const aceitar = avaliacaoIA < -70 || (pecasAtivas <= 6 && avaliacaoIA <= 60) || (Math.abs(avaliacaoIA) <= 25 && estado.historico.length >= 50);

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    if (aceitar) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Proposta aceita'` = texto literal utilizado nesta instrução, contendo Proposta aceita.
      // `'<p>A Inteligência Artificial avaliou a posição e aceitou o empate.</p>'` = texto literal utilizado nesta instrução, contendo <p>A Inteligência Artificial avaliou a posição e aceitou o empate.</p>.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      abrirModal('Proposta aceita', '<p>A Inteligência Artificial avaliou a posição e aceitou o empate.</p>', [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'Encerrar empatado'` = texto literal utilizado nesta instrução, contendo Encerrar empatado.
        // `'primary-button'` = texto literal utilizado nesta instrução, contendo primary-button.
        // `'empate_acordo'` = texto literal utilizado nesta instrução, contendo empate_acordo.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
        // `classe` = identificador usado como nome da propriedade `classe` dentro do objeto atual.
        // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
        { texto: 'Encerrar empatado', classe: 'primary-button', aoClicar: () => { fecharModalForcado(); finalizarResultado('empate_acordo'); } },

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      ], true);

    // Executa o bloco alternativo quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    } else {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Proposta recusada'` = texto literal utilizado nesta instrução, contendo Proposta recusada.
      // `'<p>A Inteligência Artificial recusou o empate e a partida continua normalmente.</p>'` = texto literal utilizado nesta instrução, contendo <p>A Inteligência Artificial recusou o empate e a partida continua normalment....
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      abrirModal('Proposta recusada', '<p>A Inteligência Artificial recusou o empate e a partida continua normalmente.</p>', [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `'Continuar partida'` = texto literal utilizado nesta instrução, contendo Continuar partida.
        // `'primary-button'` = texto literal utilizado nesta instrução, contendo primary-button.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        { texto: 'Continuar partida', classe: 'primary-button', aoClicar: fecharModalForcado },

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `desistir` para executar a rotina correspondente a desistir.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `desistir` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `desistir` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function desistir() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'jogador-ia'` = texto literal utilizado nesta instrução, contendo jogador-ia.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    if (partidaEncerrada || configuracao.modo !== 'jogador-ia') return;

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Desistir da partida'` = texto literal utilizado nesta instrução, contendo Desistir da partida.
    // `'<p>Ao desistir, a vitória será registrada para a Inteligência Artificial. Deseja realmente encerrar a partida?</p>'` = texto literal utilizado nesta instrução, contendo <p>Ao desistir, a vitória será registrada para a Inteligência Artificial. Des....
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    abrirModal('Desistir da partida', '<p>Ao desistir, a vitória será registrada para a Inteligência Artificial. Deseja realmente encerrar a partida?</p>', [

      // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
      // `'Continuar jogando'` = texto literal utilizado nesta instrução, contendo Continuar jogando.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
      // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
      // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
      { texto: 'Continuar jogando', aoClicar: fecharModalForcado },

      // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
      // `'Desistir'` = texto literal utilizado nesta instrução, contendo Desistir.
      // `'danger-button'` = texto literal utilizado nesta instrução, contendo danger-button.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `classe` = identificador usado como nome da propriedade `classe` dentro do objeto atual.
      { texto: 'Desistir', classe: 'danger-button', aoClicar: () => {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        fecharModalForcado();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `finalizarResultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `corHumana` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'vitoria_preto_desistencia'` = texto literal utilizado nesta instrução, contendo vitoria_preto_desistencia.
        // `'vitoria_branco_desistencia'` = texto literal utilizado nesta instrução, contendo vitoria_branco_desistencia.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        finalizarResultado(corHumana() === BRANCO ? 'vitoria_preto_desistencia' : 'vitoria_branco_desistencia');

      // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      } },

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    ]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `voltarMenu` para executar a rotina correspondente a voltarMenu.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `voltarMenu` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `voltarMenu` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `forcar` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a forcar.
  function voltarMenu(forcar = false) {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `0` = representa o primeiro índice possível quando a contagem começa em zero.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `>` = verifica se o valor da esquerda é maior que o valor da direita.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    if (!forcar && !partidaEncerrada && estado.historico.length > 0) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Voltar ao menu'` = texto literal utilizado nesta instrução, contendo Voltar ao menu.
      // `'<p>A partida atual ainda não terminou. Se voltar agora, ela será abandonada sem registro no ranking.</p>'` = texto literal utilizado nesta instrução, contendo <p>A partida atual ainda não terminou. Se voltar agora, ela será abandonada s....
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      abrirModal('Voltar ao menu', '<p>A partida atual ainda não terminou. Se voltar agora, ela será abandonada sem registro no ranking.</p>', [

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `'Continuar partida'` = texto literal utilizado nesta instrução, contendo Continuar partida.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
        // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
        // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
        { texto: 'Continuar partida', aoClicar: fecharModalForcado },

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `voltarMenu` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `'Voltar ao menu'` = texto literal utilizado nesta instrução, contendo Voltar ao menu.
        // `'danger-button'` = texto literal utilizado nesta instrução, contendo danger-button.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `classe` = identificador usado como nome da propriedade `classe` dentro do objeto atual.
        { texto: 'Voltar ao menu', classe: 'danger-button', aoClicar: () => voltarMenu(true) },

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      ]);

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Armazena ou atualiza em `idPartida` o valor ou resultado definido nesta linha.
    // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
    // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
    // `;` = encerra a instrução JavaScript atual.
    // `idPartida` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a idPartida.
    idPartida += 1;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorIA.
    clearTimeout(temporizadorIA);

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorCaptura.
    clearTimeout(temporizadorCaptura);

    // Armazena ou atualiza o valor de `ia.cancelar` utilizando o resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ia` = identificador que representa a Inteligência Artificial utilizada na partida.
    // `cancelar` = identificador de propriedade ou método chamado `cancelar`, acessado a partir do objeto indicado antes do ponto.
    ia.cancelar = true;

    // Armazena ou atualiza em `iaPensando` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `iaPensando` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPensando.
    iaPensando = false;

    // Armazena ou atualiza em `partidaEncerrada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    partidaEncerrada = true;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `fecharModalForcado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    fecharModalForcado();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.pensando.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `pensando` = identificador de propriedade ou método chamado `pensando`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `add` = identificador de propriedade ou método chamado `add`, acessado a partir do objeto indicado antes do ponto.
    ui.pensando.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.avisoCaptura.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `avisoCaptura` = identificador de propriedade ou método chamado `avisoCaptura`, acessado a partir do objeto indicado antes do ponto.
    ui.avisoCaptura.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.telaJogo.classList.add` = chama a função ou método `add` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `telaJogo` = identificador de propriedade ou método chamado `telaJogo`, acessado a partir do objeto indicado antes do ponto.
    ui.telaJogo.classList.add('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `ui.telaMenu.classList.remove` = chama a função ou método `remove` pertencente ao objeto ou recurso indicado antes do ponto.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `telaMenu` = identificador de propriedade ou método chamado `telaMenu`, acessado a partir do objeto indicado antes do ponto.
    // `remove` = identificador de propriedade ou método chamado `remove`, acessado a partir do objeto indicado antes do ponto.
    ui.telaMenu.classList.remove('hidden');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'menu'` = texto literal utilizado nesta instrução, contendo menu.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    tocarSom('menu');

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `comoJogar` para executar a rotina correspondente a comoJogar.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `comoJogar` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `comoJogar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function comoJogar() {

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Como jogar'` = texto literal utilizado nesta instrução, contendo Como jogar.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    abrirModal('Como jogar', `
      <h3>1. Objetivo</h3>
      <p>O objetivo é dar xeque-mate no rei adversário. Xeque-mate acontece quando o rei está ameaçado e não existe nenhum movimento legal capaz de eliminar a ameaça.</p>
      <h3>2. Controles</h3>
      <ul>
        <li>No modo Jogador x IA, escolha seu nome, sua cor, a dificuldade e a câmera.</li>
        <li>As Brancas sempre realizam o primeiro movimento.</li>
        <li>Clique em uma peça sua. As casas permitidas ficam destacadas.</li>
        <li>Círculos verdes indicam movimentos comuns e marcações vermelhas indicam capturas.</li>
        <li>A origem e o destino da última jogada da IA permanecem destacados.</li>
        <li>A câmera pode ser trocada durante a partida sem alterar a posição real das peças.</li>
      </ul>
      <h3>3. Movimento das peças</h3>
      <p><strong>Rei:</strong> uma casa em qualquer direção. <strong>Dama:</strong> linhas retas e diagonais. <strong>Torre:</strong> horizontal e vertical. <strong>Bispo:</strong> diagonais. <strong>Cavalo:</strong> formato de L e pode saltar. <strong>Peão:</strong> avança para frente e captura na diagonal.</p>
      <h3>4. Regras especiais</h3>
      <p>O motor inclui roque pequeno e grande, captura en passant, promoção para Dama/Torre/Bispo/Cavalo, afogamento, material insuficiente, reivindicação por três repetições e 50 lances, além de empates automáticos por cinco repetições e 75 lances.</p>
      <h3>5. Inteligência Artificial</h3>
      <p>Fácil oferece partidas mais variadas; Intermediário utiliza Minimax com poda Alpha-Beta em profundidade moderada; Avançado analisa uma profundidade maior e prioriza os lances mais promissores.</p>
      <h3>6. Quatro câmeras</h3>
      <ul>
        <li><strong>Superior:</strong> visão clássica de cima.</li>
        <li><strong>Perspectiva das Brancas:</strong> tabuleiro inclinado visto pelo lado das Brancas.</li>
        <li><strong>Perspectiva das Pretas:</strong> tabuleiro inclinado pelo lado oposto.</li>
        <li><strong>Lateral/Isométrica:</strong> visão diagonal para acompanhar o tabuleiro por outro ângulo.</li>
      </ul>
      <h3>7. Sons e dados</h3>
      <p>A tecla F8 liga ou desliga o som. Estatísticas, ranking e histórico são armazenados localmente no navegador usando LocalStorage, sem necessidade de banco de dados externo.</p>
    `, [{ texto: 'Fechar', classe: 'primary-button', aoClicar: fecharModalForcado }]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `estatisticas` para executar a rotina correspondente a estatisticas.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `estatisticas` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `estatisticas` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function estatisticas() {

    // Declara `nome` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `nome` = identificador utilizado para armazenar ou acessar o valor relacionado a nome.
    // `'Jogador'` = texto literal utilizado nesta instrução, contendo Jogador.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `nomeJogador` = identificador de propriedade ou método chamado `nomeJogador`, acessado a partir do objeto indicado antes do ponto.
    // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
    // `trim` = identificador de propriedade ou método chamado `trim`, acessado a partir do objeto indicado antes do ponto.
    const nome = (ui.nomeJogador.value || 'Jogador').trim() || 'Jogador';

    // Declara `e` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `e` = identificador utilizado para armazenar ou acessar o valor relacionado a e.
    // `banco.estatisticas` = chama a função ou método `estatisticas` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `banco` = objeto responsável pelo armazenamento local de jogadores, ranking e histórico.
    const e = banco.estatisticas(nome);

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    if (!e) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Estatísticas'` = texto literal utilizado nesta instrução, contendo Estatísticas.
      // `'Fechar'` = texto literal utilizado nesta instrução, contendo Fechar.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
      // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
      // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
      abrirModal('Estatísticas', `<p>Ainda não existem partidas registradas para <strong>${escapeHTML(nome)}</strong>.</p><p>Conclua uma partida no modo Jogador x IA para gerar estatísticas.</p>`, [{ texto: 'Fechar', aoClicar: fecharModalForcado }]);

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `aproveitamento` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `aproveitamento` = identificador utilizado para armazenar ou acessar o valor relacionado a aproveitamento.
    // `'0.0'` = texto literal utilizado nesta instrução, contendo 0.0.
    // `3` = quantidade de pontos adicionada ao ranking por uma vitória.
    // `100` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `1` = incrementa em uma unidade o contador correspondente a esta estatística.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `*` = realiza multiplicação.
    // `/` = realiza divisão.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `e` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a e.
    // `partidas` = identificador de propriedade ou método chamado `partidas`, acessado a partir do objeto indicado antes do ponto.
    // `pontos` = identificador de propriedade ou método chamado `pontos`, acessado a partir do objeto indicado antes do ponto.
    // `toFixed` = identificador de propriedade ou método chamado `toFixed`, acessado a partir do objeto indicado antes do ponto.
    const aproveitamento = e.partidas ? ((e.pontos / (e.partidas * 3)) * 100).toFixed(1) : '0.0';

    // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    abrirModal(`Estatísticas — ${e.nome}`, `
      <table><tbody>
        <tr><th>Partidas</th><td>${e.partidas}</td></tr>
        <tr><th>Vitórias</th><td>${e.vitorias}</td></tr>
        <tr><th>Empates</th><td>${e.empates}</td></tr>
        <tr><th>Derrotas</th><td>${e.derrotas}</td></tr>
        <tr><th>Placar</th><td>${e.placar} pontos</td></tr>
        <tr><th>Aproveitamento</th><td>${aproveitamento}%</td></tr>
      </tbody></table>`, [{ texto: 'Fechar', aoClicar: fecharModalForcado }]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `ranking` para executar a rotina correspondente a ranking.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `ranking` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `ranking` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function ranking() {

    // Declara `lista` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `lista` = identificador utilizado para armazenar ou acessar o valor relacionado a lista.
    // `banco.ranking` = chama a função ou método `ranking` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `banco` = objeto responsável pelo armazenamento local de jogadores, ranking e histórico.
    const lista = banco.ranking();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    if (!lista.length) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Ranking'` = texto literal utilizado nesta instrução, contendo Ranking.
      // `'<p>O ranking ainda está vazio. Conclua partidas no modo Jogador x IA para registrar pontuação.</p>'` = texto literal utilizado nesta instrução, contendo <p>O ranking ainda está vazio. Conclua partidas no modo Jogador x IA para reg....
      // `'Fechar'` = texto literal utilizado nesta instrução, contendo Fechar.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
      // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
      // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
      abrirModal('Ranking', '<p>O ranking ainda está vazio. Conclua partidas no modo Jogador x IA para registrar pontuação.</p>', [{ texto: 'Fechar', aoClicar: fecharModalForcado }]);

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `linhas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `linhas` = identificador utilizado para armazenar ou acessar o valor relacionado a linhas.
    // `lista.slice` = chama a função ou método `slice` pertencente ao objeto ou recurso indicado antes do ponto.
    // `''` = texto literal utilizado nesta instrução.
    // `0` = indica que a operação deve começar no primeiro elemento da coleção.
    // `50` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `lista` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a lista.
    // `slice` = identificador de propriedade ou método chamado `slice`, acessado a partir do objeto indicado antes do ponto.
    // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
    // `j` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a j.
    // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
    // `join` = identificador de propriedade ou método chamado `join`, acessado a partir do objeto indicado antes do ponto.
    const linhas = lista.slice(0, 50).map((j, i) => `<tr><td>${i + 1}º</td><td>${escapeHTML(j.nome)}</td><td>${j.placar}</td><td>${j.vitorias}</td><td>${j.empates}</td><td>${j.derrotas}</td></tr>`).join('');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Ranking'` = texto literal utilizado nesta instrução, contendo Ranking.
    // `'Fechar'` = texto literal utilizado nesta instrução, contendo Fechar.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    abrirModal('Ranking', `<table><thead><tr><th>#</th><th>Jogador</th><th>Pontos</th><th>V</th><th>E</th><th>D</th></tr></thead><tbody>${linhas}</tbody></table>`, [{ texto: 'Fechar', aoClicar: fecharModalForcado }]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `historicoGeral` para executar a rotina correspondente a historicoGeral.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `historicoGeral` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `historicoGeral` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function historicoGeral() {

    // Declara `lista` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `lista` = identificador utilizado para armazenar ou acessar o valor relacionado a lista.
    // `banco.historico` = chama a função ou método `historico` pertencente ao objeto ou recurso indicado antes do ponto.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `banco` = objeto responsável pelo armazenamento local de jogadores, ranking e histórico.
    // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
    const lista = banco.historico();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
    if (!lista.length) {

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Histórico de partidas'` = texto literal utilizado nesta instrução, contendo Histórico de partidas.
      // `'<p>Ainda não existem partidas concluídas no histórico local.</p>'` = texto literal utilizado nesta instrução, contendo <p>Ainda não existem partidas concluídas no histórico local.</p>.
      // `'Fechar'` = texto literal utilizado nesta instrução, contendo Fechar.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
      // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
      // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
      abrirModal('Histórico de partidas', '<p>Ainda não existem partidas concluídas no histórico local.</p>', [{ texto: 'Fechar', aoClicar: fecharModalForcado }]);

      // Retorna o resultado desta linha para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Declara `linhas` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `linhas` = identificador utilizado para armazenar ou acessar o valor relacionado a linhas.
    // `lista.slice` = chama a função ou método `slice` pertencente ao objeto ou recurso indicado antes do ponto.
    // `0` = indica que a operação deve começar no primeiro elemento da coleção.
    // `60` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `lista` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a lista.
    // `slice` = identificador de propriedade ou método chamado `slice`, acessado a partir do objeto indicado antes do ponto.
    // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
    // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
    const linhas = lista.slice(0, 60).map((p) => {

      // Declara `data` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `new` = cria uma nova instância da classe ou construtor indicado.
      // `data` = identificador utilizado para armazenar ou acessar o valor relacionado a data.
      // `Date` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dataHora` = identificador de propriedade ou método chamado `dataHora`, acessado a partir do objeto indicado antes do ponto.
      const data = new Date(p.dataHora);

      // Declara `dataTxt` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `dataTxt` = identificador utilizado para armazenar ou acessar o valor relacionado a dataTxt.
      // `Number.isNaN` = chama a função ou método `isNaN` pertencente ao objeto ou recurso indicado antes do ponto.
      // `data.getTime` = chama a função ou método `getTime` pertencente ao objeto ou recurso indicado antes do ponto.
      // `data.toLocaleString` = chama a função ou método `toLocaleString` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'—'` = texto literal utilizado nesta instrução, contendo —.
      // `'pt-BR'` = texto literal utilizado nesta instrução, contendo pt-BR.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Number` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a Number.
      // `isNaN` = identificador de propriedade ou método chamado `isNaN`, acessado a partir do objeto indicado antes do ponto.
      // `getTime` = identificador de propriedade ou método chamado `getTime`, acessado a partir do objeto indicado antes do ponto.
      // `toLocaleString` = identificador de propriedade ou método chamado `toLocaleString`, acessado a partir do objeto indicado antes do ponto.
      const dataTxt = Number.isNaN(data.getTime()) ? '—' : data.toLocaleString('pt-BR');

      // Declara `resultado` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `resultado` = identificador utilizado para armazenar ou acessar o valor relacionado a resultado.
      // `'vitoria'` = texto literal utilizado nesta instrução, contendo vitoria.
      // `'Vitória'` = texto literal utilizado nesta instrução, contendo Vitória.
      // `'empate'` = texto literal utilizado nesta instrução, contendo empate.
      // `'Empate'` = texto literal utilizado nesta instrução, contendo Empate.
      // `'Derrota'` = texto literal utilizado nesta instrução, contendo Derrota.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const resultado = p.resultado === 'vitoria' ? 'Vitória' : p.resultado === 'empate' ? 'Empate' : 'Derrota';

      // Retorna ``<tr><td>${escapeHTML(dataTxt)}</td><td>${escapeHTML(p.jogador)}</td><td>${escapeHTML(p.corJogador)}</td><td>${escapeHTML(p.dificuldade)}</td><td>${resultado}</td><td>${p.totalLances}</td></tr>`` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return `<tr><td>${escapeHTML(dataTxt)}</td><td>${escapeHTML(p.jogador)}</td><td>${escapeHTML(p.corJogador)}</td><td>${escapeHTML(p.dificuldade)}</td><td>${resultado}</td><td>${p.totalLances}</td></tr>`;

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `''` = texto literal utilizado nesta instrução.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `join` = identificador de propriedade ou método chamado `join`, acessado a partir do objeto indicado antes do ponto.
    }).join('');

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `abrirModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Histórico de partidas'` = texto literal utilizado nesta instrução, contendo Histórico de partidas.
    // `'Fechar'` = texto literal utilizado nesta instrução, contendo Fechar.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `texto` = identificador usado como nome da propriedade `texto` dentro do objeto atual.
    // `aoClicar` = identificador usado como nome da propriedade `aoClicar` dentro do objeto atual.
    // `fecharModalForcado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModalForcado.
    abrirModal('Histórico de partidas', `<table><thead><tr><th>Data</th><th>Jogador</th><th>Cor</th><th>Dificuldade</th><th>Resultado</th><th>Mov.</th></tr></thead><tbody>${linhas}</tbody></table>`, [{ texto: 'Fechar', aoClicar: fecharModalForcado }]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `escapeHTML` para executar a rotina correspondente a escapeHTML.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `escapeHTML` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `escapeHTML` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `valor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a valor.
  function escapeHTML(valor) {

    // Retorna `String(valor).replace(/[&<>'"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[ch])` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `String` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'"]/g, (ch) => ({ '` = texto literal utilizado nesta instrução, contendo "]/g, (ch) => ({ .
    // `': '` = texto literal utilizado nesta instrução, contendo : .
    // `', '` = texto literal utilizado nesta instrução, contendo , .
    // `', "'` = texto literal utilizado nesta instrução, contendo , ".
    // `": '&#39;', '"` = texto literal utilizado nesta instrução, contendo : '&#39;', '.
    // `>` = verifica se o valor da esquerda é maior que o valor da direita.
    // `<` = verifica se o valor da esquerda é menor que o valor da direita.
    // `/` = realiza divisão.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `replace` = identificador de propriedade ou método chamado `replace`, acessado a partir do objeto indicado antes do ponto.
    // `amp` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a amp.
    // `lt` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a lt.
    // `gt` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a gt.
    // `quot` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a quot.
    return String(valor).replace(/[&<>'"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[ch]);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `alternarSom` para executar a rotina correspondente a alternarSom.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `alternarSom` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `alternarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function alternarSom() {

    // Armazena ou atualiza em `somLigado` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `;` = encerra a instrução JavaScript atual.
    // `somLigado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a somLigado.
    somLigado = !somLigado;

    // Armazena ou atualiza o valor de `ui.btnSom.textContent` utilizando o resultado definido nesta linha.
    // `'🔊 Som'` = texto literal utilizado nesta instrução, contendo 🔊 Som.
    // `'🔇 Som'` = texto literal utilizado nesta instrução, contendo 🔇 Som.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `btnSom` = identificador de propriedade ou método chamado `btnSom`, acessado a partir do objeto indicado antes do ponto.
    // `textContent` = identificador de propriedade ou método chamado `textContent`, acessado a partir do objeto indicado antes do ponto.
    ui.btnSom.textContent = somLigado ? '🔊 Som' : '🔇 Som';

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `tocarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'selecao'` = texto literal utilizado nesta instrução, contendo selecao.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    if (somLigado) tocarSom('selecao');

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `async` = indica que a rotina é assíncrona e pode trabalhar com operações que terminam posteriormente.
  // `alternarTelaCheia` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  async function alternarTelaCheia() {

    // Inicia um bloco protegido para executar operações que podem gerar uma exceção durante a execução.
    // `try` = inicia um bloco protegido para executar instruções que podem gerar uma exceção.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    try {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `document.documentElement.requestFullscreen` = chama a função ou método `requestFullscreen` pertencente ao objeto ou recurso indicado antes do ponto.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `document` = objeto que representa o documento HTML carregado no navegador.
      // `fullscreenElement` = identificador de propriedade ou método chamado `fullscreenElement`, acessado a partir do objeto indicado antes do ponto.
      // `documentElement` = identificador de propriedade ou método chamado `documentElement`, acessado a partir do objeto indicado antes do ponto.
      // `requestFullscreen` = identificador de propriedade ou método chamado `requestFullscreen`, acessado a partir do objeto indicado antes do ponto.
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();

      // Executa o bloco alternativo quando a condição anterior não foi atendida.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `await` = aguarda a conclusão de uma operação assíncrona antes de continuar a rotina.
      // `document.exitFullscreen` = chama a função ou método `exitFullscreen` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `exitFullscreen` = identificador de propriedade ou método chamado `exitFullscreen`, acessado a partir do objeto indicado antes do ponto.
      else await document.exitFullscreen();

    // Captura e trata uma possível exceção produzida pelas instruções executadas no bloco protegido anterior.
    // `catch` = captura uma exceção produzida no bloco try e permite tratá-la.
    // `mostrarToast` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'O navegador não permitiu ativar a tela cheia.'` = texto literal utilizado nesta instrução, contendo O navegador não permitiu ativar a tela cheia..
    // `'error'` = texto literal utilizado nesta instrução, contendo error.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    // `_` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a  .
    } catch (_) { mostrarToast('O navegador não permitiu ativar a tela cheia.', 'error'); }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `alternarPausaIA` para executar a rotina correspondente a alternarPausaIA.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `alternarPausaIA` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `alternarPausaIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  function alternarPausaIA() {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'ia-ia'` = texto literal utilizado nesta instrução, contendo ia-ia.
    // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `?.` = realiza acesso opcional e evita erro quando o valor anterior é nulo ou indefinido.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `configuracao` = identificador que armazena as opções selecionadas para a partida atual.
    // `modo` = identificador de propriedade ou método chamado `modo`, acessado a partir do objeto indicado antes do ponto.
    // `partidaEncerrada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a partidaEncerrada.
    if (configuracao?.modo !== 'ia-ia' || partidaEncerrada) return;

    // Armazena ou atualiza em `iaPausada` o valor ou resultado definido nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `;` = encerra a instrução JavaScript atual.
    // `iaPausada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iaPausada.
    iaPausada = !iaPausada;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `clearTimeout` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `temporizadorIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a temporizadorIA.
    if (iaPausada) clearTimeout(temporizadorIA);

    // Executa o bloco alternativo quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não é atendida.
    // `agendarIA` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    else agendarIA();

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `atualizarPainel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    atualizarPainel();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.modoJogo.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'change'` = texto literal utilizado nesta instrução, contendo change.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
  // `modoJogo` = identificador de propriedade ou método chamado `modoJogo`, acessado a partir do objeto indicado antes do ponto.
  // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
  // `atualizarCampoCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a atualizarCampoCor.
  ui.modoJogo.addEventListener('change', atualizarCampoCor);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.cameraMenu.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'change'` = texto literal utilizado nesta instrução, contendo change.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `cameraMenu` = identificador de propriedade ou método chamado `cameraMenu`, acessado a partir do objeto indicado antes do ponto.
  // `value` = identificador de propriedade ou método chamado `value`, acessado a partir do objeto indicado antes do ponto.
  ui.cameraMenu.addEventListener('change', () => cameraAplicar(ui.cameraMenu.value));

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.cameraJogo.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'change'` = texto literal utilizado nesta instrução, contendo change.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `cameraJogo` = identificador de propriedade ou método chamado `cameraJogo`, acessado a partir do objeto indicado antes do ponto.
  ui.cameraJogo.addEventListener('change', () => cameraAplicar(ui.cameraJogo.value));

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnIniciar.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnIniciar` = identificador de propriedade ou método chamado `btnIniciar`, acessado a partir do objeto indicado antes do ponto.
  // `iniciarPartida` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a iniciarPartida.
  ui.btnIniciar.addEventListener('click', iniciarPartida);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnComoJogar.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
  // `btnComoJogar` = identificador de propriedade ou método chamado `btnComoJogar`, acessado a partir do objeto indicado antes do ponto.
  // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
  // `comoJogar` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a comoJogar.
  ui.btnComoJogar.addEventListener('click', comoJogar);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnEstatisticas.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnEstatisticas` = identificador de propriedade ou método chamado `btnEstatisticas`, acessado a partir do objeto indicado antes do ponto.
  // `estatisticas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a estatisticas.
  ui.btnEstatisticas.addEventListener('click', estatisticas);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnRanking.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnRanking` = identificador de propriedade ou método chamado `btnRanking`, acessado a partir do objeto indicado antes do ponto.
  // `ranking` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ranking.
  ui.btnRanking.addEventListener('click', ranking);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnHistoricoGeral.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnHistoricoGeral` = identificador de propriedade ou método chamado `btnHistoricoGeral`, acessado a partir do objeto indicado antes do ponto.
  // `historicoGeral` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a historicoGeral.
  ui.btnHistoricoGeral.addEventListener('click', historicoGeral);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnSom.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnSom` = identificador de propriedade ou método chamado `btnSom`, acessado a partir do objeto indicado antes do ponto.
  // `alternarSom` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alternarSom.
  ui.btnSom.addEventListener('click', alternarSom);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnTelaCheia.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
  // `btnTelaCheia` = identificador de propriedade ou método chamado `btnTelaCheia`, acessado a partir do objeto indicado antes do ponto.
  // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
  // `alternarTelaCheia` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alternarTelaCheia.
  ui.btnTelaCheia.addEventListener('click', alternarTelaCheia);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnVoltarMenu.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `voltarMenu` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnVoltarMenu` = identificador de propriedade ou método chamado `btnVoltarMenu`, acessado a partir do objeto indicado antes do ponto.
  ui.btnVoltarMenu.addEventListener('click', () => voltarMenu(false));

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnReivindicar.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnReivindicar` = identificador de propriedade ou método chamado `btnReivindicar`, acessado a partir do objeto indicado antes do ponto.
  // `reivindicarEmpate` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a reivindicarEmpate.
  ui.btnReivindicar.addEventListener('click', reivindicarEmpate);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnOferecer.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnOferecer` = identificador de propriedade ou método chamado `btnOferecer`, acessado a partir do objeto indicado antes do ponto.
  // `oferecerEmpate` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a oferecerEmpate.
  ui.btnOferecer.addEventListener('click', oferecerEmpate);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnDesistir.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
  // `btnDesistir` = identificador de propriedade ou método chamado `btnDesistir`, acessado a partir do objeto indicado antes do ponto.
  // `desistir` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a desistir.
  ui.btnDesistir.addEventListener('click', desistir);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnPausarIA.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnPausarIA` = identificador de propriedade ou método chamado `btnPausarIA`, acessado a partir do objeto indicado antes do ponto.
  // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
  // `alternarPausaIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alternarPausaIA.
  ui.btnPausarIA.addEventListener('click', alternarPausaIA);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.btnFecharModal.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `btnFecharModal` = identificador de propriedade ou método chamado `btnFecharModal`, acessado a partir do objeto indicado antes do ponto.
  // `fecharModal` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a fecharModal.
  ui.btnFecharModal.addEventListener('click', fecharModal);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `ui.modal.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'click'` = texto literal utilizado nesta instrução, contendo click.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `modal` = identificador de propriedade ou método chamado `modal`, acessado a partir do objeto indicado antes do ponto.
  // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
  ui.modal.addEventListener('click', (evento) => {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `fecharModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `target` = identificador de propriedade ou método chamado `target`, acessado a partir do objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `modalBloqueante` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a modalBloqueante.
    if (evento.target === ui.modal && !modalBloqueante) fecharModal();

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  });

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `document.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'keydown'` = texto literal utilizado nesta instrução, contendo keydown.
  // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `document` = objeto que representa o documento HTML carregado no navegador.
  // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
  document.addEventListener('keydown', (evento) => {

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `evento.preventDefault` = chama a função ou método `preventDefault` pertencente ao objeto ou recurso indicado antes do ponto.
    // `alternarSom` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'F8'` = texto literal utilizado nesta instrução, contendo F8.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `key` = identificador de propriedade ou método chamado `key`, acessado a partir do objeto indicado antes do ponto.
    // `preventDefault` = identificador de propriedade ou método chamado `preventDefault`, acessado a partir do objeto indicado antes do ponto.
    if (evento.key === 'F8') { evento.preventDefault(); alternarSom(); }

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `fecharModal` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'Escape'` = texto literal utilizado nesta instrução, contendo Escape.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
    if (evento.key === 'Escape' && !modalBloqueante) fecharModal();

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `ui.telaJogo.classList.contains` = chama a função ou método `contains` pertencente ao objeto ou recurso indicado antes do ponto.
    // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'1'` = texto literal utilizado nesta instrução, contendo 1.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `telaJogo` = identificador de propriedade ou método chamado `telaJogo`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `contains` = identificador de propriedade ou método chamado `contains`, acessado a partir do objeto indicado antes do ponto.
    if (evento.key === '1' && !ui.telaJogo.classList.contains('hidden')) cameraAplicar('superior');

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `ui.telaJogo.classList.contains` = chama a função ou método `contains` pertencente ao objeto ou recurso indicado antes do ponto.
    // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'2'` = texto literal utilizado nesta instrução, contendo 2.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `'brancas'` = texto literal utilizado nesta instrução, contendo brancas.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `key` = identificador de propriedade ou método chamado `key`, acessado a partir do objeto indicado antes do ponto.
    if (evento.key === '2' && !ui.telaJogo.classList.contains('hidden')) cameraAplicar('brancas');

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `ui.telaJogo.classList.contains` = chama a função ou método `contains` pertencente ao objeto ou recurso indicado antes do ponto.
    // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'3'` = texto literal utilizado nesta instrução, contendo 3.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `'pretas'` = texto literal utilizado nesta instrução, contendo pretas.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `evento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a evento.
    if (evento.key === '3' && !ui.telaJogo.classList.contains('hidden')) cameraAplicar('pretas');

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `ui.telaJogo.classList.contains` = chama a função ou método `contains` pertencente ao objeto ou recurso indicado antes do ponto.
    // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `'4'` = texto literal utilizado nesta instrução, contendo 4.
    // `'hidden'` = texto literal utilizado nesta instrução, contendo hidden.
    // `'lateral'` = texto literal utilizado nesta instrução, contendo lateral.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `!` = realiza negação lógica do valor ou condição indicada.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    // `telaJogo` = identificador de propriedade ou método chamado `telaJogo`, acessado a partir do objeto indicado antes do ponto.
    // `classList` = identificador de propriedade ou método chamado `classList`, acessado a partir do objeto indicado antes do ponto.
    // `contains` = identificador de propriedade ou método chamado `contains`, acessado a partir do objeto indicado antes do ponto.
    if (evento.key === '4' && !ui.telaJogo.classList.contains('hidden')) cameraAplicar('lateral');

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  });

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `window.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'resize'` = texto literal utilizado nesta instrução, contendo resize.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
  // `addEventListener` = identificador de propriedade ou método chamado `addEventListener`, acessado a partir do objeto indicado antes do ponto.
  // `ajustarEnquadramento3D` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ajustarEnquadramento3D.
  window.addEventListener('resize', ajustarEnquadramento3D);

  // Registra um evento no elemento indicado para executar a rotina informada quando a interação correspondente acontecer.
  // `document.addEventListener` = chama a função ou método `addEventListener` pertencente ao objeto ou recurso indicado antes do ponto.
  // `'fullscreenchange'` = texto literal utilizado nesta instrução, contendo fullscreenchange.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `document` = objeto que representa o documento HTML carregado no navegador.
  document.addEventListener('fullscreenchange', ajustarEnquadramento3D);

  // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
  // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
  // `typeof` = obtém o tipo do valor ou expressão indicada.
  // `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
  // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
  // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `ResizeObserver` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ResizeObserver.
  // `boardZone` = identificador de propriedade ou método chamado `boardZone`, acessado a partir do objeto indicado antes do ponto.
  if (typeof ResizeObserver !== 'undefined' && ui.boardZone) {

    // Declara `observadorEnquadramento` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `new` = cria uma nova instância da classe ou construtor indicado.
    // `observadorEnquadramento` = identificador utilizado para armazenar ou acessar o valor relacionado a observadorEnquadramento.
    // `ResizeObserver` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `ajustarEnquadramento3D` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    const observadorEnquadramento = new ResizeObserver(() => ajustarEnquadramento3D());

    // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
    // `observadorEnquadramento.observe` = chama a função ou método `observe` pertencente ao objeto ou recurso indicado antes do ponto.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `observe` = identificador de propriedade ou método chamado `observe`, acessado a partir do objeto indicado antes do ponto.
    // `ui` = objeto que reúne referências aos elementos visuais e controles da interface.
    observadorEnquadramento.observe(ui.boardZone);

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
  // `criarTabuleiroDOM` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  criarTabuleiroDOM();

  // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
  // `atualizarCampoCor` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  atualizarCampoCor();

  // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
  // `cameraAplicar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'superior'` = texto literal utilizado nesta instrução, contendo superior.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  cameraAplicar('superior');

  // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
  // `renderizarTudo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  renderizarTudo();

// Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
// `;` = encerra a instrução JavaScript atual.
})();
