// Cria e executa uma função isolada para manter as variáveis do jogo protegidas no próprio escopo.
// `function` = define uma nova função para agrupar uma rotina reutilizável.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
// `global` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a global.
(function (global) {

  // Ativa o modo estrito do JavaScript para tornar a execução mais segura e impedir determinados usos ambíguos da linguagem.
  // `'use strict'` = texto literal utilizado nesta instrução, contendo use strict.
  // `;` = encerra a instrução JavaScript atual.
  'use strict';

  // Declara `BRANCO` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `BRANCO` = identificador utilizado para armazenar ou acessar o valor relacionado a BRANCO.
  // `'branco'` = texto literal utilizado nesta instrução, contendo branco.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const BRANCO = 'branco';

  // Declara `PRETO` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `PRETO` = identificador utilizado para armazenar ou acessar o valor relacionado a PRETO.
  // `'preto'` = texto literal utilizado nesta instrução, contendo preto.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const PRETO = 'preto';

  // Declara `REI` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `REI` = identificador utilizado para armazenar ou acessar o valor relacionado a REI.
  // `'rei'` = texto literal utilizado nesta instrução, contendo rei.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const REI = 'rei';

  // Declara `DAMA` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `DAMA` = identificador utilizado para armazenar ou acessar o valor relacionado a DAMA.
  // `'dama'` = texto literal utilizado nesta instrução, contendo dama.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const DAMA = 'dama';

  // Declara `TORRE` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `TORRE` = identificador utilizado para armazenar ou acessar o valor relacionado a TORRE.
  // `'torre'` = texto literal utilizado nesta instrução, contendo torre.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const TORRE = 'torre';

  // Declara `BISPO` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `BISPO` = identificador utilizado para armazenar ou acessar o valor relacionado a BISPO.
  // `'bispo'` = texto literal utilizado nesta instrução, contendo bispo.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const BISPO = 'bispo';

  // Declara `CAVALO` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `CAVALO` = identificador utilizado para armazenar ou acessar o valor relacionado a CAVALO.
  // `'cavalo'` = texto literal utilizado nesta instrução, contendo cavalo.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const CAVALO = 'cavalo';

  // Declara `PEAO` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `PEAO` = identificador utilizado para armazenar ou acessar o valor relacionado a PEAO.
  // `'peao'` = texto literal utilizado nesta instrução, contendo peao.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `;` = encerra a instrução JavaScript atual.
  const PEAO = 'peao';

  // Declara `TIPOS_PROMOCAO` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `TIPOS_PROMOCAO` = identificador utilizado para armazenar ou acessar o valor relacionado a TIPOS PROMOCAO.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
  // `]` = fecha a lista, o acesso por índice ou a chave calculada.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  const TIPOS_PROMOCAO = [DAMA, TORRE, BISPO, CAVALO];

  // Declara `VALORES` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `VALORES` = identificador utilizado para armazenar ou acessar o valor relacionado a VALORES.
  // `100` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
  // `320` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
  // `330` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
  // `500` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
  // `900` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
  // `20000` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
  // `]` = fecha a lista, o acesso por índice ou a chave calculada.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
  // `;` = encerra a instrução JavaScript atual.
  // `TORRE` = constante que identifica a peça Torre.
  // `DAMA` = constante que identifica a peça Dama.
  // `REI` = constante que identifica a peça Rei.
  const VALORES = { [PEAO]: 100, [CAVALO]: 320, [BISPO]: 330, [TORRE]: 500, [DAMA]: 900, [REI]: 20000 };

  // Define a função `corOposta` para executar a rotina correspondente a corOposta.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `corOposta` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
  function corOposta(cor) {

    // Retorna `cor === BRANCO ? PRETO : BRANCO` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
    // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
    return cor === BRANCO ? PRETO : BRANCO;

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `criarPeca` para executar a rotina correspondente a criarPeca.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `criarPeca` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `criarPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
  function criarPeca(cor, tipo) {

    // Retorna `{ cor, tipo }` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    return { cor, tipo };

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `criarMovimento` para executar a rotina correspondente a criarMovimento.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `criarMovimento` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `origem` = identificador que representa a casa de origem de um movimento.
  // `destino` = identificador que representa a casa de destino de um movimento.
  // `peca` = identificador que representa uma peça de xadrez.
  // `opcoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a opcoes.
  function criarMovimento(origem, destino, peca, opcoes = {}) {

    // Retorna `{` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    return {

      // Define a propriedade `origem` do objeto com o valor informado nesta linha.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      origem: [origem[0], origem[1]],

      // Define a propriedade `destino` do objeto com o valor informado nesta linha.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      destino: [destino[0], destino[1]],

      // Define a propriedade `peca` do objeto com o valor informado nesta linha.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      peca: peca ? { ...peca } : null,

      // Define a propriedade `capturada` do objeto com o valor informado nesta linha.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `capturada` = identificador que representa a peça capturada em uma jogada.
      capturada: opcoes.capturada ? { ...opcoes.capturada } : null,

      // Define a propriedade `promocao` do objeto com o valor informado nesta linha.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
      promocao: opcoes.promocao || null,

      // Define a propriedade `enPassant` do objeto com o valor informado nesta linha.
      // `Boolean` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
      // `opcoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a opcoes.
      enPassant: Boolean(opcoes.enPassant),

      // Define a propriedade `roque` do objeto com o valor informado nesta linha.
      // `Boolean` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
      roque: Boolean(opcoes.roque),

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `;` = encerra a instrução JavaScript atual.
    };

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `posIgual` para executar a rotina correspondente a posIgual.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `posIgual` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
  // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
  function posIgual(a, b) {

    // Retorna `a && b && a[0] === b[0] && a[1] === b[1]` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
    // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `;` = encerra a instrução JavaScript atual.
    return a && b && a[0] === b[0] && a[1] === b[1];

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a classe `EstadoXadrez`, responsável por agrupar dados e comportamentos relacionados a esta parte do jogo.
  // `class` = define uma classe utilizada para criar objetos com dados e comportamentos relacionados.
  // `EstadoXadrez` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  class EstadoXadrez {

    // Define o método construtor responsável por inicializar os dados e estados da nova instância da classe.
    // `constructor` = define o método construtor executado automaticamente ao criar uma instância da classe.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `inicializar` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a inicializar.
    constructor(inicializar = true) {

      // Armazena ou atualiza o valor de `this.tabuleiro` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.tabuleiro = [];

      // Armazena ou atualiza o valor de `this.turno` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
      this.turno = BRANCO;

      // Armazena ou atualiza o valor de `this.direitosRoque` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.direitosRoque = {};

      // Armazena ou atualiza o valor de `this.alvoEnPassant` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.alvoEnPassant = null;

      // Armazena ou atualiza o valor de `this.historico` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.historico` = acessa o atributo ou método `historico` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.historico = [];

      // Armazena ou atualiza o valor de `this.capturadasBrancas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.capturadasBrancas` = acessa o atributo ou método `capturadasBrancas` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.capturadasBrancas = [];

      // Armazena ou atualiza o valor de `this.capturadasPretas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.capturadasPretas` = acessa o atributo ou método `capturadasPretas` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.capturadasPretas = [];

      // Armazena ou atualiza o valor de `this.meioLances` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.meioLances` = acessa o atributo ou método `meioLances` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.meioLances = 0;

      // Armazena ou atualiza o valor de `this.numeroLance` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.numeroLance` = acessa o atributo ou método `numeroLance` pertencente à própria instância atual.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.numeroLance = 1;

      // Armazena ou atualiza o valor de `this.repeticoes` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.repeticoes` = acessa o atributo ou método `repeticoes` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.repeticoes = {};

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.reiniciar` = acessa o atributo ou método `reiniciar` pertencente à própria instância atual.
      // `this.reiniciar` = chama o método ou recurso `reiniciar` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `inicializar` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a inicializar.
      if (inicializar) this.reiniciar();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `reiniciar` para executar a rotina correspondente a reiniciar.
    // `reiniciar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    reiniciar() {

      // Armazena ou atualiza o valor de `this.tabuleiro` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `Array.from` = chama a função ou método `from` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Array` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `from` = identificador de propriedade ou método chamado `from`, acessado a partir do objeto indicado antes do ponto.
      // `length` = identificador usado como nome da propriedade `length` dentro do objeto atual.
      // `fill` = identificador de propriedade ou método chamado `fill`, acessado a partir do objeto indicado antes do ponto.
      this.tabuleiro = Array.from({ length: 8 }, () => Array(8).fill(null));

      // Declara `ordem` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ordem` = identificador utilizado para armazenar ou acessar o valor relacionado a ordem.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `TORRE` = constante que identifica a peça Torre.
      // `CAVALO` = constante que identifica a peça Cavalo.
      // `BISPO` = constante que identifica a peça Bispo.
      // `DAMA` = constante que identifica a peça Dama.
      // `REI` = constante que identifica a peça Rei.
      const ordem = [TORRE, CAVALO, BISPO, DAMA, REI, BISPO, CAVALO, TORRE];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      for (let coluna = 0; coluna < 8; coluna += 1) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `criarPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
        this.tabuleiro[0][coluna] = criarPeca(PRETO, ordem[coluna]);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `criarPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `PEAO` = constante que identifica a peça Peão.
        this.tabuleiro[1][coluna] = criarPeca(PRETO, PEAO);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `criarPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        this.tabuleiro[6][coluna] = criarPeca(BRANCO, PEAO);

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `criarPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        // `ordem` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ordem.
        this.tabuleiro[7][coluna] = criarPeca(BRANCO, ordem[coluna]);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Armazena ou atualiza o valor de `this.turno` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.turno = BRANCO;

      // Armazena ou atualiza o valor de `this.direitosRoque` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.direitosRoque = {

        // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `rei` = identificador usado como nome da propriedade `rei` dentro do objeto atual.
        // `dama` = identificador usado como nome da propriedade `dama` dentro do objeto atual.
        [BRANCO]: { rei: true, dama: true },

        // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
        [PRETO]: { rei: true, dama: true },

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

      // Armazena ou atualiza o valor de `this.alvoEnPassant` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.alvoEnPassant = null;

      // Armazena ou atualiza o valor de `this.historico` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.historico` = acessa o atributo ou método `historico` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.historico = [];

      // Armazena ou atualiza o valor de `this.capturadasBrancas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.capturadasBrancas` = acessa o atributo ou método `capturadasBrancas` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.capturadasBrancas = [];

      // Armazena ou atualiza o valor de `this.capturadasPretas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.capturadasPretas` = acessa o atributo ou método `capturadasPretas` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.capturadasPretas = [];

      // Armazena ou atualiza o valor de `this.meioLances` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.meioLances` = acessa o atributo ou método `meioLances` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.meioLances = 0;

      // Armazena ou atualiza o valor de `this.numeroLance` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.numeroLance` = acessa o atributo ou método `numeroLance` pertencente à própria instância atual.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.numeroLance = 1;

      // Armazena ou atualiza o valor de `this.repeticoes` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.repeticoes` = acessa o atributo ou método `repeticoes` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.repeticoes = {};

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._registrarPosicao` = acessa o atributo ou método `_registrarPosicao` pertencente à própria instância atual.
      // `this._registrarPosicao` = chama o método ou recurso `_registrarPosicao` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._registrarPosicao();

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `clonar` para executar a rotina correspondente a clonar.
    // `clonar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    clonar() {

      // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `new` = cria uma nova instância da classe ou construtor indicado.
      // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
      // `EstadoXadrez` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      const copia = new EstadoXadrez(false);

      // Armazena ou atualiza o valor de `copia.tabuleiro` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `this.tabuleiro.map` = chama o método ou recurso `map` pertencente à instância atual.
      // `linha.map` = chama a função ou método `map` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `p` = identificador de propriedade ou método chamado `p`, acessado a partir do objeto indicado antes do ponto.
      copia.tabuleiro = this.tabuleiro.map((linha) => linha.map((p) => (p ? { ...p } : null)));

      // Armazena ou atualiza o valor de `copia.turno` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      copia.turno = this.turno;

      // Armazena ou atualiza o valor de `copia.direitosRoque` utilizando o resultado definido nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `direitosRoque` = identificador de propriedade ou método chamado `direitosRoque`, acessado a partir do objeto indicado antes do ponto.
      copia.direitosRoque = {

        // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        [BRANCO]: { ...this.direitosRoque[BRANCO] },

        // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
        [PRETO]: { ...this.direitosRoque[PRETO] },

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

      // Armazena ou atualiza o valor de `copia.alvoEnPassant` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `copia` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a copia.
      copia.alvoEnPassant = this.alvoEnPassant ? [...this.alvoEnPassant] : null;

      // Armazena ou atualiza o valor de `copia.historico` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.historico` = acessa o atributo ou método `historico` pertencente à própria instância atual.
      // `this.historico.map` = chama o método ou recurso `map` pertencente à instância atual.
      // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `origem` = identificador que representa a casa de origem de um movimento.
      // `destino` = identificador que representa a casa de destino de um movimento.
      // `peca` = identificador que representa uma peça de xadrez.
      copia.historico = this.historico.map((m) => criarMovimento(m.origem, m.destino, m.peca, {

        // Define a propriedade `capturada` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `capturada` = identificador que representa a peça capturada em uma jogada.
        capturada: m.capturada,

        // Define a propriedade `promocao` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
        promocao: m.promocao,

        // Define a propriedade `enPassant` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
        enPassant: m.enPassant,

        // Define a propriedade `roque` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
        roque: m.roque,

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      }));

      // Armazena ou atualiza o valor de `copia.capturadasBrancas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.capturadasBrancas` = acessa o atributo ou método `capturadasBrancas` pertencente à própria instância atual.
      // `this.capturadasBrancas.map` = chama o método ou recurso `map` pertencente à instância atual.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `copia` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a copia.
      // `map` = identificador de propriedade ou método chamado `map`, acessado a partir do objeto indicado antes do ponto.
      // `p` = identificador de propriedade ou método chamado `p`, acessado a partir do objeto indicado antes do ponto.
      copia.capturadasBrancas = this.capturadasBrancas.map((p) => ({ ...p }));

      // Armazena ou atualiza o valor de `copia.capturadasPretas` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.capturadasPretas` = acessa o atributo ou método `capturadasPretas` pertencente à própria instância atual.
      // `this.capturadasPretas.map` = chama o método ou recurso `map` pertencente à instância atual.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      copia.capturadasPretas = this.capturadasPretas.map((p) => ({ ...p }));

      // Armazena ou atualiza o valor de `copia.meioLances` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.meioLances` = acessa o atributo ou método `meioLances` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      copia.meioLances = this.meioLances;

      // Armazena ou atualiza o valor de `copia.numeroLance` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.numeroLance` = acessa o atributo ou método `numeroLance` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      copia.numeroLance = this.numeroLance;

      // Armazena ou atualiza o valor de `copia.repeticoes` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.repeticoes` = acessa o atributo ou método `repeticoes` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      copia.repeticoes = { ...this.repeticoes };

      // Retorna `copia` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return copia;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `dentro` para executar a rotina correspondente a dentro.
    // `dentro` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `linha` = identificador que representa a linha de uma casa no tabuleiro.
    // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
    dentro(linha, coluna) {

      // Retorna `linha >= 0 && linha < 8 && coluna >= 0 && coluna < 8` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `;` = encerra a instrução JavaScript atual.
      return linha >= 0 && linha < 8 && coluna >= 0 && coluna < 8;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `pecaEm` para executar a rotina correspondente a pecaEm.
    // `pecaEm` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `posicao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a posicao.
    pecaEm(posicao) {

      // Retorna `this.tabuleiro[posicao[0]][posicao[1]]` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return this.tabuleiro[posicao[0]][posicao[1]];

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `movimentosLegais` para executar a rotina correspondente a movimentosLegais.
    // `this` = representa a própria instância atual da classe ou objeto.
    // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
    // `movimentosLegais` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    movimentosLegais(cor = this.turno) {

      // Declara `candidatos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `candidatos` = identificador utilizado para armazenar ou acessar o valor relacionado a candidatos.
      // `this._movimentosPseudoLegais` = acessa o atributo ou método `_movimentosPseudoLegais` pertencente à própria instância atual.
      // `this._movimentosPseudoLegais` = chama o método ou recurso `_movimentosPseudoLegais` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const candidatos = this._movimentosPseudoLegais(cor);

      // Declara `legais` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `legais` = identificador utilizado para armazenar ou acessar o valor relacionado a legais.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const legais = [];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      for (const movimento of candidatos) {

        // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
        // `this.clonar` = acessa o atributo ou método `clonar` pertencente à própria instância atual.
        // `this.clonar` = chama o método ou recurso `clonar` pertencente à instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const copia = this.clonar();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `copia._aplicarSemValidar` = chama a função ou método `_aplicarSemValidar` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `_aplicarSemValidar` = identificador de propriedade ou método chamado `_aplicarSemValidar`, acessado a partir do objeto indicado antes do ponto.
        copia._aplicarSemValidar(movimento, false);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `copia.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
        // `legais.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
        // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
        // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
        if (!copia.estaEmXeque(cor)) legais.push(movimento);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `legais` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      // `legais` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a legais.
      return legais;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `movimentosDaCasa` para executar a rotina correspondente a movimentosDaCasa.
    // `movimentosDaCasa` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `origem` = identificador que representa a casa de origem de um movimento.
    movimentosDaCasa(origem) {

      // Retorna `this.movimentosLegais(this.turno).filter((m) => posIgual(m.origem, origem))` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.movimentosLegais` = acessa o atributo ou método `movimentosLegais` pertencente à própria instância atual.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `this.movimentosLegais` = chama o método ou recurso `movimentosLegais` pertencente à instância atual.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      return this.movimentosLegais(this.turno).filter((m) => posIgual(m.origem, origem));

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `explicarMovimentoInvalido` para executar a rotina correspondente a explicarMovimentoInvalido.
    // `explicarMovimentoInvalido` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `destino` = identificador que representa a casa de destino de um movimento.
    explicarMovimentoInvalido(origem, destino) {

      // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
      // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
      // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const peca = this.pecaEm(origem);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'Não existe nenhuma peça na casa selecionada.'` = texto literal utilizado nesta instrução, contendo Não existe nenhuma peça na casa selecionada..
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!peca) return 'Não existe nenhuma peça na casa selecionada.';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `'Essa peça não pode ser movida agora porque não pertence ao jogador da vez.'` = texto literal utilizado nesta instrução, contendo Essa peça não pode ser movida agora porque não pertence ao jogador da vez..
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      if (peca.cor !== this.turno) return 'Essa peça não pode ser movida agora porque não pertence ao jogador da vez.';

      // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a alvo.
      // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
      // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `destino` = identificador que representa a casa de destino de um movimento.
      const alvo = this.pecaEm(destino);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'Essa casa já está ocupada por uma peça da mesma cor. Escolha uma casa livre ou uma peça adversária que possa ser capturada.'` = texto literal utilizado nesta instrução, contendo Essa casa já está ocupada por uma peça da mesma cor. Escolha uma casa livre o....
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      if (alvo && alvo.cor === peca.cor) return 'Essa casa já está ocupada por uma peça da mesma cor. Escolha uma casa livre ou uma peça adversária que possa ser capturada.';

      // Declara `pseudo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `pseudo` = identificador utilizado para armazenar ou acessar o valor relacionado a pseudo.
      // `this._movimentosPseudoLegais` = acessa o atributo ou método `_movimentosPseudoLegais` pertencente à própria instância atual.
      // `this._movimentosPseudoLegais` = chama o método ou recurso `_movimentosPseudoLegais` pertencente à instância atual.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `origem` = identificador que representa a casa de origem de um movimento.
      const pseudo = this._movimentosPseudoLegais(peca.cor).filter((m) => posIgual(m.origem, origem) && posIgual(m.destino, destino));

      // Declara `legais` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `legais` = identificador utilizado para armazenar ou acessar o valor relacionado a legais.
      // `this.movimentosLegais` = acessa o atributo ou método `movimentosLegais` pertencente à própria instância atual.
      // `this.movimentosLegais` = chama o método ou recurso `movimentosLegais` pertencente à instância atual.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      // `destino` = identificador que representa a casa de destino de um movimento.
      const legais = this.movimentosLegais(peca.cor).filter((m) => posIgual(m.origem, origem) && posIgual(m.destino, destino));

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'Esse movimento não é permitido porque deixaria o seu rei em xeque ou não resolveria o xeque atual. O rei deve permanecer protegido.'` = texto literal utilizado nesta instrução, contendo Esse movimento não é permitido porque deixaria o seu rei em xeque ou não reso....
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      if (pseudo.length && !legais.length) return 'Esse movimento não é permitido porque deixaria o seu rei em xeque ou não resolveria o xeque atual. O rei deve permanecer protegido.';

      // Declara `dl` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `dl` = identificador utilizado para armazenar ou acessar o valor relacionado a dl.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const dl = destino[0] - origem[0];

      // Declara `dc` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `dc` = identificador utilizado para armazenar ou acessar o valor relacionado a dc.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `origem` = identificador que representa a casa de origem de um movimento.
      const dc = destino[1] - origem[1];

      // Declara `adl` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `adl` = identificador utilizado para armazenar ou acessar o valor relacionado a adl.
      // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `abs` = identificador de propriedade ou método chamado `abs`, acessado a partir do objeto indicado antes do ponto.
      const adl = Math.abs(dl);

      // Declara `adc` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `adc` = identificador utilizado para armazenar ou acessar o valor relacionado a adc.
      // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const adc = Math.abs(dc);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'O cavalo anda somente em formato de L: duas casas em uma direção e uma casa na direção perpendicular. Ele pode saltar sobre outras peças.'` = texto literal utilizado nesta instrução, contendo O cavalo anda somente em formato de L: duas casas em uma direção e uma casa n....
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `CAVALO` = constante que identifica a peça Cavalo.
      if (peca.tipo === CAVALO) return 'O cavalo anda somente em formato de L: duas casas em uma direção e uma casa na direção perpendicular. Ele pode saltar sobre outras peças.';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'O bispo anda somente pelas diagonais.'` = texto literal utilizado nesta instrução, contendo O bispo anda somente pelas diagonais..
      // `'O caminho diagonal do bispo está bloqueado por outra peça.'` = texto literal utilizado nesta instrução, contendo O caminho diagonal do bispo está bloqueado por outra peça..
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `BISPO` = constante que identifica a peça Bispo.
      if (peca.tipo === BISPO) return adl !== adc ? 'O bispo anda somente pelas diagonais.' : 'O caminho diagonal do bispo está bloqueado por outra peça.';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'A torre anda somente na horizontal ou na vertical.'` = texto literal utilizado nesta instrução, contendo A torre anda somente na horizontal ou na vertical..
      // `'O caminho da torre está bloqueado por outra peça.'` = texto literal utilizado nesta instrução, contendo O caminho da torre está bloqueado por outra peça..
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `TORRE` = constante que identifica a peça Torre.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      if (peca.tipo === TORRE) return dl !== 0 && dc !== 0 ? 'A torre anda somente na horizontal ou na vertical.' : 'O caminho da torre está bloqueado por outra peça.';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'A dama anda em linha reta ou pelas diagonais.'` = texto literal utilizado nesta instrução, contendo A dama anda em linha reta ou pelas diagonais..
      // `'Existe uma peça bloqueando o caminho da dama.'` = texto literal utilizado nesta instrução, contendo Existe uma peça bloqueando o caminho da dama..
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `DAMA` = constante que identifica a peça Dama.
      // `adl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a adl.
      // `adc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a adc.
      if (peca.tipo === DAMA) return !(dl === 0 || dc === 0 || adl === adc) ? 'A dama anda em linha reta ou pelas diagonais.' : 'Existe uma peça bloqueando o caminho da dama.';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `REI` = constante que identifica a peça Rei.
      if (peca.tipo === REI) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `'O rei não pode ir para essa casa porque ela está ocupada, atacada ou o movimento deixaria o rei em xeque.'` = texto literal utilizado nesta instrução, contendo O rei não pode ir para essa casa porque ela está ocupada, atacada ou o movime....
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        if (adl <= 1 && adc <= 1) return 'O rei não pode ir para essa casa porque ela está ocupada, atacada ou o movimento deixaria o rei em xeque.';

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `'O roque não está disponível. Rei e torre não podem ter se movido, o caminho deve estar livre e o rei não pode estar em xeque, atravessar ou terminar em casa atacada.'` = texto literal utilizado nesta instrução, contendo O roque não está disponível. Rei e torre não podem ter se movido, o caminho d....
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
        if (dl === 0 && adc === 2) return 'O roque não está disponível. Rei e torre não podem ter se movido, o caminho deve estar livre e o rei não pode estar em xeque, atravessar ou terminar em casa atacada.';

        // Retorna `'O rei normalmente anda apenas uma casa por vez em qualquer direção. A exceção é o roque.'` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `'O rei normalmente anda apenas uma casa por vez em qualquer direção. A exceção é o roque.'` = texto literal utilizado nesta instrução, contendo O rei normalmente anda apenas uma casa por vez em qualquer direção. A exceção....
        // `;` = encerra a instrução JavaScript atual.
        return 'O rei normalmente anda apenas uma casa por vez em qualquer direção. A exceção é o roque.';

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `PEAO` = constante que identifica a peça Peão.
      if (peca.tipo === PEAO) {

        // Declara `direcao` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `direcao` = identificador utilizado para armazenar ou acessar o valor relacionado a direcao.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
        const direcao = peca.cor === BRANCO ? -1 : 1;

        // Declara `linhaInicial` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `linhaInicial` = identificador utilizado para armazenar ou acessar o valor relacionado a linhaInicial.
        // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const linhaInicial = peca.cor === BRANCO ? 6 : 1;

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
        if (dc === 0) {

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `'O peão não pode andar para trás.'` = texto literal utilizado nesta instrução, contendo O peão não pode andar para trás..
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
          if (dl === -direcao) return 'O peão não pode andar para trás.';

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `'O peão só pode avançar para uma casa vazia.'` = texto literal utilizado nesta instrução, contendo O peão só pode avançar para uma casa vazia..
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `direcao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a direcao.
          if (dl === direcao) return 'O peão só pode avançar para uma casa vazia.';

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `'O peão só pode avançar duas casas em seu primeiro movimento.'` = texto literal utilizado nesta instrução, contendo O peão só pode avançar duas casas em seu primeiro movimento..
          // `'O avanço de duas casas exige que as duas casas à frente estejam livres.'` = texto literal utilizado nesta instrução, contendo O avanço de duas casas exige que as duas casas à frente estejam livres..
          // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `0` = representa o primeiro índice possível quando a contagem começa em zero.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
          // `*` = realiza multiplicação.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `linhaInicial` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaInicial.
          if (dl === 2 * direcao) return origem[0] !== linhaInicial ? 'O peão só pode avançar duas casas em seu primeiro movimento.' : 'O avanço de duas casas exige que as duas casas à frente estejam livres.';

          // Retorna `'O peão avança uma casa e, no primeiro movimento, pode avançar duas se o caminho estiver livre.'` para o ponto do programa que chamou a rotina atual.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `'O peão avança uma casa e, no primeiro movimento, pode avançar duas se o caminho estiver livre.'` = texto literal utilizado nesta instrução, contendo O peão avança uma casa e, no primeiro movimento, pode avançar duas se o camin....
          // `;` = encerra a instrução JavaScript atual.
          return 'O peão avança uma casa e, no primeiro movimento, pode avançar duas se o caminho estiver livre.';

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `'O peão só se move na diagonal ao capturar uma peça adversária ou em uma captura en passant válida.'` = texto literal utilizado nesta instrução, contendo O peão só se move na diagonal ao capturar uma peça adversária ou em uma captu....
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `adc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a adc.
        // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
        if (adc === 1 && dl === direcao) return 'O peão só se move na diagonal ao capturar uma peça adversária ou em uma captura en passant válida.';

        // Retorna `'O peão anda para frente e captura uma casa na diagonal.'` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `'O peão anda para frente e captura uma casa na diagonal.'` = texto literal utilizado nesta instrução, contendo O peão anda para frente e captura uma casa na diagonal..
        // `;` = encerra a instrução JavaScript atual.
        return 'O peão anda para frente e captura uma casa na diagonal.';

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `'Esse movimento não é permitido pelas regras do xadrez.'` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `'Esse movimento não é permitido pelas regras do xadrez.'` = texto literal utilizado nesta instrução, contendo Esse movimento não é permitido pelas regras do xadrez..
      // `;` = encerra a instrução JavaScript atual.
      return 'Esse movimento não é permitido pelas regras do xadrez.';

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_movimentosPseudoLegais` para executar a rotina correspondente a movimentosPseudoLegais.
    // `_movimentosPseudoLegais` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    _movimentosPseudoLegais(cor) {

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const movimentos = [];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      for (let linha = 0; linha < 8; linha += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        for (let coluna = 0; coluna < 8; coluna += 1) {

          // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const peca = this.tabuleiro[linha][coluna];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `continue` = encerra a iteração atual e avança para a próxima repetição.
          // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
          // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          if (!peca || peca.cor !== cor) continue;

          // Declara `origem` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `origem` = identificador utilizado para armazenar ou acessar o valor relacionado a origem.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `linha` = identificador que representa a linha de uma casa no tabuleiro.
          const origem = [linha, coluna];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._movimentosPeao` = acessa o atributo ou método `_movimentosPeao` pertencente à própria instância atual.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._movimentosPeao` = chama o método ou recurso `_movimentosPeao` pertencente à instância atual.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `PEAO` = constante que identifica a peça Peão.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          if (peca.tipo === PEAO) movimentos.push(...this._movimentosPeao(origem, peca));

          // Verifica uma condição alternativa quando a condição anterior não foi atendida.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._movimentosCavalo` = acessa o atributo ou método `_movimentosCavalo` pertencente à própria instância atual.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._movimentosCavalo` = chama o método ou recurso `_movimentosCavalo` pertencente à instância atual.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `peca` = identificador que representa uma peça de xadrez.
          // `CAVALO` = constante que identifica a peça Cavalo.
          else if (peca.tipo === CAVALO) movimentos.push(...this._movimentosCavalo(origem, peca));

          // Verifica uma condição alternativa quando a condição anterior não foi atendida.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._movimentosDeslizantes` = acessa o atributo ou método `_movimentosDeslizantes` pertencente à própria instância atual.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._movimentosDeslizantes` = chama o método ou recurso `_movimentosDeslizantes` pertencente à instância atual.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `BISPO` = constante que identifica a peça Bispo.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
          else if (peca.tipo === BISPO) movimentos.push(...this._movimentosDeslizantes(origem, peca, [[-1, -1], [-1, 1], [1, -1], [1, 1]]));

          // Verifica uma condição alternativa quando a condição anterior não foi atendida.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._movimentosDeslizantes` = acessa o atributo ou método `_movimentosDeslizantes` pertencente à própria instância atual.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._movimentosDeslizantes` = chama o método ou recurso `_movimentosDeslizantes` pertencente à instância atual.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `TORRE` = constante que identifica a peça Torre.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          else if (peca.tipo === TORRE) movimentos.push(...this._movimentosDeslizantes(origem, peca, [[-1, 0], [1, 0], [0, -1], [0, 1]]));

          // Verifica uma condição alternativa quando a condição anterior não foi atendida.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._movimentosDeslizantes` = acessa o atributo ou método `_movimentosDeslizantes` pertencente à própria instância atual.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._movimentosDeslizantes` = chama o método ou recurso `_movimentosDeslizantes` pertencente à instância atual.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `peca` = identificador que representa uma peça de xadrez.
          // `DAMA` = constante que identifica a peça Dama.
          else if (peca.tipo === DAMA) movimentos.push(...this._movimentosDeslizantes(origem, peca, [[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]]));

          // Verifica uma condição alternativa quando a condição anterior não foi atendida.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this._movimentosRei` = acessa o atributo ou método `_movimentosRei` pertencente à própria instância atual.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `this._movimentosRei` = chama o método ou recurso `_movimentosRei` pertencente à instância atual.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `REI` = constante que identifica a peça Rei.
          // `origem` = identificador que representa a casa de origem de um movimento.
          else if (peca.tipo === REI) movimentos.push(...this._movimentosRei(origem, peca));

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `movimentos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      return movimentos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_movimentosPeao` para executar a rotina correspondente a movimentosPeao.
    // `_movimentosPeao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _movimentosPeao(origem, peca) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      const [linha, coluna] = origem;

      // Declara `direcao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `direcao` = identificador utilizado para armazenar ou acessar o valor relacionado a direcao.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      const direcao = peca.cor === BRANCO ? -1 : 1;

      // Declara `linhaInicial` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `linhaInicial` = identificador utilizado para armazenar ou acessar o valor relacionado a linhaInicial.
      // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const linhaInicial = peca.cor === BRANCO ? 6 : 1;

      // Declara `linhaPromocao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `linhaPromocao` = identificador utilizado para armazenar ou acessar o valor relacionado a linhaPromocao.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const linhaPromocao = peca.cor === BRANCO ? 0 : 7;

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const movimentos = [];

      // Declara `frente` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `frente` = identificador utilizado para armazenar ou acessar o valor relacionado a frente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `direcao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a direcao.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      const frente = [linha + direcao, coluna];

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
      // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
      // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
      // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (this.dentro(...frente) && !this.pecaEm(frente)) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `linhaPromocao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaPromocao.
        if (frente[0] === linhaPromocao) {

          // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
          // `of` = indica os valores percorridos em uma estrutura for...of.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
          // `TIPOS_PROMOCAO` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a TIPOS PROMOCAO.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `frente` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a frente.
          // `peca` = identificador que representa uma peça de xadrez.
          // `promocao` = identificador usado como nome da propriedade `promocao` dentro do objeto atual.
          for (const tipo of TIPOS_PROMOCAO) movimentos.push(criarMovimento(origem, frente, peca, { promocao: tipo }));

        // Executa o bloco alternativo quando a condição anterior não foi atendida.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
        // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        } else movimentos.push(criarMovimento(origem, frente, peca));

        // Declara `duas` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `duas` = identificador utilizado para armazenar ou acessar o valor relacionado a duas.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `*` = realiza multiplicação.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        // `direcao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a direcao.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        const duas = [linha + 2 * direcao, coluna];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
        // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
        // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
        // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `linhaInicial` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaInicial.
        // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
        if (linha === linhaInicial && !this.pecaEm(duas)) movimentos.push(criarMovimento(origem, duas, peca));

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      for (const dc of [-1, 1]) {

        // Declara `destino` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `destino` = identificador utilizado para armazenar ou acessar o valor relacionado a destino.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        // `direcao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a direcao.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        const destino = [linha + direcao, coluna + dc];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (!this.dentro(...destino)) continue;

        // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a alvo.
        // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
        // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const alvo = this.pecaEm(destino);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        if (alvo && alvo.cor !== peca.cor) {

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `0` = representa o primeiro índice possível quando a contagem começa em zero.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `destino` = identificador que representa a casa de destino de um movimento.
          // `linhaPromocao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaPromocao.
          if (destino[0] === linhaPromocao) {

            // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
            // `const` = declara uma constante que recebe um valor na própria declaração.
            // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
            // `of` = indica os valores percorridos em uma estrutura for...of.
            // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
            // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
            // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
            // `TIPOS_PROMOCAO` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a TIPOS PROMOCAO.
            // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
            // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
            // `origem` = identificador que representa a casa de origem de um movimento.
            // `capturada` = identificador que representa a peça capturada em uma jogada.
            // `promocao` = identificador usado como nome da propriedade `promocao` dentro do objeto atual.
            for (const tipo of TIPOS_PROMOCAO) movimentos.push(criarMovimento(origem, destino, peca, { capturada: alvo, promocao: tipo }));

          // Executa o bloco alternativo quando a condição anterior não foi atendida.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `peca` = identificador que representa uma peça de xadrez.
          // `alvo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alvo.
          } else movimentos.push(criarMovimento(origem, destino, peca, { capturada: alvo }));

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `destino` = identificador que representa a casa de destino de um movimento.
        } else if (this.alvoEnPassant && posIgual(this.alvoEnPassant, destino)) {

          // Declara `capturada` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `capturada` = identificador utilizado para armazenar ou acessar o valor relacionado a capturada.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `linha` = identificador que representa a linha de uma casa no tabuleiro.
          const capturada = this.tabuleiro[linha][destino[1]];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `PEAO` = constante que identifica a peça Peão.
          if (capturada && capturada.cor !== peca.cor && capturada.tipo === PEAO) {

            // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
            // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
            // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
            // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
            // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
            // `origem` = identificador que representa a casa de origem de um movimento.
            // `peca` = identificador que representa uma peça de xadrez.
            // `enPassant` = identificador usado como nome da propriedade `enPassant` dentro do objeto atual.
            movimentos.push(criarMovimento(origem, destino, peca, { capturada, enPassant: true }));

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `movimentos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return movimentos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_movimentosCavalo` para executar a rotina correspondente a movimentosCavalo.
    // `_movimentosCavalo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _movimentosCavalo(origem, peca) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      const [linha, coluna] = origem;

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const movimentos = [];

      // Declara `saltos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `saltos` = identificador utilizado para armazenar ou acessar o valor relacionado a saltos.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `-2` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      const saltos = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      for (const [dl, dc] of saltos) {

        // Declara `destino` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `destino` = identificador utilizado para armazenar ou acessar o valor relacionado a destino.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        const destino = [linha + dl, coluna + dc];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (!this.dentro(...destino)) continue;

        // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a alvo.
        // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
        // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const alvo = this.pecaEm(destino);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
        // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
        // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
        // `origem` = identificador que representa a casa de origem de um movimento.
        // `destino` = identificador que representa a casa de destino de um movimento.
        // `capturada` = identificador que representa a peça capturada em uma jogada.
        if (!alvo || alvo.cor !== peca.cor) movimentos.push(criarMovimento(origem, destino, peca, { capturada: alvo }));

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `movimentos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return movimentos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_movimentosDeslizantes` para executar a rotina correspondente a movimentosDeslizantes.
    // `_movimentosDeslizantes` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `direcoes` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a direcoes.
    _movimentosDeslizantes(origem, peca, direcoes) {

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const movimentos = [];

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      const [linha, coluna] = origem;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      for (const [dl, dc] of direcoes) {

        // Declara `l` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `l` = identificador utilizado para armazenar ou acessar o valor relacionado a l.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        let l = linha + dl;

        // Declara `c` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `c` = identificador utilizado para armazenar ou acessar o valor relacionado a c.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        let c = coluna + dc;

        // Repete o bloco de instruções enquanto a condição informada permanecer verdadeira.
        // `while` = inicia uma repetição que continua enquanto a condição permanecer verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        while (this.dentro(l, c)) {

          // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a alvo.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const alvo = this.tabuleiro[l][c];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `peca` = identificador que representa uma peça de xadrez.
          if (!alvo) movimentos.push(criarMovimento(origem, [l, c], peca));

          // Executa o bloco alternativo quando a condição anterior não foi atendida.
          // `else` = define o caminho executado quando a condição anterior não é atendida.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          else {

            // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
            // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
            // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
            // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
            // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
            // `]` = fecha a lista, o acesso por índice ou a chave calculada.
            // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
            // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
            // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
            // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
            // `l` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a l.
            // `c` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a c.
            // `capturada` = identificador que representa a peça capturada em uma jogada.
            if (alvo.cor !== peca.cor) movimentos.push(criarMovimento(origem, [l, c], peca, { capturada: alvo }));

            // Interrompe imediatamente a estrutura de repetição ou seleção atual.
            // `break` = interrompe a estrutura de repetição ou seleção atual.
            // `;` = encerra a instrução JavaScript atual.
            break;

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Armazena ou atualiza em `l` o valor ou resultado definido nesta linha.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `;` = encerra a instrução JavaScript atual.
          // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
          l += dl;

          // Armazena ou atualiza em `c` o valor ou resultado definido nesta linha.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `;` = encerra a instrução JavaScript atual.
          // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
          c += dc;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `movimentos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      return movimentos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_movimentosRei` para executar a rotina correspondente a movimentosRei.
    // `_movimentosRei` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `origem` = identificador que representa a casa de origem de um movimento.
    // `peca` = identificador que representa uma peça de xadrez.
    _movimentosRei(origem, peca) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      const [linha, coluna] = origem;

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const movimentos = [];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      for (let dl = -1; dl <= 1; dl += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
        for (let dc = -1; dc <= 1; dc += 1) {

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `continue` = encerra a iteração atual e avança para a próxima repetição.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          if (dl === 0 && dc === 0) continue;

          // Declara `destino` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `destino` = identificador utilizado para armazenar ou acessar o valor relacionado a destino.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `linha` = identificador que representa a linha de uma casa no tabuleiro.
          // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
          const destino = [linha + dl, coluna + dc];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `continue` = encerra a iteração atual e avança para a próxima repetição.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
          // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          if (!this.dentro(...destino)) continue;

          // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a alvo.
          // `this.pecaEm` = acessa o atributo ou método `pecaEm` pertencente à própria instância atual.
          // `this.pecaEm` = chama o método ou recurso `pecaEm` pertencente à instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const alvo = this.pecaEm(destino);

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
          // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          // `peca` = identificador que representa uma peça de xadrez.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `destino` = identificador que representa a casa de destino de um movimento.
          // `capturada` = identificador que representa a peça capturada em uma jogada.
          if (!alvo || alvo.cor !== peca.cor) movimentos.push(criarMovimento(origem, destino, peca, { capturada: alvo }));

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._movimentosRoque` = acessa o atributo ou método `_movimentosRoque` pertencente à própria instância atual.
      // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
      // `this._movimentosRoque` = chama o método ou recurso `_movimentosRoque` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      movimentos.push(...this._movimentosRoque(origem, peca));

      // Retorna `movimentos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return movimentos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_movimentosRoque` para executar a rotina correspondente a movimentosRoque.
    // `_movimentosRoque` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _movimentosRoque(origem, peca) {

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const movimentos = [];

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `REI` = constante que identifica a peça Rei.
      if (peca.tipo !== REI) return movimentos;

      // Declara `linhaEsperada` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `linhaEsperada` = identificador utilizado para armazenar ou acessar o valor relacionado a linhaEsperada.
      // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
      const linhaEsperada = peca.cor === BRANCO ? 7 : 0;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.estaEmXeque` = acessa o atributo ou método `estaEmXeque` pertencente à própria instância atual.
      // `this.estaEmXeque` = chama o método ou recurso `estaEmXeque` pertencente à instância atual.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `origem` = identificador que representa a casa de origem de um movimento.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      if (!posIgual(origem, [linhaEsperada, 4]) || this.estaEmXeque(peca.cor)) return movimentos;

      // Declara `adversaria` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `adversaria` = identificador utilizado para armazenar ou acessar o valor relacionado a adversaria.
      // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const adversaria = corOposta(peca.cor);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `rei` = identificador de propriedade ou método chamado `rei`, acessado a partir do objeto indicado antes do ponto.
      if (this.direitosRoque[peca.cor].rei) {

        // Declara `torre` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `torre` = identificador utilizado para armazenar ou acessar o valor relacionado a torre.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `linhaEsperada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaEsperada.
        const torre = this.tabuleiro[linhaEsperada][7];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        // `TORRE` = constante que identifica a peça Torre.
        if (torre && torre.cor === peca.cor && torre.tipo === TORRE && !this.tabuleiro[linhaEsperada][5] && !this.tabuleiro[linhaEsperada][6]

          // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.casaAtacada` = acessa o atributo ou método `casaAtacada` pertencente à própria instância atual.
          // `this.casaAtacada` = chama o método ou recurso `casaAtacada` pertencente à instância atual.
          // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `adversaria` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a adversaria.
          && !this.casaAtacada([linhaEsperada, 5], adversaria) && !this.casaAtacada([linhaEsperada, 6], adversaria)) {

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `linhaEsperada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaEsperada.
          // `peca` = identificador que representa uma peça de xadrez.
          // `roque` = identificador usado como nome da propriedade `roque` dentro do objeto atual.
          movimentos.push(criarMovimento(origem, [linhaEsperada, 6], peca, { roque: true }));

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
      // `dama` = identificador de propriedade ou método chamado `dama`, acessado a partir do objeto indicado antes do ponto.
      if (this.direitosRoque[peca.cor].dama) {

        // Declara `torre` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `torre` = identificador utilizado para armazenar ou acessar o valor relacionado a torre.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const torre = this.tabuleiro[linhaEsperada][0];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        // `TORRE` = constante que identifica a peça Torre.
        // `linhaEsperada` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaEsperada.
        if (torre && torre.cor === peca.cor && torre.tipo === TORRE && !this.tabuleiro[linhaEsperada][1] && !this.tabuleiro[linhaEsperada][2] && !this.tabuleiro[linhaEsperada][3]

          // Abre um novo bloco de instruções ou estrutura que será completado pelas linhas seguintes.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.casaAtacada` = acessa o atributo ou método `casaAtacada` pertencente à própria instância atual.
          // `this.casaAtacada` = chama o método ou recurso `casaAtacada` pertencente à instância atual.
          // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `adversaria` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a adversaria.
          && !this.casaAtacada([linhaEsperada, 3], adversaria) && !this.casaAtacada([linhaEsperada, 2], adversaria)) {

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `movimentos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          // `origem` = identificador que representa a casa de origem de um movimento.
          // `roque` = identificador usado como nome da propriedade `roque` dentro do objeto atual.
          movimentos.push(criarMovimento(origem, [linhaEsperada, 2], peca, { roque: true }));

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `movimentos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return movimentos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `casaAtacada` para executar a rotina correspondente a casaAtacada.
    // `casaAtacada` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `casa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a casa.
    // `porCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a porCor.
    casaAtacada(casa, porCor) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
      const [linha, coluna] = casa;

      // Declara `direcao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `direcao` = identificador utilizado para armazenar ou acessar o valor relacionado a direcao.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      const direcao = porCor === BRANCO ? -1 : 1;

      // Declara `origemLinha` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `origemLinha` = identificador utilizado para armazenar ou acessar o valor relacionado a origemLinha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      const origemLinha = linha - direcao;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      for (const dc of [-1, 1]) {

        // Declara `origemColuna` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `origemColuna` = identificador utilizado para armazenar ou acessar o valor relacionado a origemColuna.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `;` = encerra a instrução JavaScript atual.
        const origemColuna = coluna - dc;

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (this.dentro(origemLinha, origemColuna)) {

          // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `origemLinha` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a origemLinha.
          const p = this.tabuleiro[origemLinha][origemColuna];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          // `porCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a porCor.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `PEAO` = constante que identifica a peça Peão.
          if (p && p.cor === porCor && p.tipo === PEAO) return true;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      // `-2` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      for (const [dl, dc] of [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]]) {

        // Declara `l` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `l` = identificador utilizado para armazenar ou acessar o valor relacionado a l.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        const l = linha + dl;

        // Declara `c` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `c` = identificador utilizado para armazenar ou acessar o valor relacionado a c.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        const c = coluna + dc;

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (this.dentro(l, c)) {

          // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const p = this.tabuleiro[l][c];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          // `porCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a porCor.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `CAVALO` = constante que identifica a peça Cavalo.
          if (p && p.cor === porCor && p.tipo === CAVALO) return true;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      for (let dl = -1; dl <= 1; dl += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
        for (let dc = -1; dc <= 1; dc += 1) {

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `continue` = encerra a iteração atual e avança para a próxima repetição.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          if (dl === 0 && dc === 0) continue;

          // Declara `l` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `l` = identificador utilizado para armazenar ou acessar o valor relacionado a l.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `;` = encerra a instrução JavaScript atual.
          // `linha` = identificador que representa a linha de uma casa no tabuleiro.
          const l = linha + dl;

          // Declara `c` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `c` = identificador utilizado para armazenar ou acessar o valor relacionado a c.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `;` = encerra a instrução JavaScript atual.
          // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
          const c = coluna + dc;

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
          // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          if (this.dentro(l, c)) {

            // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
            // `const` = declara uma constante que recebe um valor na própria declaração.
            // `this` = representa a própria instância atual da classe ou objeto.
            // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
            // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
            // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
            // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
            // `]` = fecha a lista, o acesso por índice ou a chave calculada.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            const p = this.tabuleiro[l][c];

            // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
            // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
            // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
            // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
            // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
            // `porCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a porCor.
            // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
            // `REI` = constante que identifica a peça Rei.
            if (p && p.cor === porCor && p.tipo === REI) return true;

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      for (const [dl, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {

        // Declara `l` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `l` = identificador utilizado para armazenar ou acessar o valor relacionado a l.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        let l = linha + dl;

        // Declara `c` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `c` = identificador utilizado para armazenar ou acessar o valor relacionado a c.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        let c = coluna + dc;

        // Repete o bloco de instruções enquanto a condição informada permanecer verdadeira.
        // `while` = inicia uma repetição que continua enquanto a condição permanecer verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        while (this.dentro(l, c)) {

          // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const p = this.tabuleiro[l][c];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          if (p) {

            // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
            // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
            // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
            // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
            // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
            // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
            // `porCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a porCor.
            // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
            // `TORRE` = constante que identifica a peça Torre.
            // `DAMA` = constante que identifica a peça Dama.
            if (p.cor === porCor && (p.tipo === TORRE || p.tipo === DAMA)) return true;

            // Interrompe imediatamente a estrutura de repetição ou seleção atual.
            // `break` = interrompe a estrutura de repetição ou seleção atual.
            // `;` = encerra a instrução JavaScript atual.
            break;

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Armazena ou atualiza em `l` o valor ou resultado definido nesta linha.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `;` = encerra a instrução JavaScript atual.
          // `l` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a l.
          // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
          l += dl;

          // Armazena ou atualiza em `c` o valor ou resultado definido nesta linha.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `;` = encerra a instrução JavaScript atual.
          // `c` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a c.
          // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
          c += dc;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      for (const [dl, dc] of [[-1, -1], [-1, 1], [1, -1], [1, 1]]) {

        // Declara `l` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `l` = identificador utilizado para armazenar ou acessar o valor relacionado a l.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        // `linha` = identificador que representa a linha de uma casa no tabuleiro.
        let l = linha + dl;

        // Declara `c` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `c` = identificador utilizado para armazenar ou acessar o valor relacionado a c.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        let c = coluna + dc;

        // Repete o bloco de instruções enquanto a condição informada permanecer verdadeira.
        // `while` = inicia uma repetição que continua enquanto a condição permanecer verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        while (this.dentro(l, c)) {

          // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const p = this.tabuleiro[l][c];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
          if (p) {

            // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
            // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
            // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
            // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
            // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
            // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
            // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
            // `;` = encerra a instrução JavaScript atual.
            // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
            // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
            // `porCor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a porCor.
            // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
            // `BISPO` = constante que identifica a peça Bispo.
            // `DAMA` = constante que identifica a peça Dama.
            if (p.cor === porCor && (p.tipo === BISPO || p.tipo === DAMA)) return true;

            // Interrompe imediatamente a estrutura de repetição ou seleção atual.
            // `break` = interrompe a estrutura de repetição ou seleção atual.
            // `;` = encerra a instrução JavaScript atual.
            break;

          // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
          // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
          }

          // Armazena ou atualiza em `l` o valor ou resultado definido nesta linha.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `;` = encerra a instrução JavaScript atual.
          // `l` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a l.
          // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
          l += dl;

          // Armazena ou atualiza em `c` o valor ou resultado definido nesta linha.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `;` = encerra a instrução JavaScript atual.
          // `c` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a c.
          // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
          c += dc;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `false` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return false;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `encontrarRei` para executar a rotina correspondente a encontrarRei.
    // `encontrarRei` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    encontrarRei(cor) {

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      for (let linha = 0; linha < 8; linha += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        for (let coluna = 0; coluna < 8; coluna += 1) {

          // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const p = this.tabuleiro[linha][coluna];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `REI` = constante que identifica a peça Rei.
          if (p && p.cor === cor && p.tipo === REI) return [linha, coluna];

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `null` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return null;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `estaEmXeque` para executar a rotina correspondente a estaEmXeque.
    // `estaEmXeque` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    estaEmXeque(cor) {

      // Declara `rei` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `rei` = identificador utilizado para armazenar ou acessar o valor relacionado a rei.
      // `this.encontrarRei` = acessa o atributo ou método `encontrarRei` pertencente à própria instância atual.
      // `this.encontrarRei` = chama o método ou recurso `encontrarRei` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const rei = this.encontrarRei(cor);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!rei) return true;

      // Retorna `this.casaAtacada(rei, corOposta(cor))` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.casaAtacada` = acessa o atributo ou método `casaAtacada` pertencente à própria instância atual.
      // `this.casaAtacada` = chama o método ou recurso `casaAtacada` pertencente à instância atual.
      // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
      return this.casaAtacada(rei, corOposta(cor));

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `aplicarMovimento` para executar a rotina correspondente a aplicarMovimento.
    // `aplicarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    aplicarMovimento(movimento) {

      // Declara `legais` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `legais` = identificador utilizado para armazenar ou acessar o valor relacionado a legais.
      // `this.movimentosLegais` = acessa o atributo ou método `movimentosLegais` pertencente à própria instância atual.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `this.movimentosLegais` = chama o método ou recurso `movimentosLegais` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const legais = this.movimentosLegais(this.turno);

      // Declara `correspondente` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `correspondente` = identificador utilizado para armazenar ou acessar o valor relacionado a correspondente.
      // `legais.find` = chama a função ou método `find` pertencente ao objeto ou recurso indicado antes do ponto.
      // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `find` = identificador de propriedade ou método chamado `find`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `origem` = identificador que representa a casa de origem de um movimento.
      // `destino` = identificador que representa a casa de destino de um movimento.
      // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
      const correspondente = legais.find((m) => posIgual(m.origem, movimento.origem) && posIgual(m.destino, movimento.destino) && m.promocao === (movimento.promocao || null));

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `throw` = interrompe o fluxo normal lançando explicitamente uma exceção.
      // `new` = cria uma nova instância da classe ou construtor indicado.
      // `Error` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Movimento inválido para a posição atual.'` = texto literal utilizado nesta instrução, contendo Movimento inválido para a posição atual..
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!correspondente) throw new Error('Movimento inválido para a posição atual.');

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._aplicarSemValidar` = acessa o atributo ou método `_aplicarSemValidar` pertencente à própria instância atual.
      // `this._aplicarSemValidar` = chama o método ou recurso `_aplicarSemValidar` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this._aplicarSemValidar(correspondente, true);

      // Retorna `correspondente` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return correspondente;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_aplicarSemValidar` para executar a rotina correspondente a aplicarSemValidar.
    // `_aplicarSemValidar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    // `registrarRepeticao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a registrarRepeticao.
    _aplicarSemValidar(movimento, registrarRepeticao = true) {

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ol` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ol.
      // `oc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a oc.
      // `origem` = identificador que representa a casa de origem de um movimento.
      const [ol, oc] = movimento.origem;

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      // `destino` = identificador que representa a casa de destino de um movimento.
      const [dl, dc] = movimento.destino;

      // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const peca = this.tabuleiro[ol][oc];

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `throw` = interrompe o fluxo normal lançando explicitamente uma exceção.
      // `new` = cria uma nova instância da classe ou construtor indicado.
      // `Error` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `'Não existe peça na casa de origem.'` = texto literal utilizado nesta instrução, contendo Não existe peça na casa de origem..
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      if (!peca) throw new Error('Não existe peça na casa de origem.');

      // Declara `alvo` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `alvo` = identificador utilizado para armazenar ou acessar o valor relacionado a alvo.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const alvo = this.tabuleiro[dl][dc];

      // Declara `houveCaptura` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `houveCaptura` = identificador utilizado para armazenar ou acessar o valor relacionado a houveCaptura.
      // `Boolean` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
      const houveCaptura = Boolean(alvo || movimento.enPassant);

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `capturada` = identificador utilizado para armazenar ou acessar o valor relacionado a capturada.
      // `;` = encerra a instrução JavaScript atual.
      let capturada;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (movimento.enPassant) {

        // Armazena ou atualiza em `capturada` o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `ol` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ol.
        // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
        capturada = this.tabuleiro[ol][dc];

        // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        this.tabuleiro[ol][dc] = null;

      // Executa o bloco alternativo quando a condição anterior não foi atendida.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `alvo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alvo.
      } else capturada = alvo;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (capturada) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.capturadasBrancas` = acessa o atributo ou método `capturadasBrancas` pertencente à própria instância atual.
        // `this.capturadasBrancas.push` = chama o método ou recurso `push` pertencente à instância atual.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `capturada` = identificador que representa a peça capturada em uma jogada.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
        if (capturada.cor === BRANCO) this.capturadasBrancas.push({ ...capturada });

        // Executa o bloco alternativo quando a condição anterior não foi atendida.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.capturadasPretas` = acessa o atributo ou método `capturadasPretas` pertencente à própria instância atual.
        // `this.capturadasPretas.push` = chama o método ou recurso `push` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        else this.capturadasPretas.push({ ...capturada });

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `ol` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ol.
      // `oc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a oc.
      this.tabuleiro[ol][oc] = null;

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `criarPeca` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      this.tabuleiro[dl][dc] = movimento.promocao ? criarPeca(peca.cor, movimento.promocao) : peca;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
      if (movimento.roque) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        if (dc === 6) {

          // Declara `torre` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `torre` = identificador utilizado para armazenar ou acessar o valor relacionado a torre.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const torre = this.tabuleiro[dl][7];

          // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          this.tabuleiro[dl][7] = null;

          // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
          this.tabuleiro[dl][5] = torre;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `dc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dc.
        } else if (dc === 2) {

          // Declara `torre` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `torre` = identificador utilizado para armazenar ou acessar o valor relacionado a torre.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const torre = this.tabuleiro[dl][0];

          // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          this.tabuleiro[dl][0] = null;

          // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          this.tabuleiro[dl][3] = torre;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._atualizarDireitosRoque` = acessa o atributo ou método `_atualizarDireitosRoque` pertencente à própria instância atual.
      // `this._atualizarDireitosRoque` = chama o método ou recurso `_atualizarDireitosRoque` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `peca` = identificador que representa uma peça de xadrez.
      // `capturada` = identificador que representa a peça capturada em uma jogada.
      this._atualizarDireitosRoque(movimento, peca, capturada);

      // Armazena ou atualiza o valor de `this.alvoEnPassant` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.alvoEnPassant = null;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `/` = realiza divisão.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `PEAO` = constante que identifica a peça Peão.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `abs` = identificador de propriedade ou método chamado `abs`, acessado a partir do objeto indicado antes do ponto.
      // `dl` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a dl.
      // `ol` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a ol.
      // `oc` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a oc.
      if (peca.tipo === PEAO && Math.abs(dl - ol) === 2) this.alvoEnPassant = [(ol + dl) / 2, oc];

      // Armazena ou atualiza o valor de `this.meioLances` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.meioLances` = acessa o atributo ou método `meioLances` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `houveCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a houveCaptura.
      this.meioLances = (peca.tipo === PEAO || houveCaptura) ? 0 : this.meioLances + 1;

      // Declara `registrado` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `registrado` = identificador utilizado para armazenar ou acessar o valor relacionado a registrado.
      // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `origem` = identificador que representa a casa de origem de um movimento.
      // `destino` = identificador que representa a casa de destino de um movimento.
      const registrado = criarMovimento(movimento.origem, movimento.destino, peca, {

        // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `capturada` = identificador que representa a peça capturada em uma jogada.
        capturada,

        // Define a propriedade `promocao` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
        promocao: movimento.promocao,

        // Define a propriedade `enPassant` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
        enPassant: movimento.enPassant,

        // Define a propriedade `roque` do objeto com o valor informado nesta linha.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
        roque: movimento.roque,

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.historico` = acessa o atributo ou método `historico` pertencente à própria instância atual.
      // `this.historico.push` = chama o método ou recurso `push` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
      // `registrado` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a registrado.
      this.historico.push(registrado);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `this.numeroLance` = acessa o atributo ou método `numeroLance` pertencente à própria instância atual.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
      if (this.turno === PRETO) this.numeroLance += 1;

      // Armazena ou atualiza o valor de `this.turno` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.turno = corOposta(this.turno);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._registrarPosicao` = acessa o atributo ou método `_registrarPosicao` pertencente à própria instância atual.
      // `this._registrarPosicao` = chama o método ou recurso `_registrarPosicao` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `registrarRepeticao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a registrarRepeticao.
      if (registrarRepeticao) this._registrarPosicao();

      // Retorna `registrado` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return registrado;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_atualizarDireitosRoque` para executar a rotina correspondente a atualizarDireitosRoque.
    // `_atualizarDireitosRoque` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    // `peca` = identificador que representa uma peça de xadrez.
    // `capturada` = identificador que representa a peça capturada em uma jogada.
    _atualizarDireitosRoque(movimento, peca, capturada) {

      // Declara `origem` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `origem` = identificador utilizado para armazenar ou acessar o valor relacionado a origem.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const origem = movimento.origem;

      // Declara `destino` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `destino` = identificador utilizado para armazenar ou acessar o valor relacionado a destino.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const destino = movimento.destino;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `REI` = constante que identifica a peça Rei.
      if (peca.tipo === REI) {

        // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `rei` = identificador de propriedade ou método chamado `rei`, acessado a partir do objeto indicado antes do ponto.
        this.direitosRoque[peca.cor].rei = false;

        // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        // `dama` = identificador de propriedade ou método chamado `dama`, acessado a partir do objeto indicado antes do ponto.
        this.direitosRoque[peca.cor].dama = false;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `TORRE` = constante que identifica a peça Torre.
      if (peca.tipo === TORRE) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `origem` = identificador que representa a casa de origem de um movimento.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        if (posIgual(origem, [7, 0])) this.direitosRoque[BRANCO].dama = false;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `rei` = identificador de propriedade ou método chamado `rei`, acessado a partir do objeto indicado antes do ponto.
        else if (posIgual(origem, [7, 7])) this.direitosRoque[BRANCO].rei = false;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
        // `dama` = identificador de propriedade ou método chamado `dama`, acessado a partir do objeto indicado antes do ponto.
        else if (posIgual(origem, [0, 0])) this.direitosRoque[PRETO].dama = false;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `origem` = identificador que representa a casa de origem de um movimento.
        else if (posIgual(origem, [0, 7])) this.direitosRoque[PRETO].rei = false;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `capturada` = identificador que representa a peça capturada em uma jogada.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `TORRE` = constante que identifica a peça Torre.
      if (capturada && capturada.tipo === TORRE) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `destino` = identificador que representa a casa de destino de um movimento.
        // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
        // `dama` = identificador de propriedade ou método chamado `dama`, acessado a partir do objeto indicado antes do ponto.
        if (posIgual(destino, [7, 0])) this.direitosRoque[BRANCO].dama = false;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `rei` = identificador de propriedade ou método chamado `rei`, acessado a partir do objeto indicado antes do ponto.
        else if (posIgual(destino, [7, 7])) this.direitosRoque[BRANCO].rei = false;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
        else if (posIgual(destino, [0, 0])) this.direitosRoque[PRETO].dama = false;

        // Verifica uma condição alternativa quando a condição anterior não foi atendida.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `else` = define o caminho executado quando a condição anterior não é atendida.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
        // `posIgual` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `destino` = identificador que representa a casa de destino de um movimento.
        else if (posIgual(destino, [0, 7])) this.direitosRoque[PRETO].rei = false;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `resultado` para executar a rotina correspondente a resultado.
    // `resultado` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    resultado() {

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `this.movimentosLegais` = acessa o atributo ou método `movimentosLegais` pertencente à própria instância atual.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `this.movimentosLegais` = chama o método ou recurso `movimentosLegais` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const movimentos = this.movimentosLegais(this.turno);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      if (!movimentos.length) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.estaEmXeque` = acessa o atributo ou método `estaEmXeque` pertencente à própria instância atual.
        // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
        // `this.estaEmXeque` = chama o método ou recurso `estaEmXeque` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (this.estaEmXeque(this.turno)) return `vitoria_${corOposta(this.turno)}`;

        // Retorna `'empate_afogamento'` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `'empate_afogamento'` = texto literal utilizado nesta instrução, contendo empate_afogamento.
        // `;` = encerra a instrução JavaScript atual.
        return 'empate_afogamento';

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.materialInsuficiente` = acessa o atributo ou método `materialInsuficiente` pertencente à própria instância atual.
      // `this.materialInsuficiente` = chama o método ou recurso `materialInsuficiente` pertencente à instância atual.
      // `'empate_material'` = texto literal utilizado nesta instrução, contendo empate_material.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (this.materialInsuficiente()) return 'empate_material';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.repeticoes` = acessa o atributo ou método `repeticoes` pertencente à própria instância atual.
      // `this._chavePosicao` = acessa o atributo ou método `_chavePosicao` pertencente à própria instância atual.
      // `this._chavePosicao` = chama o método ou recurso `_chavePosicao` pertencente à instância atual.
      // `'empate_5_repeticoes'` = texto literal utilizado nesta instrução, contendo empate_5_repeticoes.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if ((this.repeticoes[this._chavePosicao()] || 0) >= 5) return 'empate_5_repeticoes';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.meioLances` = acessa o atributo ou método `meioLances` pertencente à própria instância atual.
      // `'empate_75_lances'` = texto literal utilizado nesta instrução, contendo empate_75_lances.
      // `150` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (this.meioLances >= 150) return 'empate_75_lances';

      // Retorna `null` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return null;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `podeReivindicarEmpateRepeticao` para executar a rotina correspondente a podeReivindicarEmpateRepeticao.
    // `podeReivindicarEmpateRepeticao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    podeReivindicarEmpateRepeticao() {

      // Retorna `(this.repeticoes[this._chavePosicao()] || 0) >= 3` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.repeticoes` = acessa o atributo ou método `repeticoes` pertencente à própria instância atual.
      // `this._chavePosicao` = acessa o atributo ou método `_chavePosicao` pertencente à própria instância atual.
      // `this._chavePosicao` = chama o método ou recurso `_chavePosicao` pertencente à instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return (this.repeticoes[this._chavePosicao()] || 0) >= 3;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `podeReivindicarEmpate50Lances` para executar a rotina correspondente a podeReivindicarEmpate50Lances.
    // `podeReivindicarEmpate50Lances` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    podeReivindicarEmpate50Lances() {

      // Retorna `this.meioLances >= 100` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.meioLances` = acessa o atributo ou método `meioLances` pertencente à própria instância atual.
      // `100` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      return this.meioLances >= 100;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `motivosEmpateReivindicavel` para executar a rotina correspondente a motivosEmpateReivindicavel.
    // `motivosEmpateReivindicavel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    motivosEmpateReivindicavel() {

      // Declara `motivos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `motivos` = identificador utilizado para armazenar ou acessar o valor relacionado a motivos.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const motivos = [];

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.podeReivindicarEmpateRepeticao` = acessa o atributo ou método `podeReivindicarEmpateRepeticao` pertencente à própria instância atual.
      // `this.podeReivindicarEmpateRepeticao` = chama o método ou recurso `podeReivindicarEmpateRepeticao` pertencente à instância atual.
      // `motivos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'repetição da mesma posição pelo menos três vezes'` = texto literal utilizado nesta instrução, contendo repetição da mesma posição pelo menos três vezes.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
      if (this.podeReivindicarEmpateRepeticao()) motivos.push('repetição da mesma posição pelo menos três vezes');

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.podeReivindicarEmpate50Lances` = acessa o atributo ou método `podeReivindicarEmpate50Lances` pertencente à própria instância atual.
      // `this.podeReivindicarEmpate50Lances` = chama o método ou recurso `podeReivindicarEmpate50Lances` pertencente à instância atual.
      // `motivos.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'regra dos 50 lances sem movimento de peão ou captura'` = texto literal utilizado nesta instrução, contendo regra dos 50 lances sem movimento de peão ou captura.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (this.podeReivindicarEmpate50Lances()) motivos.push('regra dos 50 lances sem movimento de peão ou captura');

      // Retorna `motivos` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return motivos;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `materialInsuficiente` para executar a rotina correspondente a materialInsuficiente.
    // `materialInsuficiente` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    materialInsuficiente() {

      // Declara `pecas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `pecas` = identificador utilizado para armazenar ou acessar o valor relacionado a pecas.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      const pecas = [];

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `pecas.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `peca` = identificador que representa uma peça de xadrez.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `REI` = constante que identifica a peça Rei.
      // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
      for (const linha of this.tabuleiro) for (const peca of linha) if (peca && peca.tipo !== REI) pecas.push(peca);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      if (!pecas.length) return true;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `pecas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pecas.
      // `BISPO` = constante que identifica a peça Bispo.
      // `CAVALO` = constante que identifica a peça Cavalo.
      if (pecas.length === 1 && (pecas[0].tipo === BISPO || pecas[0].tipo === CAVALO)) return true;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `pecas.every` = chama a função ou método `every` pertencente ao objeto ou recurso indicado antes do ponto.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `every` = identificador de propriedade ou método chamado `every`, acessado a partir do objeto indicado antes do ponto.
      // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
      if (pecas.length === 2 && pecas.every((p) => p.tipo === BISPO)) {

        // Declara `coresCasas` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `coresCasas` = identificador utilizado para armazenar ou acessar o valor relacionado a coresCasas.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        const coresCasas = [];

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `8` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `l` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a l.
        // `c` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a c.
        for (let l = 0; l < 8; l += 1) for (let c = 0; c < 8; c += 1) {

          // Declara `p` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `p` = identificador utilizado para armazenar ou acessar o valor relacionado a p.
          // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const p = this.tabuleiro[l][c];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `coresCasas.push` = chama a função ou método `push` pertencente ao objeto ou recurso indicado antes do ponto.
          // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `%` = calcula o resto de uma divisão inteira.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `BISPO` = constante que identifica a peça Bispo.
          // `push` = identificador de propriedade ou método chamado `push`, acessado a partir do objeto indicado antes do ponto.
          if (p && p.tipo === BISPO) coresCasas.push((l + c) % 2);

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Retorna `coresCasas.length === 2 && coresCasas[0] === coresCasas[1]` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `coresCasas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a coresCasas.
        // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
        return coresCasas.length === 2 && coresCasas[0] === coresCasas[1];

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `false` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return false;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_chavePosicao` para executar a rotina correspondente a chavePosicao.
    // `_chavePosicao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _chavePosicao() {

      // Declara `mapa` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `mapa` = identificador utilizado para armazenar ou acessar o valor relacionado a mapa.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      const mapa = {

        // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
        // `'K'` = texto literal utilizado nesta instrução, contendo K.
        // `'Q'` = texto literal utilizado nesta instrução, contendo Q.
        // `'R'` = texto literal utilizado nesta instrução, contendo R.
        // `'B'` = texto literal utilizado nesta instrução, contendo B.
        // `'N'` = texto literal utilizado nesta instrução, contendo N.
        // `'P'` = texto literal utilizado nesta instrução, contendo P.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        [`${BRANCO}_${REI}`]: 'K', [`${BRANCO}_${DAMA}`]: 'Q', [`${BRANCO}_${TORRE}`]: 'R', [`${BRANCO}_${BISPO}`]: 'B', [`${BRANCO}_${CAVALO}`]: 'N', [`${BRANCO}_${PEAO}`]: 'P',

        // Define uma propriedade calculada do objeto usando a chave indicada entre colchetes.
        // `'k'` = texto literal utilizado nesta instrução, contendo k.
        // `'q'` = texto literal utilizado nesta instrução, contendo q.
        // `'r'` = texto literal utilizado nesta instrução, contendo r.
        // `'b'` = texto literal utilizado nesta instrução, contendo b.
        // `'n'` = texto literal utilizado nesta instrução, contendo n.
        // `'p'` = texto literal utilizado nesta instrução, contendo p.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        [`${PRETO}_${REI}`]: 'k', [`${PRETO}_${DAMA}`]: 'q', [`${PRETO}_${TORRE}`]: 'r', [`${PRETO}_${BISPO}`]: 'b', [`${PRETO}_${CAVALO}`]: 'n', [`${PRETO}_${PEAO}`]: 'p',

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      };

      // Declara `casas` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `casas` = identificador utilizado para armazenar ou acessar o valor relacionado a casas.
      // `''` = texto literal utilizado nesta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let casas = '';

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
      // `'.'` = texto literal utilizado nesta instrução, contendo ..
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `peca` = identificador que representa uma peça de xadrez.
      // `mapa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a mapa.
      for (const linha of this.tabuleiro) for (const peca of linha) casas += peca ? mapa[`${peca.cor}_${peca.tipo}`] : '.';

      // Declara `r` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `r` = identificador utilizado para armazenar ou acessar o valor relacionado a r.
      // `this.direitosRoque` = acessa o atributo ou método `direitosRoque` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const r = this.direitosRoque;

      // Declara `roque` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `roque` = identificador utilizado para armazenar ou acessar o valor relacionado a roque.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const roque = `${Number(r[BRANCO].rei)}${Number(r[BRANCO].dama)}${Number(r[PRETO].rei)}${Number(r[PRETO].dama)}`;

      // Declara `ep` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `ep` = identificador utilizado para armazenar ou acessar o valor relacionado a ep.
      // `'-'` = texto literal utilizado nesta instrução, contendo -.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let ep = '-';

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `this._enPassantLegalDisponivel` = acessa o atributo ou método `_enPassantLegalDisponivel` pertencente à própria instância atual.
      // `this._enPassantLegalDisponivel` = chama o método ou recurso `_enPassantLegalDisponivel` pertencente à instância atual.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (this.alvoEnPassant && this._enPassantLegalDisponivel()) ep = `${this.alvoEnPassant[0]}${this.alvoEnPassant[1]}`;

      // Retorna ``${casas}|${this.turno}|${roque}|${ep}`` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return `${casas}|${this.turno}|${roque}|${ep}`;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_enPassantLegalDisponivel` para executar a rotina correspondente a enPassantLegalDisponivel.
    // `_enPassantLegalDisponivel` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _enPassantLegalDisponivel() {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      if (!this.alvoEnPassant) return false;

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `alvoLinha` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alvoLinha.
      // `alvoColuna` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alvoColuna.
      const [alvoLinha, alvoColuna] = this.alvoEnPassant;

      // Declara `direcao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `direcao` = identificador utilizado para armazenar ou acessar o valor relacionado a direcao.
      // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
      // `-1` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      const direcao = this.turno === BRANCO ? -1 : 1;

      // Declara `origemLinha` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `origemLinha` = identificador utilizado para armazenar ou acessar o valor relacionado a origemLinha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      const origemLinha = alvoLinha - direcao;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `origemColuna` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a origemColuna.
      for (const origemColuna of [alvoColuna - 1, alvoColuna + 1]) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.dentro` = acessa o atributo ou método `dentro` pertencente à própria instância atual.
        // `this.dentro` = chama o método ou recurso `dentro` pertencente à instância atual.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (!this.dentro(origemLinha, origemColuna)) continue;

        // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const peca = this.tabuleiro[origemLinha][origemColuna];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        // `PEAO` = constante que identifica a peça Peão.
        if (!peca || peca.cor !== this.turno || peca.tipo !== PEAO) continue;

        // Declara `capturada` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `capturada` = identificador utilizado para armazenar ou acessar o valor relacionado a capturada.
        // `this.tabuleiro` = acessa o atributo ou método `tabuleiro` pertencente à própria instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `origemLinha` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a origemLinha.
        // `alvoColuna` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alvoColuna.
        const capturada = this.tabuleiro[origemLinha][alvoColuna];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (!capturada || capturada.cor === this.turno || capturada.tipo !== PEAO) continue;

        // Declara `movimento` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `movimento` = identificador utilizado para armazenar ou acessar o valor relacionado a movimento.
        // `this.alvoEnPassant` = acessa o atributo ou método `alvoEnPassant` pertencente à própria instância atual.
        // `criarMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `origemColuna` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a origemColuna.
        // `peca` = identificador que representa uma peça de xadrez.
        // `enPassant` = identificador usado como nome da propriedade `enPassant` dentro do objeto atual.
        const movimento = criarMovimento([origemLinha, origemColuna], this.alvoEnPassant, peca, { capturada, enPassant: true });

        // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
        // `this.clonar` = acessa o atributo ou método `clonar` pertencente à própria instância atual.
        // `this.clonar` = chama o método ou recurso `clonar` pertencente à instância atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const copia = this.clonar();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `copia._aplicarSemValidar` = chama a função ou método `_aplicarSemValidar` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `_aplicarSemValidar` = identificador de propriedade ou método chamado `_aplicarSemValidar`, acessado a partir do objeto indicado antes do ponto.
        copia._aplicarSemValidar(movimento, false);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.turno` = acessa o atributo ou método `turno` pertencente à própria instância atual.
        // `copia.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
        // `!` = realiza negação lógica do valor ou condição indicada.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
        if (!copia.estaEmXeque(this.turno)) return true;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `false` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return false;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_registrarPosicao` para executar a rotina correspondente a registrarPosicao.
    // `_registrarPosicao` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _registrarPosicao() {

      // Declara `chave` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `chave` = identificador utilizado para armazenar ou acessar o valor relacionado a chave.
      // `this._chavePosicao` = acessa o atributo ou método `_chavePosicao` pertencente à própria instância atual.
      // `this._chavePosicao` = chama o método ou recurso `_chavePosicao` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const chave = this._chavePosicao();

      // Executa a instrução desta linha como parte da lógica e do fluxo do Jogo de Xadrez.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.repeticoes` = acessa o atributo ou método `repeticoes` pertencente à própria instância atual.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.repeticoes[chave] = (this.repeticoes[chave] || 0) + 1;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Define a função `notacaoSimples` para executar a rotina correspondente a notacaoSimples.
  // `function` = define uma nova função para agrupar uma rotina reutilizável.
  // `notacaoSimples` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `notacaoSimples` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
  function notacaoSimples(movimento) {

    // Declara `letras` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `letras` = identificador utilizado para armazenar ou acessar o valor relacionado a letras.
    // `'abcdefgh'` = texto literal utilizado nesta instrução, contendo abcdefgh.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    const letras = 'abcdefgh';

    // Declara `origem` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `origem` = identificador utilizado para armazenar ou acessar o valor relacionado a origem.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    const origem = `${letras[movimento.origem[1]]}${8 - movimento.origem[0]}`;

    // Declara `destino` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `destino` = identificador utilizado para armazenar ou acessar o valor relacionado a destino.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    const destino = `${letras[movimento.destino[1]]}${8 - movimento.destino[0]}`;

    // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
    // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `'O-O'` = texto literal utilizado nesta instrução, contendo O-O.
    // `'O-O-O'` = texto literal utilizado nesta instrução, contendo O-O-O.
    // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
    // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
    // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
    if (movimento.roque) return movimento.destino[1] === 6 ? 'O-O' : 'O-O-O';

    // Declara `mapa` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `mapa` = identificador utilizado para armazenar ou acessar o valor relacionado a mapa.
    // `'D'` = texto literal utilizado nesta instrução, contendo D.
    // `'T'` = texto literal utilizado nesta instrução, contendo T.
    // `'B'` = texto literal utilizado nesta instrução, contendo B.
    // `'C'` = texto literal utilizado nesta instrução, contendo C.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
    // `]` = fecha a lista, o acesso por índice ou a chave calculada.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `DAMA` = constante que identifica a peça Dama.
    // `TORRE` = constante que identifica a peça Torre.
    // `BISPO` = constante que identifica a peça Bispo.
    // `CAVALO` = constante que identifica a peça Cavalo.
    const mapa = { [DAMA]: 'D', [TORRE]: 'T', [BISPO]: 'B', [CAVALO]: 'C' };

    // Declara `sufixo` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `sufixo` = identificador utilizado para armazenar ou acessar o valor relacionado a sufixo.
    // `'D'` = texto literal utilizado nesta instrução, contendo D.
    // `''` = texto literal utilizado nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
    const sufixo = movimento.promocao ? `=${mapa[movimento.promocao] || 'D'}` : '';

    // Declara `separador` e armazena nele o valor ou resultado definido nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `separador` = identificador utilizado para armazenar ou acessar o valor relacionado a separador.
    // `'x'` = texto literal utilizado nesta instrução, contendo x.
    // `'-'` = texto literal utilizado nesta instrução, contendo -.
    // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
    // `;` = encerra a instrução JavaScript atual.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `capturada` = identificador que representa a peça capturada em uma jogada.
    // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
    const separador = movimento.capturada || movimento.enPassant ? 'x' : '-';

    // Retorna ``${origem}${separador}${destino}${sufixo}`` para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
    // `;` = encerra a instrução JavaScript atual.
    return `${origem}${separador}${destino}${sufixo}`;

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Armazena ou atualiza o valor de `global.XadrezMotor` utilizando o resultado definido nesta linha.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `global` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a global.
  // `XadrezMotor` = identificador de propriedade ou método chamado `XadrezMotor`, acessado a partir do objeto indicado antes do ponto.
  global.XadrezMotor = {

    // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
    // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
    // `REI` = constante que identifica a peça Rei.
    // `DAMA` = constante que identifica a peça Dama.
    // `TORRE` = constante que identifica a peça Torre.
    // `PEAO` = constante que identifica a peça Peão.
    BRANCO, PRETO, REI, DAMA, TORRE, BISPO, CAVALO, PEAO,

    // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `TIPOS_PROMOCAO` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a TIPOS PROMOCAO.
    // `VALORES` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a VALORES.
    // `corOposta` = função que obtém a cor adversária em relação à cor informada.
    // `criarPeca` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a criarPeca.
    // `criarMovimento` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a criarMovimento.
    // `posIgual` = função que verifica se duas posições do tabuleiro representam a mesma casa.
    TIPOS_PROMOCAO, VALORES, corOposta, criarPeca, criarMovimento, posIgual,

    // Adiciona ou configura este elemento na estrutura iniciada nas linhas anteriores.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `EstadoXadrez` = classe responsável por representar e controlar o estado completo de uma partida de xadrez.
    // `notacaoSimples` = função que transforma um movimento em uma notação textual simples para exibição.
    EstadoXadrez, notacaoSimples,

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  };

  // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
  // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
  // `typeof` = obtém o tipo do valor ou expressão indicada.
  // `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
  // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
  // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `module` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a module.
  // `exports` = identificador de propriedade ou método chamado `exports`, acessado a partir do objeto indicado antes do ponto.
  if (typeof module !== 'undefined' && module.exports) module.exports = global.XadrezMotor;

// Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
// `typeof` = obtém o tipo do valor ou expressão indicada.
// `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
// `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
// `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
// `;` = encerra a instrução JavaScript atual.
// `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
// `globalThis` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a globalThis.
})(typeof window !== 'undefined' ? window : globalThis);
