// Cria e executa uma função isolada para manter as variáveis do jogo protegidas no próprio escopo.
// `function` = define uma nova função para agrupar uma rotina reutilizável.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
// `global` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a global.
(function (global) {

  // Ativa o modo estrito do JavaScript para tornar a execução mais segura e impedir determinados usos ambíguos da linguagem.
  // `'use strict'` = texto literal utilizado nesta instrução, contendo use strict.
  // `;` = encerra a instrução JavaScript atual.
  'use strict';

  // Declara `M` e armazena nele o valor ou resultado definido nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `typeof` = obtém o tipo do valor ou expressão indicada.
  // `M` = identificador utilizado para armazenar ou acessar o valor relacionado a M.
  // `require` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
  // `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
  // `'./motor.js'` = texto literal utilizado nesta instrução, contendo ./motor.js.
  // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
  // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `XadrezMotor` = identificador de propriedade ou método chamado `XadrezMotor`, acessado a partir do objeto indicado antes do ponto.
  const M = global.XadrezMotor || (typeof require !== 'undefined' ? require('./motor.js') : null);

  // Declara constantes por desestruturação, extraindo propriedades do objeto indicado para identificadores individuais.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
  // `PRETO` = constante que identifica a cor preta e o conjunto de peças pretas no jogo.
  // `REI` = constante que identifica a peça Rei.
  // `DAMA` = constante que identifica a peça Dama.
  // `TORRE` = constante que identifica a peça Torre.
  // `BISPO` = constante que identifica a peça Bispo.
  // `CAVALO` = constante que identifica a peça Cavalo.
  // `PEAO` = constante que identifica a peça Peão.
  // `VALORES` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a VALORES.
  // `corOposta` = função que obtém a cor adversária em relação à cor informada.
  const { BRANCO, PRETO, REI, DAMA, TORRE, BISPO, CAVALO, PEAO, VALORES, corOposta } = M;

  // Define a classe `InteligenciaXadrez`, responsável por agrupar dados e comportamentos relacionados a esta parte do jogo.
  // `class` = define uma classe utilizada para criar objetos com dados e comportamentos relacionados.
  // `InteligenciaXadrez` = nome atribuído à rotina ou estrutura definida nesta linha.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  class InteligenciaXadrez {

    // Define o método construtor responsável por inicializar os dados e estados da nova instância da classe.
    // `constructor` = define o método construtor executado automaticamente ao criar uma instância da classe.
    // `'intermediario'` = texto literal utilizado nesta instrução, contendo intermediario.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `nivel` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a nivel.
    constructor(nivel = 'intermediario') {

      // Armazena ou atualiza o valor de `this.nivel` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.nivel` = acessa o atributo ou método `nivel` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.nivel = nivel;

      // Armazena ou atualiza o valor de `this.cancelar` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.cancelar` = acessa o atributo ou método `cancelar` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.cancelar = false;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `escolherMovimento` para executar a rotina correspondente a escolherMovimento.
    // `escolherMovimento` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    escolherMovimento(estado, cor = estado.turno) {

      // Armazena ou atualiza o valor de `this.cancelar` utilizando o resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.cancelar` = acessa o atributo ou método `cancelar` pertencente à própria instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      this.cancelar = false;

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `estado.movimentosLegais` = chama a função ou método `movimentosLegais` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentosLegais` = identificador de propriedade ou método chamado `movimentosLegais`, acessado a partir do objeto indicado antes do ponto.
      let movimentos = estado.movimentosLegais(cor);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      if (!movimentos.length) return null;

      // Declara `nivel` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `nivel` = identificador utilizado para armazenar ou acessar o valor relacionado a nivel.
      // `this.nivel` = acessa o atributo ou método `nivel` pertencente à própria instância atual.
      // `'intermediario'` = texto literal utilizado nesta instrução, contendo intermediario.
      // `'avancado'` = texto literal utilizado nesta instrução, contendo avancado.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `medio` = identificador usado como nome da propriedade `medio` dentro do objeto atual.
      // `dificil` = identificador usado como nome da propriedade `dificil` dentro do objeto atual.
      const nivel = ({ medio: 'intermediario', dificil: 'avancado' })[this.nivel] || this.nivel;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._escolherFacil` = acessa o atributo ou método `_escolherFacil` pertencente à própria instância atual.
      // `this._escolherFacil` = chama o método ou recurso `_escolherFacil` pertencente à instância atual.
      // `'facil'` = texto literal utilizado nesta instrução, contendo facil.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
      if (nivel === 'facil') return this._escolherFacil(estado, movimentos, cor);

      // Declara `profundidade` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `profundidade` = identificador utilizado para armazenar ou acessar o valor relacionado a profundidade.
      // `'intermediario'` = texto literal utilizado nesta instrução, contendo intermediario.
      // `2` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `3` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      const profundidade = nivel === 'intermediario' ? 2 : 3;

      // Armazena ou atualiza em `movimentos` o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._ordenarMovimentos` = acessa o atributo ou método `_ordenarMovimentos` pertencente à própria instância atual.
      // `this._ordenarMovimentos` = chama o método ou recurso `_ordenarMovimentos` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      movimentos = this._ordenarMovimentos(movimentos);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `movimentos.slice` = chama a função ou método `slice` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'avancado'` = texto literal utilizado nesta instrução, contendo avancado.
      // `0` = indica que a operação deve começar no primeiro elemento da coleção.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `nivel` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a nivel.
      // `slice` = identificador de propriedade ou método chamado `slice`, acessado a partir do objeto indicado antes do ponto.
      if (nivel === 'avancado') movimentos = movimentos.slice(0, 14);

      // Declara `melhor` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `melhor` = identificador utilizado para armazenar ou acessar o valor relacionado a melhor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let melhor = null;

      // Declara `melhorValor` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `melhorValor` = identificador utilizado para armazenar ou acessar o valor relacionado a melhorValor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      // `Infinity` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a Infinity.
      let melhorValor = -Infinity;

      // Declara `alfa` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `alfa` = identificador utilizado para armazenar ou acessar o valor relacionado a alfa.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      let alfa = -Infinity;

      // Declara `beta` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `beta` = identificador utilizado para armazenar ou acessar o valor relacionado a beta.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const beta = Infinity;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      for (const movimento of movimentos) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `break` = interrompe a estrutura de repetição ou seleção atual.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.cancelar` = acessa o atributo ou método `cancelar` pertencente à própria instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        if (this.cancelar) break;

        // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
        // `estado.clonar` = chama a função ou método `clonar` pertencente ao objeto ou recurso indicado antes do ponto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estado` = identificador que representa o estado atual da partida de xadrez.
        // `clonar` = identificador de propriedade ou método chamado `clonar`, acessado a partir do objeto indicado antes do ponto.
        const copia = estado.clonar();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `copia._aplicarSemValidar` = chama a função ou método `_aplicarSemValidar` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `_aplicarSemValidar` = identificador de propriedade ou método chamado `_aplicarSemValidar`, acessado a partir do objeto indicado antes do ponto.
        copia._aplicarSemValidar(movimento, false);

        // Declara `valor` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `valor` = identificador utilizado para armazenar ou acessar o valor relacionado a valor.
        // `this._minimax` = acessa o atributo ou método `_minimax` pertencente à própria instância atual.
        // `this._minimax` = chama o método ou recurso `_minimax` pertencente à instância atual.
        // `1` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
        // `alfa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alfa.
        // `beta` = valor utilizado como limite beta no algoritmo Alpha-Beta da Inteligência Artificial.
        // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
        let valor = this._minimax(copia, profundidade - 1, alfa, beta, false, cor);

        // Armazena ou atualiza em `valor` o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this._ajusteAntiCiclo` = acessa o atributo ou método `_ajusteAntiCiclo` pertencente à própria instância atual.
        // `this._ajusteAntiCiclo` = chama o método ou recurso `_ajusteAntiCiclo` pertencente à instância atual.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
        valor += this._ajusteAntiCiclo(estado, movimento, cor);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `>` = verifica se o valor da esquerda é maior que o valor da direita.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `melhor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a melhor.
        // `melhorValor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a melhorValor.
        if (melhor === null || valor > melhorValor) {

          // Armazena ou atualiza em `melhorValor` o valor ou resultado definido nesta linha.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          melhorValor = valor;

          // Armazena ou atualiza em `melhor` o valor ou resultado definido nesta linha.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `;` = encerra a instrução JavaScript atual.
          melhor = movimento;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Armazena ou atualiza em `alfa` o valor ou resultado definido nesta linha.
        // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `alfa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alfa.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
        alfa = Math.max(alfa, melhorValor);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `melhor || movimentos[0]` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      return melhor || movimentos[0];

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_escolherFacil` para executar a rotina correspondente a escolherFacil.
    // `_escolherFacil` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    _escolherFacil(estado, movimentos, cor) {

      // Declara `capturas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `capturas` = identificador utilizado para armazenar ou acessar o valor relacionado a capturas.
      // `movimentos.filter` = chama a função ou método `filter` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `capturada` = identificador que representa a peça capturada em uma jogada.
      // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
      const capturas = movimentos.filter((m) => m.capturada || m.enPassant);

      // Declara `promocoes` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `promocoes` = identificador utilizado para armazenar ou acessar o valor relacionado a promocoes.
      // `movimentos.filter` = chama a função ou método `filter` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
      const promocoes = movimentos.filter((m) => m.promocao);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `Math.random` = chama a função ou método `random` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.floor` = chama a função ou método `floor` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.85` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `random` = identificador de propriedade ou método chamado `random`, acessado a partir do objeto indicado antes do ponto.
      // `floor` = identificador de propriedade ou método chamado `floor`, acessado a partir do objeto indicado antes do ponto.
      if (promocoes.length && Math.random() < 0.85) return promocoes[Math.floor(Math.random() * promocoes.length)];

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `Math.random` = chama a função ou método `random` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0.65` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `capturas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a capturas.
      if (capturas.length && Math.random() < 0.65) {

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `capturas.sort` = chama a função ou método `sort` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `sort` = identificador de propriedade ou método chamado `sort`, acessado a partir do objeto indicado antes do ponto.
        // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
        // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
        // `capturada` = identificador que representa a peça capturada em uma jogada.
        // `VALORES` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a VALORES.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        capturas.sort((a, b) => (b.capturada ? VALORES[b.capturada.tipo] : 0) - (a.capturada ? VALORES[a.capturada.tipo] : 0));

        // Declara `melhores` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `melhores` = identificador utilizado para armazenar ou acessar o valor relacionado a melhores.
        // `capturas.slice` = chama a função ou método `slice` pertencente ao objeto ou recurso indicado antes do ponto.
        // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
        // `0` = indica que a operação deve começar no primeiro elemento da coleção.
        // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `slice` = identificador de propriedade ou método chamado `slice`, acessado a partir do objeto indicado antes do ponto.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
        // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
        const melhores = capturas.slice(0, Math.min(3, capturas.length));

        // Retorna `melhores[Math.floor(Math.random() * melhores.length)]` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `Math.floor` = chama a função ou método `floor` pertencente ao objeto ou recurso indicado antes do ponto.
        // `Math.random` = chama a função ou método `random` pertencente ao objeto ou recurso indicado antes do ponto.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `floor` = identificador de propriedade ou método chamado `floor`, acessado a partir do objeto indicado antes do ponto.
        // `random` = identificador de propriedade ou método chamado `random`, acessado a partir do objeto indicado antes do ponto.
        return melhores[Math.floor(Math.random() * melhores.length)];

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Declara `candidatos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `candidatos` = identificador utilizado para armazenar ou acessar o valor relacionado a candidatos.
      // `this._ajusteAntiCiclo` = acessa o atributo ou método `_ajusteAntiCiclo` pertencente à própria instância atual.
      // `movimentos.filter` = chama a função ou método `filter` pertencente ao objeto ou recurso indicado antes do ponto.
      // `this._ajusteAntiCiclo` = chama o método ou recurso `_ajusteAntiCiclo` pertencente à instância atual.
      // `160` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `>` = verifica se o valor da esquerda é maior que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      // `filter` = identificador de propriedade ou método chamado `filter`, acessado a partir do objeto indicado antes do ponto.
      // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
      // `-160` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      const candidatos = movimentos.filter((m) => this._ajusteAntiCiclo(estado, m, cor) > -160);

      // Declara `lista` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `lista` = identificador utilizado para armazenar ou acessar o valor relacionado a lista.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      const lista = candidatos.length ? candidatos : movimentos;

      // Retorna `lista[Math.floor(Math.random() * lista.length)]` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `Math.floor` = chama a função ou método `floor` pertencente ao objeto ou recurso indicado antes do ponto.
      // `Math.random` = chama a função ou método `random` pertencente ao objeto ou recurso indicado antes do ponto.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `floor` = identificador de propriedade ou método chamado `floor`, acessado a partir do objeto indicado antes do ponto.
      // `random` = identificador de propriedade ou método chamado `random`, acessado a partir do objeto indicado antes do ponto.
      return lista[Math.floor(Math.random() * lista.length)];

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_minimax` para executar a rotina correspondente a minimax.
    // `_minimax` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
    // `alfa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alfa.
    // `beta` = valor utilizado como limite beta no algoritmo Alpha-Beta da Inteligência Artificial.
    // `maximizando` = indicador que informa se o nível atual da busca procura maximizar a avaliação da posição.
    // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
    _minimax(estado, profundidade, alfa, beta, maximizando, corIA) {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.cancelar` = acessa o atributo ou método `cancelar` pertencente à própria instância atual.
      // `this.avaliar` = acessa o atributo ou método `avaliar` pertencente à própria instância atual.
      // `this.avaliar` = chama o método ou recurso `avaliar` pertencente à instância atual.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      if (this.cancelar) return this.avaliar(estado, corIA);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `0` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      if (profundidade <= 0) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
        // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
        if (estado.estaEmXeque(estado.turno)) {

          // Declara `respostas` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `respostas` = identificador utilizado para armazenar ou acessar o valor relacionado a respostas.
          // `estado.movimentosLegais` = chama a função ou método `movimentosLegais` pertencente ao objeto ou recurso indicado antes do ponto.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `movimentosLegais` = identificador de propriedade ou método chamado `movimentosLegais`, acessado a partir do objeto indicado antes do ponto.
          const respostas = estado.movimentosLegais(estado.turno);

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `1000000` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
          // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
          // `-1000000` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
          if (!respostas.length) return corOposta(estado.turno) === corIA ? 1000000 : -1000000;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Retorna `this.avaliar(estado, corIA)` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `this.avaliar` = acessa o atributo ou método `avaliar` pertencente à própria instância atual.
        // `this.avaliar` = chama o método ou recurso `avaliar` pertencente à instância atual.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estado` = identificador que representa o estado atual da partida de xadrez.
        return this.avaliar(estado, corIA);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `estado._chavePosicao` = chama a função ou método `_chavePosicao` pertencente ao objeto ou recurso indicado antes do ponto.
      // `estado.materialInsuficiente` = chama a função ou método `materialInsuficiente` pertencente ao objeto ou recurso indicado antes do ponto.
      // `150` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `meioLances` = identificador de propriedade ou método chamado `meioLances`, acessado a partir do objeto indicado antes do ponto.
      // `repeticoes` = identificador de propriedade ou método chamado `repeticoes`, acessado a partir do objeto indicado antes do ponto.
      // `_chavePosicao` = identificador de propriedade ou método chamado `_chavePosicao`, acessado a partir do objeto indicado antes do ponto.
      // `materialInsuficiente` = identificador de propriedade ou método chamado `materialInsuficiente`, acessado a partir do objeto indicado antes do ponto.
      if (estado.meioLances >= 150 || (estado.repeticoes[estado._chavePosicao()] || 0) >= 5 || estado.materialInsuficiente()) return 0;

      // Declara `movimentos` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `movimentos` = identificador utilizado para armazenar ou acessar o valor relacionado a movimentos.
      // `estado.movimentosLegais` = chama a função ou método `movimentosLegais` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentosLegais` = identificador de propriedade ou método chamado `movimentosLegais`, acessado a partir do objeto indicado antes do ponto.
      // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
      let movimentos = estado.movimentosLegais(estado.turno);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      if (!movimentos.length) {

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estado` = identificador que representa o estado atual da partida de xadrez.
        // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
        if (estado.estaEmXeque(estado.turno)) {

          // Declara `vencedor` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `vencedor` = identificador utilizado para armazenar ou acessar o valor relacionado a vencedor.
          // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const vencedor = corOposta(estado.turno);

          // Retorna `vencedor === corIA ? 1000000 + profundidade : -1000000 - profundidade` para o ponto do programa que chamou a rotina atual.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `1000000` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
          // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
          // `-1000000` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
          return vencedor === corIA ? 1000000 + profundidade : -1000000 - profundidade;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Retorna `0` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `;` = encerra a instrução JavaScript atual.
        return 0;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Armazena ou atualiza em `movimentos` o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._ordenarMovimentos` = acessa o atributo ou método `_ordenarMovimentos` pertencente à própria instância atual.
      // `this._ordenarMovimentos` = chama o método ou recurso `_ordenarMovimentos` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      movimentos = this._ordenarMovimentos(movimentos);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this.nivel` = acessa o atributo ou método `nivel` pertencente à própria instância atual.
      // `movimentos.slice` = chama a função ou método `slice` pertencente ao objeto ou recurso indicado antes do ponto.
      // `'avancado'` = texto literal utilizado nesta instrução, contendo avancado.
      // `'dificil'` = texto literal utilizado nesta instrução, contendo dificil.
      // `1` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `0` = indica que a operação deve começar no primeiro elemento da coleção.
      // `14` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `slice` = identificador de propriedade ou método chamado `slice`, acessado a partir do objeto indicado antes do ponto.
      if ((this.nivel === 'avancado' || this.nivel === 'dificil') && profundidade >= 1) movimentos = movimentos.slice(0, 14);

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `maximizando` = indicador que informa se o nível atual da busca procura maximizar a avaliação da posição.
      if (maximizando) {

        // Declara `melhor` e armazena nele o valor ou resultado definido nesta linha.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `melhor` = identificador utilizado para armazenar ou acessar o valor relacionado a melhor.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `;` = encerra a instrução JavaScript atual.
        // `Infinity` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a Infinity.
        let melhor = -Infinity;

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `of` = indica os valores percorridos em uma estrutura for...of.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
        for (const movimento of movimentos) {

          // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
          // `estado.clonar` = chama a função ou método `clonar` pertencente ao objeto ou recurso indicado antes do ponto.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `estado` = identificador que representa o estado atual da partida de xadrez.
          // `clonar` = identificador de propriedade ou método chamado `clonar`, acessado a partir do objeto indicado antes do ponto.
          const copia = estado.clonar();

          // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
          // `copia._aplicarSemValidar` = chama a função ou método `_aplicarSemValidar` pertencente ao objeto ou recurso indicado antes do ponto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `_aplicarSemValidar` = identificador de propriedade ou método chamado `_aplicarSemValidar`, acessado a partir do objeto indicado antes do ponto.
          copia._aplicarSemValidar(movimento, false);

          // Declara `valor` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `valor` = identificador utilizado para armazenar ou acessar o valor relacionado a valor.
          // `this._minimax` = acessa o atributo ou método `_minimax` pertencente à própria instância atual.
          // `this._minimax` = chama o método ou recurso `_minimax` pertencente à instância atual.
          // `1` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
          // `alfa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alfa.
          // `beta` = valor utilizado como limite beta no algoritmo Alpha-Beta da Inteligência Artificial.
          // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
          const valor = this._minimax(copia, profundidade - 1, alfa, beta, false, corIA);

          // Armazena ou atualiza em `melhor` o valor ou resultado definido nesta linha.
          // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `melhor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a melhor.
          // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
          // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
          melhor = Math.max(melhor, valor);

          // Armazena ou atualiza em `alfa` o valor ou resultado definido nesta linha.
          // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          alfa = Math.max(alfa, melhor);

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `break` = interrompe a estrutura de repetição ou seleção atual.
          // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          if (beta <= alfa) break;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

        // Retorna `melhor` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `;` = encerra a instrução JavaScript atual.
        return melhor;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Declara `melhor` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `melhor` = identificador utilizado para armazenar ou acessar o valor relacionado a melhor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      // `Infinity` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a Infinity.
      let melhor = Infinity;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
      for (const movimento of movimentos) {

        // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
        // `estado.clonar` = chama a função ou método `clonar` pertencente ao objeto ou recurso indicado antes do ponto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `estado` = identificador que representa o estado atual da partida de xadrez.
        // `clonar` = identificador de propriedade ou método chamado `clonar`, acessado a partir do objeto indicado antes do ponto.
        const copia = estado.clonar();

        // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
        // `copia._aplicarSemValidar` = chama a função ou método `_aplicarSemValidar` pertencente ao objeto ou recurso indicado antes do ponto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `_aplicarSemValidar` = identificador de propriedade ou método chamado `_aplicarSemValidar`, acessado a partir do objeto indicado antes do ponto.
        copia._aplicarSemValidar(movimento, false);

        // Declara `valor` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância atual da classe ou objeto.
        // `valor` = identificador utilizado para armazenar ou acessar o valor relacionado a valor.
        // `this._minimax` = acessa o atributo ou método `_minimax` pertencente à própria instância atual.
        // `this._minimax` = chama o método ou recurso `_minimax` pertencente à instância atual.
        // `1` = define ou participa da profundidade de análise utilizada pela Inteligência Artificial.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `profundidade` = valor que indica quantos níveis de jogadas futuras a Inteligência Artificial deve analisar.
        // `alfa` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a alfa.
        // `beta` = valor utilizado como limite beta no algoritmo Alpha-Beta da Inteligência Artificial.
        // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
        const valor = this._minimax(copia, profundidade - 1, alfa, beta, true, corIA);

        // Armazena ou atualiza em `melhor` o valor ou resultado definido nesta linha.
        // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `melhor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a melhor.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `min` = identificador de propriedade ou método chamado `min`, acessado a partir do objeto indicado antes do ponto.
        melhor = Math.min(melhor, valor);

        // Armazena ou atualiza em `beta` o valor ou resultado definido nesta linha.
        // `Math.min` = chama a função ou método `min` pertencente ao objeto ou recurso indicado antes do ponto.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        beta = Math.min(beta, melhor);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `break` = interrompe a estrutura de repetição ou seleção atual.
        // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        if (beta <= alfa) break;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `melhor` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return melhor;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `deveReivindicarEmpate` para executar a rotina correspondente a deveReivindicarEmpate.
    // `deveReivindicarEmpate` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    // `turno` = identificador de propriedade ou método chamado `turno`, acessado a partir do objeto indicado antes do ponto.
    deveReivindicarEmpate(estado, cor = estado.turno) {

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `estado.podeReivindicarEmpateRepeticao` = chama a função ou método `podeReivindicarEmpateRepeticao` pertencente ao objeto ou recurso indicado antes do ponto.
      // `estado.podeReivindicarEmpate50Lances` = chama a função ou método `podeReivindicarEmpate50Lances` pertencente ao objeto ou recurso indicado antes do ponto.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `podeReivindicarEmpateRepeticao` = identificador de propriedade ou método chamado `podeReivindicarEmpateRepeticao`, acessado a partir do objeto indicado antes do ponto.
      // `podeReivindicarEmpate50Lances` = identificador de propriedade ou método chamado `podeReivindicarEmpate50Lances`, acessado a partir do objeto indicado antes do ponto.
      if (!estado.podeReivindicarEmpateRepeticao() && !estado.podeReivindicarEmpate50Lances()) return false;

      // Declara `avaliacao` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `avaliacao` = identificador utilizado para armazenar ou acessar o valor relacionado a avaliacao.
      // `this.avaliar` = acessa o atributo ou método `avaliar` pertencente à própria instância atual.
      // `this.avaliar` = chama o método ou recurso `avaliar` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const avaliacao = this.avaliar(estado, cor);

      // Declara `pecasAtivas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `pecasAtivas` = identificador utilizado para armazenar ou acessar o valor relacionado a pecasAtivas.
      // `this._contarPecasAtivas` = acessa o atributo ou método `_contarPecasAtivas` pertencente à própria instância atual.
      // `this._contarPecasAtivas` = chama o método ou recurso `_contarPecasAtivas` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const pecasAtivas = this._contarPecasAtivas(estado);

      // Declara `simples` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `simples` = identificador utilizado para armazenar ou acessar o valor relacionado a simples.
      // `6` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const simples = pecasAtivas <= 6;

      // Declara `equilibrada` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `equilibrada` = identificador utilizado para armazenar ou acessar o valor relacionado a equilibrada.
      // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
      // `85` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `abs` = identificador de propriedade ou método chamado `abs`, acessado a partir do objeto indicado antes do ponto.
      const equilibrada = Math.abs(avaliacao) <= 85;

      // Declara `ruim` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ruim` = identificador utilizado para armazenar ou acessar o valor relacionado a ruim.
      // `140` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `;` = encerra a instrução JavaScript atual.
      // `avaliacao` = valor numérico que representa a qualidade estimada de uma posição do tabuleiro para a Inteligência Artificial.
      // `-140` = valor numérico negativo utilizado nesta coordenada, deslocamento, cálculo, limite ou configuração.
      const ruim = avaliacao <= -140;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `estado.podeReivindicarEmpateRepeticao` = chama a função ou método `podeReivindicarEmpateRepeticao` pertencente ao objeto ou recurso indicado antes do ponto.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `podeReivindicarEmpateRepeticao` = identificador de propriedade ou método chamado `podeReivindicarEmpateRepeticao`, acessado a partir do objeto indicado antes do ponto.
      if (estado.podeReivindicarEmpateRepeticao()) return simples || ruim;

      // Retorna `simples || pecasAtivas <= 8 || equilibrada || ruim` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `;` = encerra a instrução JavaScript atual.
      // `simples` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a simples.
      // `pecasAtivas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pecasAtivas.
      return simples || pecasAtivas <= 8 || equilibrada || ruim;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_contarPecasAtivas` para executar a rotina correspondente a contarPecasAtivas.
    // `_contarPecasAtivas` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    _contarPecasAtivas(estado) {

      // Declara `total` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `total` = identificador utilizado para armazenar ou acessar o valor relacionado a total.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let total = 0;

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `of` = indica os valores percorridos em uma estrutura for...of.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
      // `p` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a p.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `REI` = constante que identifica a peça Rei.
      for (const linha of estado.tabuleiro) for (const p of linha) if (p && p.tipo !== REI) total += 1;

      // Retorna `total` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return total;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_ajusteAntiCiclo` para executar a rotina correspondente a ajusteAntiCiclo.
    // `_ajusteAntiCiclo` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
    // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
    _ajusteAntiCiclo(estado, movimento, corIA) {

      // Declara `penalidade` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `penalidade` = identificador utilizado para armazenar ou acessar o valor relacionado a penalidade.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let penalidade = 0;

      // Declara `pecasAtivas` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `pecasAtivas` = identificador utilizado para armazenar ou acessar o valor relacionado a pecasAtivas.
      // `this._contarPecasAtivas` = acessa o atributo ou método `_contarPecasAtivas` pertencente à própria instância atual.
      // `this._contarPecasAtivas` = chama o método ou recurso `_contarPecasAtivas` pertencente à instância atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      const pecasAtivas = this._contarPecasAtivas(estado);

      // Declara `copia` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `copia` = identificador utilizado para armazenar ou acessar o valor relacionado a copia.
      // `estado.clonar` = chama a função ou método `clonar` pertencente ao objeto ou recurso indicado antes do ponto.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `clonar` = identificador de propriedade ou método chamado `clonar`, acessado a partir do objeto indicado antes do ponto.
      const copia = estado.clonar();

      // Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
      // `copia._aplicarSemValidar` = chama a função ou método `_aplicarSemValidar` pertencente ao objeto ou recurso indicado antes do ponto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `_aplicarSemValidar` = identificador de propriedade ou método chamado `_aplicarSemValidar`, acessado a partir do objeto indicado antes do ponto.
      copia._aplicarSemValidar(movimento, false);

      // Declara `repeticoes` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `repeticoes` = identificador utilizado para armazenar ou acessar o valor relacionado a repeticoes.
      // `copia._chavePosicao` = chama a função ou método `_chavePosicao` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `_chavePosicao` = identificador de propriedade ou método chamado `_chavePosicao`, acessado a partir do objeto indicado antes do ponto.
      const repeticoes = (estado.repeticoes[copia._chavePosicao()] || 0) + 1;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `220` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `70` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `penalidade` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a penalidade.
      // `pecasAtivas` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pecasAtivas.
      if (repeticoes >= 3) penalidade -= pecasAtivas >= 8 ? 220 : 70;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `80` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      else if (repeticoes === 2) penalidade -= pecasAtivas >= 10 ? 80 : 25;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._desfazMovimentoProprioRecente` = acessa o atributo ou método `_desfazMovimentoProprioRecente` pertencente à própria instância atual.
      // `this._desfazMovimentoProprioRecente` = chama o método ou recurso `_desfazMovimentoProprioRecente` pertencente à instância atual.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `90` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `30` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
      // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
      if (this._desfazMovimentoProprioRecente(estado, movimento, corIA)) penalidade -= pecasAtivas >= 8 ? 90 : 30;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `this` = representa a própria instância atual da classe ou objeto.
      // `this._moveMesmaPecaNovamente` = acessa o atributo ou método `_moveMesmaPecaNovamente` pertencente à própria instância atual.
      // `this._moveMesmaPecaNovamente` = chama o método ou recurso `_moveMesmaPecaNovamente` pertencente à instância atual.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `!` = realiza negação lógica do valor ou condição indicada.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `capturada` = identificador que representa a peça capturada em uma jogada.
      // `enPassant` = identificador de propriedade ou método chamado `enPassant`, acessado a partir do objeto indicado antes do ponto.
      // `promocao` = identificador de propriedade ou método chamado `promocao`, acessado a partir do objeto indicado antes do ponto.
      // `peca` = identificador que representa uma peça de xadrez.
      // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
      // `PEAO` = constante que identifica a peça Peão.
      // `penalidade` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a penalidade.
      if (!movimento.capturada && !movimento.enPassant && !movimento.promocao && movimento.peca.tipo !== PEAO && this._moveMesmaPecaNovamente(estado, movimento, corIA)) penalidade -= 14;

      // Retorna `penalidade` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return penalidade;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_desfazMovimentoProprioRecente` para executar a rotina correspondente a desfazMovimentoProprioRecente.
    // `_desfazMovimentoProprioRecente` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    _desfazMovimentoProprioRecente(estado, movimento, corIA) {

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      for (let i = estado.historico.length - 1; i >= 0; i -= 1) {

        // Declara `lance` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `lance` = identificador utilizado para armazenar ou acessar o valor relacionado a lance.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const lance = estado.historico[i];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
        if (lance.peca.cor !== corIA) continue;

        // Retorna `movimento.peca.tipo === lance.peca.tipo && M.posIgual(movimento.origem, lance.destino) && M.posIgual(movimento.destino, lance.origem)` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `M.posIgual` = chama a função ou método `posIgual` pertencente ao objeto ou recurso indicado antes do ponto.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        // `M` = referência utilizada como atalho para acessar o módulo que contém o motor e as regras de xadrez.
        // `posIgual` = função que verifica se duas posições do tabuleiro representam a mesma casa.
        // `origem` = identificador que representa a casa de origem de um movimento.
        // `destino` = identificador que representa a casa de destino de um movimento.
        return movimento.peca.tipo === lance.peca.tipo && M.posIgual(movimento.origem, lance.destino) && M.posIgual(movimento.destino, lance.origem);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `false` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return false;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_moveMesmaPecaNovamente` para executar a rotina correspondente a moveMesmaPecaNovamente.
    // `_moveMesmaPecaNovamente` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    _moveMesmaPecaNovamente(estado, movimento, corIA) {

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
      // `historico` = identificador de propriedade ou método chamado `historico`, acessado a partir do objeto indicado antes do ponto.
      // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
      for (let i = estado.historico.length - 1; i >= 0; i -= 1) {

        // Declara `lance` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `lance` = identificador utilizado para armazenar ou acessar o valor relacionado a lance.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        const lance = estado.historico[i];

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `continue` = encerra a iteração atual e avança para a próxima repetição.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `peca` = identificador que representa uma peça de xadrez.
        // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
        // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
        if (lance.peca.cor !== corIA) continue;

        // Retorna `movimento.peca.tipo === lance.peca.tipo && M.posIgual(movimento.origem, lance.destino)` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `M.posIgual` = chama a função ou método `posIgual` pertencente ao objeto ou recurso indicado antes do ponto.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `movimento` = identificador que representa um movimento de uma peça no tabuleiro.
        // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
        // `M` = referência utilizada como atalho para acessar o módulo que contém o motor e as regras de xadrez.
        // `posIgual` = função que verifica se duas posições do tabuleiro representam a mesma casa.
        // `origem` = identificador que representa a casa de origem de um movimento.
        // `destino` = identificador que representa a casa de destino de um movimento.
        return movimento.peca.tipo === lance.peca.tipo && M.posIgual(movimento.origem, lance.destino);

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Retorna `false` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return false;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `avaliar` para executar a rotina correspondente a avaliar.
    // `avaliar` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `estado` = identificador que representa o estado atual da partida de xadrez.
    avaliar(estado, corIA) {

      // Declara `adversaria` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `adversaria` = identificador utilizado para armazenar ou acessar o valor relacionado a adversaria.
      // `corOposta` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
      const adversaria = corOposta(corIA);

      // Declara `pontuacao` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `pontuacao` = identificador utilizado para armazenar ou acessar o valor relacionado a pontuacao.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let pontuacao = 0;

      // Declara `bispos` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `bispos` = identificador utilizado para armazenar ou acessar o valor relacionado a bispos.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      const bispos = { [corIA]: 0, [adversaria]: 0 };

      // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
      // `0` = representa o primeiro índice possível quando a contagem começa em zero.
      // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `<` = verifica se o valor da esquerda é menor que o valor da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `linha` = identificador que representa a linha de uma casa no tabuleiro.
      for (let linha = 0; linha < 8; linha += 1) {

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `8` = representa as oito linhas ou oito colunas que compõem o tabuleiro de xadrez.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        for (let coluna = 0; coluna < 8; coluna += 1) {

          // Declara `peca` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `peca` = identificador utilizado para armazenar ou acessar o valor relacionado a peca.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `estado` = identificador que representa o estado atual da partida de xadrez.
          // `tabuleiro` = estrutura que representa as 64 casas e as peças posicionadas na partida.
          const peca = estado.tabuleiro[linha][coluna];

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `continue` = encerra a iteração atual e avança para a próxima repetição.
          // `!` = realiza negação lógica do valor ou condição indicada.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `;` = encerra a instrução JavaScript atual.
          if (!peca) continue;

          // Declara `total` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `this` = representa a própria instância atual da classe ou objeto.
          // `total` = identificador utilizado para armazenar ou acessar o valor relacionado a total.
          // `this._bonusPosicional` = acessa o atributo ou método `_bonusPosicional` pertencente à própria instância atual.
          // `this._bonusPosicional` = chama o método ou recurso `_bonusPosicional` pertencente à instância atual.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `VALORES` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a VALORES.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          // `cor` = identificador de propriedade ou método chamado `cor`, acessado a partir do objeto indicado antes do ponto.
          // `linha` = identificador que representa a linha de uma casa no tabuleiro.
          const total = VALORES[peca.tipo] + this._bonusPosicional(peca.tipo, peca.cor, linha, coluna);

          // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
          // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `peca` = identificador que representa uma peça de xadrez.
          // `BISPO` = constante que identifica a peça Bispo.
          // `bispos` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a bispos.
          if (peca.tipo === BISPO) bispos[peca.cor] += 1;

          // Armazena ou atualiza em `pontuacao` o valor ou resultado definido nesta linha.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `pontuacao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pontuacao.
          // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
          pontuacao += peca.cor === corIA ? total : -total;

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        }

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      }

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      if (bispos[corIA] >= 2) pontuacao += 25;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `25` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `;` = encerra a instrução JavaScript atual.
      // `adversaria` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a adversaria.
      if (bispos[adversaria] >= 2) pontuacao -= 25;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
      // `28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `estado` = identificador que representa o estado atual da partida de xadrez.
      // `estaEmXeque` = identificador de propriedade ou método chamado `estaEmXeque`, acessado a partir do objeto indicado antes do ponto.
      if (estado.estaEmXeque(adversaria)) pontuacao += 28;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `estado.estaEmXeque` = chama a função ou método `estaEmXeque` pertencente ao objeto ou recurso indicado antes do ponto.
      // `28` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `-=` = subtrai o valor da direita do valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `corIA` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a corIA.
      // `pontuacao` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a pontuacao.
      if (estado.estaEmXeque(corIA)) pontuacao -= 28;

      // Retorna `pontuacao` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return pontuacao;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_bonusPosicional` para executar a rotina correspondente a bonusPosicional.
    // `_bonusPosicional` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
    // `cor` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a cor.
    // `linha` = identificador que representa a linha de uma casa no tabuleiro.
    // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
    _bonusPosicional(tipo, cor, linha, coluna) {

      // Declara `linhaPerspectiva` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `linhaPerspectiva` = identificador utilizado para armazenar ou acessar o valor relacionado a linhaPerspectiva.
      // `7` = representa o último índice válido de uma linha ou coluna do tabuleiro quando a contagem começa em zero.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `BRANCO` = constante que identifica a cor branca e o conjunto de peças brancas no jogo.
      const linhaPerspectiva = cor === BRANCO ? 7 - linha : linha;

      // Declara `distanciaCentro` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `distanciaCentro` = identificador utilizado para armazenar ou acessar o valor relacionado a distanciaCentro.
      // `Math.abs` = chama a função ou método `abs` pertencente ao objeto ou recurso indicado antes do ponto.
      // `3.5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `+` = realiza soma, concatenação ou composição conforme os valores envolvidos.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `abs` = identificador de propriedade ou método chamado `abs`, acessado a partir do objeto indicado antes do ponto.
      const distanciaCentro = Math.abs(3.5 - coluna) + Math.abs(3.5 - linha);

      // Declara `centro` e armazena nele o valor ou resultado definido nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `centro` = identificador utilizado para armazenar ou acessar o valor relacionado a centro.
      // `Math.max` = chama a função ou método `max` pertencente ao objeto ou recurso indicado antes do ponto.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `7` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `max` = identificador de propriedade ou método chamado `max`, acessado a partir do objeto indicado antes do ponto.
      const centro = Math.max(0, 7 - distanciaCentro);

      // Declara `bonus` e armazena nele o valor ou resultado definido nesta linha.
      // `let` = declara uma variável que pode receber novos valores durante a execução.
      // `bonus` = identificador utilizado para armazenar ou acessar o valor relacionado a bonus.
      // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      let bonus = 0;

      // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
      // `PEAO` = constante que identifica a peça Peão.
      if (tipo === PEAO) {

        // Armazena ou atualiza em `bonus` o valor ou resultado definido nesta linha.
        // `Math.trunc` = chama a função ou método `trunc` pertencente ao objeto ou recurso indicado antes do ponto.
        // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `trunc` = identificador de propriedade ou método chamado `trunc`, acessado a partir do objeto indicado antes do ponto.
        // `linhaPerspectiva` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaPerspectiva.
        bonus += Math.trunc(linhaPerspectiva * 5);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `9` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `coluna` = identificador que representa a coluna de uma casa no tabuleiro.
        if (coluna === 3 || coluna === 4) bonus += 9;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `CAVALO` = constante que identifica a peça Cavalo.
      } else if (tipo === CAVALO) {

        // Armazena ou atualiza em `bonus` o valor ou resultado definido nesta linha.
        // `Math.trunc` = chama a função ou método `trunc` pertencente ao objeto ou recurso indicado antes do ponto.
        // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `bonus` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a bonus.
        // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
        // `centro` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a centro.
        bonus += Math.trunc(centro * 5);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `5` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `linhaPerspectiva` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaPerspectiva.
        if (linhaPerspectiva >= 2) bonus += 5;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
      // `BISPO` = constante que identifica a peça Bispo.
      } else if (tipo === BISPO) {

        // Armazena ou atualiza em `bonus` o valor ou resultado definido nesta linha.
        // `Math.trunc` = chama a função ou método `trunc` pertencente ao objeto ou recurso indicado antes do ponto.
        // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `*` = realiza multiplicação.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `trunc` = identificador de propriedade ou método chamado `trunc`, acessado a partir do objeto indicado antes do ponto.
        bonus += Math.trunc(centro * 3);

        // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
        // `>=` = verifica se o valor da esquerda é maior ou igual ao da direita.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        if (linhaPerspectiva >= 2) bonus += 4;

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `Math.trunc` = chama a função ou método `trunc` pertencente ao objeto ou recurso indicado antes do ponto.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `DAMA` = constante que identifica a peça Dama.
      // `bonus` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a bonus.
      // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
      // `centro` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a centro.
      } else if (tipo === DAMA) bonus += Math.trunc(centro);

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `Math.trunc` = chama a função ou método `trunc` pertencente ao objeto ou recurso indicado antes do ponto.
      // `2` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `*` = realiza multiplicação.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `tipo` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a tipo.
      // `TORRE` = constante que identifica a peça Torre.
      // `linhaPerspectiva` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a linhaPerspectiva.
      else if (tipo === TORRE) bonus += Math.trunc(linhaPerspectiva * 2);

      // Verifica uma condição alternativa quando a condição anterior não foi atendida.
      // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
      // `else` = define o caminho executado quando a condição anterior não é atendida.
      // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
      // `14` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
      // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
      // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `;` = encerra a instrução JavaScript atual.
      // `REI` = constante que identifica a peça Rei.
      else if (tipo === REI && linhaPerspectiva <= 1) bonus += 14;

      // Retorna `bonus` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return bonus;

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

    // Define o método `_ordenarMovimentos` para executar a rotina correspondente a ordenarMovimentos.
    // `_ordenarMovimentos` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
    // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
    // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
    // `movimentos` = identificador que representa uma coleção de movimentos do jogo.
    _ordenarMovimentos(movimentos) {

      // Retorna `[...movimentos].sort((a, b) => {` para o ponto do programa que chamou a rotina atual.
      // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
      // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
      // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
      // `]` = fecha a lista, o acesso por índice ou a chave calculada.
      // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
      // `sort` = identificador de propriedade ou método chamado `sort`, acessado a partir do objeto indicado antes do ponto.
      // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
      // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
      return [...movimentos].sort((a, b) => {

        // Declara `prioridade` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `prioridade` = identificador utilizado para armazenar ou acessar o valor relacionado a prioridade.
        // `=>` = define uma função de seta e separa seus parâmetros do corpo executado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
        // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
        const prioridade = (m) => {

          // Declara `valorCaptura` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `valorCaptura` = identificador utilizado para armazenar ou acessar o valor relacionado a valorCaptura.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `capturada` = identificador que representa a peça capturada em uma jogada.
          // `VALORES` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a VALORES.
          // `tipo` = identificador de propriedade ou método chamado `tipo`, acessado a partir do objeto indicado antes do ponto.
          const valorCaptura = m.capturada ? VALORES[m.capturada.tipo] : 0;

          // Declara `valorPeca` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `valorPeca` = identificador utilizado para armazenar ou acessar o valor relacionado a valorPeca.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `peca` = identificador que representa uma peça de xadrez.
          const valorPeca = VALORES[m.peca.tipo];

          // Declara `promocao` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `promocao` = identificador utilizado para armazenar ou acessar o valor relacionado a promocao.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          const promocao = m.promocao ? VALORES[m.promocao] : 0;

          // Declara `centro` e armazena nele o valor ou resultado definido nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `centro` = identificador utilizado para armazenar ou acessar o valor relacionado a centro.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `3` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `4` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `===` = compara dois valores exigindo igualdade de conteúdo e de tipo.
          // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
          // `||` = operador lógico OU, que aceita que pelo menos uma das condições seja verdadeira.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `m` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a m.
          // `destino` = identificador que representa a casa de destino de um movimento.
          const centro = (m.destino[0] === 3 || m.destino[0] === 4) && (m.destino[1] === 3 || m.destino[1] === 4) ? 1 : 0;

          // Retorna `[promocao, valorCaptura - Math.trunc(valorPeca / 10), m.roque ? 1 : 0, centro]` para o ponto do programa que chamou a rotina atual.
          // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
          // `Math.trunc` = chama a função ou método `trunc` pertencente ao objeto ou recurso indicado antes do ponto.
          // `10` = valor numérico utilizado nesta condição, cálculo, configuração, limite, coordenada ou estado da lógica.
          // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
          // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
          // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
          // `/` = realiza divisão.
          // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
          // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
          // `]` = fecha a lista, o acesso por índice ou a chave calculada.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
          // `;` = encerra a instrução JavaScript atual.
          // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
          // `valorCaptura` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a valorCaptura.
          // `Math` = objeto nativo que disponibiliza funções e constantes matemáticas.
          // `trunc` = identificador de propriedade ou método chamado `trunc`, acessado a partir do objeto indicado antes do ponto.
          // `valorPeca` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a valorPeca.
          // `roque` = identificador de propriedade ou método chamado `roque`, acessado a partir do objeto indicado antes do ponto.
          return [promocao, valorCaptura - Math.trunc(valorPeca / 10), m.roque ? 1 : 0, centro];

        // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
        // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
        // `;` = encerra a instrução JavaScript atual.
        };

        // Declara `pa` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `pa` = identificador utilizado para armazenar ou acessar o valor relacionado a pa.
        // `prioridade` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `a` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a a.
        const pa = prioridade(a);

        // Declara `pb` e armazena nele o valor ou resultado definido nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `pb` = identificador utilizado para armazenar ou acessar o valor relacionado a pb.
        // `prioridade` = função, método ou construtor chamado nesta linha para executar a operação correspondente.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `;` = encerra a instrução JavaScript atual.
        // `b` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a b.
        const pb = prioridade(b);

        // Percorre os elementos ou repete as instruções de acordo com a configuração definida nesta estrutura de repetição.
        // `let` = declara uma variável que pode receber novos valores durante a execução.
        // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
        // `for` = inicia uma estrutura de repetição que percorre valores ou repete um bloco de instruções.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `0` = representa o primeiro índice possível quando a contagem começa em zero.
        // `1` = valor numérico um utilizado nesta condição, cálculo, incremento ou configuração.
        // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
        // `+=` = soma o valor da direita ao valor atual e armazena o resultado.
        // `<` = verifica se o valor da esquerda é menor que o valor da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `-` = realiza subtração ou representa um valor negativo conforme o contexto.
        // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
        // `[` = abre uma lista, um acesso por índice ou uma chave calculada.
        // `]` = fecha a lista, o acesso por índice ou a chave calculada.
        // `;` = encerra a instrução JavaScript atual.
        // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
        // `i` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a i.
        // `length` = identificador de propriedade ou método chamado `length`, acessado a partir do objeto indicado antes do ponto.
        for (let i = 0; i < pa.length; i += 1) if (pa[i] !== pb[i]) return pb[i] - pa[i];

        // Retorna `0` para o ponto do programa que chamou a rotina atual.
        // `return` = encerra a rotina atual e devolve o valor indicado ao ponto que fez a chamada.
        // `0` = valor numérico zero utilizado nesta condição, cálculo, índice ou inicialização.
        // `;` = encerra a instrução JavaScript atual.
        return 0;

      // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
      // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
      // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
      // `;` = encerra a instrução JavaScript atual.
      });

    // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
    // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
    }

  // Fecha ou organiza o bloco, objeto, lista ou chamada iniciado nas linhas anteriores.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  }

  // Armazena ou atualiza o valor de `global.XadrezIA` utilizando o resultado definido nesta linha.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `global` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a global.
  // `XadrezIA` = identificador de propriedade ou método chamado `XadrezIA`, acessado a partir do objeto indicado antes do ponto.
  // `InteligenciaXadrez` = classe responsável pelas decisões da Inteligência Artificial do jogo.
  global.XadrezIA = { InteligenciaXadrez };

  // Verifica a condição informada e executa o bloco seguinte somente quando ela for verdadeira.
  // `if` = inicia uma condição e executa o bloco seguinte quando a expressão avaliada for verdadeira.
  // `typeof` = obtém o tipo do valor ou expressão indicada.
  // `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
  // `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
  // `&&` = operador lógico E, que exige que as condições combinadas sejam verdadeiras.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
  // `{` = abre um bloco de instruções, objeto ou estrutura de desestruturação.
  // `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
  // `;` = encerra a instrução JavaScript atual.
  // `.` = acessa uma propriedade ou método pertencente ao objeto indicado antes do ponto.
  // `module` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a module.
  // `exports` = identificador de propriedade ou método chamado `exports`, acessado a partir do objeto indicado antes do ponto.
  if (typeof module !== 'undefined' && module.exports) module.exports = { InteligenciaXadrez };

// Executa a chamada de função ou método indicada nesta linha com os argumentos informados.
// `typeof` = obtém o tipo do valor ou expressão indicada.
// `'undefined'` = texto literal utilizado nesta instrução, contendo undefined.
// `!==` = verifica se dois valores são diferentes em conteúdo ou tipo.
// `(` = abre a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `)` = fecha a lista de argumentos, parâmetros, condição ou agrupamento correspondente.
// `}` = fecha um bloco de instruções, objeto ou estrutura de desestruturação.
// `:` = separa uma propriedade de seu valor, define um rótulo de case ou participa da sintaxe correspondente.
// `;` = encerra a instrução JavaScript atual.
// `window` = objeto global disponibilizado pelo navegador para acessar recursos globais da página.
// `globalThis` = identificador utilizado nesta linha para representar, armazenar ou acessar o valor relacionado a globalThis.
})(typeof window !== 'undefined' ? window : globalThis);
