JOGO DE XADREZ
=======================================

Projeto desenvolvido para funcionar diretamente no navegador, sem bibliotecas externas.

ARQUIVOS PRINCIPAIS
-------------------
index.html          -> página principal do jogo
css/estilo.css      -> layout, responsividade, tabuleiro e quatro câmeras
js/motor.js         -> regras e motor completo de xadrez
js/ia.js            -> Inteligência Artificial com Minimax e poda Alpha-Beta
js/app.js           -> interface, controles, sons, ranking e fluxo da partida
sons/               -> efeitos sonoros WAV

COMO ABRIR
----------
Dê dois cliques em index.html.

O projeto foi preparado para funcionar localmente no navegador. Não é necessário
instalar Python, Node.js, servidor web ou bibliotecas adicionais para jogar.

MODOS
-----
- Jogador x IA
- IA x IA

DIFICULDADES
------------
- Fácil
- Intermediário
- Avançado

QUATRO CÂMERAS
--------------
1. Superior clássica
2. Perspectiva das Brancas
3. Perspectiva das Pretas
4. Lateral / Isométrica

As câmeras podem ser trocadas no menu e durante a partida. Também é possível usar
as teclas 1, 2, 3 e 4 durante o jogo.

REGRAS IMPLEMENTADAS
--------------------
- Movimentos legais de todas as peças
- Xeque e xeque-mate
- Roque pequeno e grande
- Captura en passant
- Promoção do peão
- Afogamento
- Material insuficiente
- Reivindicação por três repetições
- Reivindicação pela regra dos 50 lances
- Empate automático por cinco repetições
- Empate automático pela regra dos 75 lances
- Oferta de empate contra a IA
- Desistência

OUTROS RECURSOS
---------------
- Sons para seleção, movimento, captura, xeque, roque, promoção e resultados
- F8 liga/desliga o som
- Histórico de lances
- Destaque da última jogada da IA
- Destaque de movimentos e capturas válidas
- Explicações em português para movimentos inválidos
- Peças capturadas
- Tela cheia
- Ranking, estatísticas e histórico persistidos no LocalStorage do navegador
- Layout responsivo

PONTUAÇÃO DO RANKING
--------------------
Vitória = 3 pontos
Empate = 1 ponto
Derrota = 0 ponto
