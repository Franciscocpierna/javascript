// Ativa o modo estrito do JavaScript para aplicar regras mais rigorosas durante a execução deste arquivo.
// `'use strict'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
// `;` = encerra a instrução JavaScript atual.
'use strict';

// Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
// `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
// `>` = verifica se o valor da esquerda é maior que o da direita.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
(() => {

  // Declara `canvas` e armazena nele elemento canvas utilizado para exibir graficamente o jogo.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `document.getElementById` = localiza no documento HTML o elemento que possui o identificador informado.
  // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
  // `'jogo'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  const canvas = document.getElementById('jogo');

  // Declara `jogo` e armazena nele instância principal que controla a partida de futebol.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `new` = cria uma nova instância da classe ou construtor indicado.
  // `JogoFutebolWeb` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo` = instância principal que controla a partida de futebol.
  // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `;` = encerra a instrução JavaScript atual.
  const jogo = new JogoFutebolWeb(canvas);

  // Declara `impedir` e armazena nele o valor ou resultado calculado nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `new` = cria uma nova instância da classe ou construtor indicado.
  // `Set` = função ou método chamado nesta linha para executar a operação correspondente.
  // `impedir` = identificador utilizado para armazenar o valor produzido por esta instrução.
  // `'ArrowUp'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `'ArrowDown'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `'ArrowLeft'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `'ArrowRight'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `'Space'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  const impedir = new Set(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space']);

  // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
  // `window.addEventListener` = registra uma função para responder ao evento informado.
  // `e` = objeto de evento recebido do navegador.
  // `'keydown'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  window.addEventListener('keydown', e => {

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `jogo.desbloquearAudio` = função ou método chamado nesta linha para executar a operação correspondente.
    // `jogo` = instância principal que controla a partida de futebol.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    jogo.desbloquearAudio();

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `impedir.has` = verifica se a coleção contém o elemento informado.
    // `e.preventDefault` = impede o comportamento padrão do navegador para o evento atual.
    // `e` = objeto de evento recebido do navegador.
    // `code` = código da tecla ou ação utilizado na lógica de entrada.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (impedir.has(e.code)) e.preventDefault();

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `jogo.teclas.has` = verifica se a coleção contém o elemento informado.
    // `jogo.teclaPressionada` = função ou método chamado nesta linha para executar a operação correspondente.
    // `jogo` = instância principal que controla a partida de futebol.
    // `e` = objeto de evento recebido do navegador.
    // `code` = código da tecla ou ação utilizado na lógica de entrada.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (!jogo.teclas.has(e.code)) jogo.teclaPressionada(e.code);

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `jogo.teclas.add` = adiciona à coleção o elemento informado.
    // `jogo` = instância principal que controla a partida de futebol.
    // `e` = objeto de evento recebido do navegador.
    // `code` = código da tecla ou ação utilizado na lógica de entrada.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    jogo.teclas.add(e.code);

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  // `false` = valor lógico falso.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  }, {passive:false});

  // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
  // `window.addEventListener` = registra uma função para responder ao evento informado.
  // `jogo.teclas.delete` = remove da coleção o elemento correspondente ao valor informado.
  // `e` = objeto de evento recebido do navegador.
  // `jogo` = instância principal que controla a partida de futebol.
  // `code` = código da tecla ou ação utilizado na lógica de entrada.
  // `'keyup'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  window.addEventListener('keyup', e => jogo.teclas.delete(e.code));

  // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
  // `window.addEventListener` = registra uma função para responder ao evento informado.
  // `jogo.teclas.clear` = remove todos os elementos atualmente armazenados na coleção.
  // `jogo` = instância principal que controla a partida de futebol.
  // `'blur'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  window.addEventListener('blur', () => jogo.teclas.clear());

  // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
  // `canvas.addEventListener` = registra uma função para responder ao evento informado.
  // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
  // `e` = objeto de evento recebido do navegador.
  // `'pointerdown'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  canvas.addEventListener('pointerdown', e => {

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `jogo.desbloquearAudio` = função ou método chamado nesta linha para executar a operação correspondente.
    // `jogo` = instância principal que controla a partida de futebol.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    jogo.desbloquearAudio();

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `canvas.focus` = coloca o foco de entrada no elemento.
    // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    canvas.focus();

    // Declara `r` e armazena nele retângulo que representa posição e dimensões do canvas na tela.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `canvas.getBoundingClientRect` = obtém a posição e as dimensões atuais do elemento na tela.
    // `r` = retângulo que representa posição e dimensões do canvas na tela.
    // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const r = canvas.getBoundingClientRect();

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `jogo.clique` = função ou método chamado nesta linha para executar a operação correspondente.
    // `jogo` = instância principal que controla a partida de futebol.
    // `e` = objeto de evento recebido do navegador.
    // `r` = retângulo que representa posição e dimensões do canvas na tela.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `LARGURA` = largura lógica da área de jogo em pixels.
    // `ALTURA` = altura lógica da área de jogo em pixels.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    jogo.clique((e.clientX-r.left)*CFG.LARGURA/r.width, (e.clientY-r.top)*CFG.ALTURA/r.height);

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  // `;` = encerra a instrução JavaScript atual.
  });

  // Declara `toque` e armazena nele área que reúne os controles de toque do jogo.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `document.getElementById` = localiza no documento HTML o elemento que possui o identificador informado.
  // `toque` = área que reúne os controles de toque do jogo.
  // `'controlesToque'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  const toque = document.getElementById('controlesToque');

  // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
  // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
  // `matchMedia` = função ou método chamado nesta linha para executar a operação correspondente.
  // `toque.classList.add` = adiciona à coleção o elemento informado.
  // `toque` = área que reúne os controles de toque do jogo.
  // `'(hover: none) and (pointer: coarse)'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `'ativo'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  if (matchMedia('(hover: none) and (pointer: coarse)').matches) toque.classList.add('ativo');

  // Percorre os elementos ou repetições definidos nesta linha para executar o bloco correspondente.
  // `for` = inicia uma estrutura de repetição.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `toque.querySelectorAll` = localiza todos os elementos descendentes que correspondem ao seletor informado.
  // `btn` = elemento de botão processado nesta rotina.
  // `toque` = área que reúne os controles de toque do jogo.
  // `'[data-tecla]'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  for (const btn of toque.querySelectorAll('[data-tecla]')) {

    // Declara `code` e armazena nele código da tecla ou ação utilizado na lógica de entrada.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `code` = código da tecla ou ação utilizado na lógica de entrada.
    // `btn` = elemento de botão processado nesta rotina.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const code=btn.dataset.tecla;

    // Declara `down` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `e.preventDefault` = impede o comportamento padrão do navegador para o evento atual.
    // `jogo.desbloquearAudio` = função ou método chamado nesta linha para executar a operação correspondente.
    // `jogo.teclas.add` = adiciona à coleção o elemento informado.
    // `canvas.focus` = coloca o foco de entrada no elemento.
    // `e` = objeto de evento recebido do navegador.
    // `jogo` = instância principal que controla a partida de futebol.
    // `code` = código da tecla ou ação utilizado na lógica de entrada.
    // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
    // `down` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const down=e=>{e.preventDefault();jogo.desbloquearAudio();jogo.teclas.add(code);canvas.focus();};

    // Declara `up` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `e.preventDefault` = impede o comportamento padrão do navegador para o evento atual.
    // `jogo.teclas.delete` = remove da coleção o elemento correspondente ao valor informado.
    // `e` = objeto de evento recebido do navegador.
    // `jogo` = instância principal que controla a partida de futebol.
    // `code` = código da tecla ou ação utilizado na lógica de entrada.
    // `up` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const up=e=>{e.preventDefault();jogo.teclas.delete(code);};

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `btn.addEventListener` = registra uma função para responder ao evento informado.
    // `btn` = elemento de botão processado nesta rotina.
    // `'pointerdown'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `'pointerup'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `'pointercancel'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `'pointerleave'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    btn.addEventListener('pointerdown',down);btn.addEventListener('pointerup',up);btn.addEventListener('pointercancel',up);btn.addEventListener('pointerleave',up);

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Declara `acoes` e armazena nele o valor ou resultado calculado nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `jogo.acaoPasse` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoProfundidade` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoCruzamento` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoChute` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoChuteForte` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoCavadinha` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoDrible` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoProtegerBola` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoDesarme` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoCarrinho` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.trocarJogador` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo.acaoSubstituicao` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogo` = instância principal que controla a partida de futebol.
  // `acoes` = identificador utilizado para armazenar o valor produzido por esta instrução.
  // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  const acoes={passe:()=>jogo.acaoPasse(),profundidade:()=>jogo.acaoProfundidade(),cruzamento:()=>jogo.acaoCruzamento(),chute:()=>jogo.acaoChute(),chute_forte:()=>jogo.acaoChuteForte(),cavadinha:()=>jogo.acaoCavadinha(),drible:()=>jogo.acaoDrible(),proteger:()=>jogo.acaoProtegerBola(),desarme:()=>jogo.acaoDesarme(),carrinho:()=>jogo.acaoCarrinho(),trocar:()=>jogo.trocarJogador(),substituir:()=>jogo.acaoSubstituicao()};

  // Percorre os elementos ou repetições definidos nesta linha para executar o bloco correspondente.
  // `for` = inicia uma estrutura de repetição.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `toque.querySelectorAll` = localiza todos os elementos descendentes que correspondem ao seletor informado.
  // `btn.addEventListener` = registra uma função para responder ao evento informado.
  // `e.preventDefault` = impede o comportamento padrão do navegador para o evento atual.
  // `jogo.desbloquearAudio` = função ou método chamado nesta linha para executar a operação correspondente.
  // `canvas.focus` = coloca o foco de entrada no elemento.
  // `btn` = elemento de botão processado nesta rotina.
  // `toque` = área que reúne os controles de toque do jogo.
  // `e` = objeto de evento recebido do navegador.
  // `jogo` = instância principal que controla a partida de futebol.
  // `canvas` = elemento canvas utilizado para exibir graficamente o jogo.
  // `'[data-acao]'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `'pointerdown'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  for(const btn of toque.querySelectorAll('[data-acao]'))btn.addEventListener('pointerdown',e=>{e.preventDefault();jogo.desbloquearAudio();acoes[btn.dataset.acao]?.();canvas.focus();});

  // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
  // `jogo` = instância principal que controla a partida de futebol.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  window.jogoFutebol = jogo;

// Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `;` = encerra a instrução JavaScript atual.
})();
