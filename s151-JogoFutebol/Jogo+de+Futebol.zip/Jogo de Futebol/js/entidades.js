// Ativa o modo estrito do JavaScript para aplicar regras mais rigorosas durante a execução deste arquivo.
// `'use strict'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
// `;` = encerra a instrução JavaScript atual.
'use strict';

// Declara a classe `Bola` que reúne estado e comportamentos usados pelo jogo.
// `class` = declara uma classe utilizada para criar objetos com estado e comportamento próprios.
class Bola {

  // Define o método construtor responsável por inicializar os dados necessários quando um novo objeto desta classe é criado.
  // `constructor` = método executado automaticamente quando um novo objeto da classe é criado.
  // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
  // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  constructor(x, y) {

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos = { x, y };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `0` = valor numérico zero utilizado como coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel = { x: 0, y: 0 };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.dono = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimoToque = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.altura = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.velAltura = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.curva = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.giro = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.rastro = [];

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownCabecada = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tipoJogada = '';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.receptorPlanejado = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoPlanejado = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.sequenciaJogada = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.origemJogada = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownDesvio = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownIntercepcao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.toqueConducao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoDesdeChute = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimaPosDono = { x, y };

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `soltar` responsável por executar a lógica correspondente a esta rotina.
  // `null` = representa ausência intencional de um objeto ou valor.
  // `soltar` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogador` = objeto que representa um jogador de futebol.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  soltar(jogador = null) {

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (this.dono) this.dono.temBola = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.dono = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `jogador` = objeto que representa um jogador de futebol.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimoToque = jogador || this.ultimoToque;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `darPosse` responsável por executar a lógica correspondente a esta rotina.
  // `null` = representa ausência intencional de um objeto ou valor.
  // `darPosse` = função ou método chamado nesta linha para executar a operação correspondente.
  // `jogador` = objeto que representa um jogador de futebol.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  darPosse(jogador, usandoMaos = null) {

    // Declara `donoAnterior` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `donoAnterior` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const donoAnterior = this.dono;

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `jogador` = objeto que representa um jogador de futebol.
    // `!==` = compara dois valores exigindo diferença de valor ou tipo.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `==` = compara dois valores verificando igualdade.
    // `!=` = compara dois valores verificando diferença.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (this.dono && this.dono !== jogador) this.dono.temBola = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `jogador` = objeto que representa um jogador de futebol.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.dono = jogador;

    // Declara `mudouDeTime` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `jogador` = objeto que representa um jogador de futebol.
    // `time` = lista ou estrutura que representa os jogadores de uma equipe.
    // `mudouDeTime` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `!==` = compara dois valores exigindo diferença de valor ou tipo.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `==` = compara dois valores verificando igualdade.
    // `!=` = compara dois valores verificando diferença.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const mudouDeTime = donoAnterior && donoAnterior !== jogador && donoAnterior.time !== jogador.time;

    // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `jogador` = objeto que representa um jogador de futebol.
    // `max` = limite máximo aceito pela operação.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `0.26` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `0.11` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    jogador.protecaoPosse = Math.max(jogador.protecaoPosse || 0, mudouDeTime ? 0.26 : 0.11);

    // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
    // `true` = valor lógico verdadeiro.
    // `jogador` = objeto que representa um jogador de futebol.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    jogador.temBola = true;

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `false` = valor lógico falso.
    // `jogador` = objeto que representa um jogador de futebol.
    // `!==` = compara dois valores exigindo diferença de valor ou tipo.
    // `==` = compara dois valores verificando igualdade.
    // `!=` = compara dois valores verificando diferença.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (jogador.goleiro) jogador.usandoMaos = usandoMaos !== false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `jogador` = objeto que representa um jogador de futebol.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimoToque = jogador;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.velAltura = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.curva = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tipoJogada = '';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.receptorPlanejado = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoPlanejado = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.toqueConducao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoDesdeChute = 0;

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `jogador` = objeto que representa um jogador de futebol.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (!jogador.goleiro && !jogador.controlado) {

      // Declara `visao` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `jogador` = objeto que representa um jogador de futebol.
      // `visao` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `70` = valor numérico utilizado para definir valor relacionado a `visao`.
      // `100` = valor numérico utilizado para definir valor relacionado a `visao`.
      // `0.45` = valor numérico utilizado para definir valor relacionado a `visao`.
      // `0.95` = valor numérico utilizado para definir valor relacionado a `visao`.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      const visao = clamp((jogador.atributos?.visao || 70) / 100, 0.45, 0.95);

      // Declara `papel` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `String` = função ou método chamado nesta linha para executar a operação correspondente.
      // `jogador` = objeto que representa um jogador de futebol.
      // `papel` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const papel = String(jogador.papel || '');

      // Declara `criador` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
      // `criador` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `'Meia'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `'Volante'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const criador = papel.includes('Meia') || papel.includes('Volante');

      // Declara `atacante` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
      // `atacante` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `'Atacante'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `'Ponta'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const atacante = papel.includes('Atacante') || papel.includes('Ponta');

      // Declara `ajustePapel` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `ajustePapel` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `0.06` = valor numérico utilizado para definir valor relacionado a `ajustePapel`.
      // `0.035` = valor numérico utilizado para definir valor relacionado a `ajustePapel`.
      // `0.02` = valor numérico utilizado para definir valor relacionado a `ajustePapel`.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const ajustePapel = criador ? 0.06 : atacante ? -0.035 : 0.02;

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `randomEntre` = função ou método chamado nesta linha para executar a operação correspondente.
      // `jogador` = objeto que representa um jogador de futebol.
      // `0.58` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.94` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.70` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.18` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.48` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `1.02` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      jogador.tempoMinimoDecisao = clamp(randomEntre(0.58, 0.94) + ajustePapel - (visao - 0.70) * 0.18, 0.48, 1.02);

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `randomEntre` = função ou método chamado nesta linha para executar a operação correspondente.
      // `jogador` = objeto que representa um jogador de futebol.
      // `1.75` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `2.70` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.12` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.70` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0.22` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `1.45` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `2.90` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      jogador.tempoMaximoPosse = clamp(randomEntre(1.75, 2.70) + (criador ? 0.12 : 0) - (visao - 0.70) * 0.22, 1.45, 2.90);

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `Math.random` = gera um número pseudoaleatório entre 0 e 1.
      // `jogador` = objeto que representa um jogador de futebol.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      jogador.tendenciaDrible = Math.random();

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `null` = representa ausência intencional de um objeto ou valor.
      // `jogador` = objeto que representa um jogador de futebol.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      jogador.alvoConducaoIA = null;

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `jogador` = objeto que representa um jogador de futebol.
      // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      jogador.tempoAlvoConducao = 0;

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `randomEntre` = função ou método chamado nesta linha para executar a operação correspondente.
      // `jogador` = objeto que representa um jogador de futebol.
      // `0.06` = valor numérico utilizado no cálculo de probabilidade ou aleatoriedade desta decisão.
      // `0.16` = valor numérico utilizado no cálculo de probabilidade ou aleatoriedade desta decisão.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      jogador.relogioDecisaoIA = randomEntre(0.06, 0.16);

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `jogador` = objeto que representa um jogador de futebol.
      // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      jogador.compromissoMovimentoIA = 0;

      // Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
      // `null` = representa ausência intencional de um objeto ou valor.
      // `jogador` = objeto que representa um jogador de futebol.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      jogador.alvoCompromissoIA = null;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `chutar` responsável por executar a lógica correspondente a esta rotina.
  // `null` = representa ausência intencional de um objeto ou valor.
  // `chutar` = função ou método chamado nesta linha para executar a operação correspondente.
  // `'passe'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
  // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  chutar(origem, alvo, velocidade, altura = 0, impulso = 0, curva = 0, tipo = 'passe', receptor = null) {

    // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
    // `this` = representa a própria instância do objeto atual.
    // `this.soltar` = função ou método chamado nesta linha para executar a operação correspondente.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.soltar(origem);

    // Declara `d` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `d` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const d = normalizar(alvo.x - this.pos.x, alvo.y - this.pos.y);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x = d.x * velocidade;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y = d.y * velocidade;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.altura = Math.max(this.altura, altura);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.velAltura = impulso;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.curva = curva;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tipoJogada = tipo;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.receptorPlanejado = receptor;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoPlanejado = { ...alvo };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.origemJogada = origem?.pos ? { ...origem.pos } : null;

    // Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
    // `this` = representa a própria instância do objeto atual.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.sequenciaJogada++;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoDesdeChute = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.rastro.length = 0;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `atualizar` responsável por executar a lógica correspondente a esta rotina.
  // `atualizar` = função ou método chamado nesta linha para executar a operação correspondente.
  // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  atualizar(dt) {

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownCabecada = Math.max(0, this.cooldownCabecada - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownDesvio = Math.max(0, this.cooldownDesvio - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownIntercepcao = Math.max(0, this.cooldownIntercepcao - dt);

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (this.dono) {

      // Declara `dono` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `dono` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const dono = this.dono;

      // Declara `frentePadrao` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `time` = lista ou estrutura que representa os jogadores de uma equipe.
      // `frentePadrao` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `'azul'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `1` = valor numérico utilizado para definir valor relacionado a `frentePadrao`.
      // `===` = compara dois valores exigindo igualdade de valor e tipo.
      // `==` = compara dois valores verificando igualdade.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const frentePadrao = dono.time === 'azul' ? 1 : -1;

      // Declara `d` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `d` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `0` = valor numérico zero utilizado como valor relacionado a `d`.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const d = dono.direcao.x || dono.direcao.y ? dono.direcao : { x: frentePadrao, y: 0 };

      // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
      // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
      // `false` = valor lógico falso.
      // `!==` = compara dois valores exigindo diferença de valor ou tipo.
      // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
      // `==` = compara dois valores verificando igualdade.
      // `!=` = compara dois valores verificando diferença.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      if (dono.goleiro && dono.usandoMaos !== false) {

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `12` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.pos.x = dono.pos.x + d.x * 12;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `8` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `4` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.pos.y = dono.pos.y - 8 + d.y * 4;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `7` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.altura = 7;

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      // `else` = define o caminho executado quando a condição anterior não for atendida.
      } else {

        // Declara `velocidadeDono` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `velocidadeDono` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const velocidadeDono = Math.hypot(dono.vel.x, dono.vel.y);

        // Declara `proporcao` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `Math.max` = retorna o maior valor entre os argumentos informados.
        // `max` = limite máximo aceito pela operação.
        // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
        // `VELOCIDADE_USUARIO` = velocidade-base do jogador controlado pelo usuário.
        // `proporcao` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `1` = valor numérico utilizado para definir valor relacionado a `proporcao`.
        // `0` = valor numérico zero utilizado como valor relacionado a `proporcao`.
        // `1.15` = valor numérico utilizado para definir valor relacionado a `proporcao`.
        // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        const proporcao = clamp(velocidadeDono / Math.max(1, dono.velocidadeAtual || CFG.VELOCIDADE_USUARIO), 0, 1.15);

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
        // `4.2` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
        // `6.4` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
        // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `;` = encerra a instrução JavaScript atual.
        this.toqueConducao += dt * (4.2 + proporcao * 6.4);

        // Declara `pulso` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância do objeto atual.
        // `Math.sin` = calcula o seno do ângulo informado.
        // `pulso` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `1` = valor numérico utilizado para definir valor relacionado a `pulso`.
        // `0.5` = valor numérico utilizado para definir valor relacionado a `pulso`.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `;` = encerra a instrução JavaScript atual.
        const pulso = (Math.sin(this.toqueConducao) + 1) * 0.5;

        // Declara `emDrible` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `String` = função ou método chamado nesta linha para executar a operação correspondente.
        // `startsWith` = função ou método chamado nesta linha para executar a operação correspondente.
        // `emDrible` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `'drible'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
        // `0` = valor numérico zero utilizado como valor relacionado a `emDrible`.
        // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
        // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
        // `>` = verifica se o valor da esquerda é maior que o da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const emDrible = String(dono.acaoVisual || '').startsWith('drible') && dono.tempoAcao > 0;

        // Declara `bonusDrible` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `bonusDrible` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `'arrancada'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
        // `3.5` = valor numérico utilizado para definir valor relacionado a `bonusDrible`.
        // `2.5` = valor numérico utilizado para definir valor relacionado a `bonusDrible`.
        // `0` = valor numérico zero utilizado como valor relacionado a `bonusDrible`.
        // `===` = compara dois valores exigindo igualdade de valor e tipo.
        // `==` = compara dois valores verificando igualdade.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `;` = encerra a instrução JavaScript atual.
        const bonusDrible = emDrible ? (dono.dribleTipo === 'arrancada' ? 3.5 : 2.5) : 0;

        // Declara `alcance` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `alcance` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `10` = valor numérico utilizado para definir valor relacionado a `alcance`.
        // `7` = valor numérico utilizado para definir valor relacionado a `alcance`.
        // `2.5` = valor numérico utilizado para definir valor relacionado a `alcance`.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `;` = encerra a instrução JavaScript atual.
        const alcance = 10 + proporcao * 7 + pulso * (2.5 + proporcao * 2.5) + bonusDrible;

        // Declara `lateralNormal` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância do objeto atual.
        // `Math.sin` = calcula o seno do ângulo informado.
        // `Math.min` = retorna o menor valor entre os argumentos informados.
        // `min` = limite mínimo aceito pela operação.
        // `lateralNormal` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `0.53` = valor numérico utilizado para definir valor relacionado a `lateralNormal`.
        // `2.6` = valor numérico utilizado para definir valor relacionado a `lateralNormal`.
        // `0.010` = valor numérico utilizado para definir valor relacionado a `lateralNormal`.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        const lateralNormal = Math.sin(this.toqueConducao * 0.53) * Math.min(2.6, velocidadeDono * 0.010);

        // Declara `lateralDrible` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `lateralDrible` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `'corte'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
        // `'pedalada'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
        // `1` = valor numérico utilizado para definir valor relacionado a `lateralDrible`.
        // `10` = valor numérico utilizado para definir valor relacionado a `lateralDrible`.
        // `7` = valor numérico utilizado para definir valor relacionado a `lateralDrible`.
        // `4.5` = valor numérico utilizado para definir valor relacionado a `lateralDrible`.
        // `0` = valor numérico zero utilizado como valor relacionado a `lateralDrible`.
        // `===` = compara dois valores exigindo igualdade de valor e tipo.
        // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
        // `==` = compara dois valores verificando igualdade.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `;` = encerra a instrução JavaScript atual.
        const lateralDrible = emDrible ? (dono.dribleLado || 1) * (dono.dribleTipo === 'corte' ? 10 : dono.dribleTipo === 'pedalada' ? 7 : 4.5) : 0;

        // Declara `lateral` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `lateral` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        const lateral = lateralNormal + lateralDrible;

        // Declara `px` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `px` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const px = -d.y;

        // Declara `py` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `py` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const py = d.x;

        // Declara `alvoX` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `alvoX` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const alvoX = dono.pos.x + d.x * alcance + px * lateral;

        // Declara `alvoY` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `alvoY` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const alvoY = dono.pos.y + d.y * alcance + py * lateral;

        // Declara `suavizar` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
        // `suavizar` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `19` = valor numérico utilizado para definir valor relacionado a `suavizar`.
        // `3` = valor numérico utilizado para definir valor relacionado a `suavizar`.
        // `0.24` = valor numérico utilizado para definir valor relacionado a `suavizar`.
        // `0.88` = valor numérico utilizado para definir valor relacionado a `suavizar`.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        const suavizar = clamp(dt * (19 - proporcao * 3), 0.24, 0.88);

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        this.pos.x = clamp(

          // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
          // `this` = representa a própria instância do objeto atual.
          // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
          // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
          // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          lerp(this.pos.x, alvoX, suavizar),

          // Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
          // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
          // `CAMPO_ESQUERDA` = coordenada horizontal da borda esquerda do campo.
          // `3` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          CFG.CAMPO_ESQUERDA + 3,

          // Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
          // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
          // `CAMPO_DIREITA` = coordenada horizontal da borda direita do campo.
          // `3` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          CFG.CAMPO_DIREITA - 3

        // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
        // `;` = encerra a instrução JavaScript atual.
        );

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        this.pos.y = clamp(

          // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
          // `this` = representa a própria instância do objeto atual.
          // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
          // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
          // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          lerp(this.pos.y, alvoY, suavizar),

          // Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
          // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
          // `CAMPO_TOPO` = coordenada vertical da borda superior do campo.
          // `3` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          CFG.CAMPO_TOPO + 3,

          // Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
          // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
          // `CAMPO_BASE` = coordenada vertical da borda inferior do campo.
          // `3` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          CFG.CAMPO_BASE - 3

        // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
        // `;` = encerra a instrução JavaScript atual.
        );

        // Declara `dxBola` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância do objeto atual.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `dxBola` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const dxBola = this.pos.x - dono.pos.x;

        // Declara `dyBola` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `this` = representa a própria instância do objeto atual.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `dyBola` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const dyBola = this.pos.y - dono.pos.y;

        // Declara `distanciaBola` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
        // `distanciaBola` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        const distanciaBola = Math.hypot(dxBola, dyBola);

        // Declara `limiteControle` e armazena nele o valor ou resultado calculado nesta linha.
        // `const` = declara uma constante que recebe um valor na própria declaração.
        // `limiteControle` = identificador utilizado para armazenar o valor produzido por esta instrução.
        // `29` = valor numérico utilizado para definir valor relacionado a `limiteControle`.
        // `24` = valor numérico utilizado para definir valor relacionado a `limiteControle`.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        const limiteControle = emDrible ? 29 : 24;

        // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
        // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
        // `>` = verifica se o valor da esquerda é maior que o da direita.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        if (distanciaBola > limiteControle) {

          // Declara `k` e armazena nele o valor ou resultado calculado nesta linha.
          // `const` = declara uma constante que recebe um valor na própria declaração.
          // `Math.max` = retorna o maior valor entre os argumentos informados.
          // `max` = limite máximo aceito pela operação.
          // `k` = identificador utilizado para armazenar o valor produzido por esta instrução.
          // `0.001` = valor numérico utilizado para definir valor relacionado a `k`.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `;` = encerra a instrução JavaScript atual.
          const k = limiteControle / Math.max(0.001, distanciaBola);

          // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
          // `this` = representa a própria instância do objeto atual.
          // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
          // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
          // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
          // `CAMPO_ESQUERDA` = coordenada horizontal da borda esquerda do campo.
          // `CAMPO_DIREITA` = coordenada horizontal da borda direita do campo.
          // `3` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          // `;` = encerra a instrução JavaScript atual.
          this.pos.x = clamp(dono.pos.x + dxBola * k, CFG.CAMPO_ESQUERDA + 3, CFG.CAMPO_DIREITA - 3);

          // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
          // `this` = representa a própria instância do objeto atual.
          // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
          // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
          // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
          // `CAMPO_TOPO` = coordenada vertical da borda superior do campo.
          // `CAMPO_BASE` = coordenada vertical da borda inferior do campo.
          // `3` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
          // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
          // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
          // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
          // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
          // `;` = encerra a instrução JavaScript atual.
          this.pos.y = clamp(dono.pos.y + dyBola * k, CFG.CAMPO_TOPO + 3, CFG.CAMPO_BASE - 3);

        // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
        }

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.altura = 0;

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      }

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.ultimaPosDono = { ...dono.pos };

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x = 0;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y = 0;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.velAltura = 0;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `0.018` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.giro += dt * (2 + Math.hypot(dono.vel.x, dono.vel.y) * 0.018);

      // Encerra a rotina atual e devolve o controle ao ponto que realizou a chamada.
      // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoDesdeChute += dt;

    // Declara `velocidade` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `velocidade` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const velocidade = Math.hypot(this.vel.x, this.vel.y);

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `125` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    if (velocidade > 125) {

      // Declara `forte` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `forte` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `'chute_forte'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `===` = compara dois valores exigindo igualdade de valor e tipo.
      // `==` = compara dois valores verificando igualdade.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const forte = this.tipoJogada === 'chute_forte';

      // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
      // `this` = representa a própria instância do objeto atual.
      // `this.rastro.push` = função ou método chamado nesta linha para executar a operação correspondente.
      // `Math.min` = retorna o menor valor entre os argumentos informados.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `a` = primeiro valor, ponto ou objeto utilizado nesta operação.
      // `min` = limite mínimo aceito pela operação.
      // `1` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `430` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.rastro.push({ x: this.pos.x, y: this.pos.y, a: Math.min(1, velocidade / 430), forte });

      // Declara `maxRastro` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `maxRastro` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `21` = valor numérico utilizado para definir valor relacionado a `maxRastro`.
      // `9` = valor numérico utilizado para definir valor relacionado a `maxRastro`.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const maxRastro = forte ? 21 : 9;

      // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
      // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
      // `this` = representa a própria instância do objeto atual.
      // `this.rastro.shift` = função ou método chamado nesta linha para executar a operação correspondente.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      if (this.rastro.length > maxRastro) this.rastro.shift();

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    } else if (this.rastro.length) {

      // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
      // `this` = representa a própria instância do objeto atual.
      // `this.rastro.shift` = função ou método chamado nesta linha para executar a operação correspondente.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.rastro.shift();

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Math.abs` = retorna o valor absoluto do número informado.
    // `0.01` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `40` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    if (Math.abs(this.curva) > 0.01 && velocidade > 40) {

      // Declara `nx` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `Math.max` = retorna o maior valor entre os argumentos informados.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `max` = limite máximo aceito pela operação.
      // `nx` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `1` = valor numérico utilizado para definir valor relacionado a `nx`.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const nx = -this.vel.y / Math.max(1, velocidade);

      // Declara `ny` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `Math.max` = retorna o maior valor entre os argumentos informados.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `max` = limite máximo aceito pela operação.
      // `ny` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `1` = valor numérico utilizado para definir valor relacionado a `ny`.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const ny = this.vel.x / Math.max(1, velocidade);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x += nx * this.curva * dt;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y += ny * this.curva * dt;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `0.50` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.curva *= Math.pow(0.50, dt);

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos.x += this.vel.x * dt;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos.y += this.vel.y * dt;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `ATRITO_BOLA` = fator de atrito que reduz gradualmente a velocidade da bola.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `60` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x *= Math.pow(CFG.ATRITO_BOLA, dt * 60);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `ATRITO_BOLA` = fator de atrito que reduz gradualmente a velocidade da bola.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `60` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y *= Math.pow(CFG.ATRITO_BOLA, dt * 60);

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Math.abs` = retorna o valor absoluto do número informado.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (Math.abs(this.vel.x) < 2) this.vel.x = 0;

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Math.abs` = retorna o valor absoluto do número informado.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (Math.abs(this.vel.y) < 2) this.vel.y = 0;

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (this.altura > 0 || this.velAltura > 0) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.altura += this.velAltura * dt;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
      // `GRAVIDADE_BOLA` = intensidade da gravidade aplicada à bola quando ela está no ar.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `-=` = subtrai o valor da direita do valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.velAltura -= CFG.GRAVIDADE_BOLA * dt;

      // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
      // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
      // `this` = representa a própria instância do objeto atual.
      // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      if (this.altura <= 0) {

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.altura = 0;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `0.22` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
        // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        this.velAltura *= -0.22;

        // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
        // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
        // `this` = representa a própria instância do objeto atual.
        // `Math.abs` = retorna o valor absoluto do número informado.
        // `5` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
        // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
        // `<` = verifica se o valor da esquerda é menor que o da direita.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        if (Math.abs(this.velAltura) < 5) this.velAltura = 0;

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      }

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `18` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
    // `0` = valor numérico utilizado para definir uma dimensão ou limite espacial nesta linha.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `==` = compara dois valores verificando igualdade.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (velocidade < 18 && this.altura === 0) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.tipoJogada = '';

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `null` = representa ausência intencional de um objeto ou valor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.receptorPlanejado = null;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `null` = representa ausência intencional de um objeto ou valor.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.alvoPlanejado = null;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0.06` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.giro += velocidade * dt * 0.06;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

// Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
}

// Declara a classe `Jogador` que reúne estado e comportamentos usados pelo jogo.
// `class` = declara uma classe utilizada para criar objetos com estado e comportamento próprios.
class Jogador {

  // Define o método construtor responsável por inicializar os dados necessários quando um novo objeto desta classe é criado.
  // `constructor` = método executado automaticamente quando um novo objeto da classe é criado.
  // `false` = valor lógico falso.
  // `time` = lista ou estrutura que representa os jogadores de uma equipe.
  // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
  // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  constructor(nome, time, numero, x, y, posBase, goleiro = false, papel = '') {

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.nome = nome;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `time` = lista ou estrutura que representa os jogadores de uma equipe.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.time = time;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.numero = numero;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos = { x, y };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `0` = valor numérico zero utilizado como coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel = { x: 0, y: 0 };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.posBase = { ...posBase };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.goleiro = goleiro;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.papel = papel || nome;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.controlado = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.temBola = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `time` = lista ou estrutura que representa os jogadores de uma equipe.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `'azul'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `1` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `0` = valor numérico zero utilizado como coordenada vertical ou componente vertical utilizado nesta operação.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `==` = compara dois valores verificando igualdade.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.direcao = { x: time === 'azul' ? 1 : -1, y: 0 };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `FOLEGO_MAX` = quantidade máxima de fôlego disponível.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.folego = CFG.FOLEGO_MAX;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `'POSICIONAR'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.estadoIA = 'POSICIONAR';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoComBola = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownAcao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.animacao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.acaoVisual = '';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoAcao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.mergulho = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.usandoMaos = goleiro;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.marcacao = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoTatico = { ...posBase };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.indiceEquipe = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `1` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimaJogadaVista = -1;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.reacaoGoleiro = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.recebeuDe = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoEvitarDevolver = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.carrinhoTempo = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.carrinhoDuracao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `0` = valor numérico zero utilizado como coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.carrinhoDirecao = { x: 0, y: 0 };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.caidoTempo = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoSemControle = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `'POSICIONAR'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.intencao = 'POSICIONAR';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoIntencao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoIntencao = { ...posBase };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.corpoDirecao = { ...this.direcao };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.velocidadeAtual = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.sprintAtivo = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.amarelos = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.faltasCometidas = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownEntradaIA = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cautelaDisciplinar = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.expulso = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `false` = valor lógico falso.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.saindoExpulso = false;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoSaidaExpulsao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoSaidaExpulsao = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `1` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ladoSaidaExpulsao = 1;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownDrible = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.dribleLado = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.dribleTipo = '';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimoContato = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.protegendoBola = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pivoAtivo = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimaAcaoEspecial = '';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0.62` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoMinimoDecisao = 0.62;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `1.90` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoMaximoPosse = 1.90;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0.50` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.tendenciaDrible = 0.50;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoConducaoIA = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoAlvoConducao = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.relogioDecisaoIA = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimaEscolhaIA = '';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoUltimaEscolhaIA = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimoAlvoPasseIA = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.historicoEscolhasIA = [];

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.compromissoMovimentoIA = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `null` = representa ausência intencional de um objeto ou valor.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoCompromissoIA = null;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoMovimentoSuave = { ...this.pos };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.direcaoMovimentoIA = { ...this.direcao };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.protecaoPosse = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoPosDesarme = 0;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `String` = função ou método chamado nesta linha para executar a operação correspondente.
    // `includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Esquerdo'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `'E'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `'D'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `5` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `0` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `==` = compara dois valores verificando igualdade.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.peDominante = (String(this.papel).includes('Esquerdo') || this.numero % 5 === 0) ? 'E' : 'D';

    // Declara `tonsPele` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `tonsPele` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `'#f2cfad'` = código hexadecimal que representa aproximadamente a cor cor personalizada.
    // `'#e2ae83'` = código hexadecimal que representa aproximadamente a cor cor personalizada.
    // `'#c98962'` = código hexadecimal que representa aproximadamente a cor vermelho.
    // `'#9e6548'` = código hexadecimal que representa aproximadamente a cor vermelho.
    // `'#754632'` = código hexadecimal que representa aproximadamente a cor vermelho escuro.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const tonsPele = ['#f2cfad', '#e2ae83', '#c98962', '#9e6548', '#754632'];

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `time` = lista ou estrutura que representa os jogadores de uma equipe.
    // `'azul'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `1` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `3` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `==` = compara dois valores verificando igualdade.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tomPele = tonsPele[(this.numero + (this.time === 'azul' ? 1 : 3)) % tonsPele.length];

    // Declara `cabelos` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `cabelos` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `'#24150f'` = código hexadecimal que representa aproximadamente a cor vermelho escuro.
    // `'#3a2418'` = código hexadecimal que representa aproximadamente a cor vermelho escuro.
    // `'#101010'` = código hexadecimal que representa aproximadamente a cor preto ou tom quase preto.
    // `'#5a3825'` = código hexadecimal que representa aproximadamente a cor vermelho escuro.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const cabelos = ['#24150f', '#3a2418', '#101010', '#5a3825'];

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `time` = lista ou estrutura que representa os jogadores de uma equipe.
    // `'azul'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `3` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `0` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `1` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `==` = compara dois valores verificando igualdade.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.corCabelo = cabelos[(this.numero * 3 + (this.time === 'azul' ? 0 : 1)) % cabelos.length];

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `this._criarAtributos` = função ou método chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.atributos = this._criarAtributos();

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `_criarAtributos` responsável por executar a lógica correspondente a esta rotina.
  // `_criarAtributos` = função ou método chamado nesta linha para executar a operação correspondente.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  _criarAtributos() {

    // Declara `papel` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `String` = função ou método chamado nesta linha para executar a operação correspondente.
    // `papel` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const papel = String(this.papel || this.nome || '');

    // Declara `base` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `base` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    const base = {

      // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
      // `velocidade` = propriedade configurada nesta estrutura.
      // `72` = valor numérico utilizado para definir valor relacionado a `velocidade`.
      // `68` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
      // `70` = valor numérico utilizado para definir valor relacionado a `drible`.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      velocidade: 72, aceleracao: 72, passe: 72, finalizacao: 68, drible: 70,

      // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
      // `marcacao` = propriedade configurada nesta estrutura.
      // `68` = valor numérico utilizado para definir valor relacionado a `marcacao`.
      // `70` = valor numérico utilizado para definir valor relacionado a `forca`.
      // `50` = valor numérico utilizado para definir valor relacionado a `reflexo`.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      marcacao: 68, desarme: 68, forca: 70, cabecada: 68, visao: 70, reflexo: 50,

      // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
      // `dominio` = propriedade configurada nesta estrutura.
      // `70` = valor numérico utilizado para definir valor relacionado a `dominio`.
      // `76` = valor numérico utilizado para definir valor relacionado a `disciplina`.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      dominio: 70, equilibrio: 70, disciplina: 76

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    // `;` = encerra a instrução JavaScript atual.
    };

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `60` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `66` = valor numérico utilizado para definir valor relacionado a `aceleracao`.
    // `72` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `25` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `55` = valor numérico utilizado para definir valor relacionado a `drible`.
    // `74` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `48` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `78` = valor numérico utilizado para definir valor relacionado a `forca`.
    // `35` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `76` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `86` = valor numérico utilizado para definir valor relacionado a `reflexo`.
    // `80` = valor numérico utilizado para definir valor relacionado a `equilibrio`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (this.goleiro) Object.assign(base, { velocidade: 60, aceleracao: 66, passe: 72, finalizacao: 25, drible: 55, marcacao: 74, desarme: 48, forca: 78, cabecada: 35, visao: 76, reflexo: 86, dominio: 72, equilibrio: 80, disciplina: 86 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Zagueiro'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `'Defensor'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `68` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `69` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `48` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `56` = valor numérico utilizado para definir valor relacionado a `drible`.
    // `84` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `85` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `82` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `65` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `64` = valor numérico utilizado para definir valor relacionado a `dominio`.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Zagueiro') || papel.includes('Defensor')) Object.assign(base, { velocidade: 68, passe: 69, finalizacao: 48, drible: 56, marcacao: 84, desarme: 85, forca: 84, cabecada: 82, visao: 65, dominio: 64, equilibrio: 84, disciplina: 82 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Lateral'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `82` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `75` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `58` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `76` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `74` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `70` = valor numérico utilizado para definir valor relacionado a `forca`.
    // `62` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `73` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `78` = valor numérico utilizado para definir valor relacionado a `disciplina`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Lateral')) Object.assign(base, { velocidade: 82, aceleracao: 82, passe: 75, finalizacao: 58, drible: 75, marcacao: 76, desarme: 74, forca: 70, cabecada: 62, visao: 73, dominio: 76, equilibrio: 74, disciplina: 78 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Ala'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `86` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `85` = valor numérico utilizado para definir valor relacionado a `aceleracao`.
    // `78` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `64` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `80` = valor numérico utilizado para definir valor relacionado a `drible`.
    // `72` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `70` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `69` = valor numérico utilizado para definir valor relacionado a `forca`.
    // `77` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `75` = valor numérico utilizado para definir valor relacionado a `equilibrio`.
    // `76` = valor numérico utilizado para definir valor relacionado a `disciplina`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Ala')) Object.assign(base, { velocidade: 86, aceleracao: 85, passe: 78, finalizacao: 64, drible: 80, marcacao: 72, desarme: 70, forca: 69, cabecada: 64, visao: 77, dominio: 80, equilibrio: 75, disciplina: 76 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Volante'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `72` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `80` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `62` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `82` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `78` = valor numérico utilizado para definir valor relacionado a `forca`.
    // `68` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `84` = valor numérico utilizado para definir valor relacionado a `disciplina`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Volante')) Object.assign(base, { velocidade: 72, passe: 80, finalizacao: 62, drible: 72, marcacao: 82, desarme: 82, forca: 78, cabecada: 68, visao: 82, dominio: 78, equilibrio: 80, disciplina: 84 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Meia'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `76` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `77` = valor numérico utilizado para definir valor relacionado a `aceleracao`.
    // `87` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `75` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `84` = valor numérico utilizado para definir valor relacionado a `drible`.
    // `61` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `58` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `65` = valor numérico utilizado para definir valor relacionado a `forca`.
    // `60` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `89` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `88` = valor numérico utilizado para definir valor relacionado a `dominio`.
    // `80` = valor numérico utilizado para definir valor relacionado a `disciplina`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Meia')) Object.assign(base, { velocidade: 76, aceleracao: 77, passe: 87, finalizacao: 75, drible: 84, marcacao: 61, desarme: 58, forca: 65, cabecada: 60, visao: 89, dominio: 88, equilibrio: 76, disciplina: 80 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Ponta'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `90` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `78` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `88` = valor numérico utilizado para definir valor relacionado a `drible`.
    // `52` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `48` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `62` = valor numérico utilizado para definir valor relacionado a `forca`.
    // `58` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `79` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `75` = valor numérico utilizado para definir valor relacionado a `disciplina`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Ponta')) Object.assign(base, { velocidade: 90, aceleracao: 90, passe: 78, finalizacao: 78, drible: 88, marcacao: 52, desarme: 48, forca: 62, cabecada: 58, visao: 79, dominio: 90, equilibrio: 78, disciplina: 75 });

    // Verifica uma condição alternativa quando a condição anterior não foi atendida.
    // `else` = define o caminho executado quando a condição anterior não for atendida.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `papel.includes` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Object.assign` = função ou método chamado nesta linha para executar a operação correspondente.
    // `'Atacante'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `82` = valor numérico utilizado para definir valor relacionado a `velocidade`.
    // `72` = valor numérico utilizado para definir valor relacionado a `passe`.
    // `89` = valor numérico utilizado para definir valor relacionado a `finalizacao`.
    // `80` = valor numérico utilizado para definir valor relacionado a `drible`.
    // `42` = valor numérico utilizado para definir valor relacionado a `marcacao`.
    // `40` = valor numérico utilizado para definir valor relacionado a `desarme`.
    // `86` = valor numérico utilizado para definir valor relacionado a `cabecada`.
    // `78` = valor numérico utilizado para definir valor relacionado a `visao`.
    // `83` = valor numérico utilizado para definir valor relacionado a `dominio`.
    // `84` = valor numérico utilizado para definir valor relacionado a `equilibrio`.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    else if (papel.includes('Atacante')) Object.assign(base, { velocidade: 82, aceleracao: 82, passe: 72, finalizacao: 89, drible: 80, marcacao: 42, desarme: 40, forca: 80, cabecada: 86, visao: 78, dominio: 83, equilibrio: 84, disciplina: 78 });

    // Declara `variacao` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `variacao` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `17` = valor numérico utilizado para definir valor relacionado a `variacao`.
    // `7` = valor numérico utilizado para definir valor relacionado a `variacao`.
    // `9` = valor numérico utilizado para definir valor relacionado a `variacao`.
    // `4` = valor numérico utilizado para definir valor relacionado a `variacao`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const variacao = ((this.numero * 17 + this.indiceEquipe * 7) % 9) - 4;

    // Percorre os elementos ou repetições definidos nesta linha para executar o bloco correspondente.
    // `for` = inicia uma estrutura de repetição.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `Object.keys` = função ou método chamado nesta linha para executar a operação correspondente.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `35` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `95` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    for (const k of Object.keys(base)) base[k] = clamp(base[k] + variacao, 35, 95);

    // Retorna o valor ou resultado calculado nesta linha para o ponto do programa que chamou a rotina atual.
    // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
    // `;` = encerra a instrução JavaScript atual.
    return base;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `definirIntencao` responsável por executar a lógica correspondente a esta rotina.
  // `definirIntencao` = função ou método chamado nesta linha para executar a operação correspondente.
  // `0.55` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  definirIntencao(nome, alvo, duracao = 0.55) {

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `==` = compara dois valores verificando igualdade.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (this.tempoIntencao > 0 && this.intencao === nome) return;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.intencao = nome;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoIntencao = alvo ? { ...alvo } : { ...this.pos };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoIntencao = duracao;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `moverManual` responsável por executar a lógica correspondente a esta rotina.
  // `moverManual` = função ou método chamado nesta linha para executar a operação correspondente.
  // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  moverManual(dx, dy, dt, sprint) {

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (this.expulso || this.carrinhoTempo > 0 || this.caidoTempo > 0 || this.tempoSemControle > 0) return;

    // Declara `d` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
    // `d` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const d = normalizar(dx, dy);

    // Declara `correndo` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `correndo` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `2` = valor numérico utilizado para definir valor relacionado a `correndo`.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const correndo = sprint && this.folego > 2 && (d.x || d.y);

    // Declara `atributoVel` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `atributoVel` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.88` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `1.12` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `35` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `60` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const atributoVel = lerp(0.88, 1.12, (this.atributos.velocidade - 35) / 60);

    // Declara `fadiga` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `FOLEGO_MAX` = quantidade máxima de fôlego disponível.
    // `fadiga` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.82` = valor numérico utilizado para definir valor relacionado a `fadiga`.
    // `1` = valor numérico utilizado para definir valor relacionado a `fadiga`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const fadiga = lerp(0.82, 1, this.folego / CFG.FOLEGO_MAX);

    // Declara `alvo` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `VELOCIDADE_USUARIO` = velocidade-base do jogador controlado pelo usuário.
    // `MULT_SPRINT` = multiplicador aplicado quando o jogador corre em velocidade máxima.
    // `alvo` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `1` = valor numérico utilizado para definir valor relacionado a `alvo`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const alvo = CFG.VELOCIDADE_USUARIO * atributoVel * fadiga * (correndo ? CFG.MULT_SPRINT : 1);

    // Declara `tx` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `tx` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const tx = d.x * alvo;

    // Declara `ty` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `ty` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const ty = d.y * alvo;

    // Declara `acel` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `ACELERACAO` = intensidade usada para aumentar gradualmente a velocidade dos jogadores.
    // `acel` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.82` = valor numérico utilizado para definir valor relacionado a `acel`.
    // `1.15` = valor numérico utilizado para definir valor relacionado a `acel`.
    // `35` = valor numérico utilizado para definir valor relacionado a `acel`.
    // `60` = valor numérico utilizado para definir valor relacionado a `acel`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const acel = CFG.ACELERACAO * lerp(0.82, 1.15, (this.atributos.aceleracao - 35) / 60);

    // Declara `t` e armazena nele fator de interpolação utilizado para calcular um valor entre dois extremos.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `t` = fator de interpolação utilizado para calcular um valor entre dois extremos.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `max` = limite máximo aceito pela operação.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `VELOCIDADE_USUARIO` = velocidade-base do jogador controlado pelo usuário.
    // `1` = valor numérico utilizado para definir fator de interpolação utilizado para calcular um valor entre dois extremos.
    // `0` = valor numérico zero utilizado como fator de interpolação utilizado para calcular um valor entre dois extremos.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const t = clamp(acel * dt / Math.max(1, CFG.VELOCIDADE_USUARIO), 0, 1);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `t` = fator de interpolação utilizado para calcular um valor entre dois extremos.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x = lerp(this.vel.x, tx, t);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `t` = fator de interpolação utilizado para calcular um valor entre dois extremos.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y = lerp(this.vel.y, ty, t);

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (!d.x && !d.y) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
      // `DESACELERACAO` = fator aplicado para reduzir gradualmente a velocidade.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `60` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x *= Math.pow(CFG.DESACELERACAO, dt * 60);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
      // `DESACELERACAO` = fator aplicado para reduzir gradualmente a velocidade.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `60` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y *= Math.pow(CFG.DESACELERACAO, dt * 60);

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos.x += this.vel.x * dt;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos.y += this.vel.y * dt;

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (d.x || d.y) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.direcao = d;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
      // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `8` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `1` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.corpoDirecao = normalizar(lerp(this.corpoDirecao.x, d.x, clamp(dt * 8, 0, 1)), lerp(this.corpoDirecao.y, d.y, clamp(dt * 8, 0, 1)));

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.sprintAtivo = !!correndo;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.velocidadeAtual = Math.hypot(this.vel.x, this.vel.y);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `GASTO_FOLEGO` = ritmo de consumo do fôlego durante esforço.
    // `RECUP_FOLEGO` = ritmo de recuperação do fôlego.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `FOLEGO_MAX` = quantidade máxima de fôlego disponível.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.folego = clamp(this.folego + (correndo ? -CFG.GASTO_FOLEGO : CFG.RECUP_FOLEGO) * dt, 0, CFG.FOLEGO_MAX);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0.078` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.animacao += this.velocidadeAtual * dt * 0.078;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `moverPara` responsável por executar a lógica correspondente a esta rotina.
  // `moverPara` = função ou método chamado nesta linha para executar a operação correspondente.
  // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
  // `1` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  moverPara(alvo, dt, velocidade, suavidade = 1) {

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    if (this.expulso || this.carrinhoTempo > 0 || this.caidoTempo > 0 || this.tempoSemControle > 0) return;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoTatico = { ...alvo };

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Number.isFinite` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (!this.alvoMovimentoSuave || !Number.isFinite(this.alvoMovimentoSuave.x) || !Number.isFinite(this.alvoMovimentoSuave.y)) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.alvoMovimentoSuave = { ...alvo };

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Declara `distanciaMudancaAlvo` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `dist` = função ou método chamado nesta linha para executar a operação correspondente.
    // `distanciaMudancaAlvo` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const distanciaMudancaAlvo = dist(this.alvoMovimentoSuave, alvo);

    // Declara `velocidadeAtualAntes` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `velocidadeAtualAntes` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const velocidadeAtualAntes = Math.hypot(this.vel.x, this.vel.y);

    // Declara `misturaAlvo` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `misturaAlvo` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `150` = valor numérico utilizado para definir valor relacionado a `misturaAlvo`.
    // `4.2` = valor numérico utilizado para definir valor relacionado a `misturaAlvo`.
    // `70` = valor numérico utilizado para definir valor relacionado a `misturaAlvo`.
    // `5.8` = valor numérico utilizado para definir valor relacionado a `misturaAlvo`.
    // `8.2` = valor numérico utilizado para definir valor relacionado a `misturaAlvo`.
    // `0` = valor numérico zero utilizado como valor relacionado a `misturaAlvo`.
    // `1` = valor numérico utilizado para definir valor relacionado a `misturaAlvo`.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const misturaAlvo = clamp(dt * (distanciaMudancaAlvo > 150 ? 4.2 : distanciaMudancaAlvo > 70 ? 5.8 : 8.2), 0, 1);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoMovimentoSuave.x = lerp(this.alvoMovimentoSuave.x, alvo.x, misturaAlvo);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.alvoMovimentoSuave.y = lerp(this.alvoMovimentoSuave.y, alvo.y, misturaAlvo);

    // Declara `dx` e armazena nele o valor ou resultado calculado nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `dx` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    let dx = this.alvoMovimentoSuave.x - this.pos.x;

    // Declara `dy` e armazena nele o valor ou resultado calculado nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `dy` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    let dy = this.alvoMovimentoSuave.y - this.pos.y;

    // Declara `distancia` e armazena nele o valor ou resultado calculado nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
    // `distancia` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    let distancia = Math.hypot(dx, dy);

    // Declara `desejada` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `desejada` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.001` = valor numérico utilizado para definir valor relacionado a `desejada`.
    // `0` = valor numérico zero utilizado como valor relacionado a `desejada`.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const desejada = distancia > 0.001 ? { x: dx / distancia, y: dy / distancia } : { x: 0, y: 0 };

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Number.isFinite` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (!this.direcaoMovimentoIA || !Number.isFinite(this.direcaoMovimentoIA.x) || !Number.isFinite(this.direcaoMovimentoIA.y)) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.direcaoMovimentoIA = { ...this.corpoDirecao };

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Declara `frenteCorpo` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `frenteCorpo` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const frenteCorpo = this.corpoDirecao.x * desejada.x + this.corpoDirecao.y * desejada.y;

    // Declara `frenteVel` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `frenteVel` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `5` = valor numérico utilizado para definir valor relacionado a `frenteVel`.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    const frenteVel = velocidadeAtualAntes > 5

      // Executa a instrução desta linha como parte da lógica atual do Jogo de Futebol.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      ? (this.vel.x / velocidadeAtualAntes) * desejada.x + (this.vel.y / velocidadeAtualAntes) * desejada.y

      // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
      // `;` = encerra a instrução JavaScript atual.
      : frenteCorpo;

    // Declara `giroNecessario` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `giroNecessario` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `1` = valor numérico utilizado para definir valor relacionado a `giroNecessario`.
    // `0.5` = valor numérico utilizado para definir valor relacionado a `giroNecessario`.
    // `0` = valor numérico zero utilizado como valor relacionado a `giroNecessario`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const giroNecessario = clamp((1 - frenteVel) * 0.5, 0, 1);

    // Declara `taxaDirecao` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `taxaDirecao` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `8.0` = valor numérico utilizado para definir valor relacionado a `taxaDirecao`.
    // `3.2` = valor numérico utilizado para definir valor relacionado a `taxaDirecao`.
    // `0` = valor numérico zero utilizado como valor relacionado a `taxaDirecao`.
    // `1` = valor numérico utilizado para definir valor relacionado a `taxaDirecao`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const taxaDirecao = clamp(dt * lerp(8.0, 3.2, giroNecessario), 0, 1);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    this.direcaoMovimentoIA = normalizar(

      // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
      // `this` = representa a própria instância do objeto atual.
      // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      lerp(this.direcaoMovimentoIA.x, desejada.x, taxaDirecao),

      // Define o método `lerp` responsável por executar a lógica correspondente a esta rotina.
      // `this` = representa a própria instância do objeto atual.
      // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      lerp(this.direcaoMovimentoIA.y, desejada.y, taxaDirecao)

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    // `;` = encerra a instrução JavaScript atual.
    );

    // Declara `fatorChegada` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `fatorChegada` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `5` = valor numérico utilizado para definir valor relacionado a `fatorChegada`.
    // `64` = valor numérico utilizado para definir valor relacionado a `fatorChegada`.
    // `0` = valor numérico zero utilizado como valor relacionado a `fatorChegada`.
    // `1` = valor numérico utilizado para definir valor relacionado a `fatorChegada`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const fatorChegada = clamp((distancia - 5) / 64, 0, 1);

    // Declara `atributoVel` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `atributoVel` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.88` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `1.12` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `35` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `60` = valor numérico utilizado para definir valor relacionado a `atributoVel`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const atributoVel = lerp(0.88, 1.12, (this.atributos.velocidade - 35) / 60);

    // Declara `fadiga` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `FOLEGO_MAX` = quantidade máxima de fôlego disponível.
    // `fadiga` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.80` = valor numérico utilizado para definir valor relacionado a `fadiga`.
    // `1` = valor numérico utilizado para definir valor relacionado a `fadiga`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const fadiga = lerp(0.80, 1, this.folego / CFG.FOLEGO_MAX);

    // Declara `penalidadeGiro` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `penalidadeGiro` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.38` = valor numérico utilizado para definir valor relacionado a `penalidadeGiro`.
    // `1` = valor numérico utilizado para definir valor relacionado a `penalidadeGiro`.
    // `0.5` = valor numérico utilizado para definir valor relacionado a `penalidadeGiro`.
    // `0` = valor numérico zero utilizado como valor relacionado a `penalidadeGiro`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const penalidadeGiro = lerp(0.38, 1, clamp((frenteVel + 1) * 0.5, 0, 1));

    // Declara `alvoV` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `alvoV` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    const alvoV = velocidade * atributoVel * fadiga * fatorChegada * penalidadeGiro;

    // Declara `tx` e armazena nele o valor ou resultado calculado nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `tx` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    let tx = this.direcaoMovimentoIA.x * alvoV;

    // Declara `ty` e armazena nele o valor ou resultado calculado nesta linha.
    // `let` = declara uma variável que pode receber novos valores durante a execução.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `ty` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    let ty = this.direcaoMovimentoIA.y * alvoV;

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `9` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `0` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `;` = encerra a instrução JavaScript atual.
    if (distancia < 9) { tx = 0; ty = 0; }

    // Declara `acelAtributo` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `acelAtributo` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.82` = valor numérico utilizado para definir valor relacionado a `acelAtributo`.
    // `1.18` = valor numérico utilizado para definir valor relacionado a `acelAtributo`.
    // `35` = valor numérico utilizado para definir valor relacionado a `acelAtributo`.
    // `60` = valor numérico utilizado para definir valor relacionado a `acelAtributo`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `;` = encerra a instrução JavaScript atual.
    const acelAtributo = lerp(0.82, 1.18, (this.atributos.aceleracao - 35) / 60);

    // Declara `aceleracao` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `ACELERACAO_IA` = aceleração utilizada pelos jogadores controlados pela IA.
    // `aceleracao` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const aceleracao = CFG.ACELERACAO_IA * acelAtributo * suavidade;

    // Declara `maxDelta` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `maxDelta` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `1` = valor numérico utilizado para definir valor relacionado a `maxDelta`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const maxDelta = Math.max(1, aceleracao * dt);

    // Declara `dvx` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `dvx` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const dvx = clamp(tx - this.vel.x, -maxDelta, maxDelta);

    // Declara `dvy` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `dvy` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const dvy = clamp(ty - this.vel.y, -maxDelta, maxDelta);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x += dvx;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y += dvy;

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `12` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `8` = valor numérico usado como limite ou referência na comparação realizada nesta condição.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    if (distancia < 12 || alvoV < 8) {

      // Declara `freio` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `freio` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `0.66` = valor numérico utilizado para definir valor relacionado a `freio`.
      // `60` = valor numérico utilizado para definir valor relacionado a `freio`.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      const freio = Math.pow(0.66, dt * 60);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x *= freio;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y *= freio;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos.x += this.vel.x * dt;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pos.y += this.vel.y * dt;

    // Declara `velocidadeAtual` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `velocidadeAtual` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const velocidadeAtual = Math.hypot(this.vel.x, this.vel.y);

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `3` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    if (velocidadeAtual > 3) {

      // Declara `mov` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `mov` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const mov = { x: this.vel.x / velocidadeAtual, y: this.vel.y / velocidadeAtual };

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.direcao = mov;

      // Declara `giroCorpo` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `giroCorpo` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `70` = valor numérico utilizado para definir valor relacionado a `giroCorpo`.
      // `6.0` = valor numérico utilizado para definir valor relacionado a `giroCorpo`.
      // `4.2` = valor numérico utilizado para definir valor relacionado a `giroCorpo`.
      // `0` = valor numérico zero utilizado como valor relacionado a `giroCorpo`.
      // `1` = valor numérico utilizado para definir valor relacionado a `giroCorpo`.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      const giroCorpo = clamp(dt * (velocidadeAtual > 70 ? 6.0 : 4.2), 0, 1);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      this.corpoDirecao = normalizar(

        // Executa a função ou método indicado nesta linha utilizando os argumentos informados.
        // `this` = representa a própria instância do objeto atual.
        // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        lerp(this.corpoDirecao.x, mov.x, giroCorpo),

        // Define o método `lerp` responsável por executar a lógica correspondente a esta rotina.
        // `this` = representa a própria instância do objeto atual.
        // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        lerp(this.corpoDirecao.y, mov.y, giroCorpo)

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      // `;` = encerra a instrução JavaScript atual.
      );

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.velocidadeAtual = velocidadeAtual;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `0.94` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `4` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `0.70` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.sprintAtivo = alvoV > velocidade * 0.94 && this.folego > 4 && frenteVel > 0.70;

    // Declara `gasto` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `GASTO_FOLEGO` = ritmo de consumo do fôlego durante esforço.
    // `RECUP_FOLEGO` = ritmo de recuperação do fôlego.
    // `gasto` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `0.48` = valor numérico utilizado para definir valor relacionado a `gasto`.
    // `0.44` = valor numérico utilizado para definir valor relacionado a `gasto`.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    const gasto = this.sprintAtivo ? CFG.GASTO_FOLEGO * 0.48 : -CFG.RECUP_FOLEGO * 0.44;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `FOLEGO_MAX` = quantidade máxima de fôlego disponível.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.folego = clamp(this.folego - gasto * dt, 0, CFG.FOLEGO_MAX);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0.066` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
    // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.animacao += this.velocidadeAtual * dt * 0.066;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `iniciarCarrinho` responsável por executar a lógica correspondente a esta rotina.
  // `iniciarCarrinho` = função ou método chamado nesta linha para executar a operação correspondente.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  iniciarCarrinho(direcao) {

    // Declara `d` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `d` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const d = normalizar(direcao.x, direcao.y);

    // Declara `frentePadrao` e armazena nele o valor ou resultado calculado nesta linha.
    // `const` = declara uma constante que recebe um valor na própria declaração.
    // `this` = representa a própria instância do objeto atual.
    // `time` = lista ou estrutura que representa os jogadores de uma equipe.
    // `frentePadrao` = identificador utilizado para armazenar o valor produzido por esta instrução.
    // `'azul'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `1` = valor numérico utilizado para definir valor relacionado a `frentePadrao`.
    // `===` = compara dois valores exigindo igualdade de valor e tipo.
    // `==` = compara dois valores verificando igualdade.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    const frentePadrao = this.time === 'azul' ? 1 : -1;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `0` = valor numérico zero utilizado como coordenada vertical ou componente vertical utilizado nesta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.carrinhoDirecao = (d.x || d.y) ? d : { x: frentePadrao, y: 0 };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.direcao = { ...this.carrinhoDirecao };

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `TEMPO_CARRINHO` = duração da animação e estado de carrinho.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.carrinhoTempo = CFG.TEMPO_CARRINHO;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `TEMPO_CARRINHO` = duração da animação e estado de carrinho.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.carrinhoDuracao = CFG.TEMPO_CARRINHO;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `'carrinho'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.acaoVisual = 'carrinho';

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `TEMPO_CARRINHO` = duração da animação e estado de carrinho.
    // `0.18` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoAcao = CFG.TEMPO_CARRINHO + 0.18;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `VELOCIDADE_CARRINHO` = velocidade aplicada ao jogador durante o carrinho.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x = this.carrinhoDirecao.x * CFG.VELOCIDADE_CARRINHO;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
    // `VELOCIDADE_CARRINHO` = velocidade aplicada ao jogador durante o carrinho.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y = this.carrinhoDirecao.y * CFG.VELOCIDADE_CARRINHO;

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `atualizarEstadoFisico` responsável por executar a lógica correspondente a esta rotina.
  // `atualizarEstadoFisico` = função ou método chamado nesta linha para executar a operação correspondente.
  // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  atualizarEstadoFisico(dt) {

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.caidoTempo = Math.max(0, this.caidoTempo - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoIntencao = Math.max(0, this.tempoIntencao - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.ultimoContato = Math.max(0, this.ultimoContato - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoSemControle = Math.max(0, this.tempoSemControle - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownDrible = Math.max(0, (this.cooldownDrible || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cooldownEntradaIA = Math.max(0, (this.cooldownEntradaIA || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.cautelaDisciplinar = Math.max(0, (this.cautelaDisciplinar || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.protegendoBola = Math.max(0, (this.protegendoBola || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.pivoAtivo = Math.max(0, (this.pivoAtivo || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoAlvoConducao = Math.max(0, (this.tempoAlvoConducao || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoUltimaEscolhaIA = Math.max(0, (this.tempoUltimaEscolhaIA || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.compromissoMovimentoIA = Math.max(0, (this.compromissoMovimentoIA || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.protecaoPosse = Math.max(0, (this.protecaoPosse || 0) - dt);

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `Math.max` = retorna o maior valor entre os argumentos informados.
    // `max` = limite máximo aceito pela operação.
    // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    // `;` = encerra a instrução JavaScript atual.
    this.tempoPosDesarme = Math.max(0, (this.tempoPosDesarme || 0) - dt);

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `&&` = operador lógico E, que exige que as condições relacionadas sejam verdadeiras.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (this.expulso && this.saindoExpulso && this.alvoSaidaExpulsao) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.max` = retorna o maior valor entre os argumentos informados.
      // `max` = limite máximo aceito pela operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.tempoSaidaExpulsao = Math.max(0, (this.tempoSaidaExpulsao || 0) - dt);

      // Declara `d` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `d` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const d = normalizar(this.alvoSaidaExpulsao.x - this.pos.x, this.alvoSaidaExpulsao.y - this.pos.y);

      // Declara `distancia` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `dist` = função ou método chamado nesta linha para executar a operação correspondente.
      // `distancia` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const distancia = dist(this.pos, this.alvoSaidaExpulsao);

      // Declara `velocidade` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `velocidade` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `34` = valor numérico utilizado para definir valor relacionado a `velocidade`.
      // `82` = valor numérico utilizado para definir valor relacionado a `velocidade`.
      // `48` = valor numérico utilizado para definir valor relacionado a `velocidade`.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      const velocidade = distancia > 34 ? 82 : 48;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `5.2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `1` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x = lerp(this.vel.x, d.x * velocidade, clamp(dt * 5.2, 0, 1));

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `5.2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `1` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y = lerp(this.vel.y, d.y * velocidade, clamp(dt * 5.2, 0, 1));

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.pos.x += this.vel.x * dt;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.pos.y += this.vel.y * dt;

      // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
      // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      if (d.x || d.y) {

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.direcao = d;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `normalizar` = função ou método chamado nesta linha para executar a operação correspondente.
        // `lerp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `clamp` = função ou método chamado nesta linha para executar a operação correspondente.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `4.2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `1` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        this.corpoDirecao = normalizar(lerp(this.corpoDirecao.x, d.x, clamp(dt * 4.2, 0, 1)), lerp(this.corpoDirecao.y, d.y, clamp(dt * 4.2, 0, 1)));

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      }

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.velocidadeAtual = Math.hypot(this.vel.x, this.vel.y);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `0.055` = valor numérico utilizado no cálculo de velocidade, força ou aceleração desta ação.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `;` = encerra a instrução JavaScript atual.
      this.animacao += this.velocidadeAtual * dt * 0.055;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `'chorando'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.acaoVisual = 'chorando';

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.max` = retorna o maior valor entre os argumentos informados.
      // `max` = limite máximo aceito pela operação.
      // `0.25` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.tempoAcao = Math.max(this.tempoAcao, 0.25);

      // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
      // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
      // `this` = representa a própria instância do objeto atual.
      // `15` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `<=` = verifica se o valor da esquerda é menor ou igual ao da direita.
      // `||` = operador lógico OU, que aceita quando pelo menos uma das condições é verdadeira.
      // `<` = verifica se o valor da esquerda é menor que o da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      if (distancia < 15 || this.tempoSaidaExpulsao <= 0) {

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `false` = valor lógico falso.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.saindoExpulso = false;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `500` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.pos.x = -500;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `500` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.pos.y = -500;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.vel.x = 0;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
        // `;` = encerra a instrução JavaScript atual.
        this.vel.y = 0;

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      }

      // Encerra a rotina atual e devolve o controle ao ponto que realizou a chamada.
      // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (this.carrinhoTempo > 0) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.max` = retorna o maior valor entre os argumentos informados.
      // `max` = limite máximo aceito pela operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.carrinhoTempo = Math.max(0, this.carrinhoTempo - dt);

      // Declara `progresso` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `this` = representa a própria instância do objeto atual.
      // `progresso` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `0` = valor numérico zero utilizado como valor relacionado a `progresso`.
      // `>` = verifica se o valor da esquerda é maior que o da direita.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      const progresso = this.carrinhoDuracao > 0 ? this.carrinhoTempo / this.carrinhoDuracao : 0;

      // Declara `velocidade` e armazena nele o valor ou resultado calculado nesta linha.
      // `const` = declara uma constante que recebe um valor na própria declaração.
      // `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
      // `VELOCIDADE_CARRINHO` = velocidade aplicada ao jogador durante o carrinho.
      // `velocidade` = identificador utilizado para armazenar o valor produzido por esta instrução.
      // `0.48` = valor numérico utilizado para definir valor relacionado a `velocidade`.
      // `0.52` = valor numérico utilizado para definir valor relacionado a `velocidade`.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `;` = encerra a instrução JavaScript atual.
      const velocidade = CFG.VELOCIDADE_CARRINHO * (0.48 + progresso * 0.52);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x = this.carrinhoDirecao.x * velocidade;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y = this.carrinhoDirecao.y * velocidade;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.pos.x += this.vel.x * dt;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.pos.y += this.vel.y * dt;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `9` = valor numérico utilizado no cálculo, configuração, índice ou condição desta linha.
      // `+=` = soma o valor da direita ao valor atual da esquerda e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.animacao += dt * 9;

      // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
      // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
      // `this` = representa a própria instância do objeto atual.
      // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
      // `===` = compara dois valores exigindo igualdade de valor e tipo.
      // `==` = compara dois valores verificando igualdade.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      if (this.carrinhoTempo === 0) {

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
        // `0.28` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        this.vel.x *= 0.28;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
        // `0.28` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
        // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `;` = encerra a instrução JavaScript atual.
        this.vel.y *= 0.28;

        // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
        // `this` = representa a própria instância do objeto atual.
        // `Math.max` = retorna o maior valor entre os argumentos informados.
        // `max` = limite máximo aceito pela operação.
        // `0.16` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
        // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
        // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
        // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
        // `;` = encerra a instrução JavaScript atual.
        this.tempoSemControle = Math.max(this.tempoSemControle, 0.16);

      // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
      }

      // Encerra a rotina atual e devolve o controle ao ponto que realizou a chamada.
      // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
      // `;` = encerra a instrução JavaScript atual.
      return;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

    // Define o método `if` responsável por executar a lógica correspondente a esta rotina.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `0` = valor numérico utilizado na duração, intervalo ou controle de tempo desta operação.
    // `>` = verifica se o valor da esquerda é maior que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (this.caidoTempo > 0) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `0.30` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `60` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x *= Math.pow(0.30, dt * 60);

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `Math.pow` = função ou método chamado nesta linha para executar a operação correspondente.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `dt` = tempo decorrido desde o último quadro, usado para manter movimentos independentes da taxa de quadros.
      // `0.30` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `60` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
      // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y *= Math.pow(0.30, dt * 60);

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

  // Define o método `parar` responsável por executar a lógica correspondente a esta rotina.
  // `parar` = função ou método chamado nesta linha para executar a operação correspondente.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  parar() {

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `0.35` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.x *= 0.35;

    // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
    // `this` = representa a própria instância do objeto atual.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `0.35` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `*=` = multiplica o valor atual pelo valor informado e armazena o resultado.
    // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
    // `;` = encerra a instrução JavaScript atual.
    this.vel.y *= 0.35;

    // Verifica a condição desta linha e executa o bloco associado somente quando o resultado for verdadeiro.
    // `if` = inicia uma condição executada somente quando a expressão indicada for verdadeira.
    // `this` = representa a própria instância do objeto atual.
    // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
    // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
    // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
    // `2` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
    // `<` = verifica se o valor da esquerda é menor que o da direita.
    // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
    if (Math.hypot(this.vel.x, this.vel.y) < 2) {

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.x = 0;

      // Atualiza um atributo do objeto atual com o valor ou resultado definido nesta linha.
      // `this` = representa a própria instância do objeto atual.
      // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
      // `0` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
      // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
      // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
      // `;` = encerra a instrução JavaScript atual.
      this.vel.y = 0;

    // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
    }

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

// Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
}
