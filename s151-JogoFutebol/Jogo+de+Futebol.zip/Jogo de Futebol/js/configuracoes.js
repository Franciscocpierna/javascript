// Ativa o modo estrito do JavaScript para aplicar regras mais rigorosas durante a execução deste arquivo.
// `'use strict'` = texto literal utilizado como valor, identificador, mensagem ou opção nesta instrução.
// `;` = encerra a instrução JavaScript atual.
'use strict';

// Declara `CFG` e armazena nele objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
const CFG = {

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `LARGURA` = largura lógica da área de jogo em pixels.
  // `1180` = valor numérico utilizado para definir largura lógica da área de jogo em pixels.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  LARGURA: 1180,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `ALTURA` = altura lógica da área de jogo em pixels.
  // `760` = valor numérico utilizado para definir altura lógica da área de jogo em pixels.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  ALTURA: 760,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `FPS` = quantidade de quadros por segundo usada como referência.
  // `60` = valor numérico utilizado para definir quantidade de quadros por segundo usada como referência.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  FPS: 60,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CAMPO_ESQUERDA` = coordenada horizontal da borda esquerda do campo.
  // `48` = valor numérico utilizado para definir coordenada horizontal da borda esquerda do campo.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  CAMPO_ESQUERDA: 48,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CAMPO_DIREITA` = coordenada horizontal da borda direita do campo.
  // `1132` = valor numérico utilizado para definir coordenada horizontal da borda direita do campo.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  CAMPO_DIREITA: 1132,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CAMPO_TOPO` = coordenada vertical da borda superior do campo.
  // `88` = valor numérico utilizado para definir coordenada vertical da borda superior do campo.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  CAMPO_TOPO: 88,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CAMPO_BASE` = coordenada vertical da borda inferior do campo.
  // `672` = valor numérico utilizado para definir coordenada vertical da borda inferior do campo.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  CAMPO_BASE: 672,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `GOL_TOPO` = coordenada vertical do início da abertura do gol.
  // `278` = valor numérico utilizado para definir coordenada vertical do início da abertura do gol.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  GOL_TOPO: 278,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `GOL_BASE` = coordenada vertical do fim da abertura do gol.
  // `482` = valor numérico utilizado para definir coordenada vertical do fim da abertura do gol.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  GOL_BASE: 482,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `GOL_PROFUNDIDADE` = profundidade visual e física da área do gol.
  // `34` = valor numérico utilizado para definir profundidade visual e física da área do gol.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  GOL_PROFUNDIDADE: 34,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `AREA_PROFUNDIDADE` = profundidade da grande área a partir da linha de gol.
  // `178` = valor numérico utilizado para definir profundidade da grande área a partir da linha de gol.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  AREA_PROFUNDIDADE: 178,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `AREA_MEIA_ALTURA` = metade da altura vertical da grande área.
  // `125` = valor numérico utilizado para definir metade da altura vertical da grande área.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  AREA_MEIA_ALTURA: 125,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `MARCA_PENALTI` = distância da marca do pênalti em relação à linha de gol.
  // `105` = valor numérico utilizado para definir distância da marca do pênalti em relação à linha de gol.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  MARCA_PENALTI: 105,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VELOCIDADE_USUARIO` = velocidade-base do jogador controlado pelo usuário.
  // `158` = valor numérico utilizado para definir velocidade-base do jogador controlado pelo usuário.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VELOCIDADE_USUARIO: 158,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VELOCIDADE_IA` = velocidades-base usadas pelos jogadores controlados pela inteligência artificial.
  // `118` = valor numérico utilizado para definir valor relacionado a `facil`.
  // `136` = valor numérico utilizado para definir valor relacionado a `normal`.
  // `153` = valor numérico utilizado para definir valor relacionado a `dificil`.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VELOCIDADE_IA: { facil: 118, normal: 136, dificil: 153 },

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `ACELERACAO` = intensidade usada para aumentar gradualmente a velocidade dos jogadores.
  // `520` = valor numérico utilizado para definir intensidade usada para aumentar gradualmente a velocidade dos jogadores.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  ACELERACAO: 520,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `MULT_SPRINT` = multiplicador aplicado quando o jogador corre em velocidade máxima.
  // `1.24` = valor numérico utilizado para definir multiplicador aplicado quando o jogador corre em velocidade máxima.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  MULT_SPRINT: 1.24,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `FOLEGO_MAX` = quantidade máxima de fôlego disponível.
  // `100` = valor numérico utilizado para definir quantidade máxima de fôlego disponível.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  FOLEGO_MAX: 100,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `GASTO_FOLEGO` = ritmo de consumo do fôlego durante esforço.
  // `23` = valor numérico utilizado para definir ritmo de consumo do fôlego durante esforço.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  GASTO_FOLEGO: 23,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `RECUP_FOLEGO` = ritmo de recuperação do fôlego.
  // `16` = valor numérico utilizado para definir ritmo de recuperação do fôlego.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  RECUP_FOLEGO: 16,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `ACELERACAO_IA` = aceleração utilizada pelos jogadores controlados pela IA.
  // `430` = valor numérico utilizado para definir aceleração utilizada pelos jogadores controlados pela IA.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  ACELERACAO_IA: 430,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `DESACELERACAO` = fator aplicado para reduzir gradualmente a velocidade.
  // `0.80` = valor numérico utilizado para definir fator aplicado para reduzir gradualmente a velocidade.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  DESACELERACAO: 0.80,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_DECISAO_TATICA` = intervalo de tempo entre decisões táticas de curto prazo da IA.
  // `0.34` = valor numérico utilizado para definir intervalo de tempo entre decisões táticas de curto prazo da IA.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_DECISAO_TATICA: 0.34,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_DECISAO_ESTRATEGICA` = intervalo entre decisões estratégicas mais amplas da IA.
  // `1.05` = valor numérico utilizado para definir intervalo entre decisões estratégicas mais amplas da IA.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_DECISAO_ESTRATEGICA: 1.05,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_VANTAGEM` = tempo em que a vantagem pode ser mantida antes da interrupção.
  // `1.75` = valor numérico utilizado para definir tempo em que a vantagem pode ser mantida antes da interrupção.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_VANTAGEM: 1.75,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `RAIO_JOGADOR` = raio físico utilizado para colisão e proximidade dos jogadores.
  // `15` = valor numérico utilizado para definir raio físico utilizado para colisão e proximidade dos jogadores.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  RAIO_JOGADOR: 15,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `RAIO_BOLA` = raio físico utilizado para representar a bola.
  // `8` = valor numérico utilizado para definir raio físico utilizado para representar a bola.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  RAIO_BOLA: 8,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `DIST_DOMINIO` = distância máxima usada para considerar domínio da bola.
  // `27` = valor numérico utilizado para definir distância máxima usada para considerar domínio da bola.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  DIST_DOMINIO: 27,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `DIST_ROUBO` = distância utilizada nas tentativas de desarme.
  // `38` = valor numérico utilizado para definir distância utilizada nas tentativas de desarme.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  DIST_ROUBO: 38,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `DIST_SEPARACAO` = distância usada para evitar que jogadores fiquem sobrepostos.
  // `48` = valor numérico utilizado para definir distância usada para evitar que jogadores fiquem sobrepostos.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  DIST_SEPARACAO: 48,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VEL_PASSE` = velocidade-base dos passes rasteiros.
  // `196` = valor numérico utilizado para definir velocidade-base dos passes rasteiros.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VEL_PASSE: 196,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VEL_PROFUNDIDADE` = velocidade-base dos passes em profundidade.
  // `258` = valor numérico utilizado para definir velocidade-base dos passes em profundidade.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VEL_PROFUNDIDADE: 258,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VEL_CRUZAMENTO` = velocidade-base dos cruzamentos.
  // `270` = valor numérico utilizado para definir velocidade-base dos cruzamentos.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VEL_CRUZAMENTO: 270,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VEL_CHUTE` = velocidade-base do chute normal.
  // `438` = valor numérico utilizado para definir velocidade-base do chute normal.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VEL_CHUTE: 438,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VEL_CHUTE_FORTE` = velocidade-base do chute forte.
  // `635` = valor numérico utilizado para definir velocidade-base do chute forte.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VEL_CHUTE_FORTE: 635,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VEL_CHUTE_MAX` = limite máximo permitido para a velocidade dos chutes.
  // `700` = valor numérico utilizado para definir limite máximo permitido para a velocidade dos chutes.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VEL_CHUTE_MAX: 700,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `ATRITO_BOLA` = fator de atrito que reduz gradualmente a velocidade da bola.
  // `0.992` = valor numérico utilizado para definir fator de atrito que reduz gradualmente a velocidade da bola.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  ATRITO_BOLA: 0.992,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `GRAVIDADE_BOLA` = intensidade da gravidade aplicada à bola quando ela está no ar.
  // `96` = valor numérico utilizado para definir intensidade da gravidade aplicada à bola quando ela está no ar.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  GRAVIDADE_BOLA: 96,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `RAIO_INTERCEPTACAO` = raio utilizado pela lógica de interceptação de passes.
  // `25` = valor numérico utilizado para definir raio utilizado pela lógica de interceptação de passes.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  RAIO_INTERCEPTACAO: 25,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `LIMITE_DOMINIO_RAPIDO` = limite de velocidade considerado pela lógica de domínio rápido.
  // `255` = valor numérico utilizado para definir limite de velocidade considerado pela lógica de domínio rápido.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  LIMITE_DOMINIO_RAPIDO: 255,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `COOLDOWN_DESARME` = tempo mínimo entre tentativas consecutivas de desarme.
  // `0.58` = valor numérico utilizado para definir tempo mínimo entre tentativas consecutivas de desarme.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  COOLDOWN_DESARME: 0.58,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `ALCANCE_DESARME` = alcance espacial de uma tentativa de desarme.
  // `47` = valor numérico utilizado para definir alcance espacial de uma tentativa de desarme.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  ALCANCE_DESARME: 47,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CHANCE_FALTA` = probabilidade-base de uma tentativa de desarme resultar em falta.
  // `0.30` = valor numérico utilizado para definir probabilidade-base de uma tentativa de desarme resultar em falta.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  CHANCE_FALTA: 0.30,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `COOLDOWN_CARRINHO` = tempo mínimo entre carrinhos consecutivos.
  // `1.05` = valor numérico utilizado para definir tempo mínimo entre carrinhos consecutivos.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  COOLDOWN_CARRINHO: 1.05,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_CARRINHO` = duração da animação e estado de carrinho.
  // `0.48` = valor numérico utilizado para definir duração da animação e estado de carrinho.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_CARRINHO: 0.48,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `VELOCIDADE_CARRINHO` = velocidade aplicada ao jogador durante o carrinho.
  // `285` = valor numérico utilizado para definir velocidade aplicada ao jogador durante o carrinho.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  VELOCIDADE_CARRINHO: 285,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `ALCANCE_CARRINHO` = alcance físico considerado pelo carrinho.
  // `64` = valor numérico utilizado para definir alcance físico considerado pelo carrinho.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  ALCANCE_CARRINHO: 64,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CHANCE_FALTA_CARRINHO` = probabilidade-base de o carrinho resultar em falta.
  // `0.42` = valor numérico utilizado para definir probabilidade-base de o carrinho resultar em falta.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  CHANCE_FALTA_CARRINHO: 0.42,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `DISTANCIA_BARREIRA` = distância utilizada para posicionar a barreira em cobranças de falta.
  // `88` = valor numérico utilizado para definir distância utilizada para posicionar a barreira em cobranças de falta.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  DISTANCIA_BARREIRA: 88,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_PREPARO_FALTA` = tempo reservado para organizar a cobrança de falta.
  // `3.0` = valor numérico utilizado para definir tempo reservado para organizar a cobrança de falta.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_PREPARO_FALTA: 3.0,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_COBRANCA_HUMANO` = tempo máximo disponibilizado ao jogador humano para executar a cobrança.
  // `7.0` = valor numérico utilizado para definir tempo máximo disponibilizado ao jogador humano para executar a cobrança.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_COBRANCA_HUMANO: 7.0,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_GOLEIRO_COM_BOLA` = tempo-base que o goleiro mantém a bola antes da reposição.
  // `1.55` = valor numérico utilizado para definir tempo-base que o goleiro mantém a bola antes da reposição.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_GOLEIRO_COM_BOLA: 1.55,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_MAX_GOLEIRO_MAOS` = limite interno de tempo para o goleiro permanecer com a bola nas mãos.
  // `4.60` = valor numérico utilizado para definir limite interno de tempo para o goleiro permanecer com a bola nas mãos.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_MAX_GOLEIRO_MAOS: 4.60,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `DISTANCIA_SEGURANCA_GOLEIRO` = distância de segurança usada ao escolher uma reposição do goleiro.
  // `118` = valor numérico utilizado para definir distância de segurança usada ao escolher uma reposição do goleiro.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  DISTANCIA_SEGURANCA_GOLEIRO: 118,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `TEMPO_CAUTELA_AMARELO` = período em que a IA joga com maior cautela após cartão amarelo.
  // `5.5` = valor numérico utilizado para definir período em que a IA joga com maior cautela após cartão amarelo.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  TEMPO_CAUTELA_AMARELO: 5.5,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `COOLDOWN_ENTRADA_IA` = intervalo mínimo entre tentativas de entrada da IA.
  // `0.78` = valor numérico utilizado para definir intervalo mínimo entre tentativas de entrada da IA.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  COOLDOWN_ENTRADA_IA: 0.78,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `MIN_JOGADORES_5X5` = quantidade mínima de jogadores ativos necessária no modo 5 contra 5.
  // `3` = valor numérico utilizado para definir quantidade mínima de jogadores ativos necessária no modo 5 contra 5.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  MIN_JOGADORES_5X5: 3,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `MIN_JOGADORES_11X11` = quantidade mínima de jogadores ativos necessária no modo 11 contra 11.
  // `7` = valor numérico utilizado para definir quantidade mínima de jogadores ativos necessária no modo 11 contra 11.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  MIN_JOGADORES_11X11: 7,

  // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
  // `CORES` = propriedade configurada nesta estrutura.
  CORES: {

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `fundo` = propriedade configurada nesta estrutura.
    // `'#0e1d2c'` = código hexadecimal que representa aproximadamente a cor azul petróleo escuro.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    fundo: '#0e1d2c',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `campo` = propriedade configurada nesta estrutura.
    // `'#31894a'` = código hexadecimal que representa aproximadamente a cor verde campo.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    campo: '#31894a',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `faixa` = propriedade configurada nesta estrutura.
    // `'#3a9452'` = código hexadecimal que representa aproximadamente a cor verde médio.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    faixa: '#3a9452',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `campoEscuro` = propriedade configurada nesta estrutura.
    // `'#246d3a'` = código hexadecimal que representa aproximadamente a cor verde floresta.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    campoEscuro: '#246d3a',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `branco` = propriedade configurada nesta estrutura.
    // `'#f5f5f5'` = código hexadecimal que representa aproximadamente a cor branco fumaça.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    branco: '#f5f5f5',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `preto` = propriedade configurada nesta estrutura.
    // `'#141414'` = código hexadecimal que representa aproximadamente a cor preto suave.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    preto: '#141414',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `azul` = propriedade configurada nesta estrutura.
    // `'#235fcd'` = código hexadecimal que representa aproximadamente a cor azul royal.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    azul: '#235fcd',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `azulEscuro` = propriedade configurada nesta estrutura.
    // `'#123682'` = código hexadecimal que representa aproximadamente a cor azul-marinho.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    azulEscuro: '#123682',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `vermelho` = propriedade configurada nesta estrutura.
    // `'#d33a3a'` = código hexadecimal que representa aproximadamente a cor vermelho.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    vermelho: '#d33a3a',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `vermelhoEscuro` = propriedade configurada nesta estrutura.
    // `'#841e1e'` = código hexadecimal que representa aproximadamente a cor vermelho escuro.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    vermelhoEscuro: '#841e1e',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `amarelo` = propriedade configurada nesta estrutura.
    // `'#f2d23c'` = código hexadecimal que representa aproximadamente a cor amarelo dourado.
    // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
    amarelo: '#f2d23c',

    // Define ou configura uma propriedade da estrutura iniciada nas linhas anteriores.
    // `pele` = propriedade configurada nesta estrutura.
    // `'#ecc7a7'` = código hexadecimal que representa aproximadamente a cor bege pele.
    pele: '#ecc7a7'

  // Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
  }

// Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
// `;` = encerra a instrução JavaScript atual.
};

// Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
// `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `CAMPO_DIREITA` = coordenada horizontal da borda direita do campo.
// `CAMPO_ESQUERDA` = coordenada horizontal da borda esquerda do campo.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
CFG.CAMPO_LARGURA = CFG.CAMPO_DIREITA - CFG.CAMPO_ESQUERDA;

// Armazena ou atualiza um valor no identificador ou propriedade indicado no lado esquerdo desta linha.
// `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `CAMPO_BASE` = coordenada vertical da borda inferior do campo.
// `CAMPO_TOPO` = coordenada vertical da borda superior do campo.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
CFG.CAMPO_ALTURA = CFG.CAMPO_BASE - CFG.CAMPO_TOPO;

// Executa a função ou método indicado nesta linha utilizando os argumentos informados.
// `Object.freeze` = impede mudanças posteriores nas propriedades diretas do objeto informado.
// `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
Object.freeze(CFG.CORES);

// Executa a função ou método indicado nesta linha utilizando os argumentos informados.
// `Object.freeze` = impede mudanças posteriores nas propriedades diretas do objeto informado.
// `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `VELOCIDADE_IA` = velocidades-base usadas pelos jogadores controlados pela inteligência artificial.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
Object.freeze(CFG.VELOCIDADE_IA);

// Executa a função ou método indicado nesta linha utilizando os argumentos informados.
// `Object.freeze` = impede mudanças posteriores nas propriedades diretas do objeto informado.
// `CFG` = objeto central que reúne as configurações e constantes utilizadas pelo jogo.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
Object.freeze(CFG);

// Declara `clamp` e armazena nele o valor ou resultado calculado nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `Math.max` = retorna o maior valor entre os argumentos informados.
// `Math.min` = retorna o menor valor entre os argumentos informados.
// `min` = limite mínimo aceito pela operação.
// `max` = limite máximo aceito pela operação.
// `clamp` = identificador utilizado para armazenar o valor produzido por esta instrução.
// `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
// `>` = verifica se o valor da esquerda é maior que o da direita.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

// Declara `dist` e armazena nele o valor ou resultado calculado nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
// `a` = primeiro valor, ponto ou objeto utilizado nesta operação.
// `b` = segundo valor, ponto ou objeto utilizado nesta operação.
// `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
// `y` = coordenada vertical ou componente vertical utilizado nesta operação.
// `dist` = identificador utilizado para armazenar o valor produzido por esta instrução.
// `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
// `>` = verifica se o valor da esquerda é maior que o da direita.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

// Declara `normalizar` e armazena nele o valor ou resultado calculado nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
// `y` = coordenada vertical ou componente vertical utilizado nesta operação.
// `normalizar` = identificador utilizado para armazenar o valor produzido por esta instrução.
// `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
// `>` = verifica se o valor da esquerda é maior que o da direita.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
const normalizar = (x, y) => {

  // Declara `m` e armazena nele o valor ou resultado calculado nesta linha.
  // `const` = declara uma constante que recebe um valor na própria declaração.
  // `Math.hypot` = calcula a distância euclidiana a partir dos componentes informados.
  // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
  // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
  // `m` = identificador utilizado para armazenar o valor produzido por esta instrução.
  // `=` = atribui ou associa o valor da direita ao elemento da esquerda.
  // `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
  // `;` = encerra a instrução JavaScript atual.
  const m = Math.hypot(x, y);

  // Retorna o valor ou resultado calculado nesta linha para o ponto do programa que chamou a rotina atual.
  // `return` = encerra a rotina atual e devolve o valor especificado ao ponto que realizou a chamada.
  // `x` = coordenada horizontal ou componente horizontal utilizado nesta operação.
  // `y` = coordenada vertical ou componente vertical utilizado nesta operação.
  // `0.0001` = valor numérico utilizado como coordenada, distância ou limite espacial nesta operação.
  // `0` = valor numérico zero utilizado como coordenada horizontal ou componente horizontal utilizado nesta operação.
  // `>` = verifica se o valor da esquerda é maior que o da direita.
  // `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
  // `;` = encerra a instrução JavaScript atual.
  return m > 0.0001 ? { x: x / m, y: y / m } : { x: 0, y: 0 };

// Encerra a estrutura, bloco, lista, objeto ou chamada iniciada nas linhas anteriores.
// `;` = encerra a instrução JavaScript atual.
};

// Declara `lerp` e armazena nele o valor ou resultado calculado nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `a` = primeiro valor, ponto ou objeto utilizado nesta operação.
// `b` = segundo valor, ponto ou objeto utilizado nesta operação.
// `t` = fator de interpolação utilizado para calcular um valor entre dois extremos.
// `lerp` = identificador utilizado para armazenar o valor produzido por esta instrução.
// `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
// `>` = verifica se o valor da esquerda é maior que o da direita.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
// `;` = encerra a instrução JavaScript atual.
const lerp = (a, b, t) => a + (b - a) * t;

// Declara `randomEntre` e armazena nele o valor ou resultado calculado nesta linha.
// `const` = declara uma constante que recebe um valor na própria declaração.
// `Math.random` = gera um número pseudoaleatório entre 0 e 1.
// `a` = primeiro valor, ponto ou objeto utilizado nesta operação.
// `b` = segundo valor, ponto ou objeto utilizado nesta operação.
// `randomEntre` = identificador utilizado para armazenar o valor produzido por esta instrução.
// `=>` = define uma função de seta, forma compacta de declarar uma função JavaScript.
// `>` = verifica se o valor da esquerda é maior que o da direita.
// `=` = atribui ou associa o valor da direita ao elemento da esquerda.
// `(` e `)` = delimitam argumentos, parâmetros, condições ou agrupamentos utilizados nesta instrução.
// `,` = separa argumentos, parâmetros, propriedades ou elementos presentes nesta linha.
// `.` = acessa uma propriedade, método ou recurso pertencente ao objeto indicado antes do ponto.
// `;` = encerra a instrução JavaScript atual.
const randomEntre = (a, b) => a + Math.random() * (b - a);
