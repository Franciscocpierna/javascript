# Jogo de Futebol

Jogo de futebol que roda diretamente no navegador, com controles por teclado, inteligência artificial dos dois times, goleiros, regras de reposição e organização tática.

## Como executar

1. Extraia o arquivo ZIP.
2. Abra `index.html` no Chrome, Edge ou Firefox.
3. Clique em **JOGAR CONTRA A IA** ou **ASSISTIR IA x IA**.

Não é necessário instalar Python, Node.js ou servidor web.

## Modos e opções

- Jogador x IA.
- IA x IA.
- Dificuldade Fácil, Normal e Difícil.
- Formato 5 x 5 ou 11 x 11.
- No 11 x 11, formação independente para cada equipe: 4-3-3, 4-4-2, 4-2-3-1, 4-5-1, 3-5-2, 5-3-2, 5-4-1 ou 3-4-3.
- Partidas de 3 ou 5 minutos.


## Visual da partida

A partida utiliza apresentação em formato 16:9 e câmera 2.5D inclinada. O campo é projetado em perspectiva sem alterar as coordenadas usadas pela física, de modo que regras, passes, colisões, goleiros e inteligência artificial continuam funcionando normalmente.

O estádio possui arquibancada, público, corredores laterais, publicidade, área técnica, traves com profundidade e rede, gramado com cortes em faixas e variações horizontais. Jogadores, árbitro, bola e assistentes mudam de escala conforme a profundidade do campo, reforçando a sensação de distância da câmera. O HUD foi deslocado para as bordas, deixando uma área maior para acompanhar a partida.

## Controles

- WASD ou Setas: movimentação.
- SHIFT: sprint.
- E ou Z: passe.
- C: passe em profundidade.
- B ou N: cruzamento alto.
- SHIFT + B ou N: cruzamento rasteiro.
- Espaço: chute normal.
- SHIFT + Espaço: chute colocado.
- X: chute forte, mais rápido e com maior risco de erro.
- L: cavadinha para tentar encobrir o goleiro adiantado.
- K: drible contextual: corte, pedalada, arrancada ou caneta.
- H: proteger a bola e fazer pivô enquanto espera apoio.
- T ou F: desarme em pé.
- V: carrinho. Pode resultar em desarme limpo, falta ou pênalti.
- Q: trocar jogador.
- U: fazer uma substituição, retirando um jogador cansado no modo Jogador x IA.
- P: pausar.
- R: reiniciar.
- I: mostrar ou ocultar o painel da IA.
- M: ativar ou desativar som.
- ESC: voltar ao menu.

## Bolas paradas

Nas faltas o jogo é paralisado para organizar os jogadores. Quando a falta estiver em distância adequada para chute direto, o time defensor monta uma barreira e o goleiro se posiciona antes da cobrança.

Quando o time Azul tiver uma falta, pênalti ou escanteio, há tempo para preparar a jogada. Nas faltas e pênaltis, use as setas para cima e para baixo para alterar a direção da mira. Nos escanteios, o cobrador fica do lado de fora das linhas e um companheiro se aproxima por dentro do campo para receber a cobrança curta.

Laterais, escanteios, tiros de meta, saídas de bola, faltas, pênaltis e impedimentos são tratados pelo jogo. Desvios de defensores e algumas defesas espalmadas do goleiro também podem gerar escanteios naturalmente.

## Comportamento dos jogadores

Os jogadores utilizam posicionamento por função. Defensores mantêm cobertura, meias oferecem linhas de passe, pontas preservam a largura do campo e atacantes atacam os espaços próximos à área.

A IA limita a quantidade de jogadores pressionando a bola para evitar aglomeração. Os demais jogadores mantêm posições de apoio, marcação e cobertura.

Os passes consideram o movimento do companheiro, o tempo de domínio e a pressão. A bola em passes comuns viaja em velocidade mais moderada, enquanto passes em profundidade continuam mais firmes para encontrar jogadores em movimento. A IA segura a posse por mais tempo antes de soltar a bola, evitando trocas instantâneas e deixando a circulação mais natural.

Bolas altas possuem disputa aérea real entre atacante e defensor. O resultado considera distância até a bola, cabeceio, força, aceleração e marcação. Em cruzamentos, atacantes fortes no jogo aéreo procuram primeiro e segundo pau e podem finalizar de cabeça nos cantos; defensores tentam ganhar a disputa e afastar a bola.

## Goleiros

Os goleiros usam as mãos dentro da própria área para segurar chutes e bolas perigosas. Depois da defesa, mantêm a posse por um pequeno intervalo e procuram uma opção de reposição.

Chutes mais fortes ou difíceis podem ser espalmados. O chute forte viaja com velocidade bem maior, reduz o tempo de reação do goleiro e deixa rebotes e defesas para escanteio mais prováveis. Reposições do próprio goleiro não são tratadas como novas defesas imediatamente após a bola ser lançada.

## Estrutura

- `index.html`: página principal.
- `css/estilo.css`: layout responsivo e controles de toque.
- `js/configuracoes.js`: medidas, velocidades e configurações gerais.
- `js/entidades.js`: classes da bola e dos jogadores.
- `js/ia.js`: comportamento tático, ofensivo, defensivo e dos goleiros.
- `js/jogo.js`: regras, física, placar, bolas paradas, impedimento, câmera e desenho no Canvas.
- `js/app.js`: teclado, mouse, toque e inicialização.
- `sons/`: efeitos sonoros do jogo.


## Times disponíveis

O menu permite escolher Santos, Flamengo, Palmeiras ou Cruzeiro para cada lado da partida. Os nomes identificam as equipes e não utilizam escudos oficiais. Cada equipe também possui um perfil tático próprio de posse, largura, pressão e contra-ataque.

## Comportamento da IA

A IA analisa linhas de passe, risco de interceptação, movimentação sem bola, impedimento em cobranças de falta e diferentes alvos de finalização. Os goleiros possuem tempo de reação, fazem saídas da área, seguram bolas com as mãos quando permitido, espalma chutes mais fortes e escolhem opções de reposição.

## Disputas e finalizações

A partida possui desarme em pé e carrinho como ações diferentes. O carrinho tem deslocamento próprio, animação no gramado e avaliação de contato: entradas bem executadas podem afastar a bola, enquanto entradas atrasadas ou por trás aumentam a chance de falta e pênalti. A IA também utiliza carrinhos em situações de pressão e emergência defensiva.

Finalizações normais, colocadas e fortes possuem velocidades, precisão e comportamento diferentes. O chute forte, acionado pela tecla X, possui preparação corporal maior, velocidade bem superior, som próprio, rastro visual mais intenso, impacto de câmera e maior dificuldade para o goleiro segurar a bola. Defensores podem bloquear chutes e desviar a trajetória, criando rebotes e escanteios.


## Inteligência coletiva e comportamento de partida

Os dois times trabalham com um plano tático coletivo que muda conforme posse, região do campo, placar e tempo restante. A equipe diferencia construção, progressão, ataque posicional, contra-ataque, transição defensiva, bloco baixo e pressão alta. Jogadores mantêm linhas, basculam com a bola, cobrem companheiros, fecham linhas de passe e ocupam zonas diferentes da área.

A movimentação ofensiva inclui ultrapassagem de lateral, entrada do ponta por dentro, triângulos de apoio, corridas em profundidade, ocupação de primeiro pau, segundo pau, centro da área e rebote, inversões de jogo, passes de primeira, passe para trás na linha de fundo e cruzamentos rasteiros. O goleiro atua também como goleiro-líbero em bolas nas costas da defesa.

Jogadores possuem atributos por função, cansaço influencia velocidade e aceleração, mudanças bruscas de direção exigem giro corporal e a condução da bola possui toques visuais em vez de permanecer rigidamente presa ao jogador.

A arbitragem considera a geometria de desarmes e carrinhos, aplica vantagem quando a equipe atacada continua em boa situação e pode mostrar cartão amarelo, segundo amarelo ou vermelho. Entradas por trás, velocidade do contato e situação de último defensor aumentam a gravidade.

Passes podem ser interceptados ativamente. O goleiro defende principalmente por alcance, posicionamento, reação e dificuldade física do chute. A bola pode atingir as traves e o travessão e retornar ao campo. O jogo também mostra árbitro e assistentes de linha; os assistentes acompanham a linha defensiva e levantam a bandeira em impedimentos.

## Substituições e desgaste

Em partidas 11 x 11, a IA administra substituições conforme o desgaste e o momento da partida. No modo Jogador x IA, a tecla U permite substituir um jogador cansado do seu time. O jogador que entra chega com fôlego renovado e mantém a função tática da posição.

## Gols e comemoração

Quando acontece um gol, a partida pausa temporariamente para a comemoração. O autor corre em direção ao canto do campo, companheiros se aproximam e levantam os braços, a câmera acompanha o grupo e a mensagem de gol permanece visível antes da nova saída de bola.

## Som

O áudio é liberado na primeira interação do usuário para respeitar as regras dos navegadores. Há torcida ambiente, sons de passe, chute normal, chute forte, defesa, desarme, apito, contato, cartão, trave, rede e reação de gol. No gol, o jogo tenta reproduzir um grito humano real de “GOOOOOL” e mantém a torcida elevada durante a comemoração. A tecla M continua ativando ou desativando todo o áudio.


## Dribles

Com a bola dominada, a tecla K executa um drible contextual. Dependendo da posição do marcador e dos atributos do jogador, podem acontecer corte lateral, pedalada, arrancada ou caneta. O sucesso considera principalmente o atributo de drible do atacante, velocidade, distância do marcador e capacidade de desarme do defensor. A IA também utiliza dribles em situações de um contra um, principalmente com pontas, alas e meias no terço ofensivo.

## Expulsões

O jogador expulso deixa de participar da jogada imediatamente, mas não desaparece do campo. Ele abaixa a postura, leva as mãos ao rosto, aparece com lágrimas e caminha em direção à lateral até sair do gramado. Caso fosse o jogador controlado, o controle passa para outro companheiro automaticamente.

## Áudio do grito de gol

O projeto usa como fonte principal um grito humano real de gol hospedado no Wikimedia Commons: **Goal Shout.ogg**, criado por **Frogfriend99**, licenciado sob **Creative Commons Attribution-ShareAlike 3.0 (CC BY-SA 3.0)**. Fonte: https://commons.wikimedia.org/wiki/File:Goal_Shout.ogg . O arquivo é reproduzido diretamente da fonte original quando houver conexão com a internet. Se a reprodução externa não estiver disponível, o jogo utiliza a voz em português instalada no sistema operacional por meio da API de síntese de voz do navegador, mantendo um grito falado em vez do antigo ruído sintetizado.

## Bolas paradas avançadas

Os escanteios são organizados como jogadas específicas. A bola é colocada no canto, o cobrador permanece do lado de fora das linhas e um companheiro da própria equipe se aproxima pelo lado de dentro do campo. A cobrança padrão da IA é um passe curto e rasteiro para esse companheiro, escolhido considerando passe, drible, visão, espaço e distância. Os demais jogadores ocupam primeiro pau, centro, segundo pau, entrada da área e zona de rebote para dar continuidade à jogada e impedir contra-ataques. No modo Jogador x IA, durante um escanteio, **E/Z** ou **B/N** executam a cobrança curta para o companheiro preparado.

Faltas próximas do gol podem ser cobradas colocadas ou fortes e fazem a barreira saltar. Faltas laterais e mais distantes podem ser levantadas para a área, gerando disputa aérea, corte, rebote, cabeçada ou voleio. O jogo também seleciona cobradores mais adequados: finalizadores para pênaltis e faltas diretas, e jogadores com melhor passe/visão para escanteios.

Nos pênaltis, a IA varia entre cobrança colocada, forte e, raramente, cavadinha. O goleiro tenta antecipar a direção conforme seus reflexos, mas pode escolher o lado errado. No modo Jogador x IA, durante o pênalti use **Espaço** para colocado, **X** para forte e **L** para cavadinha.

## Proteção de bola e pivô

A tecla **H** protege a bola. O jogador usa o corpo para dificultar o desarme e esperar a aproximação de um companheiro. Atacantes fortes também utilizam esse comportamento automaticamente: podem receber de costas, proteger a posse e escorar para um meia que chega de frente, criando jogadas de pivô.

## Contra-ataques e mudanças táticas

A IA identifica superioridade numérica em transições, incluindo situações semelhantes a 2 x 1 e 3 x 2. Nessas jogadas, o portador pode conduzir para atrair um defensor antes de soltar o passe, enquanto os companheiros atacam corredores diferentes.

Em partidas 11 x 11, a IA também adapta formação e comportamento ao placar. Quando precisa buscar o resultado, pode avançar para 4-2-3-1, 4-3-3 ou 3-4-3 e aumentar a pressão. Quando está vencendo perto do fim, pode migrar para 4-5-1 ou 5-4-1 para proteger espaços e administrar a partida. A tática utilizada aparece junto das formações no HUD.

## Cabeçadas, voleios e goleiro em cruzamentos

As cabeçadas ofensivas possuem variações: forte, colocada e para baixo. Defensores continuam podendo cortar de cabeça. Bolas cruzadas ou rebatidas em altura adequada também podem gerar voleios, cuja chance depende principalmente da posição e da finalização do jogador.

O goleiro analisa cruzamentos normais, faltas levantadas e escanteios. Ele considera distância até o ponto de queda, reflexos e quantidade de jogadores na região para decidir entre permanecer na linha, sair com as mãos ou tentar afastar uma bola congestionada.

## Replay e câmera dinâmica

O jogo guarda os segundos anteriores ao gol e, após a comemoração, apresenta um replay curto da jogada antes da nova saída de bola. A câmera também muda de comportamento conforme a situação: abre mais em contra-ataques, aproxima em faltas, escanteios e pênaltis e acompanha a comemoração do autor do gol.

As comemorações possuem variações, incluindo corrida ao canto, braços abertos, comemoração em grupo e comemoração de joelhos. O tipo é escolhido a cada gol para evitar que todas as comemorações sejam idênticas.

## Disciplina e continuidade da partida

A arbitragem diferencia desarme em pé de carrinho e considera timing, direção da entrada, velocidade relativa, contato por trás, chance clara de gol e histórico de faltas do jogador. Desarmes corretos tendem a resultar em recuperação limpa, enquanto cartões ficam concentrados em entradas realmente graves ou reincidentes.

Jogadores advertidos passam a atuar com maior cautela e a IA reduz bastante o uso de carrinhos por quem já possui cartão amarelo. Em partidas 11 x 11, um jogador amarelado e reincidente também pode ser priorizado em uma substituição tática.

O número mínimo de jogadores é respeitado. No 5 x 5, a partida não continua com menos de três jogadores em uma equipe; no 11 x 11, não continua com menos de sete. Quando esse limite é atingido, o jogo encerra a partida em vez de deixar somente o goleiro em campo.

O goleiro possui um limite de segurança para permanecer com a bola nas mãos. Se nenhuma opção de passe for escolhida dentro desse intervalo, ele procura um companheiro livre ou realiza uma reposição longa, impedindo que a partida fique presa com a bola nas mãos do goleiro.

## Movimento corporal e aparência dos jogadores

Os jogadores são desenhados com proporções corporais mais detalhadas, incluindo cabeça, pescoço, tronco, ombros, braços com cotovelos, pernas com joelhos, meias e chuteiras. Há pequenas variações visuais de pele e cabelo entre os jogadores.

A corrida utiliza passada proporcional à velocidade. As pernas alternam apoio e avanço, os braços trabalham no sentido oposto às pernas e o corpo inclina mais durante o sprint. Passe, cruzamento, lançamento, chute e chute forte movimentam a perna de execução de forma diferente. Cabeçadas utilizam elevação do corpo e abertura dos braços, enquanto proteção de bola, domínio, drible, defesa com os pés do goleiro, carrinho, queda e saída após expulsão possuem posturas próprias.

A movimentação continua utilizando aceleração, desaceleração, giro corporal, fôlego e velocidade individual. Jogadores não mudam instantaneamente de direção em velocidade máxima, o que reduz a sensação de deslizamento pelo campo.

## Domínio e contato físico

O domínio da bola considera velocidade do passe, pressão adversária e atributos técnicos. Passes mais fortes recebidos sob pressão podem escapar alguns metros do jogador, criando disputa por segunda bola em vez de posse automática.

No contato corpo a corpo, força, equilíbrio e proteção de bola influenciam quanto cada jogador é deslocado. Centroavantes fortes conseguem sustentar melhor o pivô, enquanto jogadores menores e rápidos dependem mais de aceleração e drible para escapar da marcação.
